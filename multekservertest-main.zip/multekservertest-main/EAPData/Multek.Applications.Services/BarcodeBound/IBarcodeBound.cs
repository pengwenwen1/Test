﻿using Multek.Applications.Model.Entities.EAP.Dto;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesBase;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.EAP
{
    [DescriptionForService("IBarcodeBound服务")]
    public interface IBarcodeBound
    {

        /// <summary>
        /// 条码检查
        /// </summary>
        [DescriptionForEvent("BarcodeInspection条码检查")]
        public IResultModel BarcodeInspection(string barcode);

        /// <summary>
        /// 条码上传接口
        /// </summary>
        /// <param name="barcodeBoundPackageBaseDto"></param>
        /// <returns></returns>
        [DescriptionForEvent("UploadBarcode条码上传接口")]
        public IResultModel UploadBarcode(BarcodeBoundPackageDto barcodeBoundPackageBaseDto);

        /// <summary>
        /// 获取整包条码接口
        /// </summary>
        /// <returns></returns>
        public IResultModel GetPackageBarcode(string barcode);

        /// <summary>
        /// 拆包解绑接口
        /// </summary>
        /// <returns></returns>
        public IResultModel UnpackAndUnbind(BarcodeDto barcodeDto);
    }
}
