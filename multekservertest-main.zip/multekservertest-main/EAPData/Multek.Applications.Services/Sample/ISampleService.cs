﻿
using Multek.Library_Core.ResultModel;

namespace Multek.Applications.Services.Sample
{
    public interface ISampleService
    {
        public IResultModel GetResultModel();
    }
}
