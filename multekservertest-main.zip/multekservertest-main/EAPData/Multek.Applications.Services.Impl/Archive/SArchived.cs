﻿using Autofac.Extras.DynamicProxy;
using Microsoft.EntityFrameworkCore;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.Entities.EAP;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.AOP;
using Multek.Library_Core.Quest.QuestEntity;
using Multek.Library_Core.Quest.QuestInterface;
using Multek.Library_Core.Services.AOP;
using Multek.Library_Core.ServicesInface;

namespace Multek.Applications.Services.Impl.Archive
{
    [Intercept(typeof(DistributedLockInterceptor))]
    public class SArchived : IArchived
    {
        private readonly MultekServerDbContext _multekServerDbContext;
        private readonly MultekArchiveDbContext _multekArchiveDbContext;
        private readonly MultekRestoreDbContext _multekRestoreDbContext;
        public ISubscriptionEmail _subscriptionEmail;
        public SArchived(MultekServerDbContext multekServerDbContext, MultekArchiveDbContext multekArchiveDbContext, MultekRestoreDbContext multekRestoreDbContext, ISubscriptionEmail subscriptionEmail)
        {
            _multekServerDbContext = multekServerDbContext;
            _multekArchiveDbContext = multekArchiveDbContext;
            _multekRestoreDbContext = multekRestoreDbContext;
            _subscriptionEmail = subscriptionEmail;
        }

        #region 数据归档
        /// <summary>
        /// 数据归档
        /// </summary>
        //此IP地址已运行，再次运行需等24小时
        [DistributedLock(60 * 60 * 24, null, true)]
        public void Archive()
        {
            string packNo = "8a1f748bad5c42a6b84e13ec73713818";

            //根据条码查询包号
            List<BarcodeBoundPackage> _barcode = _multekServerDbContext.barcodeBoundPackages.Where(x => x.pkgNo == packNo).AsNoTracking().ToList();
            if (_barcode.Count > 0)
            {
                using (var transaction = _multekServerDbContext.Database.BeginTransaction())
                {
                    try
                    {
                        _multekServerDbContext.RemoveRange(_barcode);
                        _multekServerDbContext.SaveChanges();
                        _multekArchiveDbContext.barcodeBoundPackages.AddRange(_barcode);
                        _multekArchiveDbContext.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        if (AdvException.NeedFeedback(ex))
                        {
                            _subscriptionEmail.AddSubscriptionEmail(new SubscriptionEmailEntity() { OccurDate = DateTime.Now, Subject = string.Format("@CU.NET(I) Exception Message[数据处理异常] [{0}]", IPAddressHelper.GetHostAddressByEnvironment()), Body = AdvException.GetExceptionMessage(ex) });
                        }
                    }
                }
            }
        }
        #endregion

        #region 数据还原
        /// <summary>
        /// 数据还原
        /// </summary>
        public void Restore()
        {
            string packNo = "8a1f748bad5c42a6b84e13ec73713818";
            //根据条码查询包号
            List<BarcodeBoundPackage> _barcode = _multekArchiveDbContext.barcodeBoundPackages.Where(x => x.pkgNo == packNo).AsNoTracking().ToList();
            if (_barcode != null)
            {
                using (var transaction = _multekArchiveDbContext.Database.BeginTransaction())
                {
                    try
                    {
                        _multekArchiveDbContext.RemoveRange(_barcode);
                        _multekArchiveDbContext.SaveChanges();
                        _multekRestoreDbContext.barcodeBoundPackages.AddRange(_barcode);
                        _multekRestoreDbContext.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        if (AdvException.NeedFeedback(ex))
                        {
                            _subscriptionEmail.AddSubscriptionEmail(new SubscriptionEmailEntity() { OccurDate = DateTime.Now, Subject = string.Format("@CU.NET(I) Exception Message[数据处理异常] [{0}]", IPAddressHelper.GetHostAddressByEnvironment()), Body = AdvException.GetExceptionMessage(ex) });
                        }
                    }
                }
            }
        }
        #endregion
    }
}
