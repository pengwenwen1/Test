﻿using AutoMapper;
using Microsoft.CodeAnalysis.FlowAnalysis;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.Entities;
using Multek.Applications.Model.Entities.EAP;
using Multek.Applications.Model.Entities.EAP.Dto;
using Multek.Applications.Model.Entities.Enum;
using Multek.Applications.Services.EAP;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.EAP
{
    public class SBarcodeBound : EFHelper<MultekServerDbContext>, IBarcodeBound
    {

        public MultekTracebilityDbContext _dbContext;
        public IMapper _mapper;

        public SBarcodeBound(MultekServerDbContext tdb, MultekTracebilityDbContext dbContext, IMapper mapper) : base(tdb)
        {
            _dbContext = dbContext;
            _mapper = mapper;
        }


        /// <summary>
        /// 条码检查
        /// </summary>
        public IResultModel BarcodeInspection(string barcode)
        {
            CodeTree _codeTree = _dbContext.codeTrees.FirstOrDefault(x => x.Code == barcode && (x.CodeType == CodeTypeEnum.Set || x.CodeType == CodeTypeEnum.Pcs));
            
            if (_codeTree == null)
            {
                return new ResultModel<string>().Failed($"无{barcode}码");
            }
            else if (_codeTree.CodeType == CodeTypeEnum.Set || _codeTree.CodeType == CodeTypeEnum.Pcs)
            {
                return new ResultModel<string>().Success("OK");
            }
            return new ResultModel<string>().Failed($"{barcode}码错误，请输入正确的！");

        }

        /// <summary>
        /// 条码上传接口
        /// </summary>
        /// <param name="barcodeBoundPackageDto"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel UploadBarcode(BarcodeBoundPackageDto barcodeBoundPackageDto)
        {
            //查询BarcodeBoundPackage是否存在相同包号
            BarcodeBoundPackage _IsPackage = db.barcodeBoundPackages.FirstOrDefault(x => x.pkgNo == barcodeBoundPackageDto.pkgNo);
            //不存在相同包号
            if (_IsPackage == null)
            {
                List<BarcodeBoundPackage> _AddBarcodeBoundPackage = new List<BarcodeBoundPackage>();
                foreach (var item in barcodeBoundPackageDto.barcodeList)
                {
                    //查询BarcodeBoundPackage是否存在相同条码
                    BarcodeBoundPackage _IsBarcode = db.barcodeBoundPackages.FirstOrDefault(x => x.barcode == item);
                    //存在相同条码
                    if (_IsBarcode != null)
                    {
                        return new ResultModel<string>().Failed($"{item}条码已存在！");
                    }
                    BarcodeBoundPackage _barcode = _mapper.Map<BarcodeBoundPackage>(barcodeBoundPackageDto);
                    _barcode.barcode = item.ToString();
                    _AddBarcodeBoundPackage.Add(_barcode);
                }
                db.barcodeBoundPackages.AddRangeAsync(_AddBarcodeBoundPackage);
                try
                {
                    if (db.SaveChanges() <= 0)
                    {
                        return new ResultModel<string>().Failed($"数据存储到BarcodeBoundPackage表失败，请重试！");
                    }
                }
                catch (Exception)
                {
                    //AddRangeAsync插入数据主键重复抛异常
                    return new ResultModel<string>().Failed($"BarcodeBoundPackage有重复数据，请重试！");
                }
                return new ResultModel<string>().Success("OK");
            }
            return new ResultModel<string>().Failed($"{barcodeBoundPackageDto.pkgNo}包号已存在！");
        }

        /// <summary>
        /// 获取整包条码接口
        /// </summary>
        /// <param name="barcode"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel GetPackageBarcode(string barcode)
        {
            //根据条码查询包号
            BarcodeBoundPackage _barcode = db.barcodeBoundPackages.FirstOrDefault(x => x.barcode == barcode);
            if (_barcode != null)
            {
                //根据包号查询整包条码信息
                List<BarcodeBoundPackage> _barcodesList = db.barcodeBoundPackages.Where(x => x.pkgNo == _barcode.pkgNo).ToList();
                List<BarcodeBoundPackageRsp> _barcodeBoundPackageRsps = _mapper.Map<List<BarcodeBoundPackageRsp>>(_barcodesList);
                return new ResultModel<List<BarcodeBoundPackageRsp>>().Success(_barcodeBoundPackageRsps);
            }
            return new ResultModel<string>().Failed($"{barcode}条码不存在，请重试！");
        }

        /// <summary>
        /// 拆包解绑接口
        /// </summary>
        /// <param name="barcodeDto"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel UnpackAndUnbind(BarcodeDto barcodeDto)
        {
            //根据条码查询包号
            BarcodeBoundPackage _barcode = db.barcodeBoundPackages.FirstOrDefault(x => x.barcode == barcodeDto.barcode);
            if (_barcode != null)
            {
                //根据包号查询整包条码信息
                List<BarcodeBoundPackage> _barcodesList = db.barcodeBoundPackages.Where(x => x.pkgNo == _barcode.pkgNo).ToList();
                db.unBarcodeBoundPackages.AddRange(_mapper.Map<List<UnBarcodeBoundPackage>>(_barcodesList));
                db.barcodeBoundPackages.RemoveRange(_barcodesList);
                if (db.SaveChanges() > 0)
                {
                    return new ResultModel<string>().Success("OK");
                }
                return new ResultModel<string>().Failed($"操作数据库出现异常，请重试！");
            }
            return new ResultModel<string>().Failed($"{barcodeDto.barcode}条码不存在，请重试！");
        }
    }
}
