﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class p7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Services",
                newName: "ServicesName");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ServicesName",
                table: "Services",
                newName: "Name");
        }
    }
}
