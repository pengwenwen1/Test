﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class p10 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "WAPServerConfigID",
                table: "WAP_ServerswaggerURL",
                type: "NUMBER(19)",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "WAPServicesID",
                table: "WAP_Fields",
                type: "NUMBER(19)",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "WAPServicesID",
                table: "WAP_Events",
                type: "NUMBER(19)",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "WAPEventID",
                table: "WAP_EventParament",
                type: "NUMBER(19)",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "WAPServerConfigID",
                table: "WAP_ServerswaggerURL",
                type: "NUMBER(19)",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)");

            migrationBuilder.AlterColumn<long>(
                name: "WAPServicesID",
                table: "WAP_Fields",
                type: "NUMBER(19)",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)");

            migrationBuilder.AlterColumn<long>(
                name: "WAPServicesID",
                table: "WAP_Events",
                type: "NUMBER(19)",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)");

            migrationBuilder.AlterColumn<long>(
                name: "WAPEventID",
                table: "WAP_EventParament",
                type: "NUMBER(19)",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "NUMBER(19)");
        }
    }
}
