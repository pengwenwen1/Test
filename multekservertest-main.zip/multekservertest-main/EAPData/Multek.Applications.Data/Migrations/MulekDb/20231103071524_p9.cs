﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class p9 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SwaggerURL",
                table: "WAP_ServerConfig");

            migrationBuilder.CreateTable(
                name: "WAP_ServerswaggerURL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    ServerIp = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Port = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    SwaggerURL = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    WAPServerConfigID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WAP_ServerswaggerURL", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_WAP_ServerswaggerURL_WAPServerConfigID",
                table: "WAP_ServerswaggerURL",
                column: "WAPServerConfigID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "WAP_ServerswaggerURL");

            migrationBuilder.AddColumn<string>(
                name: "SwaggerURL",
                table: "WAP_ServerConfig",
                type: "NVARCHAR2(2000)",
                nullable: true);
        }
    }
}
