﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class p3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "OperationType",
                table: "Events",
                type: "NVARCHAR2(2000)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OperationType",
                table: "Events");
        }
    }
}
