﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class V2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CodeTree");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CodeTree",
                columns: table => new
                {
                    Code = table.Column<string>(type: "NVARCHAR2(450)", nullable: false),
                    CodeType = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    Lot = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Material = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    Parent = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    PlainCode = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CodeTree", x => x.Code);
                });
        }
    }
}
