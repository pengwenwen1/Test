﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class p1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Events",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Path = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Events", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Fields",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Type = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    IsNull = table.Column<bool>(type: "NUMBER(1)", nullable: false),
                    IsList = table.Column<bool>(type: "NUMBER(1)", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fields", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "ServerConfig",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServerConfig", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "EventParaments",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Type = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Name = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    EventID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventParaments", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Services",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    ServicesType = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    ServerConfigID = table.Column<long>(type: "NUMBER(19)", nullable: false),
                    EventsID = table.Column<long>(type: "NUMBER(19)", nullable: false),
                    Type = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    FieldsID = table.Column<long>(type: "NUMBER(19)", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Services", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EventParaments_EventID",
                table: "EventParaments",
                column: "EventID");

            migrationBuilder.CreateIndex(
                name: "IX_Events_Name",
                table: "Events",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Fields_Name",
                table: "Fields",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ServerConfig_Name",
                table: "ServerConfig",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Services_EventsID",
                table: "Services",
                column: "EventsID");

            migrationBuilder.CreateIndex(
                name: "IX_Services_FieldsID",
                table: "Services",
                column: "FieldsID");

            migrationBuilder.CreateIndex(
                name: "IX_Services_Name",
                table: "Services",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Services_ServerConfigID",
                table: "Services",
                column: "ServerConfigID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EventParaments");

            migrationBuilder.DropTable(
                name: "Services");

            migrationBuilder.DropTable(
                name: "Events");

            migrationBuilder.DropTable(
                name: "Fields");

            migrationBuilder.DropTable(
                name: "ServerConfig");
        }
    }
}
