﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class MultekInit : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BarcodeBoundPackage",
                columns: table => new
                {
                    barcode = table.Column<string>(type: "NVARCHAR2(200)", maxLength: 200, nullable: false, comment: "条码（SET码/PCS码）"),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID"),
                    pkgNo = table.Column<string>(type: "NVARCHAR2(200)", maxLength: 200, nullable: false, comment: "包号"),
                    project = table.Column<string>(type: "NVARCHAR2(20)", maxLength: 20, nullable: false, comment: "型号"),
                    dateCode = table.Column<int>(type: "NUMBER(10)", nullable: false, comment: "周期")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BarcodeBoundPackage", x => x.barcode);
                });

            migrationBuilder.CreateTable(
                name: "DataStore",
                columns: table => new
                {
                    DataStoreId = table.Column<long>(type: "NUMBER(19)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    GUID = table.Column<byte[]>(type: "RAW(2000)", nullable: false),
                    TxnType = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    SqlStmt = table.Column<string>(type: "clob", nullable: true),
                    Params = table.Column<string>(type: "clob", nullable: true),
                    RecordDate = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DataStore", x => x.DataStoreId);
                });

            migrationBuilder.CreateTable(
                name: "SYS_EntityType",
                columns: table => new
                {
                    Id = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    TableName = table.Column<string>(type: "NVARCHAR2(30)", maxLength: 30, nullable: false),
                    SerialNumber = table.Column<long>(type: "NUMBER(19)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SYS_EntityType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UnBarcodeBoundPackage",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    barcode = table.Column<string>(type: "NVARCHAR2(200)", maxLength: 200, nullable: false, comment: "条码（SET码/PCS码）"),
                    pkgNo = table.Column<string>(type: "NVARCHAR2(200)", maxLength: 200, nullable: false, comment: "包号"),
                    project = table.Column<string>(type: "NVARCHAR2(20)", maxLength: 20, nullable: false, comment: "型号"),
                    dateCode = table.Column<int>(type: "NUMBER(10)", nullable: false, comment: "周期")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UnBarcodeBoundPackage", x => x.ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BarcodeBoundPackage");

            migrationBuilder.DropTable(
                name: "DataStore");

            migrationBuilder.DropTable(
                name: "SYS_EntityType");

            migrationBuilder.DropTable(
                name: "UnBarcodeBoundPackage");
        }
    }
}
