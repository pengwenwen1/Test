﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class p2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Services_EventsID",
                table: "Services");

            migrationBuilder.DropIndex(
                name: "IX_Services_FieldsID",
                table: "Services");

            migrationBuilder.DropColumn(
                name: "EventsID",
                table: "Services");

            migrationBuilder.DropColumn(
                name: "FieldsID",
                table: "Services");

            migrationBuilder.DropColumn(
                name: "Type",
                table: "Services");

            migrationBuilder.AddColumn<long>(
                name: "ServicesID",
                table: "Fields",
                type: "NUMBER(19)",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "ServicesID",
                table: "Events",
                type: "NUMBER(19)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Fields_ServicesID",
                table: "Fields",
                column: "ServicesID");

            migrationBuilder.CreateIndex(
                name: "IX_Events_ServicesID",
                table: "Events",
                column: "ServicesID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Fields_ServicesID",
                table: "Fields");

            migrationBuilder.DropIndex(
                name: "IX_Events_ServicesID",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "ServicesID",
                table: "Fields");

            migrationBuilder.DropColumn(
                name: "ServicesID",
                table: "Events");

            migrationBuilder.AddColumn<long>(
                name: "EventsID",
                table: "Services",
                type: "NUMBER(19)",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "FieldsID",
                table: "Services",
                type: "NUMBER(19)",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<string>(
                name: "Type",
                table: "Services",
                type: "NVARCHAR2(2000)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Services_EventsID",
                table: "Services",
                column: "EventsID");

            migrationBuilder.CreateIndex(
                name: "IX_Services_FieldsID",
                table: "Services",
                column: "FieldsID");
        }
    }
}
