﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class p8 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EventParaments");

            migrationBuilder.DropTable(
                name: "Fields");

            migrationBuilder.DropTable(
                name: "Events");

            migrationBuilder.DropTable(
                name: "Services");

            migrationBuilder.DropTable(
                name: "ServerConfig");

            migrationBuilder.CreateTable(
                name: "WAP_ServerConfig",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    SwaggerURL = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WAP_ServerConfig", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "WAP_Services",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    ServicesName = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    ServicesType = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    ServerConfigID = table.Column<long>(type: "NUMBER(19)", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WAP_Services", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "WAP_Events",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Path = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    OperationType = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    WAPServicesID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WAP_Events", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "WAP_Fields",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Type = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    IsNull = table.Column<bool>(type: "NUMBER(1)", nullable: false),
                    IsList = table.Column<bool>(type: "NUMBER(1)", nullable: false),
                    WAPServicesID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WAP_Fields", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "WAP_EventParament",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Type = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Name = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    WAPEventID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称"),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WAP_EventParament", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_WAP_EventParament_WAPEventID",
                table: "WAP_EventParament",
                column: "WAPEventID");

            migrationBuilder.CreateIndex(
                name: "IX_WAP_Events_Name",
                table: "WAP_Events",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_WAP_Events_WAPServicesID",
                table: "WAP_Events",
                column: "WAPServicesID");

            migrationBuilder.CreateIndex(
                name: "IX_WAP_Fields_Name",
                table: "WAP_Fields",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_WAP_Fields_WAPServicesID",
                table: "WAP_Fields",
                column: "WAPServicesID");

            migrationBuilder.CreateIndex(
                name: "IX_WAP_ServerConfig_Name",
                table: "WAP_ServerConfig",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_WAP_Services_ServerConfigID",
                table: "WAP_Services",
                column: "ServerConfigID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "WAP_EventParament");

            migrationBuilder.DropTable(
                name: "WAP_Fields");

            migrationBuilder.DropTable(
                name: "WAP_Events");

            migrationBuilder.DropTable(
                name: "WAP_Services");

            migrationBuilder.DropTable(
                name: "WAP_ServerConfig");

            migrationBuilder.CreateTable(
                name: "ServerConfig",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false),
                    SwaggerURL = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServerConfig", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Services",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    ServerConfigID = table.Column<long>(type: "NUMBER(19)", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    ServicesName = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    ServicesType = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Services", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Events",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false),
                    OperationType = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Path = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    ServicesID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Events", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Fields",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    IsList = table.Column<bool>(type: "NUMBER(1)", nullable: false),
                    IsNull = table.Column<bool>(type: "NUMBER(1)", nullable: false),
                    Name = table.Column<string>(type: "NVARCHAR2(450)", nullable: false),
                    ServicesID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    Type = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fields", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "EventParaments",
                columns: table => new
                {
                    ID = table.Column<long>(type: "NUMBER(19)", nullable: false, comment: "ID")
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    CreatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "创建时间"),
                    CreatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "创建者名称"),
                    Description = table.Column<string>(type: "NVARCHAR2(2000)", nullable: true),
                    EventID = table.Column<long>(type: "NUMBER(19)", nullable: true),
                    IsDeleted = table.Column<bool>(type: "NUMBER(1)", nullable: false, comment: "软删除标记"),
                    Name = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    Type = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true, comment: "更新时间"),
                    UpdatedUserName = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: true, comment: "修改者名称")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventParaments", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EventParaments_EventID",
                table: "EventParaments",
                column: "EventID");

            migrationBuilder.CreateIndex(
                name: "IX_Events_Name",
                table: "Events",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Events_ServicesID",
                table: "Events",
                column: "ServicesID");

            migrationBuilder.CreateIndex(
                name: "IX_Fields_Name",
                table: "Fields",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Fields_ServicesID",
                table: "Fields",
                column: "ServicesID");

            migrationBuilder.CreateIndex(
                name: "IX_ServerConfig_Name",
                table: "ServerConfig",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Services_ServerConfigID",
                table: "Services",
                column: "ServerConfigID");
        }
    }
}
