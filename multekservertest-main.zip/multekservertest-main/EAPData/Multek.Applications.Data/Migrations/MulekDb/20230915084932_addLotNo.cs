﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Multek.Applications.Data.Migrations.MulekDb
{
    /// <inheritdoc />
    public partial class addLotNo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "lotNo",
                table: "UnBarcodeBoundPackage",
                type: "NVARCHAR2(50)",
                maxLength: 50,
                nullable: true,
                comment: "Lot号");

            migrationBuilder.AddColumn<string>(
                name: "lotNo",
                table: "BarcodeBoundPackage",
                type: "NVARCHAR2(50)",
                maxLength: 50,
                nullable: true,
                comment: "Lot号");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "lotNo",
                table: "UnBarcodeBoundPackage");

            migrationBuilder.DropColumn(
                name: "lotNo",
                table: "BarcodeBoundPackage");
        }
    }
}
