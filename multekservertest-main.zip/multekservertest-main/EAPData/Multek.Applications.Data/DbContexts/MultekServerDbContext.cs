﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Multek.Applications.Model.Entities;
using Multek.Applications.Model.Entities.EAP;
using Multek.Library_Core.COM.DbContexts;
using Multek.Library_Core.DbContexts;

namespace Multek.Applications.Data.DbContexts.Sample
{
    public class MultekServerDbContext: MultekServerDbContextBase
    {
        #region 构造方法

        public MultekServerDbContext(DbContextOptions<MultekServerDbContext> builder) : base(builder)
        {

        }
        public MultekServerDbContext() : base()
        {

        }
        #endregion
    }   
}
