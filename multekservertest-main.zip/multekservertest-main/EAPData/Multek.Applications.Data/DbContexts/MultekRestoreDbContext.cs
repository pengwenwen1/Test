﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Multek.Applications.Model.Entities.EAP;
using Multek.Library_Core.COM.DbContexts;
using Multek.Library_Core.COM.Model;
using Multek.Library_Core.DbContexts;

namespace Multek.Applications.Data.DbContexts.Sample
{
    public class MultekRestoreDbContext : MultekServerDbContextBase
    {
        #region 构造方法

        public MultekRestoreDbContext(DbContextOptions<MultekRestoreDbContext> builder) : base(builder)
        {

        }
        #endregion
        /// <summary>
        /// 重新方法
        /// </summary>
        /// <returns></returns>
        public override int SaveChanges()
        {
            SetSystemField();
            return base.SaveChanges(true);
        }
        /// <summary>
        /// 重写保存事件
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            SetSystemField();
            return base.SaveChangesAsync(true);
        }

        #region 系统字段赋值
        /// <summary>
        /// 系统字段赋值
        /// </summary>
        private void SetSystemField()
        {
            foreach (var item in ChangeTracker.Entries())
            {
                if (item.Entity is CommEntityBase)
                {
                    var entity = (CommEntityBase)item.Entity;
                    //添加操作
                    if (item.State == EntityState.Added)
                    {
                        entity.UpdatedTime = DateTime.Now;
                        Entry(entity).Property(o => o.CreatedTime).IsModified = false;
                        Entry(entity).Property(o => o.CreatedUserName).IsModified = false;
                    }
                }
            }
        }
        #endregion
    }
}
