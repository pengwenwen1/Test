﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Multek.Applications.Model.Entities;
using Multek.Applications.Model.Entities.EAP;
using Multek.Applications.Model.Entities.WebapiHelper;
using Multek.Library_Core.COM.DbContexts;
using Multek.Library_Core.DbContexts;

namespace Multek.Applications.Data.DbContexts.Sample
{
    public class MultekServerDbContextBase : MultekDbContext
    {
        #region 新增数据库管理对象
        public DbSet<BarcodeBoundPackage> barcodeBoundPackages { get; set; }

        public DbSet<UnBarcodeBoundPackage> unBarcodeBoundPackages { get; set; }

        public DbSet<WAPServerConfig> ServerConfigs { get; set; }

        public DbSet<WAPServices> Services { get; set; }
        public DbSet<WAPEvent> Events { get; set; }
        public DbSet<WAPEventParament> EventParaments { get; set; }


        #endregion

        #region 构造方法

        public MultekServerDbContextBase(DbContextOptions builder) : base(builder)
        {

        }
        public MultekServerDbContextBase() : base()
        {

        }
        #endregion
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //var Configurat = Configuration;
                ////获取配置文件
                //var getconfig = Configuration["ConnectionStrings:SqlDb"];
                var _env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                string _fileName = "appsettings.json";
                if (_env != null)
                    _fileName = $"appsettings.{_env}.json";
                Console.WriteLine(_fileName);
                // 使用数据库
                optionsBuilder.UseOracle(new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile(_fileName).Build()["ConnectionStrings:OracleDb"]).AddInterceptors(new ShardingDbCommandInterceptor());
                //optionsBuilder.UseSqlServer(new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile(_fileName).Build()["ConnectionStrings:SqlDb"]);
                optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
                optionsBuilder.LogTo(msg =>
                {
                    if (msg.Contains("CommandExecuting"))
                        Console.WriteLine(msg);
                });
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
