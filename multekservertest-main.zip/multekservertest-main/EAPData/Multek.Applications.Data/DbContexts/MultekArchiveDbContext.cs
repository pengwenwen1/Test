﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Multek.Applications.Model.Entities.EAP;
using Multek.Library_Core.COM.DbContexts;
using Multek.Library_Core.DbContexts;

namespace Multek.Applications.Data.DbContexts.Sample
{
    public class MultekArchiveDbContext : MultekServerDbContextBase
    {
        #region 构造方法

        public MultekArchiveDbContext(DbContextOptions<MultekArchiveDbContext> builder) : base(builder)
        {

        }
        #endregion
        /// <summary>
        /// 重新方法
        /// </summary>
        /// <returns></returns>
        public override int SaveChanges()
        {
            return base.SaveChanges(true);
        }
        /// <summary>
        /// 重写保存事件
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            return base.SaveChangesAsync(true);
        }
    }   
}
