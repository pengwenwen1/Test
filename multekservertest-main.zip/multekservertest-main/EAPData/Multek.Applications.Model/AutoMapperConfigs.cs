﻿using AutoMapper;
using Multek.Applications.Model.Entities.EAP;
using Multek.Applications.Model.Entities.EAP.Dto;

namespace Multek.Applications.Model
{
    public class AutoMapperConfigs : Profile
    {
        public AutoMapperConfigs()
        {
            CreateMap<BarcodeBoundPackageDto, BarcodeBoundPackage>();

            CreateMap<BarcodeBoundPackage, BarcodeBoundPackageRsp>();

            CreateMap<BarcodeBoundPackage, UnBarcodeBoundPackage>();
        }
    }
}