﻿
using Multek.Applications.Model.Entities.Enum;
using Multek.Library_Core.Services.AOP;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Multek.Applications.Model.Entities
{
    /// <summary>
    /// CodeTree-各级码的关系
    /// </summary>
    [Table("CodeTree")]
    [DescriptionForModel("CodeTree-各级码的关系")]
    public class CodeTree
    {
        /// <summary>
        /// 生产Lot
        /// </summary>
        public string Lot { get; set; }
        /// <summary>
        /// 码类型0:Lot;  1:Pnl;  2:Set;  3:Pcs;
        /// </summary>
        public CodeTypeEnum CodeType { get; set; }

        /// <summary>
        /// 码值
        /// </summary>
        [Key]
        public string Code { get; set; }

        /// <summary>
        /// 当前码的父级码
        /// </summary>
        public string? Parent { get; set; }
        /// <summary>
        /// 内层物料码
        /// </summary>
        public string? Material { get; set; }
       

        /// <summary>
        /// 明码名称
        /// </summary>
        public string? PlainCode { get; set; }
    }
}
