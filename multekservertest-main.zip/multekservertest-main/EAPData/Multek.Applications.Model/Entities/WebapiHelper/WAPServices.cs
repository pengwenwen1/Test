﻿using Multek.Library_Core.GenerateId;
using Multek.Library_Core.Services.AOP;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.WebapiHelper
{
    /// <summary>
    /// 服务类（Service）
    /// </summary>
    [Table("WAP_Services")]
    [DataWarehouse(Library_Core.COM.Enum.DataNameEnum.EAPData)]
    public class WAPServices : IDEntityBase
    {
        public string ServicesName { get; set; }
        public WAPServicesType ServicesType { get; set; }
        public string? Description { get; set; }
        public WAPServerConfig ServerConfig { get; set; }

        public List<WAPEvent> Events { get; set; }

        public List<WAPFields> Fields { get; set; }
    }
}
