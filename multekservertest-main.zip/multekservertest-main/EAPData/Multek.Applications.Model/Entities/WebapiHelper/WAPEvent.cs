﻿using Multek.Library_Core.GenerateId;
using Multek.Library_Core.ModelBase;
using Multek.Library_Core.Services.AOP;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.WebapiHelper
{
    /// <summary>
    /// 方法实体类
    /// </summary>
    [Table("WAP_Events")]
    [DataWarehouse(Library_Core.COM.Enum.DataNameEnum.EAPData)]
    public class WAPEvent : IDEntityBase
    {
        public string Path { get; set; }

        public string? Description { get; set; }

        public string OperationType { get; set; }
        public List<WAPEventParament>? EventParaments { get; set; }

        public WAPServices WAPServices { get; set; }

        public string Name { get; set; }
    }
}
