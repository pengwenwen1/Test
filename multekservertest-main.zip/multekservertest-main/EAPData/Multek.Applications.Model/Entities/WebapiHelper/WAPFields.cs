﻿using Multek.Library_Core.GenerateId;
using Multek.Library_Core.Services.AOP;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.WebapiHelper
{
    /// <summary>
    /// 字段配置
    /// </summary>
    [Table("WAP_Fields")]
    [DataWarehouse(Library_Core.COM.Enum.DataNameEnum.EAPData)]
    public class WAPFields : IDEntityBase
    {
        public string Type { get; set; }

        public string Description { get; set; }

        public bool IsNull { get; set; }

        public bool IsList { get; set; }
        /// <summary>
        /// 服务对象
        /// </summary>
        public WAPServices WAPServices { get; set; }

        [MaxLength(450)]
        public string Name { get; set; }
    }
}
