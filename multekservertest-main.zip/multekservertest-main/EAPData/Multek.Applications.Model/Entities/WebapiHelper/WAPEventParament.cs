﻿using Multek.Library_Core.GenerateId;
using Multek.Library_Core.Services.AOP;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.WebapiHelper
{
    /// <summary>
    /// 事件参数
    /// </summary>
    [Table("WAP_EventParament")]
    [DataWarehouse(Library_Core.COM.Enum.DataNameEnum.EAPData)]
    public class WAPEventParament : IDEntityBase
    {

        public string Type { get; set; }
        public string Name { get; set; }
        public string? Description { get; set; }

        /// <summary>
        /// 事件
        /// </summary>
        public WAPEvent WAPEvent { get; set; }

    }
}
