﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.WebapiHelper
{
    /// <summary>
    /// 服务的类型
    /// </summary>
    public enum WAPServicesType
    {

        Controller = 0,
        ModelServices = 1,
        Services = 2,
        ControllerParaments= 3
    }
}
