﻿using Multek.Library_Core.GenerateId;
using Multek.Library_Core.Services.AOP;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.WebapiHelper
{
    /// <summary>
    /// 服务的Swagger配置
    /// </summary>
    [Table("WAP_ServerswaggerURL")]
    [DataWarehouse(Library_Core.COM.Enum.DataNameEnum.EAPData)]
    public class WAPServerswaggerURL:IDEntityBase
    {
        /// <summary>
        /// 地址
        /// </summary>
        public string ServerIp { get; set; }
        /// <summary>
        /// 端口
        /// </summary>
        public string Port { get; set; }
        /// <summary>
        /// SwaggerURL地址
        /// </summary>
        public string SwaggerURL { get; set; }

        /// <summary>
        /// 服务配置信息
        /// </summary>
        public WAPServerConfig WAPServerConfig { get; set; }
    }
}
