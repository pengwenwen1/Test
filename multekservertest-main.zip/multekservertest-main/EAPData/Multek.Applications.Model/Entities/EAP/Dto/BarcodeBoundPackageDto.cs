﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Multek.Library_Core.GenerateId;

namespace Multek.Applications.Model.Entities.EAP.Dto
{
    /// <summary>
    /// 上传条码记录
    /// </summary>
    public class BarcodeBoundPackageDto
    {
        /// <summary>
        /// 包号
        /// </summary>
        public string pkgNo { get; set; }
        /// <summary>
        /// Lot号
        /// </summary>
        public string? lotNo { get; set; }

        /// <summary>
        /// 型号
        /// </summary>
        public string project { get; set; }

        /// <summary>
        /// 周期
        /// </summary>
        public int dateCode { get; set; }

        /// <summary>
        /// 条码（SET码/PCS码）
        /// </summary>
        public List<string> barcodeList { get; set; }


    }
}
