﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace Multek.Applications.Model.Entities.EAP
{
    /// <summary>
    /// 上传条码记录
    /// </summary>
    [Table("BarcodeBoundPackage")]
    [PrimaryKey(nameof(barcode))]
    public class BarcodeBoundPackage: BarcodeBoundPackageBase
    {
    }
}
