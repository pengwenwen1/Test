﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Multek.Library_Core.GenerateId;

namespace Multek.Applications.Model.Entities.EAP
{
    /// <summary>
    /// 回显条码记录
    /// </summary>
    public class BarcodeBoundPackageRsp 
    {
        /// <summary>
        /// 条码（SET码/PCS码）
        public string barcode;

        /// <summary>
        /// Lot号
        /// </summary>
        public string? lotNo;

        /// <summary>
        /// 包号
        /// </summary>
        public string pkgNo;

        /// <summary>
        /// 型号
        /// </summary>
        public string project;
        /// <summary>
        /// 周期
        /// </summary>
        public int dateCode;
    

    }
}
