﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Multek.Library_Core.GenerateId;

namespace Multek.Applications.Model.Entities.EAP
{
    /// <summary>
    /// 上传条码记录
    /// </summary>
    public class BarcodeBoundPackageBase : IDEntityBase
    {
        /// <summary>
        /// 条码（SET码/PCS码）
        /// </summary>
        [MaxLength(200)]
        [Comment("条码（SET码/PCS码）")]
        public string barcode { get; set; }

        /// <summary>
        /// 包号
        /// </summary>
        [MaxLength(200)]
        [Comment("包号")]
        public string pkgNo { get; set; }

        /// <summary>
        /// 型号
        /// </summary>
        [MaxLength(20)]
        [Comment("型号")]
        public string project { get; set; }

        /// <summary>
        /// 周期
        /// </summary>
        [Comment("周期")]
        public int dateCode { get; set; }

        /// <summary>
        /// Lot号
        /// </summary>
        [Comment("Lot号")]
        [MaxLength(50)]
        public string? lotNo { get; set; }

    }
}
