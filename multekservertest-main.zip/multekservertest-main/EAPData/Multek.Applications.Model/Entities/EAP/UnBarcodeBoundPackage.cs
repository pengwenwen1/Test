﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Multek.Library_Core.GenerateId;

namespace Multek.Applications.Model.Entities.EAP
{
    /// <summary>
    /// 解包记录
    /// </summary>
    [Table("UnBarcodeBoundPackage")]
    public class UnBarcodeBoundPackage :  BarcodeBoundPackageBase
    {
        
    }
}
