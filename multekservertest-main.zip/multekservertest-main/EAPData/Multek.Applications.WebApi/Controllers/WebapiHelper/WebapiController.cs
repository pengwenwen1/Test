﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.ResultModel;
using Microsoft.OpenApi.Readers;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.Entities.WebapiHelper;
using Microsoft.EntityFrameworkCore;
using Multek.Library_Core.WebapiHelp;
using Microsoft.IdentityModel.Tokens;
using Multek.Library_Core.Services.AOP;
using System.Reflection;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.COM.Model;
using Multek.Library_Core.ModelBase;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Multek.Applications.WebApi.Controllers.WebapiHelper
{
    /// <summary>
    /// webapi说明
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class WebapiController : Controller
    {
        public MultekServerDbContext _multekServerDbContext;
        public WebapiController(MultekServerDbContext multekServerDbContext)
        {
            _multekServerDbContext = multekServerDbContext;
        }


        #region 上传Webapi的json信息
        [HttpPost]
        /// <summary>
        /// 上传Webapi的json信息
        /// </summary>
        /// <param name="UploadWebapiDto"></param>
        /// <returns></returns>
        public IResultModel UploadWebapi(UploadWebapiDto uploadWebapiDto)
        {
            //uploadWebapiDto.UploadUrl = "http://10.201.49.53:8050/swagger/CAM/swagger.json";
            //内存流
            var httpClient = new HttpClient();
            OpenApiDocument document;
            // 从指定的 Swagger URL 下载 Swagger 文件
            try
            {
                var swaggerJson = httpClient.GetStreamAsync(uploadWebapiDto.UploadUrl).Result;
                // 解析 Swagger 文件
                var reader = new OpenApiStreamReader();
                document = reader.Read(swaggerJson, out var diagnostic);
                if (document==null)
                {
                    // 处理解析错
                    return new ResultModel<string>().Failed("解析 Swagger 文件时发生错误");
                }
                //if (diagnostic.Errors.Count > 0)
                //{
                //    // 处理解析错
                //    return new ResultModel<string>().Failed("解析 Swagger 文件时发生错误");
                //}
            }
            catch (Exception)
            {
                return new ResultModel<string>().Success("解析错误！");
            }
            // 校验数据库是否操作服务
            WAPServerConfig? _serverConfig = _multekServerDbContext.ServerConfigs.Where(x => x.Name == document.Info.Title).Include(x=>x.WAPServerswaggerURL).AsTracking().FirstOrDefault();
            if (_serverConfig == null)
            {
                _serverConfig = new WAPServerConfig() { Name = document.Info.Title, Description = document.Info.Description, WAPServerswaggerURL = new List<WAPServerswaggerURL>()};
            }
            WAPServerswaggerURL wAPServerswaggerURL= _serverConfig.WAPServerswaggerURL.FirstOrDefault(x=>x.SwaggerURL ==uploadWebapiDto.UploadUrl );
            if (wAPServerswaggerURL == null)
                _serverConfig.WAPServerswaggerURL.Add(new WAPServerswaggerURL() {  ServerIp = uploadWebapiDto.Server, Port = uploadWebapiDto.Port, SwaggerURL = uploadWebapiDto.UploadUrl});
            _multekServerDbContext.SaveChanges();
            List<WAPServices> servicesList = _multekServerDbContext.Services.Where(x => x.ServerConfig.ID == _serverConfig.ID).Include(y => y.Events).AsTracking().ToList();
            // 生成服务类
            foreach (var item in document.Paths)
            {
                #region 服务

                string servicesName = item.Key.Substring(0, item.Key.LastIndexOf('/'));
                Multek.Applications.Model.Entities.WebapiHelper.WAPServices services = servicesList.FirstOrDefault(x => x.ServicesName == servicesName);
                if (services == null)
                {
                    services = new Model.Entities.WebapiHelper.WAPServices();
                    services.ServicesName = servicesName;
                    services.ServerConfig = _serverConfig;
                    servicesList.Add(services);
                }
                #endregion
                #region 事件

                WAPEvent? _event = services.Events?.FirstOrDefault(x => x.Path == item.Key);
                if (_event == null)
                {
                    foreach (var OperationsItem in item.Value.Operations)
                    {
                        _event = new WAPEvent() { Path = item.Key, Name = item.Key, Description = OperationsItem.Value.Summary, OperationType = OperationsItem.Key.ToString() };
                        services.Description = OperationsItem.Value.Tags[0].Description;
                    }

                    if (services.Events == null)
                    {
                        services.Events = new List<WAPEvent>();
                    }
                    services.Events.Add(_event);
                }
                else
                {
                    //修改
                    foreach (var OperationsItem in item.Value.Operations)
                    {
                        _event.Description = OperationsItem.Value.Summary;
                        _event.OperationType = OperationsItem.Key.ToString();
                        services.Description = OperationsItem.Value.Tags[0].Description;
                    }

                }
                #region 参数
                foreach (var OperationsItem in item.Value.Operations)
                {

                    var RequestBody = OperationsItem.Value.RequestBody;
                    if (RequestBody != null)
                    {
                        WAPEventParament? _eventParament = _event.EventParaments?.FirstOrDefault(x => x.Name == RequestBody.Content["text/json"].Schema.Reference.Id);
                        if (_eventParament == null)
                        {
                            _eventParament = new WAPEventParament();
                            string _Tpye = RequestBody.Content["text/json"].Schema.Type;
                            if (_Tpye == "array")
                            {
                                _eventParament.Name = RequestBody.Content["text/json"].Schema.Items.Reference.Id;
                                _eventParament.Type = _Tpye;
                                _eventParament.Description = "";
                            }
                            else
                            {
                                //POST当值
                                if (RequestBody.Content["text/json"].Schema.Reference == null)
                                {
                                    _eventParament.Name = _Tpye;
                                    _eventParament.Type = _Tpye;
                                    _eventParament.Description = "";
                                }
                                else
                                {
                                    _eventParament.Name = RequestBody.Content["text/json"].Schema.Reference.Id;
                                    _eventParament.Type = RequestBody.Content["text/json"].Schema.Reference.Id;
                                    _eventParament.Description = "";
                                }

                            }
                            if (_event.EventParaments == null)
                            {
                                _event.EventParaments = new List<WAPEventParament>();
                            }
                            _event.EventParaments.Add(_eventParament);
                        }
                        else
                        {
                            //修改
                            _eventParament.Name = RequestBody.Content["text/json"].Schema.Reference.Id;
                        }

                    }
                    else
                    {
                        var Parameters = OperationsItem.Value.Parameters;
                        if (Parameters != null && Parameters.Count > 0)
                        {
                            WAPEventParament? _eventParament = _event.EventParaments?.FirstOrDefault(x => x.Name == Parameters[0].Name);
                            if (_eventParament == null)
                            {
                                _eventParament = new WAPEventParament();
                                _eventParament.Name = Parameters[0].Name;
                                _eventParament.Type = Parameters[0].Schema.Type;
                                if (_event.EventParaments == null)
                                {
                                    _event.EventParaments = new List<WAPEventParament>();
                                }
                                _event.EventParaments.Add(_eventParament);
                            }
                            else
                            {
                                //修改
                                _eventParament.Name = Parameters[0].Name;
                                _eventParament.Type = Parameters[0].Schema.Type;
                            }
                        }
                    }

                }
                #endregion

                #endregion
            }
            _multekServerDbContext.UpdateRange(servicesList);
            int i = _multekServerDbContext.SaveChanges();

            // 返回生成的对象
            return new ResultModel<string>().Success("文档上传成功！");
        }
        #endregion

        #region 上传modelService信息
        /// <summary>
        /// 上传modelService信息
        /// </summary>
        /// <param name="entities"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel UploadModel(List<Entity> entities)
        {
            // 校验数据库是否操作服务
            WAPServerConfig? _serverConfig = _multekServerDbContext.ServerConfigs.Where(x => x.Name.ToLower() == entities[0].Name.ToLower()).AsTracking().FirstOrDefault();
            if (_serverConfig == null)
            {
                return new ResultModel<string>().Failed("无服务配置信息，先添加服务配置信息！");
            }

            //根据服务配置查询该项目下所有实体类信息
            List<WAPServices> servicesList = _multekServerDbContext.Services.Where(x => x.ServerConfig.ID == _serverConfig.ID).Include(y => y.Fields).AsTracking().ToList();

            foreach (var item in entities)
            {
                var _wAPServices = servicesList.FirstOrDefault(x => x.ServicesName.ToLower() == item.Type.ToLower() && x.ServicesType == WAPServicesType.ModelServices);
                if (_wAPServices == null) 
                {
                    _wAPServices = new WAPServices() { ServicesName = item.Type, ServicesType = WAPServicesType.ModelServices,ServerConfig = _serverConfig,Description = item.Description };
                    servicesList.Add(_wAPServices);
                }

                
                foreach (var filedItem in item.Fields)
                {
                    //查询实体类字段是否存在
                    WAPFields _wAPFields = _wAPServices.Fields?.FirstOrDefault(x => x.Name == filedItem.Name);
                    if (_wAPFields == null)
                    {
                        _wAPFields = new WAPFields() { Type = filedItem.Type, Name = filedItem.Name, Description = filedItem.Description, IsNull = filedItem.IsNull, IsList = filedItem.IsList};
                        if (_wAPServices.Fields == null)
                        {
                            _wAPServices.Fields = new List<WAPFields>();
                        }
                        _wAPServices.Fields.Add(_wAPFields);
                    }
                    else
                    {
                        _wAPFields.Type= filedItem.Type;
                        _wAPFields.Description= filedItem.Description;
                        _wAPFields.IsNull= filedItem.IsNull;
                        _wAPFields.IsList= filedItem.IsList;
                    }
                }
            }
            _multekServerDbContext.UpdateRange(servicesList);   //更新数据库
            int i = _multekServerDbContext.SaveChanges();
            return new ResultModel<string>().Success("上传modelService信息成功！");
        }
        #endregion

        #region 上传service信息
        /// <summary>
        /// 上传service信息
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel UploadService(List<ServiceInterface> services)
        {
            // 校验数据库是否操作服务
            WAPServerConfig? _serverConfig = _multekServerDbContext.ServerConfigs.Where(x => x.Name == services[0].Name).AsTracking().FirstOrDefault();
            if (_serverConfig == null)
            {
                return new ResultModel<string>().Failed("无服务配置信息，先添加服务配置信息！");
            }

            //根据服务配置查询该项目下所有Events信息
            List<WAPServices> servicesList = _multekServerDbContext.Services.Where(x => x.ServerConfig.ID == _serverConfig.ID).Include(y => y.Events).AsTracking().ToList();

            foreach (var item in services)
            {
                var _wAPServices = servicesList.FirstOrDefault(x => x.ServicesName.ToLower() == item.Type.ToLower() && x.ServicesType == WAPServicesType.Services);
                if (_wAPServices == null)
                {
                    _wAPServices = new WAPServices() { ServicesName = item.Type, ServicesType = WAPServicesType.Services, ServerConfig = _serverConfig, Description = item.Description };
                    servicesList.Add(_wAPServices);
                }
                #region event
                foreach (var eventItem in item.Events)
                {
                    //查询实体类字段是否存在
                    WAPEvent _wAPEvent = _wAPServices.Events?.FirstOrDefault(x => x.Name == eventItem.Name);
                    if (_wAPEvent == null)
                    {
                        _wAPEvent = new WAPEvent() { Path = eventItem.Name, Name = eventItem.Name, Description = eventItem.Description, OperationType = eventItem.Name };
                        if (_wAPServices.Events == null)
                        {
                            _wAPServices.Events = new List<WAPEvent>();
                        }
                        _wAPServices.Events.Add(_wAPEvent);
                    }
                    else
                    {
                        _wAPEvent.Description = eventItem.Description;

                    }

                    #region params
                    foreach (var paramItem in eventItem.Paraments)
                    {
                        WAPEventParament _wAPEventParament = _wAPEvent.EventParaments?.FirstOrDefault(x => x.Name == paramItem.Name);
                        if (_wAPEventParament == null)
                        {
                            _wAPEventParament = new WAPEventParament() {  Name = paramItem.Name, Description = paramItem.Description, Type = paramItem.Type };
                            if (_wAPEvent.EventParaments == null)
                            {
                                _wAPEvent.EventParaments = new List<WAPEventParament>();
                            }
                            _wAPEvent.EventParaments.Add(_wAPEventParament);
                        }
                        else
                        {
                            _wAPEventParament.Type = paramItem.Type;
                            _wAPEventParament.Description= paramItem.Description;
                        }
                    }
                    #endregion
                }
                #endregion
            }
            _multekServerDbContext.UpdateRange(servicesList);   //更新数据库
            int i = _multekServerDbContext.SaveChanges();

            return new ResultModel<string>().Success("上传service信息成功！");
        }
        #endregion


    }
}
