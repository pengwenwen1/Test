﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using System.Configuration;
using System.Diagnostics;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.ClickHouse.ClickHouseInterface;
using Multek.Library_Core.ClickHouse.ClickHouseEntity;

namespace Multek.Applications.WebApi.Controllers.SYS
{
    /// <summary>
    /// 系统
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class ClickhouseController : Controller
    {
        private readonly ICKTest _quest;
        public ClickhouseController(ICKTest quest)
        {
            _quest = quest;
        }
        [HttpPost]
        public void InitTable() { 
            _quest.InitTable();
        }
        [HttpPost]
        public void AddData()
        {
            _quest.AddData();
        }
        [HttpPost]
        public IResultModel GetData()
        {
            return _quest.GetData();
        }
        [HttpPost]
        public void Updata(CKTestEntity cKTestEntity )
        {
            _quest.Updata(cKTestEntity);
        }
        [HttpPost]
        public void Delete(CKTestEntity cKTestEntity)
        {
            _quest.Delete(cKTestEntity);
        }
        [HttpPost]
        public void DropTable(CKTestEntity cKTestEntity)
        {
            _quest.DropTable(cKTestEntity);
        }
    }
}
