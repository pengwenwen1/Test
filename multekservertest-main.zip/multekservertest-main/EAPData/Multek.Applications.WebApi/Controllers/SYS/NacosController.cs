﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using System.Configuration;
using System.Diagnostics;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.COM;
using Multek.Library_Core.Model.Token;
using Newtonsoft.Json;
using Multek.Library_Core.ServicesInface;
using System.Net;
using Multek.Library_Core.Redis;
using Multek.Library_Core.WebApi.Filters;
using Microsoft.Extensions.Caching.Memory;

namespace Multek.Applications.WebApi.Controllers.SYS
{
    /// <summary>
    /// 系统
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class NacosController : Controller
    {
        private readonly INacos _nacos;
        public NacosController( INacos nacos)
        {

            _nacos = nacos;
        }

        /// <summary>
        /// 获取网关的信息(网关地址、Token)
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ResultModel<string> GetGatewayInfo()
        {
            // 获取网关
            GatewayConst.Address = _nacos.GetBaseUrl(NacosServerNamesConst.Gateway).Result;
            // 获取Token信息
            HttpResponseMessage httpResponseMessage = WebApiHandler.PostOriginalAsyncForGateway<TokenModelRequest>(GatewayConst.Address, NacosApiUrlConst.token, new TokenModelRequest());
            if (httpResponseMessage.IsSuccessStatusCode)
            {

                //处理返回信息
                string _resultStr = httpResponseMessage.Content.ReadAsStringAsync().Result;
                GatewayConst.GatewayToken = JsonConvert.DeserializeObject<GatewayToken>(_resultStr);
                return new ResultModel<string>().Success("Token获取成功！"); ;
            }
            else
            {
                // Token获取失败
            }
            return new ResultModel<string>().Failed("Token获取失败");
            //return NacosHelper.get().Result;
        }
       

    }
}
