﻿using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Services.Impl.Sample;
using Multek.Applications.Services.Sample;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.COM.Model;
using Multek.Library_Core.Model.Token;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using Nacos.V2;
using Newtonsoft.Json;
using System.Reflection;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Multek.Applications.WebApi.Controllers.SYS
{
    [ApiExplorerSettings(GroupName = SawaggerGroupName.RCP)]
    [Route($"{SawaggerGroupName.RCP}/[controller]/[action]")]
    [ApiController]
    public class SampleController : Controller
    {
        public ICommService _CommServiceHleper;
        public ISampleService _sampleService;
        private readonly INacos _nacos;
        public SampleController(ICommService CommService, ISampleService sampleService, IHttpContextAccessor httpContextAccessor, INacos nacos)
        {
            _CommServiceHleper = CommService;
            _sampleService = sampleService;
            _nacos = nacos;
        }
       
        /// <summary>
        /// 使用Nacos发送预警信息
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ResultModel<string> pushMonitoringWarningByNacos()
        {
            // 请求发送的地址
            var url = $"{_nacos.GetBaseUrl(NacosServerNamesConst.Portal).Result}{NacosApiUrlConst.pushMonitoringWarning}";
            // 构建发送类
            PortalWarning _portalWarning = new PortalWarning() { context = "批次L1126541的DRL1工序Holding Time超时,请留意!", isRead = 0, systemName = "MES", dynamicUser = "180007203", type = "overtime_holding", id = 0 };
            HttpResponseMessage httpResponseMessage = WebApiHandler.PostOriginalAsync<PortalWarning>(_nacos.GetBaseUrl(NacosServerNamesConst.Portal).Result, NacosApiUrlConst.pushMonitoringWarning, _portalWarning);
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                //处理返回信息
                string _resultStr = httpResponseMessage.Content.ReadAsStringAsync().Result;
                ResultModel<string> _resultModel = JsonConvert.DeserializeObject<ResultModel<string>>(_resultStr);
                return _resultModel;
            }
            else
            {
                // 预警不成功处理
            }
            return new ResultModel<string>().Failed("预警不成功");
            //return NacosHelper.get().Result;
        }
        

        /// <summary>
        /// 通过网关发送预警信息
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ResultModel<string> pushMonitoringWarningByGateway()
        {
            // 构建发送类
            PortalWarning _portalWarning = new PortalWarning() { context = "批次L1126541的DRL1工序Holding Time超时,请留意!", isRead = 0, systemName = "MES", dynamicUser = "180007203", type = "overtime_holding", id = 0 };
            HttpResponseMessage httpResponseMessage = WebApiHandler.PostOriginalAsync<PortalWarning>(GatewayConst.Address, NacosServerNamesConst.Portal + NacosApiUrlConst.pushMonitoringWarning, _portalWarning, GatewayConst.GatewayToken.access_token);
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                //处理返回信息
                string _resultStr = httpResponseMessage.Content.ReadAsStringAsync().Result;
                ResultModel<string> _resultModel = JsonConvert.DeserializeObject<ResultModel<string>>(_resultStr);
                return _resultModel;
            }
            else
            {
                // 预警不成功处理
            }
            return new ResultModel<string>().Failed("预警不成功");
        }
    }
}
