﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Services.Impl.Sample;
using Multek.Applications.Services.Sample;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.Token;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Multek.Applications.WebApi.Controllers.SYS
{
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.RCP}/[controller]/[action]")]
    [ApiController]
    public class LoginController : Controller
    {
        private ICustomJWT _jwtService;
        public LoginController(ICustomJWT jwtService)
        {
            _jwtService = jwtService;
        }
        [HttpGet]
        public Task<string> GetToken(string name, string password)
        {
            var res = Task.Run(() =>
            {
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(password))
                {
                    return "参数不能为空";
                }
                UserRes user = new UserRes() { Id = 1234, Name = name };
                return _jwtService.GetToken(user);
            });
            return res; 

        }

    }
}
