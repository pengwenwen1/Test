﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.COM;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.Entities.EAP;
using Microsoft.EntityFrameworkCore;

namespace Multek.Applications.WebApi.Controllers.SYS
{
    /// <summary>
    /// 归档
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class ArchiveController : Controller
    {
        private readonly MultekServerDbContext _multekServerDbContext;
        private readonly MultekArchiveDbContext _multekArchiveDbContext;
        private readonly MultekRestoreDbContext _multekRestoreDbContext;
        public ArchiveController(MultekServerDbContext multekServerDbContext, MultekArchiveDbContext multekArchiveDbContext,MultekRestoreDbContext multekRestoreDbContext)
        {
            _multekServerDbContext = multekServerDbContext ;
            _multekArchiveDbContext = multekArchiveDbContext;
            _multekRestoreDbContext= multekRestoreDbContext;
        }

        /// <summary>
        /// 归档上传记录
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel Archive(string packNo)
        {
            //根据条码查询包号
            BarcodeBoundPackage _barcode = _multekServerDbContext.barcodeBoundPackages.Where(x => x.pkgNo == packNo).AsNoTracking().FirstOrDefault();
            if (_barcode != null)
            {
                using (var transaction = _multekServerDbContext.Database.BeginTransaction())
                {
                    try
                    {
                        _multekServerDbContext.RemoveRange(_barcode);
                        _multekServerDbContext.SaveChanges();
                        _multekArchiveDbContext.barcodeBoundPackages.AddRange(_barcode);
                        _multekArchiveDbContext.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        return new ResultModel<string>().Failed($"{AdvException.GetExceptionMessage(ex)}");
                    }
                }
                
                return new ResultModel<string>().Success($"归档成功！");
            }
            return new ResultModel<string>().Failed($"{packNo}条码不存在，请重试！");

        }

        /// <summary>
        /// 还原归档记录
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel Restore(string packNo)
        {
            //根据条码查询包号
            BarcodeBoundPackage _barcode = _multekArchiveDbContext.barcodeBoundPackages.Where(x => x.pkgNo == packNo).AsNoTracking().FirstOrDefault();
            if (_barcode != null)
            {
                using (var transaction = _multekArchiveDbContext.Database.BeginTransaction())
                {
                    try
                    {
                        _multekArchiveDbContext.RemoveRange(_barcode);
                        _multekArchiveDbContext.SaveChanges();
                        _multekRestoreDbContext.barcodeBoundPackages.AddRange(_barcode);
                        _multekRestoreDbContext.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        return new ResultModel<string>().Failed($"{AdvException.GetExceptionMessage(ex)}");
                    }
                }

                return new ResultModel<string>().Success($"还原成功！");
            }
            return new ResultModel<string>().Failed($"{packNo}条码不存在，请重试！");
        }

    }
}
