﻿using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Model.Entities.EAP.Dto;
using Multek.Applications.Services.EAP;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.ResultModel;

namespace Multek.Applications.WebApi.Controllers.EAP
{
    /// <summary>
    /// 包装条码
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.EAP)]
    [Route($"{SawaggerGroupName.EAP}/[controller]/[action]")]
    [ApiController]
    public class BarcodeBoundController : Controller
    {
        public IBarcodeBound _ibarcodeBound;

        public BarcodeBoundController(IBarcodeBound eAPService)
        {
            _ibarcodeBound = eAPService;
        }

        /// <summary>
        /// 条码检查
        /// </summary>
        /// <param name="barcode"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel BarcodeInspection(BarcodeDto barcodeDto)
        {
            return _ibarcodeBound.BarcodeInspection(barcodeDto.barcode);
        }

        /// <summary>
        /// 条码上传
        /// </summary>
        /// <param name="barcodeBoundPackageBaseDto"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel UploadBarcode(BarcodeBoundPackageDto barcodeBoundPackageBaseDto)
        {
            return _ibarcodeBound.UploadBarcode(barcodeBoundPackageBaseDto);
        }

        /// <summary>
        /// 获取整包条码
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetPackageBarcode(BarcodeDto barcodeDto)
        {
            return _ibarcodeBound.GetPackageBarcode(barcodeDto.barcode);
        }

        /// <summary>
        /// 拆包解绑
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel UnpackAndUnbind(BarcodeDto barcodeDto)
        {
            return _ibarcodeBound.UnpackAndUnbind(barcodeDto);
        }
    }
}
