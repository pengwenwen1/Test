﻿namespace Camstar.XMLClient.Enum
{
    public enum DataFormats
    {
        FormatDateAndTime,
        FormatDate,
        FormatTime,
        FormatDecimal,
        FormatFloat,
    }
}