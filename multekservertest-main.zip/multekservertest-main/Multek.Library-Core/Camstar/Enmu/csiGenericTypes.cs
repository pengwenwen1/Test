﻿namespace Camstar.XMLClient.Enum
{
    public enum CsiGenericTypes
    {
        GenericTypeNone,
        GenericTypeBoolean,
        GenericTypeDecimal,
        GenericTypeFixed,
        GenericTypeFloat,
        GenericTypeInteger,
        GenericTypeString,
        GenericTypeTimestamp,
        GenericTypeObject,
    }
}