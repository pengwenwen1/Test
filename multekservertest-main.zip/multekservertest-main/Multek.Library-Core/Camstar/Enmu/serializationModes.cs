﻿namespace Camstar.XMLClient.Enum
{
    public enum SerializationModes
    {
        SerializationModeDeep,
        SerializationModeShallow,
        SerializationModeDefault,
    }
}