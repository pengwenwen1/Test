﻿namespace Camstar.XMLClient.Enum
{
    public enum CsiReferenceTypes
    {
        ReferenceTypeNone,
        ReferenceTypeContainer,
        ReferenceTypeNamedDataObject,
        ReferenceTypeRevisionedObject,
        ReferenceTypeSubEntity,
        ReferenceTypeNamedSubEntity,
        ReferenceTypeObject,
    }
}