﻿namespace Camstar.XMLClient.Enum
{
    public enum ListActions
    {
        ListActionChange,
        ListActionReplace,
    }
}