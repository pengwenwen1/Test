﻿namespace Camstar.XMLClient.Interface
{
    public interface ICsiQueryParameters : ICsiParameters, ICsiXmlElement
    {
    }
}