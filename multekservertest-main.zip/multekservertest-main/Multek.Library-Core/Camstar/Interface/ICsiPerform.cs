﻿namespace Camstar.XMLClient.Interface
{
    public interface ICsiPerform : ICsiXmlElement
    {
        ICsiParameters AddParameters();
    }
}