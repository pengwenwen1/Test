﻿namespace Camstar.XMLClient.Interface
{
    public interface ICsiCdoType
    {
        string GetCdoTypeName();

        int GetCdoTypeId();
    }
}