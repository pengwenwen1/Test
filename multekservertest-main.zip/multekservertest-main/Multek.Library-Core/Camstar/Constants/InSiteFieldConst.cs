﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Camstar.Constants
{
    public class InSiteFieldConst
    {
        public const string BaseToChange = "BaseToChange";
        public const string CompletionMsg = "CompletionMsg";
        public const string DataCollectionDef = "DataCollectionDef";
        public const string DataVersion = "DataVersion";
        public const string Name = "Name";
        public const string ObjectChanges = "ObjectChanges";
        public const string ObjectToChange = "ObjectToChange";
        public const string ParametricDataControl = "ParametricDataControl";
        public const string Revision = "Revision";
        public const string UseROR = "UseROR";
        public const string ParametricData = "ParametricData";
        public const string IsRemoteService = "IsRemoteService";

    }
}
