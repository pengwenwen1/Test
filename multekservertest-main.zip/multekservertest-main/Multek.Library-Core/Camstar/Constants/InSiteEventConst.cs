﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Camstar.Constants
{
    public class InSiteEventConst
    {
        public const string Delete = "Delete";
        public const string DeleteAllRevisions = "DeleteAllRevisions";
        public const string Load = "Load";
        public const string Save = "Save";
        public const string SaveAs = "SaveAs";
        public const string SaveAsRev = "SaveAsRev";
        public const string New = "New";
        public const string NewRev = "NewRev";
        public const string ResolveParametricData = "ResolveParametricData";
        public const string CreateParametricData = "CreateParametricData";
        public const string Lock = "Freeze";
        public const string UnLock = "UnFreeze";

    }
}
