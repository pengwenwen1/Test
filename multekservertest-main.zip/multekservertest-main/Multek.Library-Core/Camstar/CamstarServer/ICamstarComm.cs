﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Model.COM;
using Multek.Library_Core.ResultModel;
using Nacos.AspNetCore.V2;
using Nacos.V2;
using Nacos.V2.DependencyInjection;

namespace Multek.Library_Core.ServicesInface
{
    public interface ICamstarComm
    {
        /// <summary>
        /// 获取与Camstar通讯的实例
        /// </summary>
        /// <returns></returns>
        public CamstarHelper GetCamstarHelper();

    }
}
