﻿using Castle.Core.Configuration;
using Microsoft.AspNetCore.Hosting;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Extensions.Configuration;
using Multek.Library_Core.Quest.QuestInterface;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IConfiguration = Microsoft.Extensions.Configuration.IConfiguration;

namespace Multek.Library_Core.Camstar.CamstarServer
{
    public class SCamstarComm : ICamstarComm
    {
        public readonly IConfiguration IConfiguration;
        public CamstarHelper camstarHelper;
        public SCamstarComm(IConfiguration configuration,ITracker tracker)
        {
            IConfiguration = configuration;
            camstarHelper = new CamstarHelper(configuration.GetConnectionString("CamstarIP"), Convert.ToInt32(configuration.GetConnectionString("CamstarPort")), configuration.GetConnectionString("CamstarUser"), configuration.GetConnectionString("CamstarPassWord"), tracker);
        }
        /// <summary>
        /// 获取与Camstar通讯的实例
        /// </summary>
        /// <returns></returns>
        public CamstarHelper GetCamstarHelper()
        {
            return camstarHelper;
            //throw new Exception(IConfiguration.GetConnectionString("CamstarIP"));
            //return new CamstarHelper(IConfiguration.GetConnectionString("CamstarIP"), Convert.ToInt32(IConfiguration.GetConnectionString("CamstarPort")), IConfiguration.GetConnectionString("CamstarUser"), IConfiguration.GetConnectionString("CamstarPassWord"));
        }
    }
}
