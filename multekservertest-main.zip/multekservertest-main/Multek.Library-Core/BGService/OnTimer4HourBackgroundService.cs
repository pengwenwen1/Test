﻿using Microsoft.Extensions.Hosting;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.COM;
using Multek.Library_Core.Model.Token;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.BGService
{
    public class OnTimer4HourBackgroundService : BackgroundService
    {
        private readonly INacos _nacos;
        public OnTimer4HourBackgroundService( INacos nacos)
        {
            _nacos = nacos;
            OnTimerFiredAsync(new CancellationToken());
        }
        private static readonly int _spendHour = 4;
        private static readonly TimeSpan _delaytimeSpan = new TimeSpan(1,0,0);
        private static int HoursUntilMidnight()
        {

            return (int)(DateTime.Now.AddHours(_spendHour) - DateTime.Now).Hours;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var countdown = HoursUntilMidnight();

            while (!stoppingToken.IsCancellationRequested)
            {
                if (countdown-- <= 0)
                {
                    try
                    {
                        await OnTimerFiredAsync(stoppingToken);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        countdown = HoursUntilMidnight();
                    }
                }
                await Task.Delay(_delaytimeSpan, stoppingToken);
            }
        }

        private async Task OnTimerFiredAsync(CancellationToken stoppingToken)
        {
            // 生成Token
            // 获取网关
            GatewayConst.Address = _nacos.GetBaseUrl(NacosServerNamesConst.Gateway).Result;
            // 获取Token信息
            HttpResponseMessage httpResponseMessage = WebApiHandler.PostOriginalAsyncForGateway<TokenModelRequest>(GatewayConst.Address, NacosApiUrlConst.token, new TokenModelRequest());
            if (httpResponseMessage.IsSuccessStatusCode)
            {

                //处理返回信息
                string _resultStr = httpResponseMessage.Content.ReadAsStringAsync().Result;
                GatewayConst.GatewayToken = JsonConvert.DeserializeObject<GatewayToken>(_resultStr);
            }
            else
            {
                // Token获取失败
                
            }
            //await Task.Delay(_delaytimeSpan, stoppingToken);
        }
    }
}
