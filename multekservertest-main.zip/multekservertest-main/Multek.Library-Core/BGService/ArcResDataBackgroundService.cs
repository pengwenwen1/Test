﻿using Microsoft.Extensions.Hosting;
using Multek.Library_Core.COM;
using Multek.Library_Core.DataWarehous.DataWarehousInterface;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.BGService
{
    public class ArcResDataBackgroundService : BackgroundService
    {
        private IArchived _archived;

        public ArcResDataBackgroundService(IArchived archived)
        {
            _archived = archived;
        }

        private static readonly TimeSpan _delaytimeSpan = new TimeSpan(24, 0, 0);

        #region 执行归档任务
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                //程序启动后自动运行
                _archived.Archive();
                //还原
                //_archived.Restore();
                //间隔_delaytimeSpan小时后自动运行
                await Task.Delay(_delaytimeSpan, stoppingToken);
            }

        }
        #endregion

    }
}
