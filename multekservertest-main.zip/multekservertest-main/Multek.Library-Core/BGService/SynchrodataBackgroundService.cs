﻿using Microsoft.Extensions.Hosting;
using Multek.Applications.Data.DataWarehous;
using Multek.Library_Core.COM;
using Multek.Library_Core.DataWarehous.DataWarehousInterface;
using Multek.Library_Core.Services.AOP;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.BGService
{
    public class SynchrodataBackgroundService : BackgroundService
    {
        private IDataWarehouseUpdateCode _code;

        public SynchrodataBackgroundService(IDataWarehouseUpdateCode code)
        {
            _code = code;
        }

        #region 数据同步
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _code.synDataWarehouseForCode();
            
        }
        #endregion

    }
}
