﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Audit
{
    /// <summary>
    /// 数据操作. 0:查询  1：新增  2：删除 3：修改
    /// </summary>
    public enum DataOperationEnum
    {
        Query = 0,
        Add = 1,
        Delete = 2,
        Update = 3,
    }
}
