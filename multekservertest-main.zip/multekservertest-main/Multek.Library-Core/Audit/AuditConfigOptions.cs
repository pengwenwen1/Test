﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Audit
{
    public class AuditConfigOptions
    {
        public bool AuditEnabled { get; set; } = true;

        public bool SaveUnModifiedProperties { get; set; }


        private IReadOnlyCollection<IAuditStore> _stores = Array.Empty<IAuditStore>();

        public IReadOnlyCollection<IAuditStore> Stores
        {
            get => _stores;
            set => _stores = value ?? throw new ArgumentNullException(nameof(value));
        }

        private IReadOnlyCollection<AuditEntry> _enrichers = Array.Empty<AuditEntry>();

        public IReadOnlyCollection<AuditEntry> Enrichers
        {
            get => _enrichers;
            set => _enrichers = value ?? throw new ArgumentNullException(nameof(value));
        }

        private IReadOnlyCollection<Func<EntityEntry, bool>> _entityFilters = Array.Empty<Func<EntityEntry, bool>>();

       

        private IReadOnlyCollection<Func<EntityEntry, PropertyEntry, bool>> _propertyFilters = Array.Empty<Func<EntityEntry, PropertyEntry, bool>>();

        public IReadOnlyCollection<Func<EntityEntry, PropertyEntry, bool>> PropertyFilters
        {
            get => _propertyFilters;
            ////空合并运算符(??)
            set => _propertyFilters = value ?? throw new ArgumentNullException(nameof(value));
        }
    }
}

