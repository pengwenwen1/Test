﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Audit
{
    /// <summary>
    /// audit配置
    /// </summary>
    public class AuditConfig
    {
        internal static AuditConfigOptions AuditConfigOptions = new();

        public static void EnableAudit()
        {
            AuditConfigOptions.AuditEnabled = true;
        }

        public static void DisableAudit()
        {
            AuditConfigOptions.AuditEnabled = false;
        }


        public static void Configure(Action<IAuditConfigBuilder> configAction)
        {
            if (configAction is null)
                return;

            var builder = new AuditConfigBuilder();
            configAction.Invoke(builder);
            AuditConfigOptions = builder.Build();
        }
    }
}