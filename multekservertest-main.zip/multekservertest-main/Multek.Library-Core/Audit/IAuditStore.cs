﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.DependencyInjection;
using Multek.Library_Core.Quest.QuestEntity;
using Multek.Library_Core.Quest.QuestInterface;
using Nacos.V2.Utils;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Audit
{
    /// <summary>
    /// 稽核仓库
    /// </summary>
    public interface IAuditStore
    {
        Task Save(ICollection<AuditEntry> auditEntries);
    }
    public class PeriodBatchingAuditStore : IAuditStore
    {
        public readonly IHttpContextAccessor _httpContextAccessor;
        public PeriodBatchingAuditStore(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor= httpContextAccessor;  
        }

        public Task Save(ICollection<AuditEntry> auditEntries)
        {
            IQuest quest = _httpContextAccessor.HttpContext.RequestServices.GetService<IQuest>();
            List<QuestAuditEntry> _questAudits = new List<QuestAuditEntry>();
            foreach (var auditEntry in auditEntries)
            {
                QuestAuditEntry _questAuditEntry = new QuestAuditEntry();
                _questAuditEntry.KeyValues = auditEntry.KeyValues.ToJsonString();
                _questAuditEntry.OriginalValues = auditEntry.OriginalValues.ToJsonString();
                _questAuditEntry.NewValues = auditEntry.NewValues.ToJsonString();
                _questAuditEntry.TableName = auditEntry.TableName;
                _questAuditEntry.UpdatedAt = auditEntry.UpdatedAt;
                _questAuditEntry.UpdatedBy = auditEntry.UpdatedBy;
                _questAuditEntry.KeyValues = auditEntry.KeyValues.ToJsonString();
                _questAuditEntry.Properties = auditEntry.Properties.ToJsonString();
                _questAuditEntry.OperationType = auditEntry.OperationType;
                _questAudits.Add(_questAuditEntry);
            }
            quest.AddAuditEntry(_questAudits);
            return Task.CompletedTask;
        }
    }
}
