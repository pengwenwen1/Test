﻿using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Multek.Library_Core.COM;

namespace Multek.Library_Core.Audit
{
    /// <summary>
    /// 审计类型
    /// </summary>
    public class AuditEntry
    {
        /// <summary>
        /// 表名
        /// </summary>
        public string TableName { get; set; } = null!;
        /// <summary>
        /// 原始数据
        /// </summary>
        public Dictionary<string, object?>? OriginalValues { get; set; }
        /// <summary>
        /// 新数据
        /// </summary>
        public Dictionary<string, object?>? NewValues { get; set; }
        /// <summary>
        /// 主键值
        /// </summary>
        public Dictionary<string, object?>? KeyValues { get; } = new();
        /// <summary>
        ///  0:查询  1：新增  2：删除 3：修改
        /// </summary>
        public DataOperationEnum OperationType { get; set; }
        /// <summary>
        /// 属性定义
        /// </summary>
        public Dictionary<string, object?> Properties { get; } = new();
        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime UpdatedAt { get; set; }
        /// <summary>
        /// 更新人
        /// </summary>
        public string? UpdatedBy { get; set; }
    }

    internal sealed class InternalAuditEntry : AuditEntry
    {
        public List<PropertyEntry>? TemporaryProperties { get; set; }
        public InternalAuditEntry(EntityEntry entityEntry)
        {
            TableName = entityEntry.Metadata.GetTableName() ?? entityEntry.Metadata.Name;

            if (entityEntry.Properties.Any(x => x.IsTemporary))
            {
                TemporaryProperties = new List<PropertyEntry>(4);
            }

            if (entityEntry.State == EntityState.Added)
            {
                OperationType = DataOperationEnum.Add;
                NewValues = new Dictionary<string, object?>();
            }
            else if (entityEntry.State == EntityState.Deleted)
            {
                OperationType = DataOperationEnum.Delete;
                OriginalValues = new Dictionary<string, object?>();
            }
            else if (entityEntry.State == EntityState.Modified)
            {
                OperationType = DataOperationEnum.Update;
                OriginalValues = new Dictionary<string, object?>();
                NewValues = new Dictionary<string, object?>();
            }
            foreach (var propertyEntry in entityEntry.Properties)
            {
                if (AuditConfig.AuditConfigOptions.PropertyFilters.Any(f => f.Invoke(entityEntry, propertyEntry) == false))
                {
                    continue;
                }

                if (propertyEntry.IsTemporary)
                {
                    TemporaryProperties!.Add(propertyEntry);
                    continue;
                }

                var columnName = propertyEntry.GetColumnName();
                if (propertyEntry.Metadata.IsPrimaryKey())
                {
                    KeyValues[columnName] = propertyEntry.CurrentValue;
                }
                switch (entityEntry.State)
                {
                    case EntityState.Added:
                        NewValues![columnName] = propertyEntry.CurrentValue;
                        break;

                    case EntityState.Deleted:
                        OriginalValues![columnName] = propertyEntry.OriginalValue;
                        break;

                    case EntityState.Modified:
                        if (propertyEntry.IsModified || AuditConfig.AuditConfigOptions.SaveUnModifiedProperties)
                        {
                            OriginalValues![columnName] = propertyEntry.OriginalValue;
                            NewValues![columnName] = propertyEntry.CurrentValue;
                        }
                        break;
                }
            }
        }
    }
}
