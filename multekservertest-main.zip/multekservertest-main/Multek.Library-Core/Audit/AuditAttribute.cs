﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Audit
{
    [AttributeUsage(AttributeTargets.Class)]
    public class AuditAttribute: Attribute
    {
        public AuditAttribute()
        { }
    }
}
