﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.Audit
{

    public interface IAuditConfigBuilder
    {
        IAuditConfigBuilder WithUserIdProvider(IUserIdProvider auditUserProvider);

        IAuditConfigBuilder WithUnmodifiedProperty(bool saveUnModifiedProperty = true);

        IAuditConfigBuilder WithStore(IAuditStore auditStore);

        IAuditConfigBuilder WithEntityFilter(Func<EntityEntry, bool> entityFilter);

        IAuditConfigBuilder WithPropertyFilter(Func<EntityEntry, PropertyEntry, bool> propertyFilter);

        IAuditConfigBuilder WithEnricher(AuditEntry enricher);
    }

    internal sealed class AuditConfigBuilder : IAuditConfigBuilder
    {
        private readonly List<AuditEntry> _auditPropertyEnrichers = new(4);
        private readonly List<Func<EntityEntry, bool>> _entityFilters = new();
        private readonly List<Func<EntityEntry, PropertyEntry, bool>> _propertyFilters = new();
        private readonly List<IAuditStore> _auditStores = new();
        private bool _saveUnModifiedProperty;

        public IAuditConfigBuilder WithUserIdProvider(IUserIdProvider auditUserProvider)
        {
            return this;
        }

        public IAuditConfigBuilder WithUnmodifiedProperty(bool saveUnModifiedProperty = true)
        {
            _saveUnModifiedProperty = saveUnModifiedProperty;
            return this;
        }

        public IAuditConfigBuilder WithStore(IAuditStore auditStore)
        {
            if (auditStore is null)
            {
                throw new ArgumentNullException(nameof(auditStore));
            }
            _auditStores.Add(auditStore);
            return this;
        }

        public IAuditConfigBuilder WithEntityFilter(Func<EntityEntry, bool> entityFilter)
        {
            if (entityFilter is null)
            {
                throw new ArgumentNullException(nameof(entityFilter));
            }

            _entityFilters.Add(entityFilter);
            return this;
        }

        public IAuditConfigBuilder WithPropertyFilter(Func<EntityEntry, PropertyEntry, bool> propertyFilter)
        {
            if (propertyFilter is null)
            {
                throw new ArgumentNullException(nameof(propertyFilter));
            }

            _propertyFilters.Add(propertyFilter);
            return this;
        }

        public IAuditConfigBuilder WithEnricher(AuditEntry enricher)
        {
            if (enricher is null)
            {
                throw new ArgumentNullException(nameof(enricher));
            }
            _auditPropertyEnrichers.Add(enricher);
            return this;
        }

        public AuditConfigOptions Build()
        {
            return new()
            {
                Enrichers = _auditPropertyEnrichers,
                PropertyFilters = _propertyFilters,
                Stores = _auditStores,
                SaveUnModifiedProperties = _saveUnModifiedProperty,
            };
        }
    }
}