﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM
{
    /// <summary>
    /// 系统配置
    /// </summary>
    public class AppSettings
    {
        /// <summary>
        /// 
        /// </summary>
        public static string AllowedHosts { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public static ConnectionString ConnectionStrings { get; set; }
        /// <summary>
        /// Nacos服务器地址
        /// </summary>
        public static string ServerAddresses { get; set; }
        /// <summary>
        /// Nacos注册服务器端口
        /// </summary>
        public static int PORT { get; set; }
        /// <summary>
        /// Nacos注册服务器IP
        /// </summary>
        public static string IP { get; set; }
        /// <summary>
        /// Nacos空间
        /// </summary>
        public static string Namespace { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public static ManagementOption ManagementOptions { get; set; }

        public class ConnectionString
        {
            /// <summary>
            /// 
            /// </summary>
            public static string SqlDb { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public static string OracleDb { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public static string OracleMesDb { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public static string MISqlServerDb { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public static string WPTSqlServerDb { get; set; }
            /// <summary>
            /// Redis服务器
            /// </summary>
            public static string redisConnection { get; set; }
            /// <summary>
            /// CamstarIP
            /// </summary>
            public static string CamstarIP { get; set; }
            /// <summary>
            /// Camstar用户
            /// </summary>
            public static string CamstarUser { get; set; }
            /// <summary>
            /// Camstar密码
            /// </summary>
            public static string CamstarPassWord { get; set; }
            /// <summary>
            /// Camstar端口
            /// </summary>
            public static string CamstarPort { get; set; }
        }

        public class ManagementOption
        {
            /// <summary>
            /// 启动HoldingTime服务
            /// </summary>
            public static bool HoldingTimeBackgroundService { get; set; }
            /// <summary>
            /// 数据同步
            /// </summary>
            public static bool DataWarehouse { get; set; }
            /// <summary>
            /// 项目名称
            /// </summary>
            public static string ProjectName { get; set; }

            /// <summary>
            /// 数据归档
            /// </summary>
            public static bool DataArchiving { get; set;}
        }


    }
}
