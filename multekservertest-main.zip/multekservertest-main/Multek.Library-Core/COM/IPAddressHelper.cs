﻿using Microsoft.Extensions.Configuration;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using IConfiguration = Microsoft.Extensions.Configuration.IConfiguration;

namespace Multek.Library_Core.COM
{
    /// <summary>
    /// IP地址助手
    /// </summary>
    public static class IPAddressHelper
    {
        #region 变量

        static Dictionary<string, string> _hostDict = new Dictionary<string, string>();
        #endregion

        #region 方法

        /// <summary>
        /// 根据电脑名获取IP地址
        /// </summary>
        /// <returns>IP地址</returns>
        public static string GetHostAddress()
        {
            string _address = Environment.MachineName;
            try
            {
                if (_hostDict.ContainsKey(_address))
                {
                    _address = _hostDict[_address];
                }
                else
                {
                    IPAddress[] _addressList = Dns.GetHostAddresses(Dns.GetHostName());
                    foreach (IPAddress _ipAddress in _addressList)
                    {
                        string _tmpAddress = _ipAddress.ToString();
                        if (_tmpAddress.Contains("."))
                        {

                            _address = _tmpAddress;
                            // 优先使用201网段的IP
                            if (_address.Contains("10.201"))
                                break;


                        }
                    }
                    lock (_hostDict)
                        _hostDict[Environment.MachineName] = _address;
                }
            }
            catch
            {
                // 屏蔽异常
            }
            return _address;
        }

        /// <summary>
        /// 根据电脑名获取IP地址
        /// </summary>
        /// <param name="computerName">电脑名</param>
        /// <returns>IP地址</returns>
        public static string GetHostAddress(string computerName)
        {
            string _address = computerName;
            if (!string.IsNullOrEmpty(_address))
            {
                try
                {
                    if (_hostDict.ContainsKey(computerName))
                    {
                        _address = _hostDict[computerName];
                    }
                    else
                    {
                        IPAddress[] _addressList = Dns.GetHostAddresses(_address);
                        foreach (IPAddress _ipAddress in _addressList)
                        {
                            string _tmpAddress = _ipAddress.ToString();
                            if (_tmpAddress.Contains("."))
                            {
                                _address = _tmpAddress;
                                // 优先使用10.201网段的IP
                                if (_address.Contains("10.201"))
                                    break;
                            }
                        }
                        lock (_hostDict)
                            _hostDict[computerName] = _address;
                    }
                }
                catch
                {
                    // 屏蔽异常
                }
            }
            return _address;
        }
        /// <summary>
        /// 根据电脑名获取IP地址
        /// </summary>
        /// <param name="computerName">电脑名</param>
        /// <returns>IP地址</returns>
        public static string GetHostAddressByEnvironment()
        {
           return  $"{AppSettings.IP}:{AppSettings.PORT}:{AppSettings.ManagementOption.ProjectName}";
        }
        /// <summary>
        /// 获取电脑终端的名称
        /// </summary>
        public static string GetComputerName()
        {
            // 获取机器名称
            string _computerName = Environment.MachineName;
            // 获取远程登录的信息，以解决云终端配置问题
            try
            {
                string _clientName = Environment.GetEnvironmentVariable("CLIENTNAME");
                // XP系统默认返回CLIENTNAME
                if (!string.IsNullOrEmpty(_clientName) && _clientName.ToUpper() != "CONSOLE")
                    _computerName = string.Format("{0}-{1}", _computerName, _clientName);
            }
            catch
            {
                // 屏蔽异常
            }
            return _computerName.ToUpper();
        }
        /// <summary>
        /// 获取登录账号全名（包含域名）
        /// </summary>
        /// <returns></returns>
        public static string GetFullLoginName()
        {
            // 获取账号名
            string _loginName = Environment.UserName;
            try
            {
                // 获取域名
                string _userDomainName = Environment.UserDomainName;
                _loginName = string.Format(@"{0}\{1}", _userDomainName, _loginName);
            }
            catch
            {
                // 屏蔽异常
            }
            return _loginName.ToUpper();
        }

        #endregion
    }
}
