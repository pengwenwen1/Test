﻿using Multek.Library_Core.ResultModel;
using Spire.Doc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM.Const
{
    public class NacosServerNamesConst
    {
        /// <summary>
        /// 配方
        /// </summary>
        public const string RecipeCenter = "donet-RecipeCenter";
        /// <summary>
        /// 模板
        /// </summary>
        public const string Template = "donet-Template";
        /// <summary>
        /// SPC
        /// </summary>
        public const string SPCExt = "donet-SPCExt";
        /// <summary>
        /// 追溯
        /// </summary>
        public const string Tracebility = "donet-Tracebility";
        /// <summary>
        /// javaPortal页面
        /// </summary>
        public const string Portal = "multek-portal";
        /// <summary>
        /// 网关
        /// </summary>
        public const string Gateway = "mspf-gateway";
        /// <summary>
        /// CamstarApi
        /// </summary>
        public const string CamstarApi = "donet-CamstarApi";
        /// <summary>
        /// DataWarehouse
        /// </summary>
        public const string DataWarehouse = "donet-DataWarehouse";
        /// <summary>
        /// EAPData
        /// </summary>
        public const string EAPData = "donet-EAPData";
    }
}
