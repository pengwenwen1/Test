﻿using Multek.Library_Core.ResultModel;
using Spire.Doc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM.Const
{
    public class NacosApiUrlConst
    {
        /// <summary>
        /// 预警信息
        /// </summary>
        public const string pushMonitoringWarning = "/monitoringWarning/pushMonitoringWarning";
        /// <summary>
        /// token地址
        /// </summary>
        public const string token = "/mspf-auth/oauth/token";

        /// <summary>
        /// 日志地址
        /// </summary>
        public const string log= "/log/request";

        /// <summary>
        /// 异常邮件地址
        /// </summary>
        public const string subscriptionEmail = "/subscriptionEmail/request";
        /// <summary>
        /// movein
        /// </summary>
        public const string movein = "/SYS/WIPMain/MoveIn";
        /// <summary>
        /// 更新同步代码表
        /// </summary>
        public const string DefaultAddElseUpdate = "/COD/CodDesigner/DefaultAddElseUpdate";
        /// <summary>
        /// 上传Webapi的json信息
        /// </summary>
        public const string UploadWebapi = "/SYS/Webapi/UploadWebapi";

        /// <summary>
        /// 上传Model信息
        /// </summary>
        public const string UploadModel = "/SYS/Webapi/UploadModel";
        /// <summary>
        /// 上传Service信息
        /// </summary>
        public const string UploadService = "/SYS/Webapi/UploadService";
    }
}
