﻿using Multek.Library_Core.Model.Token;
using Multek.Library_Core.ResultModel;
using Spire.Doc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM.Const
{
    /// <summary>
    /// 网关类
    /// </summary>
    public class GatewayConst
    {
        /// <summary>
        /// 网关Token信息
        /// </summary>
        public static GatewayToken GatewayToken;
        /// <summary>
        /// 网关地址
        /// </summary>
        public static string Address;
    }
}
