﻿using Multek.Library_Core.Model.Token;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM.Const
{
    public class ApplicationConst
    {
        /// <summary>
        /// 实例
        /// </summary>
        public static string PathModel = "Multek.Applications.Model.dll";
        /// <summary>
        /// 服务接口
        /// </summary>
        public static string PathServices = "Multek.Applications.Services.dll";
        /// <summary>
        /// 服务接口
        /// </summary>
        public static List<string> SwaggerDoc = new List<string>();
    }
}
