﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM.Enum
{
    /// <summary>
    /// 数据库名称
    /// </summary>
    public enum DataNameEnum
    {
        /// <summary>
        /// Quest
        /// </summary>
        Quest,
        /// <summary>
        /// ClickHouse
        /// </summary>
        ClickHouse,
        /// <summary>
        /// Camstar运行库
        /// </summary>
        CamstarWip,
        /// <summary>
        /// Camstar全部备份历史库
        /// </summary>
        CamstarODS,
        /// <summary>
        /// Camstar接口库
        /// </summary>
        CamstarInt,
        /// <summary>
        /// Tracebility
        /// </summary>
        Tracebility,
        /// <summary>
        /// EAPDATA
        /// </summary>
        EAPData,
    }
}
