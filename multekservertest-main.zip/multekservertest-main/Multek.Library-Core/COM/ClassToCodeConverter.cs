﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Primitives;
using Multek.Library_Core.Services.AOP;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static Grpc.Core.Metadata;

namespace Multek.Library_Core.COM
{
    /// <summary>
    /// 类转换器
    /// </summary>
    public static class ClassToCodeConverter
    {
        /// <summary>
        /// 代码转化
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static string ConvertToCodeClickHouse(Type type)
        {
            var _className = type.Name;
            var _tableName = type.GetCustomAttribute<System.ComponentModel.DataAnnotations.Schema.TableAttribute>()?.Name;
            if (string.IsNullOrEmpty(_tableName))
            {
                _tableName = _className;
            }
            //实体类名的属性
            var _classComment= type.GetCustomAttribute<Microsoft.EntityFrameworkCore.CommentAttribute>()?.Comment;
            var _classKey = "";
            var _keyList = type.GetCustomAttribute<Microsoft.EntityFrameworkCore.PrimaryKeyAttribute>()?.PropertyNames;
            if (_keyList!=null)
            {
                _classKey = string.Join(",", _keyList);
            }
            var _properties = type.GetProperties();
            foreach (var item in _properties)
            {
                KeyAttribute keyAttribute = item.GetCustomAttribute<System.ComponentModel.DataAnnotations.KeyAttribute>();
                if (keyAttribute != null)
                {
                    _classKey = item.Name;
                }
            }
            var _methods = type.GetMethods();
            var _dataName = type.GetCustomAttribute<DataWarehouseAttribute>().CurrentData;
           var sb = new StringBuilder();
            sb.AppendLine(String.Format(@"
using Multek.Library_Core.Audit;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Multek.Library_Core.COM.Enum;
using Multek.Applications.Services.Impl.DataWarehouse;
    [SugarTable(TableName =""{0}"",TableDescription = ""{1}"")]
    [SqlSugar.ClickHouse.CKTable(@""engine = ReplacingMergeTree PARTITION BY toYYYYMM(CreatedTime)  ORDER BY ({2}) SETTINGS index_granularity = 8192;"")]
    [Tenant(DataNameEnum.ClickHouse)]
", _className, _classComment, _classKey));
            sb.AppendLine($"public class {_className}");
            sb.AppendLine("{");
            StringBuilder _select = new StringBuilder();
            foreach (var property in _properties)
            {
                //KeyAttribute keyAttribute = property.GetCustomAttribute<KeyAttribute>();
                //var _classColumnComment = property.GetCustomAttribute<CommentAttribute>();
                var _ColumnyAttribute = property.GetCustomAttribute<ColumnAttribute>();
                //if (keyAttribute != null)
                //{
                //    sb.AppendLine("[SugarColumn((IsPrimaryKey = true)])]");
                //    //_classKey = property.Name;
                //}
                //if (_classColumnComment != null)
                //{
                //    sb.AppendLine($"[Column((Description  = \"{_classColumnComment.Comment}\"))]");
                //}
                
                string _propertyName = property.Name;
                // 类型的客制化
                Type _underlyingType = Nullable.GetUnderlyingType(property.PropertyType);
                string _typeName = property.PropertyType.Name;
                if (_typeName.StartsWith("List"))
                {
                    continue;
                }
                if (property.PropertyType.IsEnum ||( _underlyingType != null && (_underlyingType == typeof(int))))
                {
                    _typeName = "int";
                }else if ((property.PropertyType.IsClass&&  _typeName.ToUpper()!= "STRING") || (_underlyingType != null && (_underlyingType == typeof(string))))
                {
                    _typeName = "string";
                    _propertyName += "ID";
                }
                else if (_underlyingType != null && (_underlyingType == typeof(DateTime) || _underlyingType == typeof(DateTimeOffset)))
                {
                    _typeName = "DateTime";

                }else if(_underlyingType != null && (_underlyingType == typeof(Decimal))) 
                {
                    _typeName = "Decimal";
                }
                if (_ColumnyAttribute != null)
                {
                    if (_ColumnyAttribute.Name != null )
                    {
                        _propertyName = _ColumnyAttribute.Name;
                    }
                }
                sb.AppendLine($"    public {_typeName} {_propertyName} {{ get; set; }}");
                if (_typeName == "Double")
                {
                    _select.Append(_select.Length > 0 ? $", ROUND({ _propertyName},4)" :  $"ROUND({_propertyName},4)");
                }
                else
                {
                    _select.Append(_select.Length > 0 ? $", {_propertyName}" :  _propertyName);
                }
            }

            sb.AppendLine();
            // 生成Initdata方法
            sb.AppendLine(
                string.Format(@"
public Paraments InitData(DateTime startTime, DateTime endTime, Paraments key)
        {{
            bool _isUpdate = false;
            if (key == null)
            {{
                key = new Paraments() 
                {{
                            SystemDate = new DateTime(2023, 8, 1, 0, 0, 0) 
                }};
            }}
            var _initData = DataORMMain.Db.GetConnection(DataNameEnum.{1}).SqlQueryable<{0}>(String.Format(@""
SELECT 
    {3}
FROM {2}
WHERE UpdatedTime>  TO_DATE('{{0}}', 'YYYY-MM-DD HH24:MI:SS')
"", key.SystemDate.ToString(""yyyy-MM-dd HH:mm:ss""))).ToList();
            if (_initData.Count > 0)
            {{
                DataORMMain.Save(_initData, DataNameEnum.ClickHouse, _isUpdate);
                key.SystemDate = _initData.Max(x => x.UpdatedTime);
            }}
            return key;
        }}
        public class Paraments
        {{
            public DateTime SystemDate;
        }}
", _className, _dataName, _tableName,_select));
            sb.AppendLine();

            sb.AppendLine("}");
            return sb.ToString();
        }
    }
}
