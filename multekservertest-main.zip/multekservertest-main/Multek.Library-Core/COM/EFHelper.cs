﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.Services;
using System.Linq.Expressions;

namespace Multek.Library_Core.COM
{
    public class EFHelper<TDbContext> : SBaseService where TDbContext : DbContext
    {
        public readonly TDbContext db;
        public EFHelper(TDbContext tdb):base(tdb)
        {
            this.db = tdb;
        }

        
        /// <summary>
        /// 自定义回滚
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public void Rollback()
        {
            foreach (var entry in db.ChangeTracker.Entries())
            {
                switch (entry.State)
                {
                    case EntityState.Modified:
                        entry.State = EntityState.Unchanged;
                        break;
                    case EntityState.Added:
                        entry.State = EntityState.Detached;
                        break;
                    case EntityState.Deleted:
                        entry.Reload();
                        break;
                    case EntityState.Detached:
                        break;
                    case EntityState.Unchanged:
                        break;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }
    }
}
