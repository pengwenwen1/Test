﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.EntityFrameworkCore.Metadata;
using Multek.Library_Core.ResultModel;
using Spire.Pdf.Exporting.XPS.Schema;
using System.Linq;
using System.Linq.Expressions;

namespace Multek.Library_Core.COM
{
    public static class EFHelperEx
    {
        /// <summary>
        /// 根据条件成立再构建 Where 查询，支持索引器
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="sources"></param>
        /// <param name="condition"></param>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static IQueryable<TSource> Where<TSource>(this IQueryable<TSource> sources, bool condition, Expression<Func<TSource, bool>> expression)
        {
            if (!condition)
            {
                return sources;
            }

            return sources.Where(expression);
        }
        /// <summary>
        /// 根据条件成立再构建 Any 查询，支持索引器
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="source"></param>
        /// <param name="condition"></param>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public static bool Any<TSource>(this IEnumerable<TSource> sources, bool condition, Func<TSource, bool> predicate)
        {

            if (!condition)
            {
                return false;
            }

            return sources.Any(predicate);
        }

        public static string GetColumnName(this PropertyEntry propertyEntry)
        {
            var storeObjectId =
                StoreObjectIdentifier.Create(propertyEntry.Metadata.DeclaringEntityType, StoreObjectType.Table);
            return propertyEntry.Metadata.GetColumnName(storeObjectId.GetValueOrDefault()) ?? propertyEntry.Metadata.Name;
        }
    }
}
