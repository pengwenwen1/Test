﻿using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM
{
    public static class DataHelper
    {
        /// <summary>
        /// 转化为Java平台的接口格式
        /// </summary>
        /// <param name="operationResult"></param>
        /// <returns></returns>
        //public static IResultModel ConvertToResultModel(this OperationResult operationResult)
        //{
        //    ResultModel<object> resultModel = new ResultModel<object>();
        //    if (operationResult.Success)
        //    {
        //        resultModel.Success(operationResult.Data);
        //    }
        //    else
        //        resultModel.Failed(operationResult.Data, operationResult.Errors[0].ToString());
        //    return resultModel;
        //}
        /// <summary>
        /// 将字符串里转化为参数 ，使用[]定义
        /// </summary>
        /// <param name="paramenterString"></param>
        /// <returns></returns>
        public static Dictionary<string,string> ConvertToParameters(this string paramenterString)
        {

           string[] _paramenters=   paramenterString.Split('[');
            Dictionary<string, string> _result = new Dictionary<string, string>();
            int _endIndex=0;
            foreach (var item in _paramenters)
            {
                _endIndex = item.IndexOf(']');
                if (_endIndex > 0)
                {
                    _result[item.Substring(0, _endIndex)] = "" ;
                }
            }
            return _result;
        }

        /// <summary>
        /// 字符串填充参数
        /// </summary>
        /// <param name="paramenterString"></param>
        /// <param name="paramenters">参数的信息 ：key表示参数  value：表示值</param>
        /// <returns></returns>
        public static string FillParameters(this string paramenterString, Dictionary<string, string> paramenters)
        {
            foreach (var item in paramenters)
            {
                paramenterString =paramenterString.Replace($"[{item.Key}]", item.Value);
            }
            return paramenterString;
        }
        /// <summary>
        /// 获取实例ID
        /// </summary>
        /// <param name="modelName"></param>
        /// <returns></returns>
        public static string GetInstanceID(string modelName)
        {
            // 获取Redis的缓存数据后，进行数据+1，得到实例对象ID
            return  string.Empty;
        }

        /// <summary>
        /// 16进制加1后的16进制数据
        /// </summary>
        /// <param name="hexString">16进行字符串</param>
        /// <returns></returns>
        public static string Add(this string hexString,int count=1)
        {
            return (Convert.ToInt64(hexString,16)+1).ToString("X");
        }
        /// <summary>
        /// 在字符串之前新增项目名称
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns></returns>
        public static string AddProjectName(this string str)
        {
            return AppSettings.ManagementOption.ProjectName + "_" + str;
        }

    }
}
