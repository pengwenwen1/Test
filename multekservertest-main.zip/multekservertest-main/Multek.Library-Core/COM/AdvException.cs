﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM
{
    /// <summary>
    /// 异常信息内容生成器
    /// </summary>
    public static class AdvException
    {
        /// <summary>
        /// 获取异常信息内容
        /// </summary>
        /// <param name="ex">异常</param>
        /// <returns></returns>
        public static string GetExceptionMessage(Exception ex)
        {
            // 收集异常的详细信息
            StringBuilder _stringBuilder = new StringBuilder();
            try
            {
                // 收集异常描述
                _stringBuilder.Append("Message: " + ex.Message + "<BR>");
                // 收集异常类型
                _stringBuilder.Append("Type: " + ex.GetType().Name + "<BR>");
                // 收集异常来源
                _stringBuilder.Append("Source: " + ex.Source + "<BR>");
                // 收集类型名称
                _stringBuilder.Append("Occured By: " + ex.TargetSite?.Name.ToString() + "<BR>");
                // 收集方法名称
                _stringBuilder.Append("MemberType: " + ex.TargetSite?.MemberType.ToString() + "<BR>");
                // 收集发生的异常点
                _stringBuilder.Append("Occur At: <BR>");
                Exception _innerException = ex.InnerException;
                if (_innerException != null)
                {
                    List<Exception> _innerExceptionList = new List<Exception>();
                    while (_innerException != null)
                    {
                        _innerExceptionList.Add(_innerException);
                        _innerException = _innerException.InnerException;
                    }
                    for (int i = _innerExceptionList.Count - 1; i >= 0; i--)
                    {
                        // 收集每个层级的代码跟踪记录
                        _stringBuilder.Append("Level: " + i.ToString() + "<BR>");
                        _stringBuilder.Append($"Message: {(_innerExceptionList[i]).Message}<BR>");
                        _stringBuilder.Append(((Exception)_innerExceptionList[i]).StackTrace + "<BR>");
                    }
                }
                _stringBuilder.Append(ex.StackTrace);
            }
            catch (Exception baseEx)
            {
                _stringBuilder.Append("<BR>" + baseEx.Message);
            }
            return _stringBuilder.ToString().Replace("\r\n", "\n").Replace("\n", "<BR>");
        }

        /// <summary>
        /// 检验异常信息是否需要反馈给系统管理员
        /// </summary>
        /// <param name="ex">异常信息</param>
        /// <returns></returns>
        public static bool NeedFeedback(Exception ex)
        {
            if (ex as Win32Exception != null)
            {
                // 操作系统异常不需要发送异常信息
                return false;
            }
            else if (ex as DBConcurrencyException != null)
            {
                // 数据并发异常不需要发送异常信息
                return false;
            }
            //else if (ex as ExternalException != null)
            //{
            //    // 扩展项异常不需要发送异常信息
            //    return false;
            //}
            else if (ex as TargetInvocationException != null)
            {
                // 反应调用异常不需要发送异常信息
                return false;
            }
            else if (ex as AccessViolationException != null)
            {
                // 读写保护内存异常不需要发送异常信息
                return false;
            }
            else if (ex as OutOfMemoryException != null)
            {
                // 内存不足异常不需要发送异常信息
                return false;
            }
            else
            {
                // 需要把异常信息反馈给系统管理员
                return true;
            }
        }
    }
}