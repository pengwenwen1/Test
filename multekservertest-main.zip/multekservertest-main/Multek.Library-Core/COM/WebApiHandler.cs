﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Net;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using SqlSugar;
using Microsoft.AspNetCore.Mvc.Formatters;
using System.Net.Http;

namespace Multek.Library_Core.COM
{
    public class WebApiHandler
    {
        public string Get(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> param = null,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string uriString = UrlName.TrimEnd('/');
                if (uriString.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                httpClient.BaseAddress = new Uri(uriString);
                if (Token != null)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                if (param != null && param.Count > 0)
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    foreach (KeyValuePair<string, string> keyValuePair in param)
                        stringBuilder.Append(keyValuePair.Key + "=" + keyValuePair.Value + "&");
                    RequestRoute = string.Format("{0}?{1}", (object)RequestRoute, (object)stringBuilder).TrimEnd('&');
                }
                return httpClient.GetAsync(RequestRoute).Result.Content.ReadAsStringAsync().Result;
            }
        }



        public async Task<HttpResponseMessage> GetOriginalAsync<TParam>(
          string UrlName,
          string RequestRoute,
          TParam param,
          string Token = null)
          where TParam : class, new()
        {
            HttpResponseMessage async;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false,
                AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                _httpClient.BaseAddress = new Uri(Url);
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                RequestRoute = (RequestRoute + "?" + this.GenericityToRequstString<TParam>(param)).TrimEnd('&');
                async = await _httpClient.GetAsync(RequestRoute);
            }
            return async;
        }

        public static HttpResponseMessage GetOriginalAsync(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> param = null,
          string Token = null)
        {
            HttpResponseMessage async;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                _httpClient.BaseAddress = new Uri(Url);
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                if (param != null && param.Count > 0)
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    foreach (KeyValuePair<string, string> keyValuePair in param)
                    {
                        KeyValuePair<string, string> item = keyValuePair;
                        stringBuilder.Append(item.Key + "=" + item.Value + "&");
                        item = new KeyValuePair<string, string>();
                    }
                    RequestRoute = string.Format("{0}?{1}", (object)RequestRoute, (object)stringBuilder).TrimEnd('&');
                    stringBuilder = (StringBuilder)null;
                }
                async = _httpClient.GetAsync(RequestRoute).Result;
            }
            return async;
        }

        public HttpResponseMessage GetOriginal(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> param = null,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string uriString = UrlName.TrimEnd('/');
                if (uriString.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                httpClient.BaseAddress = new Uri(uriString);
                if (Token != null)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                if (param != null && param.Count > 0)
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    foreach (KeyValuePair<string, string> keyValuePair in param)
                        stringBuilder.Append(keyValuePair.Key + "=" + keyValuePair.Value + "&");
                    RequestRoute = string.Format("{0}?{1}", (object)RequestRoute, (object)stringBuilder).TrimEnd('&');
                }
                return httpClient.GetAsync(RequestRoute).Result;
            }
        }

        private string GenericityToRequstString<T>(T Genericity) => string.Join("&", ((IEnumerable<PropertyInfo>)Genericity.GetType().GetProperties()).AsEnumerable<PropertyInfo>().Select<PropertyInfo, string>((Func<PropertyInfo, string>)(x => (x.Name + "=" + (x.GetValue((object)(T)Genericity, (object[])null) == null ? string.Empty : (x.PropertyType.IsValueType ? x.GetValue((object)(T)Genericity, (object[])null).ToString() : JsonConvert.SerializeObject(x.GetValue((object)(T)Genericity, (object[])null))))).ToString())));

        public string Post(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> param,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string uriString = UrlName.TrimEnd('/');
                if (uriString.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                httpClient.BaseAddress = new Uri(uriString);
                if (Token != null)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                HttpContent content = (HttpContent)new StringContent(JsonConvert.SerializeObject((object)param), Encoding.UTF8);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpResponseMessage result = httpClient.PostAsync(RequestRoute, content).Result;
                return result.IsSuccessStatusCode ? result.Content.ReadAsStringAsync().Result : (string)null;
            }
        }

        public static HttpResponseMessage PostOriginal(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> param,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string uriString = UrlName.TrimEnd('/');
                if (uriString.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                httpClient.BaseAddress = new Uri(uriString);
                if (Token != null)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                HttpContent content = (HttpContent)new StringContent(JsonConvert.SerializeObject((object)param), Encoding.UTF8);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                return httpClient.PostAsync(RequestRoute, content).Result;
            }
        }

        public async Task<HttpResponseMessage> PostOriginalAsync<T, TParam>(
          string UrlName,
          string RequestRoute,
          TParam param,
          string Token = null)
          where T : class, new()
          where TParam : class, new()
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                _httpClient.BaseAddress = new Uri(Url);
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                string jParam = JsonConvert.SerializeObject((object)(TParam)param);
                HttpContent httpContent = (HttpContent)new StringContent(jParam, Encoding.UTF8);
                httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                httpResponseMessage = await _httpClient.PostAsync(RequestRoute, httpContent);
            }
            return httpResponseMessage;
        }
        private static bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;

        }
        public static HttpResponseMessage PostOriginalAsyncForGateway<TParam>(
          string UrlName,
          string RequestRoute,
          TParam param,
          string Token = null)
          where TParam : class, new()
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    //越过HTTPS认证
                    ServicePointManager.ServerCertificateValidationCallback += ValidateServerCertificate;
                _httpClient.BaseAddress = new Uri(Url);
                _httpClient.DefaultRequestHeaders.Add("Tenant-Id", "000000");
                _httpClient.DefaultRequestHeaders.Add("Authorization", "Basic c2FiZXI6c2FiZXJfc2VjcmV0");
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                string jParam = JsonUrlEncode(JsonConvert.SerializeObject((object)(TParam)param));
                HttpContent httpContent = (HttpContent)new StringContent(jParam, Encoding.UTF8);
                httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
                httpResponseMessage = _httpClient.PostAsync(RequestRoute, httpContent).Result;
            }
            return httpResponseMessage;
        }

        public static HttpResponseMessage PostOriginalAsyncForJson<TParam>(
          string UrlName,
          string RequestRoute,
          TParam param)
          where TParam : class, new()
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    //越过HTTPS认证
                    ServicePointManager.ServerCertificateValidationCallback += ValidateServerCertificate;
                _httpClient.BaseAddress = new Uri(Url);

                string code = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(string.Format("{0}:{1}", "admin", "123456")));
                _httpClient.DefaultRequestHeaders.Add("Authorization", "Basic "+code);
                
                string jParam = JsonConvert.SerializeObject((object)(TParam)param);
                HttpContent httpContent = (HttpContent)new StringContent(jParam, Encoding.UTF8);
                httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
               
                httpResponseMessage = _httpClient.PostAsync(RequestRoute, httpContent).Result;

            }
            return httpResponseMessage;
        }

        public static HttpResponseMessage PostOriginalAsync<TParam>(
          string UrlName,
          string RequestRoute,
          TParam param,
          string Token = null)
          where TParam : class
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false,
                ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    //越过HTTPS认证
                    ServicePointManager.ServerCertificateValidationCallback += ValidateServerCertificate;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;

                _httpClient.BaseAddress = new Uri(Url);
                _httpClient.DefaultRequestHeaders.Add("Tenant-Id", "000000");
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Add("mspf-Auth", $"bearer {Token}");
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", "c2FiZXI6c2FiZXJfc2VjcmV0");
                string jParam = JsonConvert.SerializeObject(param);
                   // JsonConvert.SerializeObject((object)(TParam)param);
                HttpContent httpContent = (HttpContent)new StringContent(jParam, Encoding.UTF8);
                httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                httpResponseMessage = _httpClient.PostAsync(RequestRoute, httpContent).Result;
            }
            return httpResponseMessage;
        }
        /// <summary>
        /// json转urlencode
        /// </summary>
        /// <returns></returns>
        public static string JsonUrlEncode(string json)
        {
            Dictionary<string, object> dic = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
            StringBuilder builder = new StringBuilder();
            foreach (KeyValuePair<string, object> item in dic)
            {
                builder.Append(GetFormDataContent(item, ""));
            }
            return builder.ToString().TrimEnd('&');
        }

        /// <summary>
        /// 递归转formdata
        /// </summary>
        /// <param name="item"></param>
        /// <param name="preStr"></param>
        /// <returns></returns>
        private static string GetFormDataContent(KeyValuePair<string, object> item, string preStr)
        {
            StringBuilder builder = new StringBuilder();
            if (string.IsNullOrEmpty(item.Value?.ToString()))
            {
                builder.AppendFormat("{0}={1}", string.IsNullOrEmpty(preStr) ? item.Key : (preStr + "[" + item.Key + "]"), System.Web.HttpUtility.UrlEncode((item.Value == null ? "" : item.Value.ToString()).ToString()));
                builder.Append("&");
            }
            else
            {
                //如果是数组
                if (item.Value.GetType().Name.Equals("JArray"))
                {
                    var children = JsonConvert.DeserializeObject<List<object>>(item.Value.ToString());
                    for (int j = 0; j < children.Count; j++)
                    {
                        Dictionary<string, object> childrendic = JsonConvert.DeserializeObject<Dictionary<string, object>>(JsonConvert.SerializeObject(children[j]));
                        foreach (var row in childrendic)
                        {
                            builder.Append(GetFormDataContent(row, string.IsNullOrEmpty(preStr) ? (item.Key + "[" + j + "]") : (preStr + "[" + item.Key + "][" + j + "]")));
                        }
                    }

                }
                //如果是对象
                else if (item.Value.GetType().Name.Equals("JObject"))
                {
                    Dictionary<string, object> children = JsonConvert.DeserializeObject<Dictionary<string, object>>(item.Value.ToString());
                    foreach (var row in children)
                    {
                        builder.Append(GetFormDataContent(row, string.IsNullOrEmpty(preStr) ? item.Key : (preStr + "[" + item.Key + "]")));
                    }
                }
                //字符串、数字等
                else
                {
                    builder.AppendFormat("{0}={1}", string.IsNullOrEmpty(preStr) ? item.Key : (preStr + "[" + item.Key + "]"), System.Web.HttpUtility.UrlEncode((item.Value == null ? "" : item.Value.ToString()).ToString()));
                    builder.Append("&");
                }
            }

            return builder.ToString();
        }
        /// <summary>
        /// 使用Post方法获取字符串结果
        /// </summary>
        /// <param name="url"></param>
        /// <param name="formItems">Post表单内容</param>
        /// <param name="cookieContainer"></param>
        /// <param name="timeOut">默认20秒</param>
        /// <param name="encoding">响应内容的编码类型（默认utf-8）</param>
        /// <returns></returns>
        public static string PostForm(string url, List<FormItemModel> formItems, CookieContainer cookieContainer = null, string refererUrl = null, Encoding encoding = null, int timeOut = 20000)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            #region 初始化请求对象
            request.Method = "POST";
            request.Timeout = timeOut;
            request.Accept = "*/*";
            request.KeepAlive = true;
            request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36";
            request.Headers.Add(new HttpRequestHeader(), "application/json");
            if (!string.IsNullOrEmpty(refererUrl))
                request.Referer = refererUrl;
            if (cookieContainer != null)
                request.CookieContainer = cookieContainer;
            #endregion

            string boundary = "----" + DateTime.Now.Ticks.ToString("x");//分隔符
            request.ContentType = string.Format("multipart/form-data; boundary={0}", boundary);
            //请求流
            var postStream = new MemoryStream();
            #region 处理Form表单请求内容
            //是否用Form上传文件
            var formUploadFile = formItems != null && formItems.Count > 0;
            if (formUploadFile)
            {
                //文件数据模板
                string fileFormdataTemplate =
                    "\r\n--" + boundary +
                    "\r\nContent-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"" +
                    "\r\nContent-Type: application/octet-stream" +
                    "\r\n\r\n";
                //文本数据模板
                string dataFormdataTemplate =
                    "\r\n--" + boundary +
                    "\r\nContent-Disposition: form-data; name=\"{0}\"" +
                    "\r\n\r\n{1}";
                foreach (var item in formItems)
                {
                    string formdata = null;
                    if (item.IsFile)
                    {
                        //上传文件
                        formdata = string.Format(
                            fileFormdataTemplate,
                            item.Key, //表单键
                            item.FileName);
                    }
                    else
                    {
                        //上传文本
                        formdata = string.Format(
                            dataFormdataTemplate,
                            item.Key,
                            item.Value);
                    }

                    //统一处理
                    byte[] formdataBytes = null;
                    //第一行不需要换行
                    postStream.Position = 0;
                    if (postStream.Length == 0)
                        formdataBytes = Encoding.UTF8.GetBytes(formdata.Substring(2, formdata.Length - 2));
                    else
                        formdataBytes = Encoding.UTF8.GetBytes(formdata);
                    postStream.Write(formdataBytes, 0, formdataBytes.Length);

                    //写入文件内容

                    if (item.FileContent != null && item.FileContent.Length > 0)
                    {
                        using (var stream = item.FileContent)
                        {
                            byte[] buffer = new byte[item.FileContent.Length];
                            stream.Read(buffer, 0, buffer.Length);
                            postStream.Write(buffer, 0, buffer.Length);
                            //File.WriteAllBytes(string.Format( @"C:\Users\mcn_mespro\Desktop\SPC\{0}", formItems[0].FileName), buffer);

                        }
                    }
                }
                //结尾
                var footer = Encoding.UTF8.GetBytes("\r\n--" + boundary + "--\r\n");
                postStream.Write(footer, 0, footer.Length);

            }
            else
            {
                request.ContentType = "application/x-www-form-urlencoded";
            }
            #endregion

            request.ContentLength = postStream.Length;

            #region 输入二进制流
            if (postStream != null)
            {
                postStream.Position = 0;
                //直接写入流
                Stream requestStream = request.GetRequestStream();

                byte[] buffer = new byte[postStream.Length];
                postStream.Read(buffer, 0, buffer.Length);
                requestStream.Write(buffer, 0, buffer.Length);

                ////debug
                //postStream.Seek(0, SeekOrigin.Begin);
                //StreamReader sr = new StreamReader(postStream);
                //var postStr = sr.ReadToEnd();
                postStream.Close();//关闭文件访问
            }
            #endregion


            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (cookieContainer != null)
            {
                response.Cookies = cookieContainer.GetCookies(response.ResponseUri);
            }

            using (Stream responseStream = response.GetResponseStream())
            {
                StreamReader myStreamReader = new StreamReader(responseStream, encoding ?? Encoding.UTF8);
                string retString = myStreamReader.ReadToEnd();
                return retString;
            }
        }

        public string Put(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> param,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string uriString = UrlName.TrimEnd('/');
                if (uriString.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                httpClient.BaseAddress = new Uri(uriString);
                if (Token != null)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                ByteArrayContent byteArrayContent = new ByteArrayContent(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject((object)param)));
                byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                return httpClient.PutAsync(RequestRoute, (HttpContent)byteArrayContent).Result.Content.ReadAsStringAsync().Result;
            }
        }

        public HttpResponseMessage PutOriginal(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> param,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string uriString = UrlName.TrimEnd('/');
                if (uriString.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                httpClient.BaseAddress = new Uri(uriString);
                if (Token != null)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                ByteArrayContent byteArrayContent = new ByteArrayContent(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject((object)param)));
                byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                return httpClient.PutAsync(RequestRoute, (HttpContent)byteArrayContent).Result;
            }
        }

        public async Task<HttpResponseMessage> PutOriginalAsync<T, TParam>(
          string UrlName,
          string RequestRoute,
          TParam param,
          string Token = null)
          where T : class, new()
          where TParam : class, new()
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                _httpClient.BaseAddress = new Uri(Url);
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                byte[] bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject((object)(TParam)param));
                ByteArrayContent byteArrayContent = new ByteArrayContent(bytes);
                byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpResponseMessage result = await _httpClient.PutAsync(RequestRoute, (HttpContent)byteArrayContent);
                httpResponseMessage = result;
            }
            return httpResponseMessage;
        }


        public static HttpResponseMessage PutOriginalAsync<TParam>(
          string UrlName,
          string RequestRoute,
          TParam param,
          string headersContentType = "application/json",
          string Token = null)
          where TParam : class, new()
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                _httpClient.BaseAddress = new Uri(Url);
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                byte[] bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject((object)(TParam)param));
                ByteArrayContent byteArrayContent = new ByteArrayContent(bytes);
                byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue(headersContentType);
                httpResponseMessage = _httpClient.PutAsync(RequestRoute, (HttpContent)byteArrayContent).Result;
            }
            return httpResponseMessage;
        }

        public string Delete(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> dic,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                httpClient.BaseAddress = new Uri(UrlName.TrimEnd('/'));
                if (Token != string.Empty)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                if (dic != null && dic.Count > 0)
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    foreach (KeyValuePair<string, string> keyValuePair in dic)
                        stringBuilder.Append(keyValuePair.Key + "=" + keyValuePair.Value + "&");
                    RequestRoute = string.Format("{0}?{1}", (object)RequestRoute, (object)stringBuilder).TrimEnd('&');
                }
                return httpClient.DeleteAsync(RequestRoute).Result.Content.ReadAsStringAsync().Result;
            }
        }


        public HttpResponseMessage DeleteOriginal(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> dic,
          string Token = null)
        {
            using (HttpClient httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                httpClient.BaseAddress = new Uri(UrlName.TrimEnd('/'));
                if (Token != string.Empty)
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                if (dic != null && dic.Count > 0)
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    foreach (KeyValuePair<string, string> keyValuePair in dic)
                        stringBuilder.Append(keyValuePair.Key + "=" + keyValuePair.Value + "&");
                    RequestRoute = string.Format("{0}?{1}", (object)RequestRoute, (object)stringBuilder).TrimEnd('&');
                }
                return httpClient.DeleteAsync(RequestRoute).Result;
            }
        }

        public async Task<HttpResponseMessage> DeleteOriginalAsync(
          string UrlName,
          string RequestRoute,
          Dictionary<string, string> dic,
          string Token = null)
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                _httpClient.BaseAddress = new Uri(Url);
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                if (dic != null && dic.Count > 0)
                {
                    foreach (KeyValuePair<string, string> keyValuePair in dic)
                    {
                        KeyValuePair<string, string> item = keyValuePair;
                        _httpClient.DefaultRequestHeaders.Add(item.Key, item.Value);
                        item = new KeyValuePair<string, string>();
                    }
                }
                HttpResponseMessage result = await _httpClient.DeleteAsync(RequestRoute);
                httpResponseMessage = result;
            }
            return httpResponseMessage;
        }

        public async Task<HttpResponseMessage> DeleteOriginalAsync<TParam>(
          string UrlName,
          string RequestRoute,
          TParam param,
          string Token = null)
          where TParam : class, new()
        {
            HttpResponseMessage httpResponseMessage;
            using (HttpClient _httpClient = new HttpClient((HttpMessageHandler)new HttpClientHandler()
            {
                UseCookies = false
            }))
            {
                string Url = UrlName.TrimEnd('/');
                if (Url.StartsWith("https"))
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                _httpClient.BaseAddress = new Uri(Url);
                if (Token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                RequestRoute = (RequestRoute + "?" + this.GenericityToRequstString<TParam>(param)).TrimEnd('&');
                httpResponseMessage = await _httpClient.DeleteAsync(RequestRoute);
            }
            return httpResponseMessage;
        }
    }
    /// <summary>
    /// 表单数据项
    /// </summary>
    public class FormItemModel
    {
        /// <summary>
        /// 表单键，request["key"]
        /// </summary>
        public string Key { set; get; }
        /// <summary>
        /// 表单值,上传文件时忽略，request["key"].value
        /// </summary>
        public string Value { set; get; }
        /// <summary>
        /// 是否是文件
        /// </summary>
        public bool IsFile
        {
            get
            {
                if (FileContent == null || FileContent.Length == 0)
                    return false;

                if (FileContent != null && FileContent.Length > 0 && string.IsNullOrWhiteSpace(FileName))
                    throw new Exception("上传文件时 FileName 属性值不能为空");
                return true;
            }
        }
        /// <summary>
        /// 上传的文件名
        /// </summary>
        public string FileName { set; get; }
        /// <summary>
        /// 上传的文件内容
        /// </summary>
        public Stream FileContent { set; get; }
    }

}