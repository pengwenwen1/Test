﻿using Castle.DynamicProxy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM
{
    public class InterceptorHelper
    {
        public static string GenerateCacheKey(IInvocation invocation)
        {
            var arguments = new List<string>();

            foreach (var argument in invocation.Arguments)
            {
                arguments.Add(argument != null ? argument.ToString() : "null");
            }

            return $"{invocation.TargetType.FullName}.{invocation.Method.Name}({string.Join(",", arguments)})";
        }
    }
}
