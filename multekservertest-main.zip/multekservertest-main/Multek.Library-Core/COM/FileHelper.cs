﻿using Multek.Library_Core.ResultModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Library_Core.COM
{
    public static class FileHelper
    {
        /// <summary>
        /// 判断用户对文件夹是否有写入权限
        /// </summary>
        /// <param name="destFolder">文件夹地址</param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool IfFolderCanWrite(string destFolder, out string message)
        {
            bool result = false;
            bool canWrite = false;
            message = "文件夹不可以被写入!";

            string NtAccountName = @"MULTEK\MCN_EAPPRO";
            if (!Directory.Exists(destFolder))
            {
                message = "目标文件夹不存在";
                return result;
            }
            else
            {
                string _fileName = string.Format(@"{0}\temp", destFolder);
                File.WriteAllText(_fileName, _fileName);
                File.Delete(_fileName);
                return true;
                //DirectorySecurity s = new DirectorySecurity(destFolder, AccessControlSections.All);
                //AuthorizationRuleCollection rules = s.GetAccessRules(true, false, typeof(System.Security.Principal.NTAccount));
                //foreach (FileSystemAccessRule rule in rules)
                //{
                //    if (rule.IdentityReference.Value.Equals(NtAccountName, StringComparison.CurrentCultureIgnoreCase))
                //    {
                //        var filesystemAccessRule = (FileSystemAccessRule)rule;

                //        if ((filesystemAccessRule.FileSystemRights & FileSystemRights.WriteData) > 0 && filesystemAccessRule.AccessControlType != AccessControlType.Deny)
                //        {
                //            result = true;
                //        }
                //    }
                //}
            }
            return result;
        }
        /// <summary>
        /// 上传Ftp文件服务器
        /// </summary>
        /// <param name="fileStream">文件流</param>
        /// <param name="fileName">文件名称</param>
        /// <param name="FtpPath">Ftp路径</param>
        /// <returns></returns>
        public static FtpResultData Upload(Stream fileStream,string fileName,string category,string userCode, string FtpPath= "http://10.201.48.20:8085/")
        {
            // 构建 From上传数据
            List<FormItemModel> _formItemModelsList = new List<FormItemModel>();
            FormItemModel _formItemModel = new FormItemModel();
            _formItemModel.Key = "file";
            _formItemModel.FileContent = fileStream;
            _formItemModel.FileName = fileName;
            _formItemModelsList.Add(_formItemModel);
            try
            {
                string _resultStr = WebApiHandler.PostForm(FtpPath + string.Format("Upload/UploadFileApi?category={0}&creator={1}",category,userCode), _formItemModelsList);
                //处理返回信息
                FtpResultData _resultModel = JsonConvert.DeserializeObject<FtpResultData>(_resultStr);
                fileStream.Close();
                return _resultModel;
            }
            catch (Exception ex)
            {
                FtpResultData _ftpResultData = new FtpResultData();
                _ftpResultData.Success = false;
                _ftpResultData.msg = AdvException.GetExceptionMessage(ex);
                return _ftpResultData;
            }
        }
        public class FtpResultData
        {
            public bool Success;
            public string msg;
            public List<FtpResultDataItem> data;
        }
        public class FtpResultDataItem
        {
            public string name;
            public string documentno;
        }

    }
}
