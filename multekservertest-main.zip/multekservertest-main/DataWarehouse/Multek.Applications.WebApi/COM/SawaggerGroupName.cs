﻿namespace Multek.Applications.WebApi.COM
{
    /// <summary>
    /// 模块常量定义类
    /// </summary>
    public class SawaggerGroupName
    {
        public const string COD = "COD";
        public const string SYS = "SYS";
    }
}
