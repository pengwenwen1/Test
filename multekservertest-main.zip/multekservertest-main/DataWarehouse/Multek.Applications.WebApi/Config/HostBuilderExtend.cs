﻿using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model;
using Multek.Applications.Services.Impl.DataWarehouse;
using Multek.Library_Core.BGService;
using Multek.Library_Core.DbContexts;
using Nacos.AspNetCore.V2;
using Nacos.V2.DependencyInjection;
using Newtonsoft.Json;

namespace Multek.Applications.WebApi.Config
{

    /// <summary>
    /// 扩展类
    /// </summary>
    public static class HostBuilderExtend
    {
        public static void Register(this WebApplicationBuilder builder)
        {
            builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());
            builder.Host.ConfigureContainer<ContainerBuilder>(builder =>
            {
                builder.RegisterModule(new AutofacModuleRegister());
            });

            //Automapper映射
            builder.Services.AddAutoMapper(typeof(AutoMapperConfigs));
            //builder.Services.AddHostedService<DataWarehouseBackgroundService>();
            
            builder.Services.AddControllersWithViews()
    .AddNewtonsoftJson(options =>
    {
        options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
    });
            // 上下文池
            builder.Services.AddDbContextPool<MultekServerDbContext>(
    x =>
        {
            x.UseSqlServer(builder.Configuration.GetConnectionString("SqlDb")).AddInterceptors(new ShardingDbCommandInterceptor());
            //x.UseOracle(builder.Configuration.GetConnectionString("OracleDb")).AddInterceptors(new ShardingDbCommandInterceptor());
            x.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
        });
        }
    }
}
