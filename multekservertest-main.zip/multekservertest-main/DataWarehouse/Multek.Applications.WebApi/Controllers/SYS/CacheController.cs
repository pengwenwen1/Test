﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using System.Configuration;
using System.Diagnostics;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.COM;
using Multek.Library_Core.Model.Token;
using Newtonsoft.Json;
using Multek.Library_Core.ServicesInface;
using System.Net;
using Multek.Library_Core.Redis;
using Multek.Library_Core.WebApi.Filters;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Caching.Distributed;

namespace Multek.Applications.WebApi.Controllers.SYS
{
    /// <summary>
    /// 缓存系统
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class CacheController : Controller
    {
        private readonly IDistributedLock _distributedLock;
        private readonly IMemoryCache _imemoryCache;
        private readonly IDistributedCache _distributedCache;
        public CacheController(IDistributedLock distributedLock, IMemoryCache memoryCache, IDistributedCache distributedCache)
        {
            _distributedLock = distributedLock;
            _imemoryCache = memoryCache;
            _distributedCache = distributedCache;
        }

        /// <summary>
        /// Redis锁
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public RedisLockHandle RedisGetRedisLock()
        {
            return (RedisLockHandle)_distributedLock.Lock("GetRedisLock");
        }
        /// <summary>
        /// 尝试获取Redis锁
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public RedisLockHandle RedisGetTryLock()
        {
            return (RedisLockHandle)_distributedLock.TryLock("GetRedisLock");
        }
        /// <summary>
        /// 获取锁后，进行释放
        /// </summary>
        [HttpPost]
        public void RedisLockRealse()
        {
            using (var handle = _distributedLock.TryLock("GetRedisLock"))
            {
                if (handle != null)
                {
                    Thread.Sleep(1000);
                    handle.Dispose();
                }

            }
        }
        ///// <summary>
        ///// AOPFiler实现队列
        ///// </summary>
        //[HttpPost]
        ////[QueueLimitFilter(IsBlock = false, IsUseParameter = true, IsUseToken = false)]
        //[CacheDataActionFilter(IsUsePost = true, IsUseToken = false, Second = 100)]
        //public string RedisGetLiemtLock(Book LockName)
        //{
        //    return "Good";
        //}
        
        
        
        /// <summary>
        /// 设置内存缓存
        /// </summary>
        [HttpPost]
        public string SetMemoryCache(string key,string value)
        {
           _imemoryCache.Set(key, value);
            return "OK";
        }
        /// <summary>
        /// 获取内存缓存
        /// </summary>
        [HttpPost]
        public string GetMemoryCache(string key)
        {
            return _imemoryCache.Get<string>(key);
        }
        /// <summary>
        /// 设置分布式缓存
        /// </summary>
        [HttpPost]
        public string SetDistributedCache(string key, string value)
        {
            _distributedCache.Set(key, value);
            return "OK";
        }
        /// <summary>
        /// 获取分布式缓存
        /// </summary>
        [HttpPost]
        public string GetDistributedyCache(string key)
        {
            return _distributedCache.GetString(key);
        }

        /// <summary>
        /// 设置数据仓库是否运行 true表示运行 ，false：停止运行
        /// </summary>
        [HttpPost]
        public string SetDataWarehouseAllowRun(bool value)
        {
            _distributedCache.Set("DataWarehouse", value, new DateTimeOffset(DateTime.MaxValue));
            return "OK";
        }
        /// <summary>
        /// 获取分布式缓存
        /// </summary>
        [HttpPost]
        public string GetDataWarehouseAllowRun()
        {
            return _distributedCache.GetString("DataWarehouse");
        }
    }
}
