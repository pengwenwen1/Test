﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using Multek.Applications.Services.COD;
using Multek.Applications.Data.DataWarehous;

namespace Multek.Applications.WebApi.Controllers.COD
{
    /// <summary>
    /// 代码设计管理
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.COD)]
    [Route($"{SawaggerGroupName.COD}/[controller]/[action]")]
    [ApiController]
    public class CodDesignerController : Controller
    {
        private ICodDesigner _codDesigner;
        public CodDesignerController(ICodDesigner codDesigner)
        {
            _codDesigner = codDesigner;

        }

        /// <summary>
        /// 更新代码设计
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel DefaultAddElseUpdate(List<CodDesigner> codDesigner)
        {
            return _codDesigner.DefaultAddElseUpdate(codDesigner);
        }
    }
}
