﻿using Microsoft.AspNetCore.Http;
using Multek.Applications.Data.DataWarehous;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.COD
{
    public interface ICodDesigner
    {
        /// <summary>
        /// 新增对象
        /// </summary>
        /// <param name="codDesigner"></param>
        /// <returns></returns>
        public IResultModel DefaultAddElseUpdate(List<CodDesigner> codDesigner);
    }
}
