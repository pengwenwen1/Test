﻿using Multek.Library_Core.COM.Enum;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.DataWarehouse
{
    public interface  IDataORMMain
    {

        /// <summary>
        /// 获取数据库里面的数据，并且会写到指定代码中
        /// </summary>
        /// <typeparam name="T">指定的实例对象</typeparam>
        /// <returns></returns>
        public void GetData<T>();
    }

}