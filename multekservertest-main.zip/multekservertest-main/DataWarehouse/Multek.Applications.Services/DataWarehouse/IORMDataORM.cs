﻿using Microsoft.CodeAnalysis.Scripting;
using Multek.Library_Core.COM.Enum;
using Multek.Library_Core.COM;
using Newtonsoft.Json;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.DataWarehouse
{
    public interface IORMDataORM
    {
        /// <summary>
        /// 
        /// </summary>
        public void InitORM();

        /// <summary>
        /// 初始化接口方法
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public void Init<T>();

        /// <summary>
        /// 执行数据仓库同步
        /// </summary>
        public void InitDW(DataNameEnum dataName);

    }

}