﻿using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities.Sample;
using Multek.Applications.Services.Sample;
using Multek.Library_Core.COM;
using Multek.Library_Core.Services;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.Sample
{
    public class SCommService : EFHelper<MultekServerDbContext>,ICommService
    {
        //public override SampleDbContext GetDbContext()
        //{
        //    return new SampleDbContext();
        //}
        //public OperationResult AddBook(Book book)
        //{
        //    book.Id = Guid.NewGuid();
        //    book.Date = DateTime.Now;
        //    return AddEntity(book);
        //}

        //public OperationResult DeleteBooks(IEnumerable<Guid> ids)
        //{
        //    return DeleteEntities<Book>(x => ids.Contains(x.Id));
        //}
        public SCommService(MultekServerDbContext tdb) : base(tdb)
        {
        }
    }
}
