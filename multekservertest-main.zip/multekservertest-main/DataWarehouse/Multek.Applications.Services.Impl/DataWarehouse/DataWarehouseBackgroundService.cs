﻿using Microsoft.Extensions.Hosting;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.COM;
using Multek.Library_Core.Model.Token;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Multek.Library_Core.COM.Enum;
using Multek.Library_Core.Quest.QuestInterface;
using Multek.Library_Core.Quest.QuestEntity;
using Microsoft.Extensions.Caching.Distributed;
using Multek.Library_Core.Redis;
using Multek.Applications.Services.Impl.Entity.FirstCode;
using SubscriptionEmailEntity = Multek.Library_Core.Quest.QuestEntity.SubscriptionEmailEntity;
using Microsoft.Extensions.Configuration;

namespace Multek.Applications.Services.Impl.DataWarehouse
{
    public class DataWarehouseBackgroundService : BackgroundService
    {
        public IORMDataORM _IORMDataORM;
        private static readonly TimeSpan _delaytimeSpan = new TimeSpan(0, 10, 0);
        public ISubscriptionEmail _subscriptionEmail;
        public IDistributedCache _distributedCache;
        public IConfiguration _configuration;
        public DataWarehouseBackgroundService(IORMDataORM oRMDataORM, ISubscriptionEmail subscriptionEmail, IDistributedCache distributedCache, IConfiguration configuration)
        {
            _IORMDataORM = oRMDataORM;
            _subscriptionEmail = subscriptionEmail;
            _distributedCache = distributedCache;
            _configuration = configuration;
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (true)
            {
                bool _distributedCacheStr = true;
                try
                {
                    _distributedCacheStr = _distributedCache.Get<bool>("DataWarehouse");
                }
                catch (Exception)
                {

                }
                if (_distributedCacheStr)
                {
                    try
                    {
                        _IORMDataORM.InitDW(DataNameEnum.ClickHouse);
                        //_IORMDataORM.Init<TrackerTempEntity>();
                    }
                    catch (Exception ex)
                    {
                        if (AdvException.NeedFeedback(ex))
                        {
                            _subscriptionEmail.AddSubscriptionEmail(new SubscriptionEmailEntity() { OccurDate = DateTime.Now, Subject = string.Format("@CU.NET(I) Exception Message[数据同步处理异常] [{0}]", IPAddressHelper.GetHostAddressByEnvironment()), Body = AdvException.GetExceptionMessage(ex) });
                        }
                    }
                }
                await Task.Delay(_delaytimeSpan, stoppingToken);
            }
        }
    }
}