﻿using Multek.Library_Core.COM.Enum;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.DataWarehouse
{
    public class DataORMMain
    {
        public static SqlSugarClient Db;
       
        /// <summary>
        /// 保存数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="initData"></param>
        /// <param name="isUpdate"></param>
        /// <param name="dataName"></param>
        public static void Save<T>(List<T> initData, DataNameEnum dataName, bool isUpdate = false) where T : class, new()
        {
            if (dataName == DataNameEnum.ClickHouse)
            {
                DataORMMain.Db.GetConnection(dataName).Fastest<T>().BulkCopy(initData);
                //DataORMMain.Db.GetConnection(dataName).Insertable(initData).UseParameter().ExecuteCommand();
            }
            else
            {
                var _storge = DataORMMain.Db.GetConnection(dataName).Storageable<T>(initData).ToStorage();
                _storge.AsInsertable.ExecuteCommand();
                if (isUpdate)
                {
                    _storge.AsUpdateable.ExecuteCommand();
                }
            }
        }

    }

}