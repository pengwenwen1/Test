﻿using Microsoft.CodeAnalysis.Scripting;
using Multek.Library_Core.COM.Enum;
using Multek.Library_Core.COM;
using Newtonsoft.Json;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Multek.Library_Core.Quest.QuestInterface;
using CSScriptLib;
using Multek.Library_Core.Quest.QuestEntity;
using Multek.Applications.Data.DataWarehous;

namespace Multek.Applications.Services.Impl.DataWarehouse
{
    public class SORMDataORM : IORMDataORM
    {
        static string nspace = "Multek.Applications.Services.Impl.Entity.FirstCode";
        static string _pathdll = "Multek.Applications.Services.Impl.dll";
        public ISubscriptionEmail _subscriptionEmail;
        public ITracker _tracker;
        public SORMDataORM(ISubscriptionEmail subscriptionEmail, ITracker tracker)
        {
            _subscriptionEmail = subscriptionEmail;
            _tracker = tracker;
            InitORM();
        }
        /// <summary>
        /// 初始化ORM框架
        /// </summary>
        public void InitORM()
        {
            if (DataORMMain.Db !=null)
            {
                return;
            }
            DataORMMain.Db = new SqlSugarClient(new List<ConnectionConfig>()
            {
                     new ConnectionConfig() { ConfigId = DataNameEnum.CamstarWip,DbType = DbType.Oracle,ConnectionString = "password=Mes#1234;User ID=mespro;Connection Lifetime=1000;Connection Timeout=600;Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.28.0.45)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=mesdev)))",IsAutoCloseConnection = true,
                        AopEvents = RecordEvents()
                     },
                     new ConnectionConfig() { ConfigId = DataNameEnum.CamstarInt,DbType = DbType.Oracle,ConnectionString = "password=Mes#1234;User ID=Mesinter;Connection Lifetime=1000;Connection Timeout=600;Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.28.0.45)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=mesdev)))",IsAutoCloseConnection = true,
                        AopEvents = RecordEvents()
                     },
                     new ConnectionConfig() { ConfigId = DataNameEnum.Tracebility,DbType = DbType.Oracle,ConnectionString = "User ID=TRACEBILITY;Password=Tra#1234;Data Source=(DESCRIPTION = (ADDRESS_LIST= (ADDRESS = (PROTOCOL = TCP)(HOST =10.28.0.65)(PORT =1521))) (CONNECT_DATA = (SERVICE_NAME = mesdev)))",IsAutoCloseConnection = true,
                        AopEvents = RecordEvents()
                     },
                     new ConnectionConfig() { ConfigId = DataNameEnum.EAPData,DbType = DbType.Oracle,ConnectionString = "User ID=eappro;Password=KcwrhNSrl;Data Source=(DESCRIPTION = (ADDRESS_LIST= (ADDRESS = (PROTOCOL = TCP)(HOST =10.28.0.65)(PORT =1521))) (CONNECT_DATA = (SERVICE_NAME = mesdev)))",IsAutoCloseConnection = true,
                        AopEvents = RecordEvents()
                     },
                    new ConnectionConfig()
                    {
                        ConfigId =DataNameEnum.Quest,
                        DbType = SqlSugar.DbType.QuestDB,
                        ConnectionString = "host=10.201.49.65;port=8812;username=admin;password=quest;database=qdb;ServerCompatibilityMode=NoTypeLoading;timeout=5",IsAutoCloseConnection = true,  },
                     new ConnectionConfig() {ConfigId = DataNameEnum.CamstarODS,DbType =DbType.Oracle,ConnectionString= "password=Mes#1234;User ID=mesods;Connection Lifetime=1000;Connection Timeout=600;Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.28.0.48)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=mes)))",IsAutoCloseConnection = true,
                        AopEvents = RecordEvents()
                     },
                     new ConnectionConfig() {
                         ConfigId =DataNameEnum.ClickHouse,
                        DbType = DbType.ClickHouse,
                        ConnectionString = "Database=default;Username=default;Password=;Host=10.201.49.64;Port=8123;Compression=False;UseSession=False;Timeout=1200;",
                        IsAutoCloseConnection = true,
                        AopEvents = RecordEvents()
                     }
             });
        }

        private AopEvents RecordEvents()
        {
            return new AopEvents
            {
                OnLogExecuted = (sql, p) =>
                {
                    if (DataORMMain.Db.Ado.SqlExecutionTime.Seconds > 1)
                    {
                        _tracker.AddTrackery(new Library_Core.Quest.QuestEntity.TrackerEntity() { OccurDate = DateTime.Now, MethodPathName = "DWSQL", RequestData = $"DWSQL:{sql}-{string.Join(",", p?.Select(it => it.ParameterName + ":" + it.Value))}", CostTime = DataORMMain.Db.Ado.SqlExecutionTime.TotalMilliseconds, EndDate = DateTime.Now, StartDate = DateTime.Now.AddSeconds(-DataORMMain.Db.Ado.SqlExecutionTime.TotalSeconds) });
                    }
                },
                OnError = (exp) =>
                {
                    List<SugarParameter> _param = ((SugarParameter[])exp.Parametres).ToList();
                    KeyValuePair<string, List<SugarParameter>> _dic = new KeyValuePair<string, List<SugarParameter>>(exp.Sql, _param);
                    _subscriptionEmail.AddSubscriptionEmail(new Library_Core.Quest.QuestEntity.SubscriptionEmailEntity() { Subject = string.Format("@CU.NET(I) Exception Message[数据处理SQL异常] [{0}]", IPAddressHelper.GetHostAddressByEnvironment()), Body = AdvException.GetExceptionMessage(exp) + UtilMethods.GetSqlString(DataORMMain.Db.CurrentConnectionConfig, _dic), OccurDate = DateTime.Now });
                }
            };
        }


        /// <summary>
        /// 初始化接口库
        /// </summary>
        public void InitDataBase()
        {
            //如果不存在则创建数据库
            //Db.DbMaintenance.CreateDatabase();
            //创建表
            #region 创建INTER

            //string nspace = "CU.DataORM.Models.CodeFirst";

            //Type[] _interType = Assembly.LoadFrom(AppContext.BaseDirectory + "CU.DataORM.dll").GetTypes().Where(p => !p.Name.Contains('<') && p.Name != "Paraments" && p.Namespace == nspace && p.GetCustomAttribute<SqlSugar.TenantAttribute>().configId.ToString() == DataName.INTER.ToString()).ToArray();
            //try
            //{
            //    //Db.GetConnection(DataName.INTER).CodeFirst.SetStringDefaultLength(200).InitTables(_interType);
            //}
            //catch (Exception)
            //{
            //}
            //foreach (Type _interTypeItem in _interType)
            //{
            //    var _hasDataMethod = _interTypeItem.GetMethod("InitData");
            //    var instance = Activator.CreateInstance(_interTypeItem);
            //    var seedData = (_hasDataMethod?.Invoke(instance, null));
            //}
            //init<repdata>();
            //init<repcustomreport>();
            //init<repdashboard>();
            //init<repreport>();
            //init<repreportlayout>();
            //Init<SysDwJob>();
            //Init<CodDesigner>();
            #endregion



        }
        /// <summary>
        /// 初始化接口方法
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public void Init<T>()
        {
            DataORMMain.Db.GetConnection(DataNameEnum.ClickHouse).CodeFirst.SetStringDefaultLength(200).InitTables(typeof(T));
            var _hasDataMethod = typeof(T).GetMethod("InitData");
            var instance = Activator.CreateInstance(typeof(T));
            object[] _parameters = new object[3];
            _parameters[0] = DateTime.Now;
            _parameters[1] = DateTime.Now;
            _parameters[2] = null;
            var seedData = (_hasDataMethod?.Invoke(instance, _parameters));
        }

        /// <summary>
        /// 执行数据仓库同步
        /// </summary>
        public void InitDW(DataNameEnum dataName)
        {
            DateTime _now = DateTime.Now;
            // 加载Dll
            Type[] _interType = Assembly.LoadFrom(AppContext.BaseDirectory + _pathdll).GetTypes().Where(p => !p.Name.Contains('<') && p.Name != "Paraments" && p.Namespace == nspace && p.GetCustomAttribute<SqlSugar.TenantAttribute>().configId.ToString() == dataName.ToString()).ToArray();
            Dictionary<string, Type> _dwTypeDic = new Dictionary<string, Type>();
            foreach (var _interTypeItem in _interType)
            {
                _dwTypeDic[_interTypeItem.Name] = _interTypeItem;
            }
            // 代码
            var _codeList = DataORMMain.Db.QueryableWithAttr<CodDesigner>().Where(x => x.TypeId == 3).ToList();
            foreach (var _codItem in _codeList)
            {
                Type[] _codeType = CSScript.Evaluator.CompileCode(_codItem.RunContent).GetTypes().Where(x => x.Name == _codItem.CodName && x.GetCustomAttribute<SqlSugar.TenantAttribute>().configId.ToString() == dataName.ToString()).ToArray();
                _dwTypeDic[_codItem.CodName] = _codeType[0];
            }

            // 获取数据仓库定义的集合
            List<SysDwJob> _sysDwJobs = DataORMMain.Db.QueryableWithAttr<SysDwJob>().ToList();
            foreach (SysDwJob _sysDwJobItem in _sysDwJobs)
            {
                //&& _sysDwJobItem.JobName == "WAPServerConfig"
                if (_dwTypeDic.ContainsKey(_sysDwJobItem.JobName))
                {
                    try
                    {
                        DataORMMain.Db.GetConnection(dataName).CodeFirst.SetStringDefaultLength(200).InitTables(_dwTypeDic[_sysDwJobItem.JobName]);
                        bool _paramsisCalss = false;
                        var _hasDataMethod = _dwTypeDic[_sysDwJobItem.JobName].GetMethod("InitData");
                        var instance = Activator.CreateInstance(_dwTypeDic[_sysDwJobItem.JobName]);
                        object[] _parameters = new object[3];
                        _parameters[0] = _sysDwJobItem.StartDate;
                        _parameters[1] = _now;
                        //得到指定方法的参数列表  
                        ParameterInfo[] paramsInfo = _hasDataMethod.GetParameters();
                        // 调整自定义的数据类型
                        if (paramsInfo.Length == 3)
                        {
                            Type _type = paramsInfo[2].ParameterType;//如果它是值类型,或者String   

                            if (_type.Equals(typeof(string)) || (!_type.IsInterface && !_type.IsClass))

                            {  //改变参数类型   
                                _parameters[2] = Convert.ChangeType(_sysDwJobItem.LastValue, _type);
                            }
                            else if (_type.IsClass)
                            {
                                //如果是类,将它的json字符串转换成对象 
                                try
                                {
                                    _paramsisCalss = true;
                                    _parameters[2] = JsonConvert.DeserializeObject(_sysDwJobItem.LastValue, _type);
                                }
                                catch (Exception)
                                {
                                    _parameters[2] = null;
                                }
                            }
                            DateTime _startTime = DateTime.Now;
                            var seedData = (_hasDataMethod?.Invoke(instance, _parameters));
                            _sysDwJobItem.StartDate = _now;
                            _sysDwJobItem.UpdateDate = _now;
                            _sysDwJobItem.LastValue = _paramsisCalss ? JsonConvert.SerializeObject(seedData) : seedData.ToString();
                            DataORMMain.Db.UpdateableWithAttr<SysDwJob>(_sysDwJobItem).ExecuteCommand();
                            _tracker.AddTrackery(new TrackerEntity() { OccurDate = DateTime.Now, MethodPathName = $"DWJOB:{_sysDwJobItem.JobName}", CostTime = (DateTime.Now - _startTime).TotalMilliseconds, EndDate = DateTime.Now, StartDate = _startTime });
                        }
                    }
                    catch (Exception ex)
                    {
                        if (AdvException.NeedFeedback(ex))
                        {
                            _subscriptionEmail.AddSubscriptionEmail(new SubscriptionEmailEntity() { OccurDate = DateTime.Now, Subject = string.Format("@CU.NET(I) Exception Message[数据处理异常] [{0}]", IPAddressHelper.GetHostAddressByEnvironment()), Body = AdvException.GetExceptionMessage(ex) + _sysDwJobItem.ToExceptionMessage?.Split(';') });
                        }
                    }
                }
            }
            //foreach (type _intertypeitem in _intertype)
            //{
            //    try
            //    {
            //        sysdwjob _sysdwjob = _sysdwjobs.find(x => x.jobname == _intertypeitem.name);
            //        bool _paramsiscalss = false;
            //        // 调用指定的定义方法
            //        if (_sysdwjob != null)
            //        {
            //            var _hasdatamethod = _intertypeitem.getmethod("initdata");
            //            var instance = activator.createinstance(_intertypeitem);
            //            object[] _parameters = new object[3];
            //            _parameters[0] = _sysdwjob.startdate;
            //            _parameters[1] = _now;
            //            //得到指定方法的参数列表  
            //            parameterinfo[] paramsinfo = _hasdatamethod.getparameters();
            //            // 调整自定义的数据类型
            //            if (paramsinfo.length == 3)
            //            {
            //                type _type = paramsinfo[2].parametertype;//如果它是值类型,或者string   

            //                if (_type.equals(typeof(string)) || (!_type.isinterface && !_type.isclass))

            //                {  //改变参数类型   
            //                    _parameters[2] = convert.changetype(_sysdwjob.lastvalue, _type);
            //                }
            //                else if (_type.isclass)
            //                {
            //                    //如果是类,将它的json字符串转换成对象 
            //                    try
            //                    {

            //                        _paramsiscalss = true;
            //                        _parameters[2] = jsonconvert.deserializeobject(_sysdwjob.lastvalue, _type);
            //                    }
            //                    catch (exception)
            //                    {
            //                        _parameters[2] = null;
            //                    }
            //                }
            //                var seeddata = (_hasdatamethod?.invoke(instance, _parameters));
            //                _sysdwjob.startdate = _now;
            //                _sysdwjob.updatedate = _now;
            //                _sysdwjob.lastvalue = _paramsiscalss ? jsonconvert.serializeobject(seeddata) : seeddata.tostring();
            //                dataormmain.db.updateablewithattr<sysdwjob>(_sysdwjob).executecommand();
            //            }

            //        }
            //    }
            //    catch (exception ex)
            //    {
            //        if (advexception.needfeedback(ex))
            //        {
            //            exceptionemailsender.sendmailbyqueue(serverconfigmanager.adminfromemail, new string[] { "tina.yan@multek.com", "wenwen.peng@multek.com" }, "", string.format("@CU.NET(I) exception message[数据处理异常] [{0}]", ipaddresshelper.getcomputername()), advexception.getexceptionmessage(ex), null, 0);
            //        }
            //    }
            //}

        }
    }
}