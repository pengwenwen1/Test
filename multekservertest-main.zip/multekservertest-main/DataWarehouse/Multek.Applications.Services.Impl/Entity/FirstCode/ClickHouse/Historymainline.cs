﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper.Execution;
using Multek.Applications.Services.Impl.DataWarehouse;
using Multek.Applications.Services.Impl.Entity.FirstCode;
using Multek.Library_Core.COM.Enum;
using SqlSugar;
namespace Multek.Applications.Services.Impl.Entity.FirstCode
{
    /// <summary>
    /// 
    ///</summary>
    [SqlSugar.ClickHouse.CKTable(@"engine = ReplacingMergeTree PARTITION BY toYYYYMM(SYSTEMDATE)  ORDER BY (HISTORYMAINLINEID) SETTINGS index_granularity = 8192;")]
    [SugarTable("Historymainline", TableDescription = "")]
    [Tenant(DataNameEnum.ClickHouse)]
    public class Historymainline
    {
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "CDONAME", ColumnDescription = "")]
        public string? Cdoname { get; set; }
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "CDOTYPEID", ColumnDescription = "")]
        public long? Cdotypeid { get; set; }
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "COMPUTERNAME", ColumnDescription = "")]
        public string? Computername { get; set; }
        [SugarColumn(ColumnName = "CONTAINERNAME", ColumnDescription = "")]
        public string? Containername { get; set; }
        [SugarColumn(ColumnName = "HISTORYMAINLINEID", IsPrimaryKey = true, ColumnDescription = "")]
        public string Historymainlineid { get; set; }
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "PRODUCTNAME", ColumnDescription = "")]
        public string? Productname { get; set; }
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "QTY", ColumnDescription = "")]
        public float? Qty { get; set; }
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "QTY2", ColumnDescription = "")]
        public float? Qty2 { get; set; }
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "SPECNAME", ColumnDescription = "")]
        public string? Specname { get; set; }
        /// <summary>
        ///  
        ///</summary>
        [SugarColumn(ColumnName = "SYSTEMDATE", ColumnDescription = "")]
        public DateTime Systemdate { get; set; }
        public string? Workstationid { get; set; }
        /// <summary>
        /// 执行数据方法
        /// </summary>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">任务的结束时间</param>
        /// <param name="key">用户定义参数</param>
        /// <returns></returns>
        public Paraments InitData(DateTime startTime, DateTime endTime, Paraments key)
        {
            // 存在的主键是否更新数据
            bool _isUpdate = false;
            DateTime? _lastDate;
            if (key == null)
            {
                key = new Paraments() { SystemDate = new DateTime(2023, 8, 1, 0, 0, 0) };
            }
            do
            {
                Console.WriteLine(key.SystemDate);
                //获取数据
                var _initData = DataORMMain.Db.GetConnection(DataNameEnum.CamstarODS).Ado.SqlQuery<Historymainline>(@$"
SELECT  
    ROUND( QTY,5) AS QTY, QTY2 AS QTY2,CONTAINERNAME,
    CDONAME,CDOTYPEID,COMPUTERNAME,HISTORYMAINLINEID,PRODUCTNAME,SPECNAME,SYSTEMDATE
FROM 
    HISTORYMAINLINE
WHERE 
HISTORYMAINLINE.SYSTEMDATE > TO_DATE('{key.SystemDate.ToString("yyyy-MM-dd HH:mm:ss")}', 'YYYY-MM-DD HH24:MI:SS') 
AND HISTORYMAINLINE.SYSTEMDATE < TO_DATE('{key.SystemDate.AddMonths(1).ToString("yyyy-MM-dd HH:mm:ss")}', 'YYYY-MM-DD HH24:MI:SS')
").ToList();
            
                // 保存数据
                DataORMMain.Save(_initData, DataNameEnum.ClickHouse, _isUpdate);
                if (_initData.Count > 0)
                {
                    _lastDate = _initData.Max(x => x.Systemdate);
                    key.SystemDate = _lastDate ?? key.SystemDate;
                }
                else
                {
                    key.SystemDate = key.SystemDate.AddMonths(1);
                }

            } while (key.SystemDate.AddMonths(1) < DateTime.Now);
            return key;
        }
        /// <summary>
        /// 参数列表
        /// </summary>
        public class Paraments
        {
            public DateTime SystemDate;
        }
    }
}
