﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Multek.Applications.Services.Impl.DataWarehouse;
using Multek.Library_Core.COM.Enum;
using Spire.Doc.Documents;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.Entity.FirstCode.CodePNLLog
{
    [SugarTable(TableName = "CodePNLLog", TableDescription = "")]
    [SqlSugar.ClickHouse.CKTable(@"engine = MergeTree PARTITION BY toYYYYMM(CreatedTime)  ORDER BY (PnlCode,Code,PnlFace,PositionX) SETTINGS index_granularity = 8192;")]
    [Tenant(DataNameEnum.ClickHouse)]
    public class CodePNLLog
    {
        public String PnlCode { get; set; }
        public int PnlFace { get; set; }
        public String Code { get; set; }
        public double PositionX { get; set; }
        public double PositionY { get; set; }
        public int type { get; set; }
        public Int32 NO { get; set; }
        public int CodeType { get; set; }
        public DateTime CreatedTime { get; set; }
        public DateTime UpdatedTime { get; set; }
        public String CreatedUserName { get; set; }
        public String UpdatedUserName { get; set; }
        public Boolean IsDeleted { get; set; }


        public Paraments InitData(DateTime startTime, DateTime endTime, Paraments key)
        {
            bool _isUpdate = false;
            if (key == null)
            {
                key = new Paraments()
                {
                    SystemDate = new DateTime(2023, 8, 1, 0, 0, 0)
                };
            }
            var _initData = DataORMMain.Db.GetConnection(DataNameEnum.Tracebility).SqlQueryable<CodePNLLog>(String.Format(@"
SELECT 
    PNLCODE,PNLFACE,CODE,ROUND(POSITIONX,4) POSITIONX,ROUND(POSITIONY,4),TYPE,NO,CODETYPE,CREATEDTIME,UPDATEDTIME,CREATEDUSERNAME,UPDATEDUSERNAME,ISDELETED 
FROM CODEPNLLOG
WHERE UpdatedTime>  TO_DATE('{0}', 'YYYY-MM-DD HH24:MI:SS')
", key.SystemDate.ToString("yyyy-MM-dd HH:mm:ss"))).ToList();
            if (_initData.Count > 0)
            {
                DataORMMain.Save(_initData, DataNameEnum.ClickHouse, _isUpdate);
                key.SystemDate = _initData.Max(x => x.UpdatedTime);
            }
            return key;
        }
        public class Paraments
        {
            public DateTime SystemDate;
        }


    }
}
