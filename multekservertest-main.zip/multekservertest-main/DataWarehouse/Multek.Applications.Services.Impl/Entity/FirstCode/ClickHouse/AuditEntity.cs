﻿using Multek.Applications.Services.Impl.DataWarehouse;
using Multek.Library_Core.Audit;
using Multek.Library_Core.COM.Enum;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.Entity.FirstCode
{
    /// <summary>
    /// 变更记录
    /// </summary>
    [SugarTable(TableName = "SYS_Audit")]
    [SqlSugar.ClickHouse.CKTable(@"engine = MergeTree PARTITION BY toYYYYMM(UpdatedAt)  ORDER BY (UpdatedAt) SETTINGS index_granularity = 8192;")]
    [Tenant(DataNameEnum.ClickHouse)]
    public class QuestAuditEntry
    {
        /// <summary>
        /// 主键
        /// </summary>
        public DateTime UpdatedAt { get; set; }
        /// <summary>
        /// 表名
        /// </summary>
        public string TableName { get; set; }
        /// <summary>
        /// 原始值
        /// </summary>
        public string? OriginalValues { get; set; }
        /// <summary>
        /// 新值
        /// </summary>
        public string? NewValues { get; set; }
        /// <summary>
        /// 主键
        /// </summary>
        public string? KeyValues { get; set; }
        /// <summary>
        /// 操作状态
        /// </summary>
        public DataOperationEnum OperationType { get; set; }

        public string Properties { get; set; }

        public string? UpdatedBy { get; set; }

        public Paraments InitData(DateTime startTime, DateTime endTime, Paraments key)
        {
            // 存在的主键是否更新数据
            bool _isUpdate = false;
            if (key == null)
            {
                key = new Paraments() { SystemDate = new DateTime(2023, 8, 1, 0, 0, 0) };
            }
            //获取数据
            var _initData = DataORMMain.Db.GetConnection(DataNameEnum.Quest).Queryable<QuestAuditEntry>().Where(x => x.UpdatedAt > key.SystemDate).ToList();
            // 保存数据
            if (_initData.Count > 0)
            {
                DataORMMain.Save(_initData, DataNameEnum.ClickHouse, _isUpdate);
                key.SystemDate = _initData.Max(x => x.UpdatedAt);
            }
            return key;
        }
        /// <summary>
        /// 参数列表
        /// </summary>
        public class Paraments
        {
            public DateTime SystemDate;
        }
    }
}
