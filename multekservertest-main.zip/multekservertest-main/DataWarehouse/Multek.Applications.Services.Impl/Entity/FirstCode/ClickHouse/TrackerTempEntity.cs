﻿using Multek.Library_Core.Audit;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Multek.Library_Core.COM.Enum;
using Multek.Applications.Services.Impl.DataWarehouse;

namespace Multek.Applications.Services.Impl.Entity.FirstCode
{
    /// <summary>
    /// 服务操作跟踪表
    ///</summary>
    [SugarTable(TableName = "TrackerTempEntity", TableDescription = "服务操作跟踪表")]
    [SqlSugar.ClickHouse.CKTable(@"engine = MergeTree PARTITION BY toYYYYMM(OccurDate)  ORDER BY (OccurDate) SETTINGS index_granularity = 8192;")]
    [Tenant(DataNameEnum.ClickHouse)]
    public class TrackerTempEntity
    {
        /// <summary>
        /// 发生日期 
        ///</summary>
        [SugarColumn(ColumnDescription = "发生日期")]
        public DateTime OccurDate { get; set; }
        /// <summary>
        /// 服务器地址 
        ///</summary>
        [SugarColumn(ColumnDescription = "服务器地址", Length = 20)]
        public string ServerAddress { get; set; }
        /// <summary>
        /// 方法名称 
        ///</summary>
        [SugarColumn(ColumnDescription = "方法名称", Length = 100)]
        public string MethodPathName { get; set; }
        /// <summary>
        /// 所耗时长 
        ///</summary>
        [SugarColumn(ColumnDescription = "所耗时长")]
        public double CostTime { get; set; }
        /// <summary>
        /// 请求数据 
        ///</summary>
        [SugarColumn(ColumnDescription = "请求数据", Length = 1000)]
        public string RequestData { get; set; }
        /// <summary>
        /// 返回数据 
        ///</summary>
        //[Column(TypeName = "nvarchar(Max)")]
        [SugarColumn(ColumnDescription = "返回数据", Length = 4000)]
        public string ResponseData { get; set; }
        /// <summary>
        /// 开启请求时间 
        ///</summary>
        [SugarColumn(ColumnDescription = "开启请求时间", IsNullable = true)]
        public DateTime? StartDate { get; set; }
        /// <summary>
        /// 结束时间 
        ///</summary>
        [SugarColumn(ColumnDescription = "结束时间")]
        public DateTime EndDate { get; set; }
        public Paraments InitData(DateTime startTime, DateTime endTime, Paraments key)
        {
            // 存在的主键是否更新数据
            bool _isUpdate = false;
            if (key == null)
            {
                key = new Paraments() { SystemDate = new DateTime(2023, 8, 1, 0, 0, 0) };
            }
            //获取数据
            var _initData = DataORMMain.Db.GetConnection(DataNameEnum.Quest).Queryable<TrackerEntity>().Where(x => x.OccurDate > key.SystemDate).ToList();
            // 保存数据
            if (_initData.Count > 0)
            {
                DataORMMain.Save(_initData, DataNameEnum.ClickHouse, _isUpdate);
                key.SystemDate = _initData.Max(x => x.OccurDate);
            }
            return key;
        }
        /// <summary>
        /// 参数列表
        /// </summary>
        public class Paraments
        {
            public DateTime SystemDate;
        }
    }

}
