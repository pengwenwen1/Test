﻿using Multek.Applications.Services.Impl.DataWarehouse;
using Multek.Library_Core.COM.Enum;
using SqlSugar;

namespace Multek.Applications.Services.Impl.Entity.FirstCode
{
    //[SqlSugar.ClickHouse.CKTable(@"engine = ReplacingMergeTree PARTITION BY toYYYYMM(dt)  ORDER BY (Id) SETTINGS index_granularity = 8192;")]
    [SqlSugar.ClickHouse.CKTable(@"engine = ReplacingMergeTree PARTITION BY toYYYYMM(SYSTEMDATE)  ORDER BY (HISTORYMAINLINEID) SETTINGS index_granularity = 8192;")]
    [Tenant(DataNameEnum.ClickHouse)]
    /// <summary>
    /// 工序在线时长
    ///</summary>
    [SugarTable("DW_LOT_SEPEC_ODTFORCH", TableDescription = "工序在线时长")]
    public class DW_LOT_SEPEC_ODTFORCH
    {
        /// <summary>
        /// Lot
        ///</summary>
        [SugarColumn(ColumnName = "HISTORYMAINLINEID", IsPrimaryKey = true, ColumnDescription = "历史主键", Length = 16)]
        public string Historymainlineid { get; set; }
        /// <summary>
        /// Lot
        ///</summary>
        [SugarColumn(ColumnName = "CONTAINERNAME", IsNullable = true, ColumnDescription = "Lot", Length = 50)]
        public string ContainerName { get; set; }
        /// <summary>
        /// 工序名称 
        ///</summary>
        [SugarColumn(ColumnName = "SPECNAME", IsNullable = true, ColumnDescription = "工序名称", Length = 40)]
        public string SpecName { get; set; }
        /// <summary>
        /// 过数时间 
        ///</summary>
        [SugarColumn(ColumnName = "SYSTEMDATE", ColumnDescription = "过数时间")]
        public DateTime SystemDate { get; set; }
        /// <summary>
        /// 等待时长Min 
        ///</summary>
        [SugarColumn(ColumnName = "WAIT_FOR", IsNullable = true, ColumnDescription = "等待时长Min")]
        public double WaitFor { get; set; }
        /// <summary>
        /// 执行数据方法
        /// </summary>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">任务的结束时间</param>
        /// <param name="key">用户定义参数</param>
        /// <returns></returns>
        public Paraments InitData(DateTime startTime, DateTime endTime, Paraments key)
        {
            // 存在的主键是否更新数据
            bool _isUpdate = false;
            if (key == null)
            {
                key = new Paraments() { SystemDate = DateTime.MinValue };
            }

            //获取数据
            var _initData = DataORMMain.Db.GetConnection(DataNameEnum.CamstarWip).Ado.SqlQuery<DW_LOT_SEPEC_ODTFORCH>(@"
SELECT HISTORYMAINLINE.CONTAINERNAME,HISTORYMAINLINE.SYSTEMDATE ,HISTORYMAINLINE.FROMSPECNAME,HISTORYMAINLINE.HISTORYMAINLINEID FROM HISTORYMAINLINE INNER JOIN CONTAINER C ON C.CONTAINERID=HISTORYMAINLINE.CONTAINERID 
WHERE C.OBJECTTYPE='LOT' AND CDONAME = 'MoveLot' AND  HISTORYMAINLINE.FROMSPECNAME NOT LIKE 'PAOI%'  AND  HISTORYMAINLINE.FROMSPECNAME NOT LIKE '%开料线边仓%'  
ORDER BY HISTORYMAINLINEID ASC").Where(x => x.SystemDate >= key.SystemDate).ToList();

            #region 业务逻辑处理
            DateTime _lotMoveData = DateTime.MinValue;
            // 记录上一次条码出站的时间
            Dictionary<string, DateTime> _lotSysData = new Dictionary<string, DateTime>();
            foreach (var item in _initData)
            {
                if (_lotSysData.Keys.Contains(item.ContainerName))
                {
                    _lotMoveData = _lotSysData[item.ContainerName];
                }
                else
                {
                    _lotMoveData = item.SystemDate;
//                    if (key.SystemDate == DateTime.MinValue)
//                    {
//                        // 第一次执行
//                        _lotMoveData = item.SystemDate;
//                    }
//                    else
//                    {
//                        // 查询前一次数据
//                        Object _obj = DataORMMain.Db.GetConnection(DataNameEnum.CamstarWip).Ado.GetScalar(string.Format(@"
//SELECT SYSTEMDATE FROM HISTORYMAINLINE
//WHERE CDONAME = 'MoveLot' AND  HISTORYMAINLINE.Specname NOT LIKE 'PAOI%' AND HISTORYMAINLINE.HISTORYMAINLINEID <'{0}' AND HISTORYMAINLINE.CONTAINERNAME ='{1}'
//ORDER BY HISTORYMAINLINEID DESC", item.Historymainlineid, item.ContainerName));
//                        if (_obj != null)
//                        {
//                            _lotMoveData = Convert.ToDateTime(_obj);
//                        }
//                        else
//                        {
//                            _lotMoveData = item.SystemDate;
//                        }

//                    }
                }
                item.WaitFor = (item.SystemDate - _lotMoveData).TotalMinutes;
                _lotSysData[item.ContainerName] = item.SystemDate;
            }

            #endregion
            // 保存数据
            DataORMMain.Save(_initData, DataNameEnum.ClickHouse, _isUpdate);

            DateTime _lastDate = _initData.Max(x => x.SystemDate);

            return new Paraments() { SystemDate = _lastDate };

        }
        /// <summary>
        /// 参数列表
        /// </summary>
        public class Paraments
        {
            public DateTime SystemDate;
        }
    }
}
