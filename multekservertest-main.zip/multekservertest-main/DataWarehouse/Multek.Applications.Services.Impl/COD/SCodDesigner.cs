﻿using Multek.Applications.Data.DataWarehous;
using Multek.Applications.Services.COD;
using Multek.Applications.Services.Impl.DataWarehouse;
using Multek.Library_Core.COM.Enum;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.COD
{
    public class SCodDesigner : ICodDesigner
    {
        public IResultModel DefaultAddElseUpdate(List<CodDesigner> codDesigner)
        {
            int count = DataORMMain.Db.GetConnection(DataNameEnum.CamstarInt).Storageable<CodDesigner>(codDesigner).ExecuteCommand();
            if (count > 0)
            {
                return new ResultModel<string>().Success("执行成功！");
            }
            return new ResultModel<string>().Failed("执行失败！");
        }
    }
}
