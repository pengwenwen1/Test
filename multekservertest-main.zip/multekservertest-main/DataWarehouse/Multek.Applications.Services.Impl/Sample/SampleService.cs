﻿using AutoMapper.Execution;
using Microsoft.EntityFrameworkCore;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities.Sample;
using Multek.Applications.Services.Sample;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Reflection.Metadata.BlobBuilder;

namespace Multek.Applications.Services.Impl.Sample
{
    public class SSampleService : EFHelper<MultekServerDbContext>, ISampleService
    {
        
        public SSampleService(MultekServerDbContext tdb) : base(tdb)
        {
        }
        public IResultModel GetResultModel()
        {
            //var d = db.Books.Join(db.mi_t_mwc_plants, Books => Books.Dies, per => per.plnt, (pet, per) => new Book
            //{
            //    Id = pet.Id,
            //    Name = per.mnwc
            //}).ToList();
            //var _resultModel = db.Books.FromSql<Book>($"SELECT * FROM Books").ToList();
            //var _resultModel = db.Database.SqlQuery<int>($"SELECT count(*) FROM Books").ToList();
            var _resultModel = from b in db.Books
                               join c in db.Books on new { b.Id, b.Name } equals new { c.Id, c.Name }
                               select new { b.Id, c.Name };

            return new ResultModel<object>().Success(_resultModel);
        }
    }
}
