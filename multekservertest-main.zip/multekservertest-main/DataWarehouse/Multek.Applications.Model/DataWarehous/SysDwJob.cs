﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Multek.Library_Core.COM.Enum;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.DataWarehous
{
    /// <summary>
    /// 数据仓库任务
    ///</summary>
    [SugarTable("SYS_DW_JOB", TableDescription = "数据仓库任务")]
    [Tenant(DataNameEnum.CamstarInt)]
    public class SysDwJob
    {
        /// <summary>
        /// 任务ID 
        ///</summary>
        [SugarColumn(ColumnName = "JOB_NAME", IsPrimaryKey = true, IsNullable = true, ColumnDescription = "任务名称", Length = 30)]
        public string JobName { get; set; }
        /// <summary>
        /// 更新时间 
        ///</summary>
        [SugarColumn(ColumnName = "UPDATE_DATE", IsNullable = true, ColumnDescription = "更新时间")]
        public DateTime? UpdateDate { get; set; }
        /// <summary>
        /// 更新最后值 
        ///</summary>
        [SugarColumn(ColumnName = "LAST_VALUE", IsNullable = true, ColumnDescription = "更新最后值", Length = 200)]
        public string LastValue { get; set; }
        /// <summary>
        /// 数据源 
        ///</summary>
        [SugarColumn(ColumnName = "REP_DATA_ID", IsNullable = true, ColumnDescription = "数据源", Length = 30)]
        public string RepDataId { get; set; }
        /// <summary>
        /// 异常通知 
        ///</summary>
        [SugarColumn(ColumnName = "TO_EXCEPTION_MESSAGE", IsNullable = true, ColumnDescription = "异常邮件通知", Length = 200)]
        public string ToExceptionMessage { get; set; }
        /// <summary>
        /// 参数名称 
        ///</summary>
        [SugarColumn(ColumnName = "PARAMENT_ID", IsNullable = true, ColumnDescription = "参数名称", Length = 30)]
        public string ParamentId { get; set; }
        /// <summary>
        /// 执行开始时间 
        ///</summary>
        [SugarColumn(ColumnName = "START_DATE", IsNullable = true, ColumnDescription = "执行开始时间")]
        public DateTime? StartDate { get; set; }
    }

}
