﻿using AutoMapper;
namespace Multek.Applications.Model
{
    public class AutoMapperConfigs : Profile
    {
        public AutoMapperConfigs()
        {
            
        }
    }
}