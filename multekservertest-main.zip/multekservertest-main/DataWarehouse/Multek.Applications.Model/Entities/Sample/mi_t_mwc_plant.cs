﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Sample
{
    [Table("mi_t_mwc_plant")]
    [PrimaryKey(nameof(plnt), nameof(mnwc))]
    public class mi_t_mwc_plant
    {
        public string plnt { get; set; }
        public string mnwc { get; set; }

        public string ispd { get; set; }
        public string enbl { get; set; }
    }
}
