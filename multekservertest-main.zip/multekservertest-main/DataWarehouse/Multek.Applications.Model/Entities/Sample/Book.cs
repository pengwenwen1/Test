﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities.Sample
{
    public class Book
    {
        /// <summary>
        /// 
        /// </summary>
        /// <example>100</example>
        [Required(ErrorMessage ="{0}不能为空！")]
        public int Id { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        /// <example>namedw</example>
        [DisplayName("姓名")]
        [StringLength(10,ErrorMessage ="{0}长度不能超10个")]
        public string Name { get; set; }
        public DateTime? Date { get; set; }

        public int? Amount { get; set; }
        public string? Dies { get; set; }
        public string? Dies1 { get; set; }
    }
}
