﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Multek.Applications.Data.Entities;
using Microsoft.Extensions.Configuration;
using Multek.Library_Core.COM.DbContexts;
using System.Reflection.Metadata;
using Multek.Applications.Model.Entities.Camstar;
using Microsoft.Identity.Client;
using Multek.Applications.Model.Entities.Multek;
using Multek.Applications.Model.WIPMain;
using Multek.Applications.Model.SplitAndCombine;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.LotTxn;
using Multek.Applications.Model.WIPData;
using Multek.Applications.Model.DrillingMachine;

namespace Multek.Applications.Data.DbContexts.Sample
{
    public class MultekCamstarDbContext : MultekDbContext
    {


        #region 新增数据库管理对象
        public DbSet<Container> Containers { get; set; }

        public DbSet<Product> Products { get; set; }

        public DbSet<Factory> Factories { get; set; }

        public DbSet<Employee> Employees { get; set; }

        public DbSet<Mfgorder> Mfgorders { get; set; }

        public DbSet<CUOEM> Cuoems { get; set; }

        public DbSet<TrackALLInfo> TrackALLInfo { get; set; }

        public DbSet<MoveOutNextStep> MoveOutNextStep { get; set; }

        public DbSet<LotMessage> LotMessage { get; set; }

        public DbSet<StepListRsp> StepListRsp { get; set; }

        public DbSet<HoldingTimeMsg> HoldingTimeMsgs { get; set; }

        public DbSet<Timers> Timers { get; set; }

        public DbSet<DCFormatRsp> DCFormatRsps { get; set; }

        public DbSet<OAFutureHoldMsgRsp> OAFutureHoldMsgRsps { get; set; }

        public DbSet<LotsFutureHoldRsp> LotsFutureHoldRsps { get; set; }
        public DbSet<GetNewLotRsp> GetNewLotRsps { get; set; }
        public DbSet<cuSplitReason> SplitReason { get; set; }

        public DbSet<LotInfoModel> LotInfoModel { get; set; }
        public DbSet<ReworkLotInfoModel> ReworkLotInfoModel { get; set; }

        public DbSet<A_InsertionReason> A_InsertionReason { get; set; }

        public DbSet<EquipmentMsgRsp> EquipmentMsgRsps { get; set; }

        public DbSet<HoldReason> holdReason { get; set; }
        public DbSet<Releasereason> releasereasons { get; set; }
        public DbSet<CURepairMethod> CURepairMethod { get; set; }

        public DbSet<EmployeeSpecRsp> EmployeeSpecRsps { get; set; }

        public DbSet<ContainerInfo> containerInfos { get; set; }

        public DbSet<Lossreason> lossreasons { get; set; }

        public DbSet<cuProcesSpec> cuProcesSpecs { get; set; }

        public DbSet<CuScraptype> cuScraptypes { get; set; }

        public DbSet<VerdorModel> Verdor { get; set; }

        public DbSet<OSLotInfoModel> OSLotInfoModel { get; set; }
        public DbSet<OSSpecInfoModel> OSSpecInfoModel { get; set; }
        public DbSet<OSOrderInfoModel> OSOrderInfoModel { get; set; }
        public DbSet<MoveStdReason> moveStdReason { get; set; }
        public DbSet<OSROrderInfo> GetOSOrder { get; set; }
        public DbSet<OSRLotInfo> OSRLotInfo { get; set; }
        public DbSet<Currentstatus> CurrentStatus { get; set; }
        public DbSet<ProductBase> ProductBases { get; set; }
        public DbSet<OrderStatus> OrderStatus { get; set; }
        public DbSet<WorkFlowStep> WorkFlowSteps { get; set; }
        public DbSet<WorkFlow> WorkFlows { get; set; }
        public DbSet<WorkFlowBase> WorkFlowBases { get; set; }
        public DbSet<CuDefectRecord> CuDefectRecords { get; set; }
        public DbSet<CuDefectBackDetails> CuDefectBackDetails { get; set; }
        public DbSet<OSRELotInfoModel> OSRELotInfoModel { get; set; }
        public DbSet<OSREFactoryModel> OSREFactoryModel { get; set; }
        public DbSet<STCreateLotInfoModel> STCreateLotInfoModel { get; set; }
        public DbSet<STCreateCategoryModel> STCreateCategoryModel { get; set; }
        public DbSet<STCreateCheckMatrixModel> STCreateCheckMatrixModel { get; set; }
        public DbSet<STCreateCheckMultTaskModel> STCreateCheckMultTaskModel { get; set; }
        public DbSet<TaskList> TaskList { get; set; }
        public DbSet<Carrier> getCarrier {  get; set; }

        public DbSet<ContinuousSpecRsp> ContinuousSpecRsps { get; set; }

        public DbSet<FollowStepRsp> FollowStepRsps { get; set; }
        public DbSet<EmployeeGroup> EmployeeGroup { get; set; }

        public DbSet<TerminateReason> TerminateReasons { get; set; }

        public DbSet<UnTerminateReason> UnTerminateReasons { get; set; }

        public DbSet<ECNFunctionChangeDetails> cuECNFunctionChanges { get; set; }
        public DbSet<LoadLotDetailModel> LoadLotDetailModel { get; set; }
        public DbSet<HoldReasonModel> HoldReasonModel { get; set; }
        public DbSet<FailReasonModel> FailReasonModel { get; set; }
        public DbSet<RevisionObjectModel> RevisionObjectModel { get; set; }
        public DbSet<CheckItemModel> CheckItemModel { get; set; }
        public DbSet<NameObjectModel> NameObjectModel { get; set; }
        public DbSet<LoadTaskListModel> LoadTaskListModel { get; set; }
        public DbSet<CuERCUpGradePNDetails> ERCUpGradePNDetails { get; set; }
        public DbSet<Spec> Spec { get; set; }
        public DbSet<cuFutureHoldDetail> CuFutureHoldDetail { get; set; }
        public DbSet<NameModeInfo> QueryData { get; set; }
        public DbSet<RevisionNameModeInfo> QueryRevisionData { get; set; }
        public DbSet<ECNGetContainerInfoReq> eCNGetContainerInfoReqs { get; set; }
        

        public DbSet<CheckSendLotModel> CheckSendLotModel { get; set; }

        public DbSet<cuOutsouringLotInfo> cuOutsouringLotInfos { get; set; }

        public DbSet<MaterialLotMsgRsp> MaterialLotMsgRsps { get; set; }
        public DbSet<TaskDetails> TaskDetails { get; set; }
        public DbSet<TaskDetailsV2> TaskDetailsV2 { get; set; }

        public DbSet<LotWIPTrackMsgRsp> LotWIPTrackMsgRsps { get; set; }
        public DbSet<LotUnTerminateWorkflow> LotUnTerminateWorkflows { get; set; }
        public DbSet<CuLayerAttachDetails> cuLayers { get; set; }
        public DbSet<cuNexLayerWorkOrder> cuNexLayerWorks { get; set; }

        public DbSet<WipCount> wipCounts { get; set; }

        public DbSet<A_ProcessSpec> a_ProcessSpecs { get; set; }

        #endregion

        #region 构造方法

        public MultekCamstarDbContext(DbContextOptions<MultekCamstarDbContext> builder) : base(builder)
        {

        }
        public MultekCamstarDbContext() : base()
        {

        }
        #endregion
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //var Configurat = Configuration;
                ////获取配置文件
                //var getconfig = Configuration["ConnectionStrings:SqlDb"];
                var _env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                string _fileName = "appsettings.json";
                if (_env != null)
                    _fileName = $"appsettings.{_env}.json";
                Console.WriteLine(_fileName);
                // 使用数据库
                //optionsBuilder.UseSqlServer(new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile(_fileName).Build()["ConnectionStrings:SqlDb"]);
                //optionsBuilder.UseSqlServer(new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile(_fileName).Build()["ConnectionStrings:SqlDb"]);
                optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
                optionsBuilder.LogTo(msg =>
                {
                    if (msg.Contains("CommandExecuting"))
                        Console.WriteLine(msg);
                });
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }
    }
}