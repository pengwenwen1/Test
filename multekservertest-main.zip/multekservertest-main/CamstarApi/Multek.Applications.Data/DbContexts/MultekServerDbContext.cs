﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Multek.Applications.Data.Entities;
using Microsoft.Extensions.Configuration;
using Multek.Library_Core.COM.DbContexts;
using System.Reflection.Metadata;
using Multek.Library_Core.DbContexts;
using Multek.Applications.Model.Entities.TRC;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.Options;
using Multek.Library_Core.Model.COM;

namespace Multek.Applications.Data.DbContexts.Sample
{
    public class MultekServerDbContext : MultekDbContext
    {
        #region 新增数据库管理对象     
        #endregion

        #region 构造方法
        public MultekServerDbContext(DbContextOptions<MultekServerDbContext> builder) : base(builder)
        {

        }

        public MultekServerDbContext() : base()
        {

        }
        #endregion
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //var Configurat = Configuration;
                ////获取配置文件
                //var getconfig = Configuration["ConnectionStrings:SqlDb"];
                var _env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                string _fileName = "appsettings.json";
                //if (_env != null)
                //    _fileName = $"appsettings.{_env}.json";
                Console.WriteLine(_fileName);
                // 使用数据库
                //optionsBuilder.UseSqlServer(new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile(_fileName).Build()["ConnectionStrings:SqlDb"]);
                optionsBuilder.UseOracle(new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile(_fileName).Build()["ConnectionStrings:OracleDb"]).AddInterceptors(new ShardingDbCommandInterceptor()).ReplaceService<IMigrationsModelDiffer, MigrationsModelDifferWithoutForeignKey>();
                optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
                optionsBuilder.LogTo(msg =>
                {
                    if (msg.Contains("CommandExecuting"))
                        Console.WriteLine(msg);
                });
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        }
    }
}
