﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    /// <summary>
    /// 获取OA预冻结信息返回实体
    /// </summary>
    public class OAFutureHoldMsgRsp
    {
        [Key]
        [Description("冻结原因")]
        public string HoldReason { get; set; }

        //[Description("当前产品")]
        //public string PN { get; set; }

        //[Description("是否不活跃")]
        //public int? InActive { get; set; }

        //[Description("是否释放")]
        //public int Release { get; set; }
    }
}
