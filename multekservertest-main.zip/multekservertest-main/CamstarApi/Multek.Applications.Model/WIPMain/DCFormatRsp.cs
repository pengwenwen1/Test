﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    /// <summary>
    /// DataCodeFormat查询返回实体
    /// </summary>
    public class DCFormatRsp
    {
        [Key]
        [Description("lot号")]
        public string Lot { get; set; }

        [Description("DataCode 格式")]
        public string? DateCodeFormat { get; set; }

        [Description("DataCode 工序")]
        public string? DateCodeSpec { get; set; }

        [Description("Lot当前工序")]
        public string? Spec { get; set; }

        [Description("DateCode值")]
        public string? CuDateCode { get; set; }
    }
}
