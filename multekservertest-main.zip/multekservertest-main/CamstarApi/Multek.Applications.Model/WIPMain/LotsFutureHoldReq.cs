﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public  class LotsFutureHoldReq
    {
        [Description("当前工序")]
        public string Spec { get; set; }

        [Description("批次集合")]
        public List<string> Lots { get; set; }

        [Description("当前操作")]
        public int Action { get; set; }
    }
}
