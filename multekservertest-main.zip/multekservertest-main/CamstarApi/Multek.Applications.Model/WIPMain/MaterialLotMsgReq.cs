﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class MaterialLotMsgReq
    {
        [Description("批次号")]
        public string? Lot { get; set; }

        [Description("设备")]
        public string? Equipment { get; set; }
    }
}
