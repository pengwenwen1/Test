﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    /// <summary>
    /// LotWIP在线信息返回实体
    /// </summary>
    public class LotWIPTrackMsgRsp
    {
        [Description("工步序号")]
        public int? StepSequence { get; set; }

        [Key]
        [Description("工步")]
        public string? STEP { get; set; }

        [Description("进站数量")]
        public double? IN_QTY { get; set; }

        [Description("出站数量")]
        public double? OUT_QTY { get; set; }

        [Description("不良数量")]
        public double? REJ_QTY { get; set; }

        [Description("进站时间")]
        public DateTime? IN_TIME { get; set; }

        [Description("出站时间")]
        public DateTime? OUT_TIME { get; set; }

        [Description("出站操作人")]
        public string? OUT_USER { get; set; }
    }
}
