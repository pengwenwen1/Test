﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class FollowStepRsp
    {
        [Key]
        [Description("工序")]
        public string Specname { get; set; }

        [Description("工步")]
        public string Step { get; set; }

        [Description("设备")]
        public int sequence { get; set; }

        [Description("是否自动出站")]
        public int automoveout { get; set; }

        [Description("是否自动进站")]
        public int automovein { get; set; }
    }
}
