﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public  class ContainerInfo
    {
        [Key]
        //[Description("批次号")]
        public string CONTAINERNAME { get; set; }

        public string? productid { get; set; }
        

        //[Description("pcs面积")]
        public string? CUPCSAREA { get; set; }

        //[Description("拼版数")]
        public string? CUPCSPERPNL { get; set; }

        //[Description("pnl面积")]
        public string? CUPNLAREA { get; set; }

        //[Description("型号")]
        public string? PRODUCTNAME { get; set; }

        //[Description("型号版本")]
        public string? PRODUCTREVISION { get; set; }

        //[Description("工单")]
        public string? MFGORDER { get; set; }

        //[Description("流程")]
        public string? WORKFLOWNAME { get; set; }

        //[Description("step")]
        public string? WORKFLOWSTEP { get; set; }

        //[Description("pcs数")]
        public string? QTY { get; set; }

        //[Description("pnl数")]
        public string? QTY2 { get; set; }

        //[Description("CUTRACKFLAG")]
        public string? CUTRACKFLAG { get; set; }

        //[Description("hold标识")]
        public string? CURRENTHOLDCOUNT { get; set; }

        //[Description("STAMPCODE")]
        public string? CUSTAMPCODE { get; set; }

        //[Description("内外层标识")]
        public string? OUTER { get; set; }

        //[Description("oem描述")]
        public string? DESCRIPTION { get; set; }

        //[Description("oemname")]
        public string? Cuoemname { get; set; }

        //[Description("工厂")]
        public string? FACTORYNAME { get; set; }

        //[Description("ECN重打LOT卡状态")]
        public string? CUECNSTATUS { get; set; }

        //[Description("ORDERSTATUSNAME")]
        public string? ORDERSTATUSNAME { get; set; }

        //[Description("状态")]
        public string? STATUS { get; set; }

        //[Description("工单报废面积")]
        public string? DefectArea;

        //[Description("工单报废面积")]
        public string? lossreasonid;
        
    }
}
