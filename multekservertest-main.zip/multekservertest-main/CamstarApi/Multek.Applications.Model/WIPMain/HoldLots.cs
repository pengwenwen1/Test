﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class HoldLots
    {
       public List<HoldLot> holdLots {get;set;}

        /// <summary>
        /// 操作人
        /// </summary>
        public string Operator { get; set; }
    }

    public class HoldLot
    {
        public string lot {get;set;}
        public string? HoldReason { get;set;}
    }
}
