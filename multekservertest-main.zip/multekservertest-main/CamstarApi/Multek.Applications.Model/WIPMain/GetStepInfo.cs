﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public  class GetStepInfo
    {
        /// <summary>
        /// 工艺流程DBID
        /// </summary>
        public string WORKFLOW_ID { get; set; }

        /// <summary>
        /// pnl工步序号
        /// </summary>
        public int? FromSeq { get; set; }

        /// <summary>
        /// Lot工步序号
        /// </summary>
        public int? ToSeq { get; set; }
    }
}
