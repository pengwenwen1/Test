﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class CreateNewInsertionReq
    {
        /// <summary>
        /// Lot号
        /// </summary>
        public string Container { get; set; }
        /// <summary>
        /// 原因
        /// </summary>
        public string InsertionReason { get; set; }
        /// <summary>
        /// 扫描的Lot号
        /// </summary>
        public string SelectionId { get; set; }
        /// <summary>
        /// 操作人
        /// </summary>
        public string Employee { get; set; }
    }
}
