﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class ContinuousLotCompletionReq
    {
        /// <summary>
        /// Lot集合
        /// </summary>
        public List<string> Lots { get; set; }

        /// <summary>
        /// 工厂
        /// </summary>
        public string? Factory { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string? SpecName { get; set; }


        /// <summary>
        /// 设备号
        /// </summary>
        public string? EquipmentName { get; set; }

        /// <summary>
        /// DateCode
        /// </summary>
        public string? DateCode { get; set; }

        /// <summary>
        /// DateCode 格式
        /// </summary>
        public string? DateCodeFormat { get; set; }

        /// <summary>
        /// 操作人
        /// </summary>
        public string? Operator { get; set; }

        /// <summary>
        /// 当前工步信息
        /// </summary>
        public FollowStepRsp nowstep { get; set; }

        /// <summary>
        /// 获取需要补录过站信息的工步列表
        /// </summary>
        public List<StepListRsp> steplist { get; set; }
    }
}
