﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public  class LotMessage
    {
        /// <summary>
        /// Lot号
        /// </summary>
        [Key]
        public string? ContainerName { get; set; }

        /// <summary>
        /// Pcs数
        /// </summary>
        public int? Qty { get; set; }

        /// <summary>
        /// Pnl数
        /// </summary>
        public int? Qty2 { get; set; }

        /// <summary>
        /// 产品
        /// </summary>
        public string? ProductName { get; set; }

        /// <summary>
        /// 是否Hold，0 release，1 hold
        /// </summary>
        public int? CurrentHoldCount { get; set; }


        /// <summary>
        /// 状态，1 active ，2 close
        /// </summary>
        public int? status { get; set; }

        /// <summary>
        /// WIP 状态
        /// </summary>
        public int? Cutrackflag { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string? SpecName { get; set; }

        /// <summary>
        /// 工序版本
        /// </summary>
        public string? SpecVer { get; set; }

        /// <summary>
        /// 工序描述
        /// </summary>
        public string? SpecDesc { get; set; }

        /// <summary>
        /// 是否为钻码工序
        /// </summary>
        public int? IsDrillRoom { get; set; }

        /// <summary>
        /// 是否有设备
        /// </summary>
        public int? IsHaveEquipment { get; set; }

        /// <summary>
        /// 下一工序
        /// </summary>
        public string? ToSpecName { get; set; }

        /// <summary>
        /// 下一工序版本
        /// </summary>
        public string? ToSpecVer { get; set; }

        /// <summary>
        /// 当前工步
        /// </summary>
        public string? Step { get; set; }

        /// <summary>
        /// 下一工步
        /// </summary>
        public string? ToStep { get; set; }

        /// <summary>
        /// 下下工步
        /// </summary>
        public string? ToNextStep { get; set; }

        /// <summary>
        /// 当前工步序号
        /// </summary>
        public int? Seq { get; set; }

        /// <summary>
        /// ToNextSeq
        /// </summary>
        public int? ToSeq { get; set; }

        /// <summary>
        /// ToNextSeq
        /// </summary>
        public int? ToNextSeq { get; set; }

        /// <summary>
        /// 工艺Id
        /// </summary>
        public string? workFlowId { get; set; }

        /// <summary>
        /// 单panel的set数
        /// </summary>
        public int? S_QTY { get; set; }

        /// <summary>
        /// 单panel的Pcs数
        /// </summary>
        public int? U_QTY { get; set; }

        /// <summary>
        /// datacode fromat
        /// </summary>
        public string? DataCode_Format { get; set; }

        /// <summary>
        /// 当前工序是否为DataCode录入工序
        /// </summary>
        public int? IsDtSpec { get; set;}

        /// <summary>
        /// DataCode值
        /// </summary>
        public string? DataCode_Value { get; set; }

        /// <summary>
        /// 工厂
        /// </summary>
        public string? Factory { get; set; }

        /// <summary>
        /// 工厂简码
        /// </summary>
        public string? FactoryNotes { get; set; }

        /// <summary>
        /// 冻结原因
        /// </summary>
        public string? holdreasonname { get; set;}

        /// <summary>
        /// 设备号
        /// </summary>
        public string? Equipment { get; set; }

        /// <summary>
        /// 流程名称
        /// </summary>
        public string? workflowname { get; set; }

        /// <summary>
        /// 流程版本
        /// </summary>
        public string? workflowrevision { get; set;}

        /// <summary>
        /// 是否连续线设备
        /// </summary>
        public int? IsContinuous { get; set; }

        /// <summary>
        /// 工单
        /// </summary>
        public string? mfgordername { get; set; }

        /// <summary>
        /// UnTerminateWorkflowStep
        /// </summary>
        public string? UnTerminateWorkflowStep { get; set; }

        /// <summary>
        /// 是否首次插入
        /// </summary>
        public int IsFirstInsertion { get; set; }

        /// <summary>
        /// 是否使用队列
        /// </summary>
        public int CuUseQueue { get; set; }


        /// <summary>
        /// stampcode
        /// </summary>
        public string? Custampcode { get; set; }



    }
}
