﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class MaterialLotMsgRsp
    {
        [Description("批次号")]
        public string? ContainerName { get; set; }

        [Description("批次数量")]
        public int? qty { get; set; }

        [Description("产品料号")]
        public string? productname { get; set; }

        [Description("物料料号")]
        public string? Materailpart { get; set; }

        
        [Description("扣料系数")]
        public string? ConsumeFactor { get; set; }


        [Description("设备")]
        public string? Equipment { get; set; }

        [Key]
        [Description("物料批次")]
        public string? MaterialLot { get; set; }

    }
}
