﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public  class LotUnTerminateWorkflow
    {
        /// <summary>
        /// Lot号
        /// </summary>
        public string? ContainerName { get; set; }

        /// <summary>
        /// 流程名称
        /// </summary>
        [Key]
        public string? UnTerminateWorkflow { get; set; }

        /// <summary>
        /// 流程版本
        /// </summary>
        public string? UnTerminateWorkflowRevision { get; set;}

       
        /// <summary>
        /// UnTerminateWorkflowStep
        /// </summary>
        public string? UnTerminateWorkflowStep { get; set; }




    }
}
