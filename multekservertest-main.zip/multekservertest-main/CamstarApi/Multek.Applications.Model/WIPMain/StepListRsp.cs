﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    /// <summary>
    /// 需要补录过站信息的工步列表
    /// </summary>
    public class StepListRsp
    {
        [Key]
        public string StepName { get; set; }

        /// <summary>
        /// Lot工步序号
        /// </summary>
        public int Seq { get; set; }

        /// <summary>
        /// 下一工步
        /// </summary>
        public string ToStepName { get; set; }

        /// <summary>
        /// 下一工步序号
        /// </summary>
        public int ToSeq { get; set; }


        /// <summary>
        /// 工序
        /// </summary>
        public string SpecName { get; set; }


        /// <summary>
        /// 工序版本
        /// </summary>
        public string SpecVer { get; set; }


        [Description("是否自动出站")]
        public int automoveout { get; set; }

        [Description("是否自动进站")]
        public int automovein { get; set; }
    }
}
