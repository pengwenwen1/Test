﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public  class EquipmentMsgRsp
    {
        [Key]
        [Description("设备号")]
        public string Equipment { get; set; }

        [Description("设备描述")]
        public string EquipmentDesc { get; set; }
    }
}
