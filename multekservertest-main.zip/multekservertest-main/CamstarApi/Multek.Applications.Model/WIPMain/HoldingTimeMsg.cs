﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class HoldingTimeMsg
    {
        [Key]
        [Comment("计时器Id")]
        public string? processtimerid { get; set; }

        [Comment("结束操作")]
        public int? endopt { get; set; }

        [Comment("结束工序")]
        public string? endspec { get; set; }

        [Comment("计时器名称")]
        public string? processtimername { get; set; }

        [Comment("计时器类型")]
        public int? timertype { get; set; }

        [Comment("最大时间")]
        public double? maxtime { get; set; }

        [Comment("最大预警时间")]
        public double? maxwarningtime { get; set; }

        [Comment("最小时间")]
        public double? mintime { get; set; }

        [Comment("最小预警时间")]
        public double? minwarningtime { get; set; }

        [Comment("最大时间指令")]
        public int? maxaction { get; set; }

        [Comment("最大时间是否hold")]
        public int? maxhold { get; set; }

        [Comment("最大时间hold原因")]
        public string? maxreason { get; set; }


        [Comment("最小时间指令")]
        public int? minaction { get; set; }

        [Comment("最小时间是否hold")]
        public int? minhold { get; set; }

        [Comment("最小时间hold原因")]
        public string? minreason { get; set; }

        [Comment("开始操作")]
        public int? startopt { get; set; }

        [Comment("开始工序")]
        public string? startspec { get; set; }

        [Comment("产品")]
        public string? ProductName { get; set; }

        [Comment("开始工序Id")]
        public string? startspecid { get; set; }
        
    }
}
