﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class EmployeeSpecRsp
    {

        [Description("员工号")]
        public string? Employee { get; set; }

        [Description("员工描述")]
        public string? EmployeeDesc { get; set; }

        [Key]
        [Description("工序")]
        public string? Spec { get; set; }

        [Description("工序描述")]
        public string? SpecDesc { get; set; }

        [Description("员工姓名")]
        public string? fullname { get; set; }
    }
}
