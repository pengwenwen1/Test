﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    /// <summary>
    /// 获取OA预冻结信息传入实体
    /// </summary>
    public class OAFutureHoldMsgReq
    {
        [Description("当前工序")]
        public string Spec { get; set; }

        [Description("当前产品")]
        public string PN { get; set; }

        [Description("当前操作")]
        public int Action { get; set; }
    }
}
