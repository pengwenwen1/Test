﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public  class GetLotInspect
    {
        /// <summary>
        /// Lot
        /// </summary>
        [Key]
        public string? ContainerName { get; set; }

        /// <summary>
        /// 首检标识
        /// </summary>
        public string? CUISFIRSTINSPECT { get; set; }

        /// <summary>
        /// 末检标识
        /// </summary>
        public string? CUISLASTINSPECT { get; set; }
    }
}
