﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class HoldingTimeReq
    {
        [Description("结束工序")]
        public string EndSpec { get; set; }

        //[Comment("结束操作")]
        //public string? EndOpt { get; set; }

        public List<string> Lots { get; set; }
    }
}
