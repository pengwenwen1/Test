﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPMain
{
    public class MoveOutNextStep
    {
        /// <summary>
        /// Lot号
        /// </summary>
        [Key]
        public string? ContainerName { get; set; }

        /// <summary>
        /// ToNextStep
        /// </summary>
        public string? ToNextStep { get; set; }

        /// <summary>
        /// ToNextSeq
        /// </summary>
        public int? ToNextSeq { get; set; }

        /// <summary>
        /// ToSpecName
        /// </summary>
        public string? ToSpecName { get; set; }

        /// <summary>
        /// ToSpecVer
        /// </summary>
        public string? ToSpecVer { get; set; }
    }
}
