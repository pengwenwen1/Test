﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.HoldRelease
{
    public class HoldLotInfoRsp
    {
        /// <summary>
        /// 冻结LOT号
        /// </summary>
        public List<HoldList> holdLists { get; set; }

        /// <summary>
        /// 冻结用户
        /// </summary>
        public string HoldUser { get; set; }

        /// <summary>
        /// 冻结默认原因
        /// </summary>
        public string? cuDefultHoldReason { get; set; }

    }

    public class HoldList
    {
        /// <summary>
        /// 冻结批次
        /// </summary>
        [Required]
        public string ContainerName {  get; set; }

        /// <summary>
        /// 冻结备注
        /// </summary>
        public string? cuComments {  get; set; }

        /// <summary>
        /// 冻结原因
        /// </summary>
        public string? HoldReason {  get; set; }
    }
}
