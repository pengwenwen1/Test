﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.SplitAndCombine
{
    public class GetNewLotRsp
    {
        public string? Level { get; set; }
        /// <summary>
        /// 原批次
        /// </summary>
        public string FromContainer { get; set; }

        /// <summary>
        /// 新批次
        /// </summary>
        [Key]
        public string ToContainer { get; set; }

        /// <summary>
        /// 拆批时间
        /// </summary>
        public DateTime? Systemdate { get; set; }

        /// <summary>
        /// 拆批次序
        /// </summary>
        public int? ToContainerSequence { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int? status { get; set; }
    }
}
