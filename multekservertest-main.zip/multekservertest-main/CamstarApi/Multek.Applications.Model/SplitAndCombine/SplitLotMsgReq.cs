﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.SplitAndCombine
{
    public class SplitLotMsgReq
    {
        /// <summary>
        /// lot
        /// </summary>
        [Required(ErrorMessage ="lot不能为空")]
        public string lot { get; set; }

        /// <summary>
        /// 拆批原因
        /// </summary>
        [Required(ErrorMessage ="拆批原因不能为空")]
        public string SplitReason { get; set; }

        /// <summary>
        /// 拆批用户
        /// </summary>
        public string SplitUser { get; set; }

        /// <summary>
        /// 执行qty名字
        /// </summary>
        public string QtyName { get; set; }

        /// <summary>
        /// 拆批数量
        /// </summary>
        [Required(ErrorMessage = "拆批数量不能为空")]
        public int Qty { get; set; }
    }
}
