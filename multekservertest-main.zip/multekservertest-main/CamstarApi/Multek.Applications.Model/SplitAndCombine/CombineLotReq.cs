﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.SplitAndCombine
{
    public class CombineLotReq
    {
        /// <summary>
        /// 主批次
        /// </summary>
        [Required(ErrorMessage ="主批次不能为空")]
        public string Container {  get; set; }

        /// <summary>
        /// 合并的批次List
        /// </summary>
        public List<Con> FromContainer {  get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int WIP_stutas { get; set; }

        /// <summary>
        /// 设备
        /// </summary>
        public string? Equipment { get; set; }

        /// <summary>
        /// 合批人员
        /// </summary>
        public string CombineUser { get; set; }

        /// <summary>
        /// 载具
        /// </summary>
        public string? Carrier { get; set; }

    }

    public class Con
    {
        /// <summary>
        /// LotName
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Lot Qty
        /// </summary>
        public int Qty { get; set; }
    }
}
