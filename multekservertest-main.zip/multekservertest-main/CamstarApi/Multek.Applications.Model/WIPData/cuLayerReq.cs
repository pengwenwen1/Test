﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class cuLayerReq
    {
        public List<CuLayerAttachDetails>? AttachDetails {  get; set; }
        public List<cuNexLayerWorkOrder>? cuNexLayerWorkOrders { get; set; }
        public string? NextLayerProductName { get; set; }
        public string? NextLayerProductRevision { get; set; }
        public string? NextLayerMaxPN { get; set; }
        public string? NextLayerMaxPNRevision { get; set; }
        public double? cuNextwomaxpnlqty { get; set; }
        public string? cuLayerNo { get; set; }
        public int? cuLayerSeq { get; set; }
        public double? cuQty { get; set; }
        public string? cuWorkOrder { get; set; }
        public double? cuPNLQty { get; set; }
        public string? cuInOutLayerLotRelName { get; set; }
        public string? cuProduct { get; set; }
        public string? cuWorkFlow { get; set; }
        public string? cuWorkFlowStep { get; set; }
        public string? cuFactory { get; set; }
        public string? cuRequestRevision { get; set; }

    }
}