﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class GetERCInfoReq
    {
        /// <summary>
        /// 产品类型
        /// </summary>
        public string Prdouct {  get; set; }
        /// <summary>
        /// 是否是在线
        /// </summary>
        public bool CUALLOWERC {  get; set; }

       
    }
}
