﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class ECNFunctionChangeDetails
    {

        public string? Cuecnfutureholdname { get; set; }
        public string? Cupjten { get; set; }
        public string? Culayerno { get; set; }
        public string? Cunewpjten { get; set; }
        public string? Cunewproductid { get; set; }
        public string? CuAssemblyWorkflow { get; set; }
        public string? CuSortNo { get; set; }
        public string? CuStep { get; set; }
        public string? Newwfname { get; set; }
        public string? CuNewWorkflow { get; set; }
        public string? CuJDE_PN { get; set; }
        public string? CuMI_PN { get; set; }
        public string? CuWOJDE_PN { get; set; }
        public string? CuNewMI_PN { get; set; }
        public string? CuInfluenceSpec { get; set; }
        public string? Influrev { get; set; }
        public string? CuSpec { get; set; }
        public string? CuJDE_Spec { get; set; }
        public string? CuTrackFlag { get; set; }
        public string? CuLayerType { get; set; }
        public string? CuProductiontypename { get; set; }
        public int cuRrentHoldCount { get; set; }
        public string? HoldReasonName { get; set; }
        public string? cuFactory { get; set; }
        public string? cuIsExecHold { get; set; }
        [Key]
        public string? cuLot { get; set; }
        public string? cunewpn { get; set; }
        public string? cupn { get; set; }

        public string? cuOrderType { get; set; }
        public string? cuPNLQty { get; set; }
        public string? cuQty { get; set; }
        public string? workflowid { get; set; }
        public string? cuWorkOrder { get; set; }


    }
}
