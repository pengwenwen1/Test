﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    /// <summary>
    /// 内外层配单-请求工单实体
    /// </summary>
    public class MiddleCuIntOutwoapply
    {

        /// <summary>
        /// Desc: MMUKID
        /// DbType: NUMBER,22
        /// Nullable: 否
        /// Default: 
        /// </summary>
        public string MMUKID { get; set; }

        /// <summary>
        /// Desc: MMEDBT
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMEDBT { get; set; }

        /// <summary>
        /// Desc: MMEDSP
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMEDSP { get; set; }

        /// <summary>
        /// Desc: MMEDLN
        /// DbType: NUMBER,22
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public decimal MMEDLN { get; set; }

        /// <summary>
        /// Desc: MMLOTN
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMLOTN { get; set; }

        /// <summary>
        /// Desc: MMITM
        /// DbType: NUMBER,22
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public decimal MMITM { get; set; }

        /// <summary>
        /// Desc: MMLITM
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMLITM { get; set; }

        /// <summary>
        /// Desc: MMMMCU
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMMMCU { get; set; }

        /// <summary>
        /// Desc: MMMSGT
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMMSGT { get; set; }

        /// <summary>
        /// Desc: MMMSGA
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMMSGA { get; set; }

        /// <summary>
        /// Desc: MMDCTO
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMDCTO { get; set; }

        /// <summary>
        /// Desc: MMDSC1
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMDSC1 { get; set; }

        /// <summary>
        /// Desc: MMTRQT
        /// DbType: NUMBER,22
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public decimal MMTRQT { get; set; }

        /// <summary>
        /// Desc: MMDRQJ
        /// DbType: DATE,7
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public int MMDRQJ { get; set; }

        /// <summary>
        /// Desc: MMSTRT
        /// DbType: DATE,7
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public int MMSTRT { get; set; }

        /// <summary>
        /// Desc: MMUPMJ
        /// DbType: DATE,7
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public int MMUPMJ { get; set; }

        /// <summary>
        /// Desc: MMUPMT
        /// DbType: NUMBER,22
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public int MMUPMT { get; set; }

        /// <summary>
        /// Desc: MMTRDJ
        /// DbType: DATE,7
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public int MMTRDJ { get; set; }

        /// <summary>
        /// Desc: MMTDAY
        /// DbType: NUMBER,22
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public int MMTDAY { get; set; }

        /// <summary>
        /// Desc: MMTBM
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMTBM { get; set; }

        /// <summary>
        /// Desc: MMTRT
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMTRT { get; set; }

        /// <summary>
        /// Desc: MMVR01
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMVR01 { get; set; }

        /// <summary>
        /// Desc: MMUORG
        /// DbType: NUMBER,22
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public decimal MMUORG { get; set; }

        /// <summary>
        /// Desc: MMURAB
        /// DbType: NUMBER,22
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public decimal MMURAB { get; set; }

        /// <summary>
        /// Desc: MMBREV
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMBREV { get; set; }


        /// <summary>
        /// Desc: MMRREV
        /// DbType: VARCHAR2,30
        /// Nullable: 是
        /// Default: 
        /// </summary>
        public string MMRREV { get; set; }
    }
}
