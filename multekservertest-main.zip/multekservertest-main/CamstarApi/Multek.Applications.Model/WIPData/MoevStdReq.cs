﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class MoevStdReq
    {
        /// <summary>
        /// 跳站批次
        /// </summary>
        [Required]
        public string Container { get; set; }

        /// <summary>
        /// 跳站原因
        /// </summary>
        public string MoveStdReason { get; set; }

        /// <summary>
        /// 是否取消生产
        /// </summary>
        public bool CancelWIPTracking { get; set; }

        /// <summary>
        /// 是否拆批
        /// </summary>
        public bool SplitBins { get; set; }

        /// <summary>
        /// 是否触发移进
        /// </summary>
        public bool TriggerMoveIn {  get; set; }

        /// <summary>
        /// 是否报废
        /// </summary>
        public bool YieldOffRejects { get; set;}
        /// <summary>
        /// 跳站工序
        /// </summary>
        public string ToWorkflowStep { get; set; }

        /// <summary>
        /// 跳站工序类型
        /// </summary>
        public  string? ToStepType { get; set; }

        /// <summary>
        /// 跳站路径
        /// </summary>
        public string? Path { get; set; }

        /// <summary>
        /// 跳站人员
        /// </summary>
        public string? Employee { get; set; }

        /// <summary>
        /// 流程
        /// </summary>
        public toWorkflow? ToWorkflow { get; set; }
    }

    public class toWorkflow
    {
        /// <summary>
        /// 流程名称
        /// </summary>
        public string? workflowname { get; set; }

        /// <summary>
        /// 流程版本
        /// </summary>
        public string? workflowrevision { get; set; }
    }
}
