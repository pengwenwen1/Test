﻿using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.WIPMain;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class EntryDataCodeReq
    {
        /// <summary>
        /// lot批次
        /// </summary>
        [Required]
        public List<LotMessage> containers {  get; set; }

        /// <summary>
        /// DataCode值
        /// </summary>
        [Required]
        public string DCValue { get; set; }
        /// <summary>
        /// dataCode 格式
        /// </summary>
        public string? DCFromt { get; set; }

        /// <summary>
        /// 登录用户 
        /// </summary>
        public string Employee { get; set; }
    }
}
