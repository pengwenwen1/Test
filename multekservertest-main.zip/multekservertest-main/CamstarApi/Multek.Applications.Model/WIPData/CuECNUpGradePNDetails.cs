﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuECNUpGradePNDetails
    {
        /// <summary>
        /// 批次
        /// </summary>
        public string Container {  get; set; }
        /// <summary>
        /// PNL数量
        /// </summary>
        public string PNLQty { get; set; }
        public string PcsQty { get; set; }

        /// <summary>
        /// 当前产品
        /// </summary>
        public string Product { get; set; }

        public string Spec {  get; set; }
        public string SpecType {  get; set; }
        public string StripQty { get; set; }
        public string WaferMapDetailsType { get; set; }
        public bool cuNeedCreateNewWO {  get; set; }
        public string cuNewJDE_PN { get; set; }
        public string cuNewMI_PN { get; set; }
    }

    public class CuERCUpGradePNDetails
    {
        /// <summary>
        /// 批次
        /// </summary>
        [Key]
        public string Container { get; set; }
        /// <summary>
        /// PNL数量
        /// </summary>
        public string? PNLQty { get; set; }
        public string? PcsQty { get; set; }

        /// <summary>
        /// 当前产品
        /// </summary>
        public string? Product { get; set; }

        public string? Spec { get; set; }
        public string? SpecType { get; set; }
        public string? StripQty { get; set; }
        public string? CUJDELOT {  get; set; }
        public string? Productrevision { get; set;}
        public string? Specrevision { get; set; }
        public string? cuContainer { get; set; }
        public string? WaferMapDetailsType { get; set; }
        

    }
}
