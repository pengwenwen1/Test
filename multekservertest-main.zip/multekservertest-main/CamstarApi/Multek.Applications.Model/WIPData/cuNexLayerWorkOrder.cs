﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class cuNexLayerWorkOrder
    {
            [Key]
            public string? MFGORDERNAME {  get; set; }
            public double? PNLQTY {  get; set; }
            public double? SETQTY {  get; set; }
            public double? PCSQTY {  get; set; }
            public string? PRODUCTNAME {  get; set; }
            public string? PRODUCTREVISION {  get; set; }
            public string? LAYERNUM {  get; set; }
            public string? LAYERNO {  get; set; }
            public string? INOUTLAYERLOTRELNAME {  get; set; }
    }
}
