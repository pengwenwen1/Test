﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuEcnChangeResult
    {
        [Required]
        [Description("批次号")]
        public string WFEDBT { get; set; }

        [Required]
        [Description("行号")]
        public decimal MMEDLN { get; set; }

        [Description("处理标记-初始值0")]
        public string WFEDSP { get; set; } = "0";

        [Description("工单类型")]
        public string WFDCTO { get; set; }

        [Description("工单号")]
        [MaxLength(8)]
        public string WFDOCO { get; set; }

        [Description("分部")]
        public string WFMMCU { get; set; }

        [Description("类型")]
        public string WFUR01 { get; set; }

        [Description("型号")]
        public string WFLITM { get; set; }

        [Description("生产_PJ(原生产型号)")]
        public string WFVR01 { get; set; }

        [Description("ERC_PJ(ECN升级后型号)")]
        public string WFURRF { get; set; }

        [Description("工序号")]
        public decimal WFOPSQ { get; set; }

        [Description("工作中心")]
        public string WFMCU { get; set; }

        [Description("是否删除工艺路线(工艺路径不一致_删除Y，工艺路径一致_不需要删除N)")]
        public string WFUNGL { get; set; }

        [Description("ERC号")]
        public string WFDL05 { get; set; }

        [Description("当前工序数量(数量*100000)")]
        public decimal WFQMTO { get; set; }

        [Description("工序报废数量(数量*100000)")]
        public decimal WFSOCN { get; set; }

        [Description("工单完工数量(数量*100000)")]
        public decimal WFSOQS { get; set; }

        [Description("雇员号")]
        public string WFAN8 { get; set; }

        [Description("JDEUser")]
        public string WFUSER { get; set; }

        [Description("发生日期")]
        public decimal WFTRDJ { get; set; }

        [Description("发生时间")]
        public decimal WFTDAY { get; set; }

        [Description("JDE_PN")]
        public string WFCITM { get; set; }

        [Description("Routing类型(如果内层当前是最新版本传M，否则就传M和当前批次的版本（M？）)")]
        public string WFTRT { get; set; }

        [Description("Camstar操作时间")]
        public DateTime CREATEDTIME { get; set; }

        [Description("Camstar当前操作用户")]
        public string CREATEDBY { get; set; }
    }
}
