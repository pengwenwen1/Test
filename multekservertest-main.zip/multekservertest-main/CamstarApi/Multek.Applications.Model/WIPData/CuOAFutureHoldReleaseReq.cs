﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuOAFutureHoldReleaseReq
    {
        /// <summary>
        /// OA预Hold的单号
        /// </summary>
        public string cuOAFutureHoldName { get; set; }

        /// <summary>
        /// OA预Hold 释放明细
        /// </summary>
        public IList<CuOAFutureHoldReleaseDetails> cuOAFutureHoldReleaseDetails { get; set; }
    }
    public class CuOAFutureHoldReleaseDetails
    {

        /// <summary>
        /// 工序
        /// </summary>
        public string cuPN { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string cuPNRev { get; set; }
        /// <summary>
        /// 工序信息
        /// </summary>
        public string cuSpec { get; set; }
    }
}
