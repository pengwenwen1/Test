﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class GetEmployeeInfo
    {
        /// <summary>
        /// 登录人员
        /// </summary>
        public string Employee { get; set; }
    }
}
