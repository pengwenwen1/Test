﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuOAFutureHoldRep
    {
        /// <summary>
        /// OA预Hold的单号
        /// </summary>
        public string cuOAFutureHoldName { get; set; }

        /// <summary>
        /// OA预Hold明细
        /// </summary>
        public IList<CuOAFutureHoldDetails> cuOAFutureHoldDetails { get; set; }

    }

    public class CuOAFutureHoldDetails
    {
        /// <summary>
        /// 1:表示MoveIn 2：MoveOut
        /// </summary>
        public int cuFutureHoldAction { get; set; } = 1;

        /// <summary>
        /// Hold的原因
        /// </summary>
        public string cuHoldReason { get; set; }


        /// <summary>
        /// 是否关联解除Hold操作  true :自动解除Hold
        /// </summary>
        public bool cuLinkRelease { get; set; } = true;
        /// <summary>
        /// 
        /// </summary>
        public string cuPN { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string cuPNRev { get; set; }
        /// <summary>
        /// 工序信息
        /// </summary>
        public string cuSpec { get; set; }
    }
}
