﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class ERCReq
    {
        /// <summary>
        /// 原产品
        /// </summary>
        public string cuProduct { get; set; }

        /// <summary>
        /// 新产品
        /// </summary>
        public string cuNewProduct { get; set; }
        /// <summary>
        /// 产品TextBox
        /// </summary>
        public string cuProductA { set; get; }

        /// <summary>
        /// 勾选Lot明细
        /// </summary>
        //public List<CuECNUpGradePNDetails> LotDetail { get; set; }
        public List<CuERCUpGradePNDetails> LotDetail { get; set; }

        /// <summary>
        /// 工序类型
        /// </summary>
        public string? cuSpecType { get; set; }

        /// <summary>
        /// 产品Type
        /// </summary>
        public string? cuProductType { set; get; }
        public string? cuNewProductType { set; get; }
        public bool cuUpGradePNBOM { get; set; }
        public string? cuOperationType { get; set; }
        public string? cuJDE_PN {  get; set; }
        public string? cuMI_PN { get; set; }
        public string? cuNewJDE_PN {  set; get; }
        public string? cuNewMI_PN{ get; set; }
        public bool? cuNeedCreateNewWO { get; set; }
    }
}
