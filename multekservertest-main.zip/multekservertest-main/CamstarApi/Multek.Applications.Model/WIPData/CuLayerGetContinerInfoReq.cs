﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuLayerGetContinerInfoReq
    {
        /// <summary>
        /// 批次号
        /// </summary>
        public string Container { get; set; }
        public string? cuFactory { get; set; }


    }
}
