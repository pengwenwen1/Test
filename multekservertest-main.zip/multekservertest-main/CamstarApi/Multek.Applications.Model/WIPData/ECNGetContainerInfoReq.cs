﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class ECNGetContainerInfoReq
    {
        public string? CUSEQUENCE { get; set; }
       
        public string CONTAINERNAME { get; set; }
        public double? QTY { get; set; }
        public double? QTY2 { get; set; }
        public string? ORDERTYPENAME { get; set; }
        public string? SPECNAME { get; set; }
        public string? MFGORDERID { get; set; }
        [Key]
        public string? MFGORDERNAME { get; set; }

        public string? PROCESSSPECID { get; set; }
        public string? PROCESSSPECNAME { get; set; }
        public string? PROCESSSPECREVISION { get; set; }
        public string? WORKFLOWID { get; set; }
        public string? SPECREVISION { get; set; }
        public string? DAYSHERE { get; set; }
        public string? PRODUCTNAME { get; set; }
        public string? PRODUCTREVISION { get; set; }
        public string? STATUS { get; set; }
        public string? ISONHOLD { get; set; }
        public string? INREWORK { get; set; }
        public string? FUTUREHOLDEXISTS { get; set; }
        public string? ONLOAN { get; set; }
        public string? INSCHEDULE { get; set; }
        public string? INSERTION { get; set; }
        public string? BATCHNO { get; set; }
        public string? EQPCOUNT { get; set; }
        public string? EQPLOADINGCOUNT { get; set; }
        public string? SPECPASS { get; set; }
        public string? SPECCATEGORY { get; set; }
        public string? SPECTYPE { get; set; }
        public string? SPECDESCRIPTION { get; set; }
        public string? NO { get; set; }
    }
}
