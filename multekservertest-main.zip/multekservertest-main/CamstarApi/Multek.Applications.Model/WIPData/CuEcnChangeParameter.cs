﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuEcnChangeParameter
    {
        /// <summary>ECN单号</summary>

        public string cuECNNo { get; set; }

        /// <summary>PJ10</summary>

        public string cuPN { get; set; }

        /// <summary>NewPJ10</summary>

        public string cuNewPN { get; set; }

        /// <summary>状态</summary>

        public int cuStatus { get; set; }

        /// <summary>OA设置明细</summary>

        public List<EcnChangeDetail>? Detail { get; set; }

        /// <summary>待记录ECN列表记录</summary>

        public IList<EcuEcnExecuteDetail>? ExecuteDetail { get; set; }

        /// <summary>设置FutureHold明细</summary>

        public IList<EcnFutureHoldModel>? ExecuteFutureHoldDetail { get; set; }

        /// <summary>
        /// 分段预Hold明细
        /// </summary>

        public IList<CuOAFutureHoldDetails>? CuOAFutureHoldDetails { get; set; }
    }

    public class EcnFutureHoldModel
    {

        public bool IsExecuteHold { get; set; }

        public IList<EcnContainerName> ContainerNames { get; set; }

        public IList<EcnFutureHoldCondition> HoldCondition { get; set; }
    }

    public class EcuEcnExecuteDetail
    {
        /// <summary>批次</summary>

        public string cuLot { get; set; }

        /// <summary>工单</summary>

        public string MfgOrder { get; set; }

        /// <summary>影响工序</summary>

        public string cuSpec { get; set; }

        /// <summary>新料号</summary>

        public string cuNewPN { get; set; }

        /// <summary>新料号版本</summary>

        public string cuNewPNVersion { get; set; }

        /// <summary>旧料号</summary>

        public string cuPN { get; set; }

        /// <summary>旧料号版本</summary>

        public string cuPNVersion { get; set; }

        /// <summary>是否执行Hold</summary>

        public bool IsExecuteHold { get; set; }


        public string IsExecuteHoldStr => IsExecuteHold ? "True" : "False";
    }

    public class EcnChangeDetail
    {
        /// <summary>影响工序</summary>

        public string cuSpec { get; set; }

        /// <summary>是否Hold</summary>

        public bool cuIsHold { get; set; }

        /// <summary>新料号</summary>

        public string cuNewPN { get; set; }

        /// <summary>新料号版本</summary>

        public string cuNewPNVersion { get; set; }

        /// <summary>旧料号</summary>

        public string cuPN { get; set; }

        /// <summary>旧料号版本</summary>

        public string cuPNVersion { get; set; }
    }

    public class EcnFutureHoldCondition
    {

        public string Comments { get; set; } = "Interface executor future hold(接口程序执行预Hold)";

        public string HoldReason { get; set; } = "ECN";

        public string Spec { get; set; }

        public string SpecVersion { get; set; }
    }

    public class EcnContainerName
    {

        public string ContainerName { get; set; }
    }
}
