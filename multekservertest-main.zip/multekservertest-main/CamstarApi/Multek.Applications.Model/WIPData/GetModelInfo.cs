﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class GetModelInfo
    {
        /// <summary>
        /// 查询实体名称
        /// </summary>
        public string ModelName { get; set; }

        public Dictionary<string, string> paramentersDic{ get; set; }

    }
}
