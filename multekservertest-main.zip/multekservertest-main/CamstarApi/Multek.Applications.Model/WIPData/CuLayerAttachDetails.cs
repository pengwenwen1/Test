﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuLayerAttachDetails
    {
        /// <summary>
        /// 批次
        /// </summary>
        [Key]
        public string cuContainer { get; set; }
        /// <summary>
        /// 工单
        /// </summary>
        public string? cuWorkOrder { get; set; }
        /// <summary>
        /// 料号
        /// </summary>
        public string? cuPN { get; set; }
        /// <summary>
        /// qty
        /// </summary>
        public double? cuStripQty { get; set; }
        /// <summary>
        /// inoutlayer
        /// </summary>
        public string? cuInOutLayerLotRelName { get; set; }
        /// <summary>
        /// layer序号
        /// </summary>
        public string? cuLayerNo { get; set; }
        /// <summary>
        /// cuPNlQty
        /// </summary>
        public double cuPNLQty { get; set; }
        /// <summary>
        /// layer序号
        /// </summary>
        public int? cuLayerSeq { get; set; }
        /// <summary>
        /// pcsqty
        /// </summary>
        public double  cuQty { get; set; }
        /// <summary>
        /// 工厂
        /// </summary>
        public string? FACTORYNAME { get; set; }
        /// <summary>
        /// 生成最新的版本
        /// </summary>
        public string? cuRequestRevision { get; set; }
        public string? cuNextLayerPNMaxRev { get; set; }
        public string? cuNextLayerPNRev { get; set; }
        public string? cuNextLayerPN { get; set; }
        public double cuNextwomaxpnlqty { get; set; }





    }
}
