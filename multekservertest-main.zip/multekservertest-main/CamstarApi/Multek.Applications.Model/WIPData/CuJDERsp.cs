﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuJDELoginResult
    {
        /// <summary>
        /// environment
        /// </summary>
        public string environment { get; set; }

        /// <summary>
        /// deviceName
        /// </summary>
        public string deviceName { get; set; }
        /// <summary>
        /// username
        /// </summary>
        public string username { get; set; }

        /// <summary>
        /// password
        /// </summary>
        public string password { get; set; }
        /// <summary>
        /// password
        /// </summary>
        public string role { get; set; }
    }
    public class CuJDELogoutResult
    {
        /// <summary>
        /// token
        /// </summary>
        public string token { get; set; }

        /// <summary>
        /// ODI
        /// </summary>
        public string deviceName { get; set; }
    }
}
