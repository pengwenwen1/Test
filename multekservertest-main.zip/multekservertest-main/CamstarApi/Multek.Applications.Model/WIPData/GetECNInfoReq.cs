﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class GetECNInfoReq
    {
        /// <summary>
        /// ECNNO
        /// </summary>
        public string cuECNNo { get; set; }
        /// <summary>
        /// 登录用户
        /// </summary>
        public string Employee { get; set; }
    }
}
