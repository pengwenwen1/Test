﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.WIPData
{
    public class CuECNChangeReq
    {
        /// <summary>
        /// ECN序号
        /// </summary>
        public string cuECNNo {  get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string? cuECNWONR { get; set; }

        public int? cuOperationType { get; set; }
        public bool? cuUpGradePNBOM { get; set; }
        public string? employee { get; set; }
        /// <summary>
        /// ECN变更序号List
        /// </summary>
        public List<ECNFunctionChangeDetails> CuECNChangeDetails { get; set; }

    }
}
