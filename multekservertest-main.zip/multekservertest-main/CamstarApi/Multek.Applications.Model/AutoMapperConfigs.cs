﻿using AutoMapper;
using Multek.Applications.Data.Entities;
using Multek.Applications.Model.DrillingMachine;
using Multek.Applications.Model.DrillingMachine.Rsp;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;

namespace Multek.Applications.Model
{
    public class AutoMapperConfigs : Profile
    {
        public AutoMapperConfigs()
        {
            CreateMap<CodeInfoOfPanel, GetPanelsCodeByLotRsp>();
            CreateMap<CodeInfoOfSet, GetSetAndPcsCodesByPnlRsp>();
            CreateMap<CodeInfoOfSet, CodeInfoOfSetDto>();
            CreateMap<WipCount,MESTrackRsp > ();
            CreateMap<WipCount, MESMoveInRsp>();
        }
    }
}