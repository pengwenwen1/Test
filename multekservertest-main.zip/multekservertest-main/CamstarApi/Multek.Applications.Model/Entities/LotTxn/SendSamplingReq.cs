﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class SendSamplingReq
    {
        public bool ManualFlag { get; set; }
        public string Employee { get; set; }
        public List<CheckBatchSrvDatas> cuCheckBatchSrvDatas { get; set; }
    }

    public class CheckBatchSrvDatas
    {
        public string SamplingTaskName { get; set; }
        public string CreateLot { get; set; }
    }
}
