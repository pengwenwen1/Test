﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class PostSamplingCheckTask_Req
    {
        public string Employee { get; set; }
        public string IsHand { get; set; }
        public bool IsPass { get; set; }
        public List<PostSamplingCheckTask> PostSamplingCheckTask { get; set; }
    }

    public class PostSamplingCheckTask
    {
        /// <summary>
        /// 任务
        /// </summary>
        public string TaskName { get; set; }
        /// <summary>
        /// 批次号
        /// </summary>
        public string Lot { get; set; }
        public string PNL { get; set; }
        /// <summary>
        /// 上传的附件 Base64编码字符串
        /// </summary>
        public List<string> UploadFile { get; set; }
    }
}
