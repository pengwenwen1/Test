﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSLotInfoModel
    {
        public string ProductreVision { get; set; }
        public string cuWorkOrder { get; set; }
        [Key]
        public string cuLot { get; set; }
        public string cuPNLQty { get; set; }
        public string cuSetQty { get; set; }
        public string cuNeedProcessQty { get; set; }
        public string cuPCSQty { get; set; }
        public string cuPN { get; set; }
        public string cuSpec { get; set; }
        public string WorkflowRevision { get; set; }
        public string cuPerPCSArea { get; set; }
        public string WorkflowName { get; set; }
        public string WorkflowStepName { get; set; }
        public string Sequence { get; set; }
        public string FactoryName { get; set; }
    }
}
