﻿using Castle.Components.DictionaryAdapter;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSSpecInfoModel
    {
        public string Sequence { get; set; }
        public string WorkflowRevision { get; set; }
        public string WorkflowName { get; set; }
        [System.ComponentModel.DataAnnotations.Key]
        public string StepName { get; set; }
        public string WorkflowStepName { get; set; }
        public string RN { get; set; }
    }
}
