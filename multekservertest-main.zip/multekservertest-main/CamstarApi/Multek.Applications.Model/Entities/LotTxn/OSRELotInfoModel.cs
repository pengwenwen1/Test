﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSRELotInfoModel
    {
        public string? Factoryname { get; set; }
        public string? CUoutsourcinglotinforname { get; set; }
        public string? CUpo { get; set; }
        [Key]
        public string? Containername { get; set; }
        public string? CUCustomsno { get; set; }
        public string? CUdeliverytime { get; set; }
        public string? MFGORDERNAME { get; set; }
        public string? PRODUCTNAME { get; set; }
        public string? CUNEEDPROCESSQTY { get; set; }
        public string? CUIndex { get; set; }
        public string? CUreceivetime { get; set; }
        public string? CUremarks { get; set; }
        public string? Vendorname { get; set; }
        public string? Description { get; set; }
        public string? CUisexternalsuppliers { get; set; }
        public string? SPECNAME { get; set; }
        public string? Workflowrevision { get; set; }
        public string? Workflowname { get; set; }
        public string? Workflowstepname { get; set; }
        public string? CUpcsqty { get; set; }
        public string? CUpnlqty { get; set; }
        public string? CUreturnqty { get; set; }
        public string? CUsetqty { get; set; }
        public string? CUspecstepno { get; set; }
        public string? CUsquare { get; set; }
        public string? CUunprocessqty { get; set; }
        public string? RN { get; set; }
    }
}
