﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class SamplingTaskForFailReq
    {
        public string CUTaskLot { get; set; }
        public string CUSamplingTaskName { get; set; }
        public bool ManualFlag { get; set; }
        public List<string> CUHoldLots { get; set; }
        public List<string> CUFailReasons { get;set; }
        public bool CUIsPass { get; set; }
        public string CUDisposeNote { get; set; }
        public string Employee { get; set; }
    }
}
