﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSRELotReq
    {
        public string Lot { get; set; }
        public string Employee { get;set; }
    }
}
