﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class STCreateCheckMatrixModel
    {
        [Key]
        public string? Cusamplingmatrixname { get; set; }
        public string? Cusamplingweight { get; set; }
        public string? RefPN { get; set; }
        public string? MatrixPN { get; set; }
        public string? RefOEM { get; set; }
        public string? MatrixOEM { get; set; }
        public string? RefProductionType { get; set; }
        public string? MatrixProductionType { get; set; }
        public string? RefCEM { get; set; }
        public string? MatrixCEM { get; set; }
    }
}
