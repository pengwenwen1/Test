﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class STCreateCategoryModel
    {
        [Key]
        public string? CateGoryName { get; set; }
    }
}
