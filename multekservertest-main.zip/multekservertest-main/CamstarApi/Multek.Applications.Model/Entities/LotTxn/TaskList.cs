﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class TaskList
    {
        [Key]
        /// <summary>
        /// 任务编号
        /// </summary>
        public string? Cusamplingtaskname { get; set; }
        /// <summary>
        /// 任务类型
        /// </summary>
        public string? cuSamplingTypeName { get; set; }
        /// <summary>
        /// 产品
        /// </summary>
        public string? Productname { get; set; }
        /// <summary>
        /// 触发批次
        /// </summary>
        public string? cuCreateLot { get; set; }
        /// <summary>
        /// 已检验批次
        /// </summary>
        public string? cuLot { get; set; }
    }
}
