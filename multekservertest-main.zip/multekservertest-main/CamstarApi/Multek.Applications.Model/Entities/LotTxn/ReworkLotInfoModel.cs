﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class ReworkLotInfoModel
    {
        [Key]
        public string? Lot { get; set; }
        public string? QTY { get; set; }
        public string? QTY2 { get; set; }
        public string? Spec { get; set; }
        public string? DaysHere { get; set; }
        public string? QueueTime { get; set; }
        public string? Product { get; set; }
        public string? Status { get; set; }
        public string? IsOnHold { get; set; }
        public string? InRework { get; set; }
        public string? Insertion { get; set; }
        public string? InsertionProcessSpec { get; set; }
        public string? InsertionSS { get; set; }
        public string? Rejects { get; set; }
        public string? MoveOutQty { get; set; }
        public string? WIPStatus { get; set; }
        public string? WIPType { get; set; }
        public string? WIPYieldResult { get; set; }
        public string? BatchNo { get; set; }
        public string? EqpCount { get; set; }
        public string? EqpLoadingCount { get; set; }
        public string? FutureHoldExists { get; set; }
        public string? InSchedule { get; set; }
        public string? SpecPass { get; set; }
        public string? SpecCategory { get; set; }
        public string? SpecType { get; set; }
        public string? SpecDescription { get; set; }
        public string? Workflowstepname { get; set; }
        public string? WorkflowstepSeq { get; set; }
        public string? Workflowrevision { get; set; }
        public string? Workflowname { get; set; }
        public string? RepairStepName { get; set; }
        public string? RepairStepSeq { get; set; }
        public string? CUTrackFlag { get; set; }
    }
}
