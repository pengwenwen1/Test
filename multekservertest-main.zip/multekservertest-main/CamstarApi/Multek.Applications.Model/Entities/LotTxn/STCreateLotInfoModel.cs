﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class STCreateLotInfoModel
    {
        [Key]
        public string? cuLot { get; set; }
        public string? cuPNName { get; set; }
        public string? cuSpecName { get; set; }
        public string? cuPNRevision { get; set; }
        public string? cuSpecRevision { get; set; }
        public string? cuTrackFlag { get; set; }
        public decimal? HoldCount { get; set; }
        public string? ContainerStatus { get; set; }
    }
}
