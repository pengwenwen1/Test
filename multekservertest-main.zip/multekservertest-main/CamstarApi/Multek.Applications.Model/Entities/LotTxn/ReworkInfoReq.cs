﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class ReworkInfoReq
    {
        public string? CancelWIPTracking { get; set; }
        public string? Container { get; set; }
        public string? cuReMark { get; set; }
        public string? cuRepairMethod { get; set; }
        public string? Employee { get; set; }
        public string? ReworkEndStep { get; set; }
        public string? Workflowname { get; set; }
        public string? Workflowrevision { get; set; }
        public string? ReworkReason { get; set; } = "REPAIR";
        public string? ReworkReEntryStep { get; set; }
        public string? SelectionId { get; set; }
        public string? SplitBins { get; set; } = "False";
        public string? ToStepType { get; set; } = "NEXTSTEPS";
        public string? ToWorkflowStep { get; set; }
        public string? TriggerMoveIn { get; set; }
        public string? YieldOffRejects { get; set; } = "False";
    }
}
