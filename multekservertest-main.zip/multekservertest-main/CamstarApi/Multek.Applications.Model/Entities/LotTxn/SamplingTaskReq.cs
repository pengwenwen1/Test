﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class SamplingTaskReq
    {
        public string Lot { get; set; }
        public string Employee { get; set; }
        public bool ManualFlag { get; set; }
        public bool IsPass { get; set; }
        public string CUSamplingTaskName { get; set; }
        public List<SamplingDetailNew> CUSamplingDetailNew { get; set; }
    }

    public class SamplingDetailNew
    {
        public int CUSamplingNo { get; set; }
        public string CUCheckItemName { get; set; }
        public string? CULowerLimit { get; set; }
        public string? CUUpperLimit { get; set; }
        public string? CUStandardValue { get; set; }
        public string CUResult { get; set; }

    }
}
