﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class SamplingCheckTasks_Req
    {
        public string? Lot { get; set; }
        public string? Product { get; set; }
        public string? Category { get; set; }
        public string? HandFlag { get; set; }
        public string? Spec { get; set; }
        public string StartDate { get; set; }
        public string Endate { get; set; }
    }
}
