﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSLotReq
    {
        public string LotName { get; set; }
        public string PN { get; set; }
        public string Spec { get; set; }
    }
}
