﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSSpecReq
    {
        public string WorkflowName { get; set; }
        public string Sequence { get; set; }
        public string WorkflowRevision { get; set; }
    }
}
