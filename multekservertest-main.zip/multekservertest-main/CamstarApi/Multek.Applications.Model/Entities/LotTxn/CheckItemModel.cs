﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class CheckItemModel
    {
        public string? CUSAMPLINGNO { get; set; }
        [Key]
        public string? CUCHECKITEMNAME { get; set; }
        public string? CULOWERLIMIT { get; set; }
        public string? CUUPPERLIMIT { get; set; }
        public string? CURESULT { get; set; }
        public string? CUPANELPCSNO { get; set; }
        public string? CUISCHECKRECORD { get; set; }
        public string? CUSTANDARDVALUE { get; set; }
    }
}
