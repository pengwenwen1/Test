﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSRESubmitReq
    {
        public string? CUoutsourcinglotinforname { get; set; }
        public string? cuIsExternalSuppliers { get; set; }
        public List<CULotDetails>? cuLotDetails { get; set; }
        public List<CUOutSouringLotDetailsV2> cuOutSouringLotDetails { get; set; }
        public string? cuReceiveEmployee { get; set; }
        public string? cuVendor { get; set; }
        public string? cuVendorDescription { get; set; }    
        public string? cuRemarks { get; set; }
    }
}
