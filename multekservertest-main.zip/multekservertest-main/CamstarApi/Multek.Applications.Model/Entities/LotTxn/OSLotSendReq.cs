﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSLotSendReq
    {
        public string? cuOutsourcingOrderNR { get; set; }
        public string? cuDeliveryOrderNo { get; set; }
        public string cuVendor { get; set; }
        public string cuVendorDescription { get; set; }
        public string? cuPO { get; set; }
        public string? cuPRF { get; set; }
        public string? cuCustomsNo { get; set; }
        public string? cuRemarks { get; set; }
        public string? cuIsExternalSuppliers { get; set; }
        public string? cuDeliveryTime { get; set; }
        public string? cuSendingEmployee { get; set; }
        public List<CUOutSouringLotDetails> cuOutSouringLotDetails { get; set; }
        public List<CULotDetails>? cuLotDetails { get; set; }
    }
}
