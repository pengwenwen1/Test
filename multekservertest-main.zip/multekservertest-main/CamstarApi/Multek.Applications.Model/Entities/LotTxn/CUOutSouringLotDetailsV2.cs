﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class CUOutSouringLotDetailsV2
    {
        public string? cuIndex { get; set; }
        public string? Containername { get; set; }
        public string? cuNeedProcessQty { get; set; }
        public string? cuPCSQty { get; set; }
        public string? cuPN { get; set; }
        public string? cuPNLQty { get; set; }
        public string? cuReturnQty { get; set; }
        public string? cuSetQty { get; set; }
        public string? cuSpec { get; set; }
        public string? cuSpecStep { get; set; }
        public string? cuSpecStepNo { get; set; }
        public string? cuSquare { get; set; }
        public string? cuUnPnlQty { get; set; }
        public string? cuUnProcessQty { get; set; }
        public string? cuWorkOrder { get; set; }
        public List<string>? cuUnPnl { get; set; }
    }
}
