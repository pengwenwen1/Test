﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class LoadTaskListForFailReq
    {
        public string? Employee { get; set; }
        public string? PN { get; set; }
        public string? Spec { get; set; }
        public string? Eqp { get; set; }
        public string? LayerMin { get; set; }
        public string? LayerMax { get; set; }
        public string? CuCEM { get; set; }
        public string? CuOEM { get; set; }
        public string CuCreateDateFrom { get; set; }
        public string CuCreateDateTo { get; set; }
        public string? DateCode { get; set; }
        public bool Disposed { get; set; }
        public bool NotDispose { get; set; }
        public bool ManualFlag { get; set; }

    }
}
