﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class TaskDetails
    {
        public string? CUSAMPLINGCATEGORYNAME { get; set; }
        public string? CUPRODUCTIONTYPENAME { get; set; }
        public string? CUSTATUS { get; set; }
        public string? PRODUCTNAME { get; set; }
        public string? SPECNAME { get; set; }
        public string? RESOURCENAME { get; set; }
        public string? CULAYERNUMMIN { get; set; }
        public string? CULAYERNUMMAX { get; set; }
        public string? CUCYCLE { get; set; }
        public string? CUQTY { get; set; }
        [Key]
        public string? CUSAMPLINGTASKNAME { get; set; }
        public string? CUWIPDATASETUPID { get; set; }
        public string? CUCEMNAME { get; set; }
        public string? CUOEMNAME { get; set; }
        public string? CUCREATELOT { get; set; }
        public string? CUDATECODE { get; set; }
        public string? CULOT { get; set; }
        public string? CUCREATEDATE { get; set; }
        public string? CUISSENDSAMPLING { get; set; }
        public string? CUSENDSAMPLINGERNAME { get; set; }
        public string? CUSENDSAMPLINGDATE { get; set; }
        public string? CUISRECORD { get; set; }
        public string? CUCHECKERNAME { get; set; }
        public string? CUCHECKDATE { get; set; }
        public string? CUISFIRSTCHECK { get; set; }
        public string? CUISSENDSAMPLINGTASK { get; set; }
        public string? WIPDATASETUPNAME { get; set; }
        public string? CUSAMPLINGTYPENAME { get; set; }
        public string? CUISUPLOADFILE { get; set; }
        public string? CUUPLOADERNAME { get; set; }
        public string? CUUPLOADTIME { get; set; }
        public string? CUMANUALFLAG { get; set; }
        public string? CUPANELPCSNO { get; set; }
        public string? CUISCHECKRECORD { get; set; }
    }
}
