﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class STCreateCheckMultTaskModel
    {
        [Key]
        public string ContainerID { get;set; }
        public string ContainerName { get;set; }
        public string SpecID { get;set; }
    }
}
