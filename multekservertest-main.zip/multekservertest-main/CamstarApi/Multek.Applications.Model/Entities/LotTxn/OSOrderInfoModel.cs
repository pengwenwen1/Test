﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSOrderInfoModel
    {
        [Key]
        public string Rownum { get; set; }
        public string? cuOutSourcingLotInforname { get; set; }
        public string? cuPO { get; set; }
        public string? ContainerName { get; set; }
        public string? cuCustomsNo { get; set; }
        public string? cuDeliveryTime { get; set; }
        public string? MfgorderName { get; set; }
        public string? ProductName { get; set; }
        public string? ProductreVision { get; set; }
        public string? CUNeedProcessQty { get; set; }
        public string? cuIndex { get; set; }
        public string? cuReceiveTime { get; set; }
        public string? cuRemarks { get; set; }
        public string? VendorName { get; set; }
        public string? Description { get; set; }
        public string? cuIsexternalSuppliers { get; set; }
        public string? SpecName { get; set; }
        public string? WorkflowRevision { get; set; }
        public string? WorkflowName { get; set; }
        public string? WorkflowStepName { get; set; }
        public string? cuPCSQty { get; set; }
        public string? cuPNLQty { get; set; }
        public string? cuReturnQty { get; set; }
        public string? cuSetQty { get; set; }
        public string? cuSpecStepNo { get; set; }
        public string? cuSquare { get; set; }
        public string? cuUnprocessQty { get; set; }
        public string? FactoryName { get; set; }
    }
}
