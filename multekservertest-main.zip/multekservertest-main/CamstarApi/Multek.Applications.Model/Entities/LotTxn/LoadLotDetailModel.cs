﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class LoadLotDetailModel
    {
        public string? ProductID { get; set; }
        [Key]
        public string? ContainerName { get; set; }
        public string? ProductName { get; set; }
        public string? Culayernum { get; set; }
        public string? SpecName { get; set; }
        public string? EquipmentName { get; set; }
        public string? CuCEMName { get; set; }
        public string? CuOEMName { get; set; }
        public string? Resourcename { get; set; }

    }
}
