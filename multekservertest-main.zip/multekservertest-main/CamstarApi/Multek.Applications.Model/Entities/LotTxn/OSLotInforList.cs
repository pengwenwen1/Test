﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSLotInforList
    {
        public string CUOUTSOURINGNO { get; set; }
        public string CULOT { get; set; }
        public string CUPNLQTY { get; set; }
        public string CUSETQTY { get; set; }
        public string CUPCSQTY { get; set; }
        public string CUSPEC { get; set; }
        public string CUPN { get; set; }
    }
}
