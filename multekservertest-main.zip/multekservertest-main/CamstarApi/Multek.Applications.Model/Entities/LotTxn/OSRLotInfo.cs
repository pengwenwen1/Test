﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSRLotInfo
    {
        public string? CUOutSouringNo { get; set; }
        public string? CUPO { get; set; }
        public string? CULot { get; set; }
        public string? CUCustomsNo { get; set; }
        public string? CUDeliveryTime { get; set; }
        public string? MfgOrderName { get; set; }
        public string? CUPN { get; set; }
        public string? Productrevision { get; set; }
        public string? CuneedProcessQty { get; set; }
        public string? CUIndex { get; set; }
        public string? CUReceivetime { get; set; }
        public string? CURemarks { get; set; }
        public string? VendorName { get; set; }
        public string? Description { get; set; }
        public string? CUIsexternalsuppliers { get; set; }
        [Key]
        public string? CUSpec { get; set; }
        public string? Specrevision { get; set; }
        public string? Workflowrevision { get; set; }
        public string? WorkflowName { get; set; }
        public string? WorkflowStepName { get; set; }
        public string? CUPCSQty { get; set; }
        public string? CUPNLQty { get; set; }
        public string? CUReturnQty { get; set; }
        public string? CUSetQty { get; set; }
        public string? CUSpecStepNo { get; set; }
        public string? CUSquare { get; set; }
        public string? CUUnProcessQty { get; set; }
    }
}
