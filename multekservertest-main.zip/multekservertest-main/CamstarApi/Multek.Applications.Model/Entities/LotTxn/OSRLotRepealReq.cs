﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class OSRLotRepealReq
    {
        public string Employee { get; set; }
        public List<OSLotInforList> CUOutSourcingLotInforList { get; set; }
        public string? CURepealRemark { get; set; }
    }
}
