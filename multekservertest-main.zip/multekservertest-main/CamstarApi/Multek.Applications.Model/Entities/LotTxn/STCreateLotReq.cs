﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class STCreateLotReq
    {
        public string? Lot { get; set; }
        public string? SamplingCategoryName { get; set; }
    }
}
