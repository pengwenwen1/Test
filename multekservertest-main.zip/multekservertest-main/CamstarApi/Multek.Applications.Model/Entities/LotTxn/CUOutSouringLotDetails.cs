﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class CUOutSouringLotDetails
    {
        public int cuIndex { get; set; }
        public string? cuLot { get; set; }
        public string? cuNeedProcessQty { get; set; }
        public string? cuPCSQty { get; set; }
        public string? cuPN { get; set; }
        public string? cuPNLQty { get; set; }
        public string? cuReturnQty { get; set; }
        public string? cuSETQty { get; set; }
        public string cuSpec { get; set; }
        public string cuSpecStep { get; set; }
        public string cuSpecStepNo { get; set; }
        public string? cuSquare { get; set; }
        public string? cuUnPnlQty { get; set; }
        public string? cuUnProcessQty { get; set; }
        public string? cuWorkOrder { get; set; }
        public string WorkflowRevision { get; set; }
        public string WorkflowName { get; set; }
    }
}
