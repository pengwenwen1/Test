﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.LotTxn
{
    public class PostSamplingTask_Req
    {
        public string? Employee { get; set; }
        public string? CategoryName { get; set; }
        public string? CheckMatrixName { get; set; }
        public List<PostSamplingTask> SamplingTasks { get; set; }
    }
}
