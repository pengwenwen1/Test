﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Multek.Library_Core.COM.Model;

namespace Multek.Applications.Model.Entities.Multek
{
    public class TrackALLInfo 
    {

        public string? Info_ID { get; set; }



        public string? TrackID { get; set; }

        public int? QTY2 { get; set; }


        public string? PN { get; set; }


        public string? PN_VER { get; set; }

     

        public string? PRODUCT_TYPE { get; set; }


        public string? PARENT_MASTER_NUM { get; set; }


        public string? ERP_PN { get; set; }


        public string? CUSTOMER_PRODUCT_NAME { get; set; }


        public string? MBOM_ID { get; set; }


        public string? PROD_ORDER { get; set; }


        public int? P_CUTTING_QTY { get; set; }


        public int? S_CUTTING_QTY { get; set; }


        public int? U_CUTTING_QTY { get; set; }


        public string? DELIVERY_UNIT { get; set; }


        public DateTime? DELIVERY_DATE { get; set; }


        public string? ORDER_TYPE { get; set; }


        public string? CUSTOMER_ID { get; set; }


        public string? LOT_PRIORITY_ID { get; set; }


        public string? FACTORY { get; set; }


        public bool? IS_SUPPLY { get; set; }


        public int? P_QTY { get; set; }


        public int? S_QTY { get; set; }


        public int? U_QTY { get; set; }


        public string? CUR_STEP { get; set; }


        public string? REMARK1 { get; set; }


        public string? REMARK2 { get; set; }


        public string? REMARK3 { get; set; }


        public string? REMARK4 { get; set; }


        public string? REMARK5 { get; set; }


        public int? IsReWork { get; set; }


        public string? WIPDetails_ID { get; set; }





        public string? WORKFLOW_Name { get; set; }


        public string WORKFLOW_ID { get; set; }

        public int? CUR_STEP_SEQ { get; set; }


        public string? CUR_STEP_NAME { get; set; }


        public int? WIP_STATUS { get; set; }


        public int? STATUS { get; set; }


        public int? NG_STATUS { get; set; }


        public string? EQUIPMENT_ID { get; set; }


        public string? TOOL_ID { get; set; }


        public string? RFID { get; set; }


        public string? SPEC_CONFIG { get; set; }


        public string? SPEC_CONFIG_VER { get; set; }

        [Key]
        public string? PARENT_LOT { get; set; }


        public string? PARENT_TrackID { get; set; }


        public int? NEXT_STEP_SEQ { get; set; }


        public string? NEXT_STEP_NAME { get; set; }


        public string? DateCode { get; set; }


        public string? CARRIER_ID { get; set; }



        public string? LAYER_MARK { get; set; }

        public int? ishold { get; set; }

    }
}
