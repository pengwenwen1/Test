﻿using Multek.Applications.Model.Entities.TRC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Dto
{
    public class SetOrPcsCodes
    {
        /// <summary>
        /// 码号
        /// </summary>
        public string? Code { get; set; }
        /// <summary>
        /// 明码
        /// </summary>
        public string PlainCode { get; set; }
        /// <summary>
        /// 码类型0:Lot;  1:Pnl;  2:Set;  3:Pcs;
        /// </summary>
        public CodeTypeEnum CodeType { get; set; }
        /// <summary>
        /// 码列表
        /// </summary>
        public List<Codes> CodeList { get; set; }

    }
}
