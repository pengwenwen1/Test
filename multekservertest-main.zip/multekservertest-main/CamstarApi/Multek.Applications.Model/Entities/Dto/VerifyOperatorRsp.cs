﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities.Dto
{
    public class VerifyOperatorRsp
    {
        /// <summary>
        ///  1 表示具有资质，0无资质
        /// </summary>
        public int Certify { get; set; }

        /// <summary>
        /// 员工姓名  
        /// </summary>
        public string Name { get; set; }


        
    }
}
