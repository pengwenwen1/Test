﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    public class GetPanelsCodeByLotRsp:CodeInfoOfPanel
    {

        /// <summary>
        /// 请求Lot号
        /// </summary>
        public string? LotNo { get; set; }

        /// <summary>
        /// 当批中的所有Panel码集合
        /// </summary>
        public List<string>? PnlCodes { get; set; }

        /// <summary>
        /// PNL数量
        /// </summary>
        public double? PnlQty { get; set; }

        /// <summary>
        /// 首板code码
        /// </summary>
        public string ? StartPNL { get; set; }
    }
}
