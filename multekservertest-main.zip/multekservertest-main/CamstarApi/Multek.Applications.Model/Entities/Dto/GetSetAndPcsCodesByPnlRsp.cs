﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Dto
{
    public class GetSetAndPcsCodesByPnlRsp
    {
        /// <summary>
        /// 型号
        /// </summary>
        public string? Project { get; set; }
        /// <summary>
        /// 请求Lot号
        /// </summary>
        public string? LotNo { get; set; }
 
        public List<SetOrPcsCodes>? CodeList { get; set; }
        /// <summary>
        /// 描述Set和Pcs码的打码位置等信息
        /// </summary>
        //public string? CodeArea { get; set; }

    }
}
