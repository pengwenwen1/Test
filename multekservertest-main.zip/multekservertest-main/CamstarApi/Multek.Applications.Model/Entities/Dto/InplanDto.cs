﻿using Multek.Applications.Model.Entities.TRC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Dto
{
    public class InplanDto
    {
        /// <summary>
        /// 码类型0:Lot;  1:Pnl;  2:Set;  3:Pcs;
        /// </summary>
        public CodeTypeEnum CodeType { get; set; }
        /// <summary>
        /// 客户名称
        /// </summary>

        public string Custom { get; set; }
    }
}
