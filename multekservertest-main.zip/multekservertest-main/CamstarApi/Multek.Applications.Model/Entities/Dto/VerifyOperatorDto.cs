﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities.Dto
{
    public class VerifyOperatorDto
    {
        /// <summary>
        /// 员工号
        /// </summary>
        public string EmployeeNo { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string WC { get; set; }

        /// <summary>
        /// 设备编号
        /// </summary>
        public string EquipmentNo { get; set; }

        
    }
}
