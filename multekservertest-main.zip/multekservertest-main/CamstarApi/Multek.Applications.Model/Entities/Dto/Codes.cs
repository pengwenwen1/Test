﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Dto
{
    public class Codes
    {
        public string Code { get; set; }
        public string PlainCode { get; set; }
    }
}
