﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    public class CodeInfoOfSetDto
    {
        /// <summary>
        /// 工厂
        /// </summary>
        public string Plant { get; set; }
        /// <summary>
        /// 13位型号 MIPN
        /// </summary>
        public string Project { get; set; }
    }
}
