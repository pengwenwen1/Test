﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    public class QueryPanelByLotDto
    {
        public string LotNo { get; set; }
        public string CodeType { get; set; }
    }
}
