﻿using Microsoft.EntityFrameworkCore;
using Multek.Applications.Model.Entities.TRC;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities.Dto
{
    public class GetPanelsCodeByLotDto
    {
        /// <summary>
        /// 工厂
        /// </summary>
        public string Plant { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string WC { get; set; }

        /// <summary>
        /// 设备编号
        /// </summary>
        public string EquipmentNo { get; set; }

        /// <summary>
        /// Lot号
        /// </summary>
        public string LotNo { get; set;}

    }
}
