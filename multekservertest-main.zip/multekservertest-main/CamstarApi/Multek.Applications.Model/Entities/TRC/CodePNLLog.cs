﻿
using Microsoft.EntityFrameworkCore;
using Multek.Applications.Model.Entities.Enum;
using Multek.Library_Core.Audit;
using Multek.Library_Core.COM.Model;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Multek.Applications.Model.Entities.TRC
{
    /// <summary>
    /// 打码记录
    /// </summary>
    [Table("CodePNLLog")]
    [Audit]
    [PrimaryKey(nameof(PnlCode), nameof(Code), nameof(PnlFace),nameof(PositionX))]
    public class CodePNLLog : CommEntityBase
    {
        /// <summary>
        /// PNL码
        /// </summary>
        public string PnlCode { get; set; }
        /// <summary>
        /// 0：Top （A面）    1:bot（B面）
        /// </summary>
        public PnlFaceEnum PnlFace { get; set; }

        /// <summary>
        /// set/pcs码
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// set/pcs码X轴坐标
        /// </summary>
        public double PositionX { get; set; }

        /// <summary>
        /// set/pcs码Y轴坐标
        /// </summary>
        public double PositionY { get; set; }

        /// <summary>
        /// 0:明码；1：二维码
        /// </summary>
        public TypeEnum type { get; set; }
        /// <summary>
        /// 计数，第几个码
        /// 1、生成set码，每Pnl下的set码从1开始依次递增
        /// 2、生成pcs码，每Pnl下的pcs码从1开始依次递增
        /// 3、生成set+pcs码，每Pnl下的set码从1开始依次递增，每Set下的pcs码从1开始依次递增
        /// </summary>
        public int NO { get; set; }
        /// <summary>
        /// 码类型0:Lot;  1:Pnl;  2:Set;  3:Pcs;
        /// </summary>
        public CodeTypeEnum CodeType { get; set; }

  
    }
}
