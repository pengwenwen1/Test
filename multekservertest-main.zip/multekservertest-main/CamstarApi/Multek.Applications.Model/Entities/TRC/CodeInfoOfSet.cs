﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [PrimaryKey(nameof(Plant), nameof(Project))]
    public class CodeInfoOfSet
    {
        /// <summary>
        /// 工厂
        /// </summary>
        [MaxLength(5)]
        public string Plant { get; set; }
        /// <summary>
        /// 13位型号 MIPN
        /// </summary>
        [MaxLength(20)]
        public string Project { get; set; }
        /// <summary>
        /// 打码位置内容
        /// </summary>
        public string AreaData { get; set; }
    }
}
