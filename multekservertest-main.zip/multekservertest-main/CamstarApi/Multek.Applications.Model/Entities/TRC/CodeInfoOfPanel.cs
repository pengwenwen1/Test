﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("CodeInfoOfPanel")]
    [PrimaryKey(nameof(Plant), nameof(Project))]
    public class CodeInfoOfPanel
    {
        /// <summary>
        /// 工厂
        /// </summary>
        [MaxLength(5)]
        public string Plant { get; set; }
        /// <summary>
        /// 13位型号 MIPN
        /// </summary>
        [MaxLength(20)]
        public string Project { get; set; }
        /// <summary>
        /// 主坐标X
        /// </summary>
        public double? Position1X { get; set; }
        /// <summary>
        /// 主坐标Y
        /// </summary>
        public double? Position1Y { get; set; }

        /// <summary>
        /// 次坐标X
        /// </summary>
        public double? Position2X { get; set; }
        /// <summary>
        /// 主坐标X
        /// </summary>
        public double? Position2Y { get; set; }
        /// <summary>
        /// 板宽
        /// </summary>
        public double? PnlWidth { get; set; }
        /// <summary>
        /// 板长
        /// </summary>
        public double? PnlLength { get; set; }
        /// <summary>
        /// 板厚
        /// </summary>
        public double? Thickness { get; set; } 

        /// <summary>
        /// 板左边距到主条码左边的距离
        /// </summary>
        public double? L1 { get; set;}

        /// <summary>
        /// 板下半边到主条码下半边的高度
        /// </summary>
        public double? W1 { get; set;}

        /// <summary>
        /// 板左边距到副条码左边的距离
        /// </summary>
        public double? L2 { get; set; }

        /// <summary>
        /// 板下半边到副条码下半边的高度
        /// </summary>
        public double? W2 { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        
        public DateTime? updateDate { get; set; }
    }
}
