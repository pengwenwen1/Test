﻿using Microsoft.EntityFrameworkCore;
using Multek.Library_Core.Audit;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    /// <summary>
    /// CodeCounter-码计数器
    /// </summary>
    [Table("CodeCounter")]
    [Comment("CodeCounter-码计数器")]
    [Audit]
    [PrimaryKey(nameof(PrefixNumber), nameof(SequenceLength))]
    public class CodeCounter
    {
        /// <summary>
        /// 前缀数据
        /// </summary>
        public string PrefixNumber { get; set; }
        /// <summary>
        /// 序列流水长度
        /// </summary>
        public int SequenceLength { get; set; }

        /// <summary>
        /// 当前计算器值
        /// </summary>
        public int CurrentValue { get; set; }
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
