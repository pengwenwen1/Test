﻿using Microsoft.EntityFrameworkCore;
using Multek.Applications.Model.Entities.TRC;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    /// <summary>
    /// CodeTree-各级码的关系
    /// </summary>
    [Table("CodeTree")]
    [Comment("CCodeTree-各级码的关系")]
    public class CodeTree
    {
        /// <summary>
        /// 工厂
        /// </summary>
        [MaxLength(5)]
        public string Plant { get; set; }

        /// <summary>
        /// 13位型号MIPN
        /// </summary>
        [MaxLength(20)]
        public string Project { get; set; }

        /// <summary>
        /// 生产Lot
        /// </summary>
        public string Lot { get; set; }
        /// <summary>
        /// 码类型0:Lot;  1:Pnl;  2:Set;  3:Pcs;
        /// </summary>
        public CodeTypeEnum CodeType { get; set; }

        /// <summary>
        /// 码值
        /// </summary>
        [Key]
        public string Code { get; set; }

        /// <summary>
        /// 当前码的父级码
        /// </summary>
        public string? Parent { get; set; }
        /// <summary>
        /// 内层物料码
        /// </summary>
        public string? Material { get; set; }
        /// <summary>
        /// 当前实体状态： O:正常 1：报废
        /// </summary>
        public CodeStatusEnum Status { get; set; }
        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Time { get; set; }

        /// <summary>
        /// 明码名称
        /// </summary>
        [MaxLength(50)]
        public string? PlainCode { get; set; }
    }
}
