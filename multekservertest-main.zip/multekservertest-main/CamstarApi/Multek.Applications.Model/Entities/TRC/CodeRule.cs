﻿using Microsoft.EntityFrameworkCore;
using Multek.Applications.Model.Entities.TRC;
using Multek.Library_Core.Audit;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    /// <summary>
    /// CodeRule-码的生成规则
    /// </summary>
    [Table("CodeRule")]
    [Comment("CodeRule-码的生成规则")]
    [Audit]
    public class CodeRule
    {
        /// <summary>
        /// 码类型0:Lot;  1:Pnl;  2:Set;  3:Pcs;
        /// </summary>
        [Comment("0:Lot;  1:Pnl;  2:Set;  3:Pcs;")]
        public CodeTypeEnum CodeType { get; set; }

        /// <summary>
        /// 工厂或客户编号
        /// </summary>
        [MaxLength(5)]
        public string Plant { get; set; }
        /// <summary>
        /// 前缀规则
        /// </summary>
        public string PrefixRule { get; set; }
        public int SequenceLength { get; set; }
        public string? NumberBaseCode { get; set; }

        /// <summary>
        /// 规则名称
        /// </summary>
        [MaxLength(50)]
        [Key]
        public string CodeRuleName { get; set; }

        /// <summary>
        /// 规则描述
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// 客户 来源与CME 360的客户
        /// </summary>
        public string? Custom { get; set; }

        /// <summary>
        /// 明码规则名称
        /// </summary>
        [MaxLength(200)]
        public string? PlainCodeRule { get; set; }



    }
}
