﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  Multek.Applications.Model.Entities.TRC
{
    /// <summary>
    /// 0:Lot  1:Pnl  2:Set  3:Pcs
    /// </summary>
    public enum CodeTypeEnum
    {

        /// <summary>
        /// Lot
        /// </summary>
        [Description("Lot")]
        Lot = 0,

        /// <summary>
        /// Pnl
        /// </summary>
        [Description("Pnl")]
        Pnl = 1,

        /// <summary>
        /// Set
        /// </summary>
        [Description("Set")]
        Set = 2,
        /// <summary>
        /// Pcs
        /// </summary>
        [Description("Pcs")]
        Pcs = 3
    }
}
