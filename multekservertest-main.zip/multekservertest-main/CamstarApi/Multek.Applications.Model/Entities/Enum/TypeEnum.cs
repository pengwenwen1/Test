﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Enum
{
    /// <summary>
    /// 0:明码；1：二维码
    /// </summary>
    public enum TypeEnum
    {
        /// <summary>
        /// PlainCode明码
        /// </summary>
        [Description("PlainCode")]
        PlainCode = 0,

        /// <summary>
        /// QRCode二维码
        /// </summary>
        [Description("QRCode")]
        QRCode = 1,
    }
}
