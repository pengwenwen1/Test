﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Enum
{
    /// <summary>
    /// 0:A面  1:B面
    /// </summary>
    public enum PnlFaceEnum
    {
        /// <summary>
        /// A面
        /// </summary>
        [Description("Top")]
        Top = 0,
        /// <summary>
        /// B面
        /// </summary>
        [Description("Bot")]
        Bot = 1
    }
}
