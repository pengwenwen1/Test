﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  Multek.Applications.Model.Entities.TRC
{
    /// <summary>
    /// O:正常 1：报废
    /// </summary>
    public enum CodeStatusEnum
    {

        /// <summary>
        /// 正常
        /// </summary>
        [Description("正常")]
        Normal = 0,

        /// <summary>
        /// 报废
        /// </summary>
        [Description("报废")]
        Scrap = 1,

    }
}
