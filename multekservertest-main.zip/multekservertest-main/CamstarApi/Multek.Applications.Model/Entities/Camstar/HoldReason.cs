﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar
{
    public class HoldReason
    {

        /// <summary>
        /// HoldReason
        /// </summary>
        [Key]
        public string HOLDREASONID { get; set; }
        /// <summary>
        /// HoldReasonname
        /// </summary>
        public string? HOLDREASONNAME { get; set; }
        /// <summary>
        /// hold原因描述
        /// </summary>
        public string? DESCRIPTION { get; set; }
    }
}
