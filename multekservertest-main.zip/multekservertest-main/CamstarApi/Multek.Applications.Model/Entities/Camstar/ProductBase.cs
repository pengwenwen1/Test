﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("ProductBase")]
    public class ProductBase
    {
        /// <summary>
        /// PNID
        /// </summary>
        [Key]
        public string ProductBaseId { get; set; }
        public string ProductName { get; set; }

  

    }
}
