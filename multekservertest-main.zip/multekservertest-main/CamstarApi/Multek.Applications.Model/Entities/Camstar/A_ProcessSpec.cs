﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Multek.Applications.Model.Entities.Camstar
{
    [Table("A_ProcessSpec")]
    public class A_ProcessSpec
    {
        [Key]
        public string ProcessSpecId { get; set; }

        public string WorkflowId { get; set; }
    }
}
