﻿using AutoMapper.Configuration.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("CONTAINER")]
    public class Container
    {
        /// <summary>
        /// Lot名称
        /// </summary>
        [Key]
        public string ContainerName { get; set; }

        public string Containerid { get; set; }
        /// <summary>
        /// Panel数量
        /// </summary>
        public float QTY2 { get; set; }

        /// <summary>
        /// ps数量(每Pnl的pcs数)
        /// </summary>
        public float QTY { get; set; }
        /// <summary>
        /// PNID
        /// </summary>
        public String ProductId { get; set; }

        /// <summary>
        /// 工厂Id
        /// </summary>
        public string OriginalFactoryId { get; set; }

        public string cuWorkOrderId { get; set; }

        /// <summary>
        /// set数量(每Pnl的Set数)
        /// </summary>
        public float SetQTY;

        /// <summary>
        /// PCS数量（每set的pcs数）
        /// </summary>
        public float CuPCSPerStrip;

        /// <summary>
        /// 工厂名称
        /// </summary>
        public string? FactoryName;
        /// <summary>
        /// Project
        /// </summary>
        public string? CUMI_PN;

        /// <summary>
        /// 每Pnl的Set数
        /// </summary>
        public float? CuStripPerPnl;

        /// <summary>
        /// 每Pnl的pcs数
        /// </summary>
        public float? cuPCSPerPnl;

        /// <summary>
        /// 客户PN
        /// </summary>
        public String? cuCustomerPN;

        /// <summary>
        /// 客户项目名称（截取后两位，作为版本，生成码的前缀）
        /// </summary>
        public string? cuCustomerVersion;

        /// <summary>
        /// STAMPCODE
        /// </summary>
        public string? cuStampCode;

        /// <summary>
        /// OEM
        /// </summary>
        public string? cuOEMName;
        /// <summary>
        /// 是否追溯Pnl码；0：不追溯；1：追溯
        /// </summary>
        public int? CuIsPnl;
        /// <summary>
        /// Set码生成规则
        /// </summary>
        public string? cuSetCodeRule;
        /// <summary>
        /// Pcs码生成规则
        /// </summary>
        public string? cuPcsCodeRule;

        /// <summary>
        /// Pnl码生成规则
        /// </summary>
        public string? cuPnlCodeRule;

        /// <summary>
        /// 方案号(GEE)
        /// </summary>
        public string? cuSolutionVersion;

        /// <summary>
        /// HOLD标识
        /// </summary>
        public string? CURRENTHOLDCOUNT { get; set; }

        /// <summary>
        /// 当前状态ID
        /// </summary>
        public string? currentStatusId { get; set; }

        /// <summary>
        /// CUTRACKFLAG
        /// </summary>
        public string? CUTRACKFLAG { get; set; }

        /// <summary>
        /// ECN重打LOT卡标识
        /// </summary>
        public string? CUECNSTATUS { get; set; }

        /// <summary>
        /// status
        /// </summary>
        public string? status { get; set; }

        public string? ProcessSpecId { get; set; }

    }
}
