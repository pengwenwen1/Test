﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class CuOARejectProcess
    {
        /// <summary>
        /// 流程编号
        /// </summary>
        public int workflowId { get; set; } = 9000301;

        /// <summary>
        /// 流程创建人AD账号,为空时默认使用系统账号创建流程
        /// </summary>
        public string creator { get; set; } = string.Empty;

        /// <summary>
        /// 主表
        /// </summary>
        public maintable mainTable { get; set; }

        /// <summary>
        /// 明细表
        /// </summary>
        public IList<IList<RejectProcessdetailTable>> detailTable { get; set; }

        public class maintable
        {
            /// <summary>
            /// 编号(报废表单号)
            /// </summary>
            public string FD_SQR { get; set; } = DateTime.Now.ToString("yyyyMMddHHmmssfffM");
 
            /// <summary>
            /// 填写人(流程MRB预审员）
            /// </summary>
            public string FD_RQ { get; set; }

            /// <summary>
            /// 关联主键
            /// </summary>
            public string FD_BH { get; set; } = DateTime.Now.ToString("d");

            /// <summary>
            /// 报废原因
            /// </summary>
            public string FD_BFYY { get; set; }

            /// <summary>
            /// 改善措施
            /// </summary>
            public string FD_GSCS { get; set; }

            /// <summary>
            /// 工厂
            /// </summary>
            public string FD_FACTORYNAME { get; set; }

            /// <summary>
            /// 工号
            /// </summary>
            public string FD_CUEMPLOYEENO { get; set; }

        }

        public class RejectProcessdetailTable
        {
            /// <summary>
            /// 工单号
            /// </summary>
            public string MX_WorkOrder { get; set; }

            /// <summary>
            /// 工序
            /// </summary>
            public string MX_GX { get; set; }

            /// <summary>
            /// 产品编号
            /// </summary>
            public string MX_CPBH { get; set; }

            /// <summary>
            /// 生产批号
            /// </summary>
            public string MX_SCPH { get; set; }

            /// <summary>
            /// Panel/PCS号
            /// </summary>
            public string MX_PPH { get; set; }

            /// <summary>
            /// 缺陷代码
            /// </summary>
            public string MX_QXDM { get; set; }

            /// <summary>
            /// Panel数
            /// </summary>
            public string MX_PanS { get; set; } = string.Empty;

            /// <summary>
            /// PCS数
            /// </summary>
            public string MX_PCSS { get; set; }

            /// <summary>
            /// 缺陷名称
            /// </summary>
            public string MX_QXMC { get; set; }

            /// <summary>
            /// 备注
            /// </summary>
            public string MX_BZ { get; set; }

            /// <summary>
            /// 报废面积
            /// </summary>
            public string MX_BFMJ { get; set; }

            /// <summary>
            /// 责任工序代码
            /// </summary>
            public string MX_ProcCode { get; set; }

            /// <summary>
            /// 责任工序
            /// </summary>
            public string MX_ProcSpec { get; set; }
            
            /// <summary>
            /// STAMPCODE
            /// </summary>
            public string MX_Stampcode { get; set; }


            /// <summary>
            /// 报废类型名称
            /// </summary>
            public string MX_SCRAPTYPENAME { get; set; }

            /// <summary>
            /// 报废类型描述
            /// </summary>
            public string MX_SCRAPTYPEDESCRIPTION { get; set; }

            /// <summary>
            /// 工单总报废面积
            /// </summary>
            public string MX_WOBFMJ { get; set; }

            /// <summary>
            /// 客户信息
            /// </summary>
            public string MX_DESCRIPTION { get; set; }

            ///// <summary>
            ///// 工号
            ///// </summary>
            //public string MX_EMPLOYEENO { get; set; }
        }
    }
}
