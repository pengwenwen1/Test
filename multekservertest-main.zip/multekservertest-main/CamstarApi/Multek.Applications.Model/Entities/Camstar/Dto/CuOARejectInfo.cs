﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using static Multek.Applications.Model.Entities.Camstar.Dto.CuOARejectProcess;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class CuOARejectInfo
    {
        /// <summary>
        /// 域账号
        /// </summary>
        public string EmployeeNo { get; set; }

        public IList<cuOARejectTable> detailTable { get; set; }
    }
}
