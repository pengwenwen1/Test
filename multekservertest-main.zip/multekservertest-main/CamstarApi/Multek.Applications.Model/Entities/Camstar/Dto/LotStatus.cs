﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    [NotMapped]
    public class LotStatus
    {

        /// <summary>
        /// 电脑名称
        /// </summary>
        public string? ComputerName { get; set; }

        /// <summary>
        /// 批次
        /// </summary>
        public List<Lots>? Container { get; set; }

        /// <summary>
        /// 原因(激活、终止、继续)
        /// </summary>
        public string? TerminateReason { get; set; }

        /// <summary>
        /// 激活的Workflow
        /// </summary>
        public string? UnTerminateWorkflow { get; set; }

        /// <summary>
        /// 激活的Workflow版本
        /// </summary>
        public string? UnTerminateWorkflowRevision { get; set; }

        /// <summary>
        /// 激活的WorkflowStep
        /// </summary>
        public string? UnTerminateWorkflowStep { get; set; }

        /// <summary>
        /// 批次继续LOT
        /// </summary>
        public string? cuLot { get; set; }
    }

    public class Lots
    {
            /// <summary>
            /// 批次名称
            /// </summary>
            public string? ContainerName { get; set; }

    }

}
