﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class GetLotMsgReq
    {
        public string Lot { get; set; }
    }
}
