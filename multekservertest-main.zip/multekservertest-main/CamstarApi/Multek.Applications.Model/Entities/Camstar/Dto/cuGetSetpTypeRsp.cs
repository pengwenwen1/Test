﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class cuGetSetpTypeRsp
    {
        /// <summary>
        /// 跳站类型
        /// </summary>
        public string SetpTye { get; set; }
        /// <summary>
        /// 批次
        /// </summary>
        public string container { get; set; }
        /// <summary>
        /// 查询类型
        /// </summary>
        public string pathOrstep { get; set; }
    }
}
