﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class Carrier
    {
        /// <summary>
        /// Carrier名称
        /// </summary>
        [Key]
        public string ResourceName { get; set; }

        public int IsFrozen { get; set; }
        /// <summary>
        /// 载具ID
        /// </summary>
        public string ResourceId { get; set; }
        /// <summary>
        /// 描述
        /// </summary>
        public string? Description { get; set; }
        /// <summary>
        /// 最后编辑时间
        /// </summary>
        public DateTime? LastEditTime { get; set; }
        /// <summary>
        /// 最后修改用户
        /// </summary>
        public string? LastEditedBy { get; set; }
    }
}
