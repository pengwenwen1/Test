﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using static Multek.Applications.Model.Entities.Camstar.Dto.CuOARejectProcess;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class CuOARejectProcessResult
    {
        [Description("单号")]
        public string? FD_BH { get; set; }

        [Description("Status")]
        public string? Status { get; set; }

        /// <summary>FD_RQ</summary>
        public string? FD_RQ { get; set; }

        /// <summary>FD_BFYY</summary>
        public string? FD_BFYY { get; set; }

        /// <summary>FD_GSCS</summary>
        public string? FD_GSCS { get; set; }

        /// <summary>FD_MRBUSER</summary>
        public string? FD_MRBUSER { get; set; }
        public IList<resultdetailTable> detailTable { get; set; }

        public class resultdetailTable
        {
            [Description("批次产品")]
            public string? CUPN { get; set; }

            [Description("产品版本")]
            public string? CUPNVERSION { get; set; }

            /// <summary>工单号</summary>
            public string? MX_WorkOrder { get; set; }

            /// <summary>工序</summary>
            public string? MX_GX { get; set; }

            /// <summary>产品编号</summary>
            public string? MX_CPBH { get; set; }

            /// <summary>生产批号</summary>
            public string? MX_SCPH { get; set; }

            /// <summary>Panel/PCS号</summary>
            public string? MX_PPH { get; set; }

            /// <summary>缺陷代码</summary>
            public string? MX_QXDM { get; set; }

            /// <summary>Panel数</summary>
            public string? MX_PanS { get; set; }

            /// <summary>申请报废PCS数</summary>
            public string? MX_AppRejPCSS { get; set; }

            /// <summary>实际报废PCS数</summary>
            public Decimal? MX_ActRejPCSS { get; set; }

            /// <summary>缺陷名称</summary>
            public string? MX_QXMC { get; set; }

            /// <summary>责任工序代码</summary>
            public string? MX_ProcCode { get; set; }

            /// <summary>责任工序</summary>
            public string? MX_ProcSpec { get; set; }

            /// <summary>备注</summary>
            public string? MX_BZ { get; set; }

            /// <summary>报废面积</summary>
            public string? MX_BFMJ { get; set; }

            /// <summary>报废类型</summary>
            public string? MX_SCRAPTYPENAME { get; set; }

            /// <summary>报废类型描述</summary>
            public string? MX_SCRAPTYPEDESCRIPTION { get; set; }
            /// <summary>工单总报废面积，不含本次</summary>
            public string? MX_WOBFMJ { get; set; }
        }
    }
}
