﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    [NotMapped]
    public class LotFirstInspect
    {


        /// <summary>
        /// 批次
        /// </summary>
        public string? Container { get; set; }

        /// <summary>
        /// cuIsDynamic
        /// </summary>
        public bool? CuIsDynamic { get; set; }

        /// <summary>
        /// 末检数量
        /// </summary>
        public string? Qty { get; set; }

        /// <summary>
        /// CuIsFirstInspect
        /// </summary>
        public bool? CuIsFirstInspect { get; set; }

        /// <summary>
        /// cuIsLastInspect
        /// </summary>
        public bool? CuIsLastInspect { get; set; }
        /// <summary>
        /// cuWorkflowStep
        /// </summary>
        public string? CuWorkflowStep { get; set; }

        /// <summary>
        /// cuWorkflowStepRevision
        /// </summary>
        public string? CuWorkflowStepRevision { get; set; }

        /// <summary>
        /// WorkflowID
        /// </summary>
        public string? WorkflowID { get; set; }

        /// <summary>
        /// cuWorkflowStepRevision
        /// </summary>
        public string? SpecName { get; set; }

        /// <summary>
        /// 批次LOT
        /// </summary>
        public string? SelectionId { get; set; }

        public IList<detail> detailTable { get; set; }

        public class detail
        {
            ///// <summary>
            ///// ForProcessType
            ///// </summary>
            //public bool? ForProcessType { get; set; }
            /// <summary>
            /// UOMid
            /// </summary>
            public string? UOMID { get; set; }
            /// <summary>
            /// UOMname
            /// </summary>
            public string? UOMName { get; set; }
            /// <summary>
            /// WIPDATAid
            /// </summary>
            public string? WIPDATANAMEID { get; set; }
            /// <summary>
            /// WIPDATANAMENAME
            /// </summary>
            public string? WIPDATANAMENAME { get; set; }
            /// <summary>
            ///  采集值
            /// </summary>
            public string? WIPDATAVALUE { get; set; }

        }
    }
}
