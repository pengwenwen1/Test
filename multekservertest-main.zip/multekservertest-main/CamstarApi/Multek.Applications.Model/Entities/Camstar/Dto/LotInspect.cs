﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    [NotMapped]
    public class LotInspect
    {

        /// <summary>
        /// 电脑名称
        /// </summary>
        public string? ComputerName { get; set; }

        /// <summary>
        /// 批次
        /// </summary>
        public string Container { get; set; }

        /// <summary>
        /// cuIsDynamic
        /// </summary>
        public bool? cuIsDynamic { get; set; }

        /// <summary>
        /// cuIsDynamic
        /// </summary>
        public bool? cuIsFirstInspect { get; set; }

        /// <summary>
        /// cuIsDynamic
        /// </summary>
        public bool? cuIsLastInspect { get; set; }

        /// <summary>
        /// 批次LOT
        /// </summary>
        public string? SelectionId { get; set; }
    }
}
