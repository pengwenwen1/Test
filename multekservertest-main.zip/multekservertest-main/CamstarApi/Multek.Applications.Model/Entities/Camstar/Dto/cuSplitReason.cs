﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class cuSplitReason
    {
        /// <summary>
        /// 拆批原因ID
        /// </summary>
        [Key]
        public string CUSPLITREASONID { get; set; }

        /// <summary>
        /// 拆批原因名称
        /// </summary>
        public string CUSPLITREASONNAME { get; set; }


        /// <summary>
        /// 拆批原因描述
        /// </summary>
        public string DESCRIPTION { get; set; }


    }
}
