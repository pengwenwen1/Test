﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using static Multek.Applications.Model.Entities.Camstar.Dto.CuOARejectProcess;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class CuOARejectInfoReturn
    {
        /// <summary>
        /// 域账号
        /// </summary>
        public string EmployeeNo { get; set; }

        public IList<cuOARejectTable> detailTable { get; set; }

        public class cuOARejectTable 
        {
            /// <summary>
            /// 日期
            /// </summary>
            public string Date { get; set; }

            /// <summary>
            /// 报废类型 1：按panel码报废 3：只有LOT时，:按panel报废 4：只有LOT时，按PCS报废
            /// </summary>
            public string cuDefectType { get; set; }

            /// <summary>
            /// 报废批次号
            /// </summary>
            public string cuLotNo { get; set; }
            /// <summary>
            /// PANEL/PCS码
            /// </summary>
            public string cuworkflowStep { get; set; }
            /// <summary>
            /// WIP结存工站
            /// </summary>
            public string cuPanelPCSNo { get; set; }
            /// <summary>
            /// 数量
            /// </summary>
            public string cuPanelQty { get; set; }
            /// <summary>
            /// 数量
            /// </summary>
            public string cuPCSQty { get; set; }
            /// <summary>
            ///  Scap Type  Remark
            /// </summary>
            public string cuScrapType { get; set; }
            /// <summary>
            /// Scap Type Desc
            /// </summary>
            public string cuScrapTypeDesc { get; set; }
            /// <summary>
            /// 缺陷代码
            /// </summary>
            public string cuLossReason { get; set; }
            /// <summary>
            /// 责任工序代码
            /// </summary>
            public string cuProcesSpec { get; set; }
            /// <summary>
            /// 缺陷名称
            /// </summary>
            public string DefectDesc { get; set; }
            /// <summary>
            /// 责任工序
            /// </summary>
            public string ProcesDesc { get; set; }
            /// <summary>
            /// 员工工号
            /// </summary>
            public string cuEmployeeNo { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string cuRemark { get; set; }

            /// <summary>
            /// 备注
            /// </summary>
            public string? cuPCSArea { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string? cuPNLArea { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string? cuPCSPerPNL { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string? cuTotalArea { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string? cuDefectTotalArea { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string? cuNewDefectTotalArea { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string? cuDefectArea { get; set; }
            /// <summary>
            /// 备注
            /// </summary>
            public string? cuTrackingLevel { get; set; }
            /// <summary>
            /// 区分内外侧
            /// </summary>
            public string? OUTER { get; set; }
            /// <summary>
            /// 客户信息
            /// </summary>
            public string? DESCRIPTION { get; set; }
            /// <summary>
            /// 工厂
            /// </summary>
            public string? FACTORYNAME { get; set; }
            /// <summary>
            /// 批次重新打印状态，1是未重打
            /// </summary>
            public string? CUECNSTATUS { get; set; }
            /// <summary>
            /// 工单状态
            /// </summary>
            public string? ORDERSTATUSNAME { get; set; }
            /// <summary>
            /// 客户编码
            /// </summary>
            public string? Cuoemname { get; set; }
            /// <summary>
            /// 产品编码
            /// </summary>
            public string? productName { get; set; }
            /// <summary>
            /// PRODUCTREVISION
            /// </summary>
            public string? PRODUCTREVISION { get; set; }
            /// <summary>
            /// 工艺路线
            /// </summary>
            public string? workFlowName { get; set; }
            /// <summary>
            /// 工单
            /// </summary>
            public string? mfgOrder { get; set; }
            /// <summary>
            /// 工序
            /// </summary>
            public string? workflowStep { get; set; }
            /// <summary>
            /// 工序
            /// </summary>
            public string? cuScrapTypeDesp { get; set; }
            /// <summary>
            /// srampcode
            /// </summary>
            public string? cuStampcode { get; set; }
            /// <summary>
            /// hold
            /// </summary>
            public string? CURRENTHOLDCOUNT { get; set; }
        }
    }
}
