﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class cuOutsouringLotInfo
    {
        /// <summary>
        /// containerid
        /// </summary>
        [Key]
        public string? containerid { get; set; }

        /// <summary>
        /// LOT号
        /// </summary>
        public string cuOutsourcingLot { get; set; }

        /// <summary>
        /// 产品
        /// </summary>
        public string? cuProductName { get; set; }

        /// <summary>
        /// 产品版本
        /// </summary>
        public string? ProductRevision { get; set; }

        /// <summary>
        /// 主料数量
        /// </summary>
        public string? cuQty { get; set; }

        /// <summary>
        /// 主料系数
        /// </summary>
        public string? cuConsume { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string? cuSpec { get; set; }

        /// <summary>
        /// 工序版本
        /// </summary>
        public string? SpecRevision { get; set; }

    }
}
