﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public  class TrackInReq
    {
        /// <summary>
        /// Lot集合
        /// </summary>
        public List<string> Lots { get; set; }

        /// <summary>
        /// 工厂
        /// </summary>
        public string? Factory { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string? SpecName { get; set; }

        /// <summary>
        /// 设备号
        /// </summary>
        public string EquipmentName { get; set; }

        /// <summary>
        /// 操作人
        /// </summary>
        public string? Operator { get; set; }

        /// <summary>
        /// 上机数量
        /// </summary>
        public string? TrackInQty { get; set; }
    }
}
