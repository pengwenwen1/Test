﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using static Multek.Applications.Model.Entities.Camstar.Dto.CuOARejectProcess;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    [NotMapped]
    public class LotStatusUpdateRsp
    {
        /// <summary>
        /// 打开/关闭LOT号
        /// </summary>
        public string Container { get; set; }

        /// <summary>
        /// 打开/关闭LOT号
        /// </summary>
        public string? Factory { get; set; }

        /// <summary>
        /// 打开/关闭LOT号
        /// </summary>
        public string? TaskContainer { get; set; }

    }
}
