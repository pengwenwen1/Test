﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class LotAndSpecDto
    {
        /// <summary>
        /// Lot
        /// </summary>
        public string LotName { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string specName { get; set; }
    }
}
