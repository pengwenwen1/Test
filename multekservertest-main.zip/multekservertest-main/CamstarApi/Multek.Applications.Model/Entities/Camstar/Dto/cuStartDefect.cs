﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class cuStartDefect
    {
        /// <summary>
        /// cuDefectRecordName
        /// </summary>
        public string cuDefectRecordName { get; set; }

        /// <summary>
        /// cuFactoryName
        /// </summary>
        public string cuFactoryName { get; set; }

        /// <summary>
        /// cuEmployeeNo
        /// </summary>
        public string cuEmployeeNo { get; set; }

        /// <summary>
        /// cuHoldReason
        /// </summary>
        public string cuHoldReason { get; set; }

        public IList<cuStartDefectDetails> CuStartDefectDetails { get; set; }

        public class cuStartDefectDetails
        {
            /// <summary>
            /// 工单报废总面积
            /// </summary>
            public float cuDefectTotalArea { get; set; }
            /// <summary>
            /// 报废类型
            /// </summary>
            public string cuDefectType { get; set; }
            /// <summary>
            /// cuDescription
            /// </summary>
            public string cuDescription { get; set; }
            /// <summary>
            /// 员工
            /// </summary>
            public string cuEmployeeNo { get; set; }
            /// <summary>
            /// 缺陷代码
            /// </summary>
            public string cuLossReason { get; set; }
            /// <summary>
            /// 报废批次号
            /// </summary>
            public string cuLot { get; set; }
            /// <summary>
            /// cuNotes
            /// </summary>
            public string cuNotes { get; set; }
            /// <summary>
            /// cuPanelPCSNo
            /// </summary>
            public string cuPanelPCSNo { get; set; }
            /// <summary>
            /// PanelQty
            /// </summary>
            public float cuPanelQty { get; set; }
            /// <summary>
            /// PCSArea
            /// </summary>
            public float cuPCSArea { get; set; }
            /// <summary>
            /// PCSQty
            /// </summary>
            public float cuPCSQty { get; set; }
            /// <summary>
            /// ProcesSpec
            /// </summary>
            public string cuProcesSpec { get; set; }
            /// <summary>
            /// ScrapType
            /// </summary>
            public string cuScrapType { get; set; }
            /// <summary>
            /// cuTrackingLevel
            /// </summary>
            public string cuTrackingLevel { get; set; }

        }
    }
}
