﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class LotReleaseReq
    {

            /// <summary>
            /// 拆批批次
            /// </summary>
            public List<conInfo> containers { get; set; }

            /// <summary>
            /// 解冻用户
            /// </summary>
            public string ReleaseUser { get; set; }

        /// <summary>
        /// 默认释放原因
        /// </summary>
            public string? cuDefultReleaseReason { get; set; }
    }

    public class conInfo
        {
            /// <summary>
            /// 批次名称
            /// </summary>
            public string ContainerName { get; set; }

            /// <summary>
            /// 解冻原因
            /// </summary>
            public string?ReleaseReason { get; set; }
        }

}
