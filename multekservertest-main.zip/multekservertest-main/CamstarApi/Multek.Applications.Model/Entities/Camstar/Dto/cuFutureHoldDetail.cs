﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar.Dto
{
    public class cuFutureHoldDetail
    {
        [Key]
        public string containername { get; set; }
        public string? specname { get; set; }
        public string? specrevision { get; set; }
        public string productname { get; set; }
        public string? productrevision { get; set; }
        public string? cuinactive { get; set; }
        public string? culinkrelease { get; set; }


    }
}
