﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar
{
    [Table("TIMER")]
    public class Timers
    {
        [Key]
        public string timerid { get; set; }

        public DateTime? maxendtimegmt { get; set; }

        public DateTime? minendtimegmt { get; set; }

        public string culotname { get; set; }

        public string processtimerid { get; set; }

        public int isstoped { get; set; }

        public DateTime starttimegmt { get; set; }

        public string scsstarttimerspecid { get; set; }

        public string PARENTID { get; set; }
    }
}
