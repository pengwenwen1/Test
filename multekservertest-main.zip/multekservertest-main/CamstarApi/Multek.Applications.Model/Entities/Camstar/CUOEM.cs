﻿using AutoMapper.Configuration.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("CUOEM")]
    public class CUOEM
    {
        /// <summary>
        /// CUOEMID
        /// </summary>
        [Key]
        public string CUOEMID { get; set; }

        /// <summary>
        /// OEMNAME
        /// </summary>
        public String CUOEMNAME { get; set; }

        public string DESCRIPTION { get; set; }

        

    }
}
