﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("Lossreason")]
    public class Lossreason
    {

        [Key]
        public string Lossreasonname { get; set; }

        /// <summary>
        /// 工厂
        /// </summary>
        public string? Description { get; set; }

        public string? lossreasonid { get; set; }
        
    }
}
