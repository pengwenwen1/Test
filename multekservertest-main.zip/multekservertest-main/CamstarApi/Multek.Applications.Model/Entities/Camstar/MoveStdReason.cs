﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar
{
    public class MoveStdReason
    {
        /// <summary>
        /// 跳站原因ID
        /// </summary>
        [Key]
        public string cumovenonstdreasonid { get; set; }

        /// <summary>
        /// 跳站原因名称
        /// </summary>
        public string cumovenonstdreasonname { get; set; }

        /// <summary>
        /// 跳站原因描述
        /// </summary>
        /// </summary>
        public string? description { get; set; }
    }

}
