﻿using AutoMapper.Configuration.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("OrderStatus")]
    public class OrderStatus
    {
        /// <summary>
        /// MFGORDERID
        /// </summary>
        [Key]
        public string OrderStatusId { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string ORDERSTATUSNAME { get; set; }

    }
}
