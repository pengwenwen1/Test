﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar
{
    [Table("RELEASEREASON")]
    public class Releasereason
    {
        /// <summary>
        /// 释放原因ID
        /// </summary>
        [Key]
        public string RELEASEREASONID { get; set; }

        /// <summary>
        /// 释放原因名称
        /// </summary>
        public string RELEASEREASONNAME { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        public string? DESCRIPTION { get; set; }

    }
}
