﻿using AutoMapper.Configuration.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("WorkFlowBase")]
    public class WorkFlowBase
    {
        /// <summary>
        /// id
        /// </summary>
        [Key]
        public string WorkFlowBaseId { get; set; }

        public string WorkFlowName { get; set; }
        
    }
}
