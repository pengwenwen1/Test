﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar
{
    [Table("A_InsertionReason")]
    public class A_InsertionReason
    {
        /// <summary>
        /// 原因
        /// </summary>
        [Key]
        public string InsertionReasonName { get; set; }

        //public string InsertionreasonId { get; set; }
    }
}
