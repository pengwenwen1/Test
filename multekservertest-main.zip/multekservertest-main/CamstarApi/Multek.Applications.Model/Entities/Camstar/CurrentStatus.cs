﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("currentstatus")]
    public class Currentstatus
    {
        /// <summary>
        /// id
        /// </summary>
        ////[Key]
        public string CURRENTSTATUSID { get; set; }

        public string WorkFlowStepId { get; set; }
        
    }
}
