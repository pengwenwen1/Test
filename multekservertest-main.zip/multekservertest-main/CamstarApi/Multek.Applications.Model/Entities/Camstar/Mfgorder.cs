﻿using AutoMapper.Configuration.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("Mfgorder")]
    public class Mfgorder
    {
        /// <summary>
        /// MFGORDERID
        /// </summary>
        [Key]
        public String MFGORDERID { get; set; }

        /// <summary>
        /// Lot名称
        /// </summary>
        public string MfgorderName { get; set; }

        /// <summary>
        /// STAMPCODE
        /// </summary>
        public string CUSTAMPCODE { get; set; }
        /// <summary>
        /// OrderStatusId
        /// </summary>
        public string OrderStatusId { get; set; }

        /// <summary>
        /// OrderStatusId
        /// </summary>
        public string cuFactoryId { get; set; }
        
    }
}
