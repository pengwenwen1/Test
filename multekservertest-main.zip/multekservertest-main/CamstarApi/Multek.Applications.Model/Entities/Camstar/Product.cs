﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("PRODUCT")]
    public class Product
    {
        /// <summary>
        /// PNID
        /// </summary>
        [Key]
        public String ProductId { get; set; }

    
        public string ProductName { get; set; }

        public String CuMI_PN { get; set; }

        //每Pnl的Set数
        public float CuStripPerPnl { get; set; }

        //每Pnl的pcs数
        public float cuPCSPerPnl { get; set; }

        /// <summary>
        /// 每set的pcs数
        /// </summary>
        public float CuPCSPerStrip { get; set; }

        //客户PN （OPPO客户，如果是7位为旧板，12位为新版）
        public string? CUCUSTOMERPN { get; set; }

        //客户项目名称（截取后两位，作为版本，生成码的前缀）
        public string? CUCUSTOMERVERSION { get; set; }

        //客户OEMID
        public string CUOEMID { get; set; }


        /// <summary>
        /// 是否追溯Pnl码；0：不追溯；1：追溯
        /// </summary>
        public int? CuIsPnl { get; set; }

        /// <summary>
        /// 1：set
        /// 2：pcs
        /// 3：set + pcs
        /// </summary>
        public int? CuIsSetPcs { get; set; }

        /// <summary>
        /// 定义是否需要PNL码 规则: 默认为工厂代号
        /// </summary>
        public string? cuPnlCodeRule { get; set; }

        /// <summary>
        /// 关联追溯系统set生成码的规则,对应CodeRule.CodeRuleName
        /// </summary>
        public string? cuSetCodeRule { get; set; }

        /// <summary>
        /// 关联追溯系统pcs生成码的规则,对应CodeRule.CodeRuleName
        /// </summary>
        public string? cuPcsCodeRule { get; set; }

        /// <summary>
        /// 方案号
        /// </summary>
        public string? cuSolutionVersion { get; set; }

        /// <summary>
        /// 内层外层标识
        /// </summary>
        public string? OUTER { get; set; }

        /// <summary>
        /// ProductBaseId
        /// </summary>
        public string? ProductBaseId { get; set; }

        /// <summary>
        /// cuPCSArea
        /// </summary>
        public string? cuPCSArea { get; set; }

        /// <summary>
        /// cuPNLArea
        /// </summary>
        public string? cuPNLArea { get; set; }

        /// <summary>
        /// cuPCSPerPNL
        /// </summary>
        public string? cuPCSPerPNL { get; set; }

        /// <summary>
        /// PRODUCTREVISION
        /// </summary>
        public string? PRODUCTREVISION { get; set; }
        
    }
}
