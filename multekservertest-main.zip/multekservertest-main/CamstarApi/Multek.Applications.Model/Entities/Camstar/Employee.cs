﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.Entities.Camstar
{
    /// <summary>
    /// 员工
    /// </summary>
    [Table("EMPLOYEE")]
    public class Employee
    {
        [Key]
        public string EmployeeId { get; set; }  

        public string EmployeeName { get; set; }

        public string FullName { get; set; }

        public string? EmployeegroupName { get; set; }
        public string? FactoryName { get; set; }
    }
}
