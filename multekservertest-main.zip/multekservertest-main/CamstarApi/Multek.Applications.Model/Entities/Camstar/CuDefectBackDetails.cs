﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Data.Entities
{
    [Table("CuDefectBackDetails")]
    public class CuDefectBackDetails
    {
        /// <summary>
        /// cudefectrecordid
        /// </summary>
        [Key]
        public string cudefectrecordid { get; set; }
        public string culotid { get; set; }

        public string cuPCSArea { get; set; }

        public string culossreasonid { get; set; }
        


    }
}
