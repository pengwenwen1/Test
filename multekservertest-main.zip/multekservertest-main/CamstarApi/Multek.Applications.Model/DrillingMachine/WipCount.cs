﻿using Castle.Components.DictionaryAdapter;
using Multek.Applications.Model.DrillingMachine.Enum;

using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Multek.Applications.Model.DrillingMachine
{
    /// <summary>
    /// MES CAMSTAR_WIP_Count表
    /// </summary>
    [Table("CAMSTAR_WIP_Count")]
    public class WipCount
    {
        /// <summary>
        /// Lot
        /// </summary>
        [System.ComponentModel.DataAnnotations.Key]
        public string containerName { get; set; }
        /// <summary>
        ///  MoveIn = 0 （已进站）
        ///  TrackIn = 2（已上机）
        ///  TrackOut = 4（已下机）
        /// </summary>
        public CuTrackFlagEnum cutrackflag { get; set; }

        /// <summary>
        /// 工厂
        /// </summary>
        public string factoryName { get; set; }
        /// <summary>
        /// PN
        /// </summary>
        public string productName { get; set; }

        public DateTime lastActivityDate { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public string specName { get; set; }
        /// <summary>
        /// 数量(PNL)
        /// </summary>
        public double QTY2 { get; set; }

        /// <summary>
        /// 设备
        /// </summary>
        public string resourceName { get; set; }
    }
}
