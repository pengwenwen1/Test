﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.DrillingMachine.Enum
{
    /// <summary>
    /// Lot跟踪标记
    /// </summary>
    public enum CuTrackFlagEnum
    {
        MoveIn = 0,
        TrackIn = 2,
        TrackOut = 4
    }
}
