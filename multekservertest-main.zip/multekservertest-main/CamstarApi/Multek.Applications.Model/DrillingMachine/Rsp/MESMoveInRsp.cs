﻿using Castle.Components.DictionaryAdapter;
using Multek.Applications.Model.DrillingMachine.Enum;

using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Multek.Applications.Model.DrillingMachine.Rsp
{
    /// <summary>
    /// MESMoveIn返回参数
    /// </summary>
    public class MESMoveInRsp
    {
        /// <summary>
        /// 工厂
        /// </summary>
        public string factoryName { get; set; }
        /// <summary>
        /// 批量卡号
        /// </summary>
        public string containerName { get; set; }

        /// <summary>
        /// 产品型号
        /// </summary>
        public string productName { get; set; }

        /// <summary>
        /// 工作中心
        /// </summary>
        public string specName { get; set; }
        /// <summary>
        /// 数量(PNL)
        /// </summary>
        public double QTY2 { get; set; }

        /// <summary>
        /// 时间
        /// </summary>
        public DateTime lastActivityDate { get; set; }
    }
}
