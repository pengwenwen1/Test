﻿using Castle.Components.DictionaryAdapter;
using Multek.Applications.Model.DrillingMachine.Enum;

using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Multek.Applications.Model.DrillingMachine.Rsp
{
    /// <summary>
    /// MES上下机返回参数
    /// </summary>
    public class MESTrackRsp : MESMoveInRsp
    {   /// <summary>
        /// 设备编号
        /// </summary>
        public string resourceName { get; set; }
    }
}
