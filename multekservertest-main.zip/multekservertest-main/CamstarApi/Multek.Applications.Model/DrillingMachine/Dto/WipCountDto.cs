﻿using Multek.Applications.Model.DrillingMachine.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Model.DrillingMachine
{
    /// <summary>
    /// MES过数信息请求参数
    /// </summary>
    public class WipCountDto
    {

        /// <summary>
        /// 工厂
        /// </summary>
        public string factoryName { get; set; }

        /// <summary>
        /// 工序
        /// </summary>
        public List<string> specName { get; set; }
        /// <summary>
        /// PN
        /// </summary>
        public List<string> productName { get; set; }
        /// <summary>
        ///  MoveIn = 0 （已进站）
        ///  TrackIn = 2（已上机）
        ///  TrackOut = 4（已下机）
        /// </summary>
        public CuTrackFlagEnum cuTrackFlag { get; set; }

        /// <summary>
        /// 开始日期
        /// </summary>
        public DateTime startTime { get; set; }
        /// <summary>
        /// 结束日期
        /// </summary>
        public DateTime endTime { get; set; }

    }
}
