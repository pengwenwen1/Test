﻿using Azure;
using Camstar.XMLClient.Interface;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.LotTxn;
using Multek.Applications.Model.Entities.Multek;
using Multek.Applications.Model.WIPData;
using Multek.Applications.Model.WIPMain;
using Multek.Applications.Services.CamstarApi;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Camstar.Constants;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.DirectoryServices.Protocols;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.CamstarApi
{
    public class SWIPMain : EFHelper<MultekCamstarDbContext>, IWIPMain
    {
        public readonly ICamstarComm ICamstarComm;
        public SWIPMain(MultekCamstarDbContext tdb, ICamstarComm camstarComm) : base(tdb)
        {
            ICamstarComm = camstarComm;
        }

        #region Move in
        /// <summary>
        /// Move in
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel MoveIn(MoveInReq param)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuAssemblyWipMain");
            var inputData = _helper.InputData();
            //_helper.InputData().NamedObjectField("Employee").SetRef("5");
            inputData.DataField("WIPFlag").SetValue("5");
            inputData.NamedObjectField("cuProcessType").SetRef("NORMAL");
            inputData.DataField("cuReportFlag").SetValue("True");

            if(param.Operator != null)
            {
                inputData.NamedObjectField("Employee").SetRef(param.Operator);
            }

            //ICsiObject csiObjectList1 = _helper.InputData();
            var list = inputData.ContainerList("Containers");
            foreach (var item in param.Lots)
            {
                list.AppendItem(item, "LOT");
            }
            _helper.SetExecute();
            var _resDocument = _helper.Submit();


            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;

        }
        #endregion

        #region  Move Out
        /// <summary>
        /// 出站前获取下下道工步信息
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        public IResultModel GetMoveOutNextStep(GetLotMsgReq param)
        {
            FormattableString fssql = $@" 
                select c.containername ，
                wt2.workflowstepname as ToNextStep ,
                wt2.sequence ToNextSeq,
                sb.specname ToSpecName,
                s.specrevision ToSpecVer
                from container c
                inner join currentstatus cs on c.currentstatusid = cs.currentstatusid
                inner join workflowstep wt on cs.workflowstepid = wt.workflowstepid
                left join workflowstep wt1 on wt1.workflowid = wt.workflowid and wt1.sequence=wt.sequence+1
                left join specbase sb on wt1.specbaseid = sb.specbaseid
                left join spec s on sb.specbaseid = s.specbaseid 
                left  join workflowstep wt2 on wt2.workflowid = wt.workflowid and wt2.sequence=wt.sequence+2
                    where c.containername = {param.Lot} ";


            MoveOutNextStep step = db.MoveOutNextStep.FromSql<MoveOutNextStep>(fssql)?.FirstOrDefault();

            return new ResultModel<MoveOutNextStep>().Success(step);
        }

        /// <summary>
        /// Move out
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel MoveOut(MoveOutReq param)
        {
            //DateCode验证
            if (!string.IsNullOrEmpty(param.DateCode) && !string.IsNullOrEmpty(param.DateCodeFormat))
            {
                // inputData.DataField("cuDateCode").SetValue(param.DateCode);
                List<LotMessage> lots = new List<LotMessage>();
                foreach (var item in param.Lots)
                {
                    LotMessage lot = new LotMessage();
                    lot.ContainerName = item;
                }
                EntryDataCodeReq entryDataCodeReq = new EntryDataCodeReq();
                entryDataCodeReq.containers = lots;
                entryDataCodeReq.DCFromt = param.DateCodeFormat;
                entryDataCodeReq.DCValue = param.DateCode;
                entryDataCodeReq.Employee = param.Operator;

                ResultModel<string> isEnrtyCode = (ResultModel<string>)CheckDataCode(entryDataCodeReq);
                if (!isEnrtyCode.success)
                    return isEnrtyCode;

            }


            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuAssemblyWipMain");
            var inputData = _helper.InputData();

            inputData.DataField("WIPFlag").SetValue("4");
            inputData.NamedObjectField("cuProcessType").SetRef("NORMAL");
            inputData.DataField("cuReportFlag").SetValue("True");

            if (param.Operator != null)
            {
                inputData.NamedObjectField("Employee").SetRef(param.Operator);
            }

            if (!string.IsNullOrEmpty(param.DateCode))
            {
                inputData.DataField("cuDateCode").SetValue(param.DateCode);
                inputData.DataField("cuDateCodeFormat").SetValue(param.DateCodeFormat);
                inputData.DataField("cuSpecName").SetValue(param.SpecName);

                // inputData.dataField("cuDateCodeSpec").setValue(lotInfo.CuDateCodeSpec);
                // inputData.namedObjectField("cuProductType").setRef(lotInfo.ProductType);
            }
            var list = inputData.ContainerList("Containers");
            foreach (var item in param.Lots)
            {
                list.AppendItem(item, "LOT");
            }
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;

        }
        #endregion

        #region Track in
        public IResultModel TrackIn(TrackInReq param)
        {
            string TrackInQty = param?.TrackInQty;
            if (param.Lots.Count == 1)  //单批次与多批次在trackin时不同，要求有trackinqty
            {
                if (string.IsNullOrEmpty(param.TrackInQty))
                    TrackInQty = GetWIPMainAttribute(param.Lots.FirstOrDefault(), "MaxTrackInQty");
            }

            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("AssemblyMotherLotWIPMain");
            var inputData = _helper.InputData();


            inputData.DataField("WIPFlag").SetValue("1");
            inputData.NamedObjectField("ProcessType").SetRef("NORMAL");
            inputData.NamedObjectField("Equipment").SetRef(param.EquipmentName);
            // _helper.InputData().DataField("cuReportFlag").SetValue("True");

            if (!string.IsNullOrEmpty(param.Operator) )
            {
                inputData.NamedObjectField("Employee").SetRef(param.Operator);
            }

            if (param.Lots.Count == 1)  //单批次与多批次在trackin时不同，要求有trackinqty
            {
                inputData.DataField("TrackInQty").SetValue(TrackInQty);
            }

            var list = inputData.ContainerList("Containers");
            foreach (var item in param.Lots)
            {
                list.AppendItem(item, "LOT");
            }

            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        #endregion

        #region Track Out
        /// <summary>
        /// 批量Lot Track Out
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel TrackOut(TrackOutReq param)
        {
            //DateCode验证
            if (!string.IsNullOrEmpty(param.DateCode)&& !string.IsNullOrEmpty(param.DateCodeFormat))
            {
                // inputData.DataField("cuDateCode").SetValue(param.DateCode);
                List<LotMessage> lots = new List<LotMessage>();
               foreach (var item in param.Lots)
               {
                    LotMessage lot = new LotMessage();
                    lot.ContainerName = item;
               }
                EntryDataCodeReq entryDataCodeReq = new EntryDataCodeReq();
                entryDataCodeReq.containers = lots;
                entryDataCodeReq.DCFromt = param.DateCodeFormat;
                entryDataCodeReq.DCValue = param.DateCode;
                entryDataCodeReq.Employee = param.Operator;

                ResultModel<string> isEnrtyCode = (ResultModel<string>)CheckDataCode(entryDataCodeReq);
                if(!isEnrtyCode.success)
                    return isEnrtyCode;

            }

            string TrackOutQty = param?.TrackOutQty;
            if (param.Lots.Count == 1)  //单批次与多批次在trackin时不同，要求有trackinqty
            {
                if (string.IsNullOrEmpty(param.TrackOutQty) )
                    TrackOutQty = GetWIPMainAttribute(param.Lots.FirstOrDefault(), "MaxTrackOutQty");
            }
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("AssemblyMotherLotWIPMain");
            var inputData = _helper.InputData();


            inputData.DataField("WIPFlag").SetValue("2");
            inputData.NamedObjectField("ProcessType").SetRef("NORMAL");
            inputData.NamedObjectField("Equipment").SetRef(param.EquipmentName);
            // _helper.InputData().DataField("cuReportFlag").SetValue("True");

            if (param.Operator != null)
            {
                inputData.NamedObjectField("Employee").SetRef(param.Operator);
            }

            if (param.Lots.Count == 1)  //单批次与多批次在trackin时不同，要求有trackinqty
            {
                inputData.DataField("TrackOutQty").SetValue(TrackOutQty);
            }

            if (!string.IsNullOrEmpty(param.DateCode))
            {
                inputData.DataField("cuDateCode").SetValue(param.DateCode);
                //inputData.DataField("cuDateCodeFormat").SetValue(param.DateCodeFormat);
                //inputData.DataField("cuSpecName").SetValue(param.SpecName);

                // inputData.dataField("cuDateCodeSpec").setValue(lotInfo.CuDateCodeSpec);
                // inputData.namedObjectField("cuProductType").setRef(lotInfo.ProductType);
            }

            var list = inputData.ContainerList("Containers");
            foreach (var item in param.Lots)
            {
                list.AppendItem(item, "LOT");
            }

            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }


        #endregion


        /// <summary>
        /// 获取Lot信息
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        public IResultModel GetLotMsg(GetLotMsgReq param)
        {
            FormattableString fssql = $@" 
                   select  
                     c.containername
                     ,c.qty
                     ,c.qty2
                      ,pb.productname
                     ,c.currentholdcount 
                     ,c.status
                     ,c.Cutrackflag
                     ,sb.specname
                     ,s.specrevision SpecVer
                     ,s.description SpecDesc
                    ,s.cu_isdrillingroom IsDrillRoom 
                    ,(case when s.resourcegroupid is null then 0 else 1 end) as IsHaveEquipment
                     ,sb1.specname ToSpecName
                     ,s1.specrevision ToSpecVer
                     ,wt.workflowstepname step
                     ,wt1.workflowstepname tostep
                     ,wt2.workflowstepname as ToNextStep
                     ,wt.sequence Seq
                     ,wt1.sequence toSeq
                     ,wt2.sequence ToNextSeq 
                     ,wt.workflowid
                      ,nvl(P.CUSTRIPPERPNL,0) S_QTY
                      ,nvl(P.CUPCSPERPNL,0) U_QTY
                      ,p.cudatacode_format DataCode_Format
                        ,（case when sb.specname = sb2.specname then 1
                        else 0
                          end) IsDtSpec
                      ,c.cudatecode DataCode_Value  
                      ,f.factoryname Factory
                      ,f.notes FactoryNotes
                      ,hd.holdreasonname
                      ,wb.workflowname
                      ,wf.workflowrevision
                      ,ae.equipmentname Equipment
                      ,nvl(rd.cu_iscontinuous,0) IsContinuous
                      ,mo.mfgordername 
                      ,WFS.WORKFLOWSTEPNAME as UnTerminateWorkflowStep
                      ,nvl(s.autocreatefirstinsertion,0) isFirstInsertion   
                      ,nvl(op.usequeue,0) cuusequeue
                      ,cc.custampcode
                      from container c
                      left  join currentstatus cs on cs.currentstatusid = c.currentstatusid
                      left join mfgorder mo on c.cuworkorderid=mo.mfgorderid 
                      left join culotcard cc on mo.mfgordername = cc.culotcardname
                      left join spec s on cs.specid = s.specid
                      left join operation op on s.operationid = op.operationid
                      left join specbase sb on sb.specbaseid = s.specbaseid
                      left join product p on p.productid = c.productid
                      left join productbase pb on p.productbaseid = pb.productbaseid
                      left join workflowstep wt on cs.workflowstepid = wt.workflowstepid
                      left  join path p1 on p1.fromstepid = wt.workflowstepid
                      left join workflowstep wt1 on wt1.workflowstepid = p1.tostepid
                      left join specbase sb1 on wt1.specbaseid = sb1.specbaseid
                      left join spec s1 on sb1.specbaseid = s1.specbaseid 
                      left join path p2 on p2.fromstepid = wt1.workflowstepid
                      left join workflowstep wt2 on wt2.workflowstepid = p2.tostepid
                      left join spec s2 on s2.specid = p.cudatecodespecid 
                      left join specbase sb2 on sb2.specbaseid = s2.specbaseid
                      left join factory f on cs.factoryid = f.factoryid
                      left join HOLDREASON hd on hd.holdreasonid = c.holdreasonid
                      left join workflow wf on wf.workflowid = wt.workflowid
                      left join workflowbase wb on wb.workflowbaseid = wf.workflowbaseid
                      left join a_Wipequipment ae on c.containerid = ae.containerid and ae.trackstatus = 'INPROCESS'
                      left join resourcedef rd on ae.equipmentid = rd.resourceid
                      left join WORKFLOWSTEP WFS ON WFS.WORKFLOWID = WF.WORKFLOWID and  WFS.CUSEQUENCE='901000'
                      where c.containername ={param.Lot} ";


            LotMessage LotMsg = db.LotMessage.FromSql<LotMessage>(fssql)?.FirstOrDefault();
            if (LotMsg == null)
                return new ResultModel<LotMessage>().Failed($"Lot【{param.Lot}】信息未找到！");
            else
            {
                //if(LotMsg.CurrentHoldCount > 0)
                //    return new ResultModel<LotMessage>().Failed($"{param.Lot}被冻结，不可执行过站操作！");
                if (LotMsg.status == 2)
                    return new ResultModel<LotMessage>().Failed($"{param.Lot}为关闭状态，不可执行过站操作！");
            }

            return new ResultModel<LotMessage>().Success(LotMsg);


        }


        public IResultModel GetLotMsgNew(GetLotMsgReq param)
        {
            String fssql = $@" 
                   select  
                     c.containername
                     ,c.qty
                     ,c.qty2
                      ,pb.productname
                     ,c.currentholdcount 
                     ,c.status
                     ,c.Cutrackflag
                     ,sb.specname
                     ,s.specrevision SpecVer
                     ,s.description SpecDesc
                    ,s.cu_isdrillingroom IsDrillRoom 
                    ,(case when s.resourcegroupid is null then 0 else 1 end) as IsHaveEquipment
                     ,sb1.specname ToSpecName
                     ,s1.specrevision ToSpecVer
                     ,wt.workflowstepname step
                     ,wt1.workflowstepname tostep
                     ,wt2.workflowstepname as ToNextStep
                     ,wt.sequence Seq
                     ,wt1.sequence toSeq
                     ,wt2.sequence ToNextSeq 
                     ,wt.workflowid
                      ,nvl(P.CUSTRIPPERPNL,0) S_QTY
                      ,nvl(P.CUPCSPERPNL,0) U_QTY
                      ,p.cudatacode_format DataCode_Format
                        ,（case when sb.specname = sb2.specname then 1
                        else 0
                          end) IsDtSpec
                      ,c.cudatecode DataCode_Value  
                      ,f.factoryname Factory
                      ,f.notes FactoryNotes
                      ,hd.holdreasonname
                      ,wb.workflowname
                      ,wf.workflowrevision
                      ,ae.equipmentname Equipment
                      ,nvl(rd.cu_iscontinuous,0) IsContinuous
                      ,mo.mfgordername 
                      ,WFS.WORKFLOWSTEPNAME as UnTerminateWorkflowStep
                      ,nvl(s.autocreatefirstinsertion,0) isFirstInsertion   
                      ,nvl(op.usequeue,0) cuusequeue
                      ,cc.custampcode
                      from container c
                      left  join currentstatus cs on cs.currentstatusid = c.currentstatusid
                      left join mfgorder mo on c.cuworkorderid=mo.mfgorderid 
                      left join culotcard cc on mo.mfgordername = cc.culotcardname
                      left join spec s on cs.specid = s.specid
                      left join operation op on s.operationid = op.operationid
                      left join specbase sb on sb.specbaseid = s.specbaseid
                      left join product p on p.productid = c.productid
                      left join productbase pb on p.productbaseid = pb.productbaseid
                      left join workflowstep wt on cs.workflowstepid = wt.workflowstepid
                      left  join path p1 on p1.fromstepid = wt.workflowstepid
                      left join workflowstep wt1 on wt1.workflowstepid = p1.tostepid
                      left join specbase sb1 on wt1.specbaseid = sb1.specbaseid
                      left join spec s1 on sb1.specbaseid = s1.specbaseid 
                      left join path p2 on p2.fromstepid = wt1.workflowstepid
                      left join workflowstep wt2 on wt2.workflowstepid = p2.tostepid
                      left join spec s2 on s2.specid = p.cudatecodespecid 
                      left join specbase sb2 on sb2.specbaseid = s2.specbaseid
                      left join factory f on cs.factoryid = f.factoryid
                      left join HOLDREASON hd on hd.holdreasonid = c.holdreasonid
                      left join workflow wf on wf.workflowid = wt.workflowid
                      left join workflowbase wb on wb.workflowbaseid = wf.workflowbaseid
                      left join a_Wipequipment ae on c.containerid = ae.containerid and ae.trackstatus = 'INPROCESS'
                      left join resourcedef rd on ae.equipmentid = rd.resourceid
                      left join WORKFLOWSTEP WFS ON WFS.WORKFLOWID = WF.WORKFLOWID and  WFS.CUSEQUENCE='901000'
                      where c.containername ='{param.Lot}' ";


            var LotMsg = db.GetTable(fssql)?.Rows[0];
            if (LotMsg == null)
                return new ResultModel<LotMessage>().Failed($"Lot【{param.Lot}】信息未找到！");
            else
            {
                //if(LotMsg.CurrentHoldCount > 0)
                //    return new ResultModel<LotMessage>().Failed($"{param.Lot}被冻结，不可执行过站操作！");
                if (LotMsg["status"].ToString() == "2")
                    return new ResultModel<LotMessage>().Failed($"{param.Lot}为关闭状态，不可执行过站操作！");
            }

            return new ResultModel<DataRow>().Success(LotMsg);


        }

        /// <summary>
        /// 获取WIPMain属性
        /// </summary>
        /// <param name="LotName"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public string GetWIPMainAttribute(string LotName, string field)
        {
            CamstarHelper helper = ICamstarComm.GetCamstarHelper();
            helper.CreateService("WIPMain");
            helper.Perform("ResolveSelectionId");
            var inputData = helper.InputData();


            inputData.NamedObjectField("Container").SetRef(LotName);
            inputData.DataField("SelectionId").SetValue(LotName);
            var csiDataList = inputData.DataList("SelectionIdTypes");
            csiDataList.AppendItem("").SetValue("Lot");
            csiDataList.AppendItem("").SetValue("WAFER");
            csiDataList.AppendItem("").SetValue("CARRIER");
            csiDataList.AppendItem("").SetValue("BATCHID");
            csiDataList.AppendItem("").SetValue("RESOURCE");
            csiDataList.AppendItem("").SetValue("WAFERBATCHID");

            ICsiRequestData requestData = helper.RequestData();
            ICsiRequestField requestField = requestData.RequestField(field);
            ICsiDocument responseDoc = helper.Submit();


            ICsiResponseData responseData1 = responseDoc.GetService().ResponseData();
            ICsiDataField s = (ICsiDataField)responseData1.GetResponseFieldByName(field);

            responseDoc.CheckErrors();

            if (s == null)
            {
                return "";
            }
            string ss = s.GetValue();
            return ss;
        }


        public string GetWIPMainAttributeNew(string LotName, string field)
        {
            CamstarHelper helper = ICamstarComm.GetCamstarHelper();
            helper.CreateService("AssemblyMotherLotWIPMain");
            helper.Perform("ResolveSelectionId");
            var inputData = helper.InputData();


            inputData.NamedObjectField("Container").SetRef(LotName);
            inputData.DataField("SelectionId").SetValue(LotName);
            var csiDataList = inputData.DataList("SelectionIdTypes");
            csiDataList.AppendItem("").SetValue("Lot");
            csiDataList.AppendItem("").SetValue("WAFER");
            csiDataList.AppendItem("").SetValue("CARRIER");
            csiDataList.AppendItem("").SetValue("BATCHID");
            csiDataList.AppendItem("").SetValue("RESOURCE");
            csiDataList.AppendItem("").SetValue("WAFERBATCHID");

            ICsiRequestData requestData = helper.RequestData();
            ICsiRequestField requestField = requestData.RequestField(field);
            ICsiDocument responseDoc = helper.Submit();


            ICsiResponseData responseData1 = responseDoc.GetService().ResponseData();
            ICsiDataField s = (ICsiDataField)responseData1.GetResponseFieldByName(field);

            responseDoc.CheckErrors();

            if (s == null)
            {
                return "";
            }
            string ss = s.GetValue();
            return ss;
        }


        /// <summary>
        /// 获取需要补录过站信息的工步列表
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        public IResultModel GetStepMsg(GetStepInfo param)
        {

            FormattableString fssql = $@" 
                    select
                    st.workflowstepname  As StepName
                    ,st.sequence as Seq
                    ,st1.workflowstepname  As ToStepName
                    ,st1.sequence as ToSeq
                    ，sb.specname
                    ，s.specrevision SpecVer
                    ,nvl(s.automoveout,0) automoveout
                    ,nvl(s.cuautomovein,0) automovein
                    from workflow wf 
                    left join  workflowstep st on wf.workflowid = st.workflowid
                    left join specbase sb on sb.specbaseid = st.specbaseid
                    left join workflowstep st1 on st.workflowid =st1.workflowid and st1.sequence =st.sequence+1
                    left join spec s on s.specbaseid = sb.specbaseid
                    where wf.workflowid = {param.WORKFLOW_ID}  and st.sequence>={param.FromSeq} 
                    and st.sequence<={param.ToSeq}
                    order by st.sequence ";

            List<StepListRsp> steplist = db.StepListRsp.FromSql<StepListRsp>(fssql).ToList();
            return new ResultModel<List<StepListRsp>>().Success(steplist);


        }


        /// <summary>
        /// 根据结束工序获取HoldingTime信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetHoldingTimeMsgCopy(HoldingTimeReq param)
        {
            FormattableString fssql = $@" 
                select 
                (case when em.txnname='Move In Lot' or em.txnname='移入批次' then 0 
                when em.txnname='Track In Lot' or em.txnname='转入批次' then 2 
                  when em.txnname='Track Out Lot' or em.txnname='转出批次' then 4
                  when em.txnname='Move Lot' or em.txnname='移动批次' then 5 
                    else -1 end ) as endopt   
                ,sb.specname as endspec 
                ,ptb.processtimername
                ,pt.timertype
                ,pt.processtimerid
                ,pt.maxtime
                ,pt.maxwarningtime
                ,pt.mintime
                ,pt.minwarningtime
                ,max.timeraction as maxaction
                ,max.ishold as maxhold
                ,hr1.holdreasonname as maxreason
                ,min.timeraction as minaction 
                ,min.ishold as minhold
                ,hr2.holdreasonname as minreason
                ,(case when sm.txnname='Move In Lot' or sm.txnname='移入批次' then 0 
                when sm.txnname='Track In Lot' or sm.txnname='转入批次' then 2 
                  when sm.txnname='Track Out Lot' or sm.txnname='转出批次' then 4
                  when sm.txnname='Move Lot' or sm.txnname='移动批次' then 5 
                    else -1 end ) as startopt 
                ,sb1.specname as startspec
                ,sm.starttimertxnmapid as SpecStartTimerID
                ,pb.productname
                ,ptm1.ss_specid startspecid
                from EndTimerTxnMap em
                inner join ss_ProcessTimerMatrix ptm on em.parentid = ptm.ss_processtimermatrixid
                inner join spec s on ptm.ss_specid = s.specid 
                inner join specbase sb on sb.specbaseid = s.specbaseid
                inner join  processtimer pt on em.processtimerid = pt.processtimerid
                inner join processtimerbase ptb on pt.processtimerbaseid = ptb.processtimerbaseid
                inner join startTimerTxnMap sm on em.processtimerid = sm.processtimerid
                left join ss_ProcessTimerMatrix ptm1 on sm.parentid = ptm1.ss_processtimermatrixid
                left join spec s1 on ptm1.ss_specid = s1.specid 
                left join specbase sb1 on sb1.specbaseid = s1.specbaseid
                left join processtimerdtl max on max.processtimerdtlid = pt.processtimermaxtimedtlid
                left join holdreason hr1 on hr1.holdreasonid = max.holdreasonid
                left join processtimerdtl min on min.processtimerdtlid = pt.processtimermintimedtlid
                left join holdreason hr2 on hr2.holdreasonid = min.holdreasonid
                left join product p on p.productid = ptm.ss_productid 
                left join productbase pb on p.productbaseid = p.productbaseid
                where sb.specname  = {param.EndSpec}";


            List<HoldingTimeMsg> Msg = db.HoldingTimeMsgs.FromSql<HoldingTimeMsg>(fssql).ToList();

            return new ResultModel<List<HoldingTimeMsg>>().Success(Msg);


        }

        public IResultModel GetHoldingTimeMsg(HoldingTimeReq param)
        {
            FormattableString fssql = $@" 
                select 
                (case when em.txnname='Move In Lot' or em.txnname='移入批次' then 0 
                when em.txnname='Track In Lot' or em.txnname='转入批次' then 2 
                  when em.txnname='Track Out Lot' or em.txnname='转出批次' then 4
                  when em.txnname='Move Lot' or em.txnname='移动批次' then 5 
                    else -1 end ) as endopt   
                ,sb.specname as endspec 
                ,ptb.processtimername
                ,pt.timertype
                ,pt.processtimerid
                ,pt.maxtime
                ,pt.maxwarningtime
                ,pt.mintime
                ,pt.minwarningtime
                ,max.timeraction as maxaction
                ,max.ishold as maxhold
                ,hr1.holdreasonname as maxreason
                ,min.timeraction as minaction 
                ,min.ishold as minhold
                ,hr2.holdreasonname as minreason
                ,(case when sm.txnname='Move In Lot' or sm.txnname='移入批次' then 0 
                when sm.txnname='Track In Lot' or sm.txnname='转入批次' then 2 
                  when sm.txnname='Track Out Lot' or sm.txnname='转出批次' then 4
                  when sm.txnname='Move Lot' or sm.txnname='移动批次' then 5 
                    else -1 end ) as startopt 
                ,sb1.specname as startspec
                ,sm.starttimertxnmapid as SpecStartTimerID
                ,pb.productname
                ,ptm1.ss_specid startspecid
                from EndTimerTxnMap em
                inner join ss_ProcessTimerMatrix ptm on em.parentid = ptm.ss_processtimermatrixid
                inner join spec s on ptm.ss_specid = s.specid 
                inner join specbase sb on sb.specbaseid = s.specbaseid
                inner join  processtimer pt on em.processtimerid = pt.processtimerid
                inner join processtimerbase ptb on pt.processtimerbaseid = ptb.processtimerbaseid
                inner join startTimerTxnMap sm on em.processtimerid = sm.processtimerid
                inner join ss_ProcessTimerMatrix ptm1 on sm.parentid = ptm1.ss_processtimermatrixid
                inner join spec s1 on ptm1.ss_specid = s1.specid 
                inner join specbase sb1 on sb1.specbaseid = s1.specbaseid
                left join processtimerdtl max on max.processtimerdtlid = pt.processtimermaxtimedtlid
                left join holdreason hr1 on hr1.holdreasonid = max.holdreasonid
                left join processtimerdtl min on min.processtimerdtlid = pt.processtimermintimedtlid
                left join holdreason hr2 on hr2.holdreasonid = min.holdreasonid
                left join product p on p.productid = ptm.ss_productid 
                left join productbase pb on p.productbaseid = p.productbaseid ";

            List<HoldingTimeMsg> Msg = db.HoldingTimeMsgs.FromSql<HoldingTimeMsg>(fssql).ToList();

            return new ResultModel<List<HoldingTimeMsg>>().Success(Msg);


        }



        /// <summary>
        /// 获取Lot集合未关闭的定时器
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotsTimerMsg(HoldingTimeReq param)
        {
            //var tms = db.Timers.Where(x => x.isstoped == 0 && param.Lots.Contains(x.culotname)).OrderByDescending(x => x.starttimegmt).ToList();

            var tms = (from a in db.Timers
                       join c in db.Containers on a.PARENTID equals c.currentStatusId
                       where a.isstoped == 0 && param.Lots.Contains(c.ContainerName)
                       select new Timers
                       {
                           timerid = a.timerid,
                           maxendtimegmt = a.maxendtimegmt,
                           minendtimegmt = a.minendtimegmt,
                           culotname = c.ContainerName,
                           processtimerid = a.processtimerid,
                           isstoped = a.isstoped,
                           starttimegmt = a.starttimegmt,
                           scsstarttimerspecid = a.scsstarttimerspecid,
                           PARENTID = a.PARENTID
                       }).ToList();

            return new ResultModel<List<Timers>>().Success(tms);
        }

        /// <summary>
        /// 批量Lot冻结
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotsHold(HoldLots param)
        {
            if (param.holdLots.Count <= 0)
                return new ResultModel<string>().Failed("无Hold项！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotHold");

            var inputData = _helper.InputData();

            var details = inputData.SubentityList("Details");
            foreach (var item in param.holdLots)
            {
                var dtl = details.AppendItem();
                dtl.NamedObjectField("HoldReason").SetRef(item.HoldReason);
                dtl.ContainerField("Container").SetRef(item.lot, "LOT");
                dtl.DataField("ApplyToChildLots").SetValue("False");
                dtl.DataField("HoldUsername").SetValue(param.Operator);
            }

            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;


        }

        /// <summary>
        /// 获取Lot当前工序及DataCode格式信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetDataCodeFormat(GetLotMsgReq param)
        {

            FormattableString fssql = $@" 
                        select  
                        c.containername as Lot
                        ,p.cudatacode_format as DateCodeFormat
                        ,sb.specname as DateCodeSpec
                        ,sb1.specname as Spec
                        ,c.cudatecode
                        from container c
                        inner join currentstatus cs on cs.currentstatusid = c.currentstatusid
                        inner join spec s1 on s1.specid = cs.specid
                        inner join specbase sb1 on s1.specbaseid = sb1.specbaseid
                        inner join product p on c.productid = p.productid
                        left join spec s on s.specid = p.cudatecodespecid
                        left join specbase sb on s.specbaseid = sb.specbaseid
                        where c.containername  = {param.Lot}  ";

            DCFormatRsp steplist = db.DCFormatRsps.FromSql<DCFormatRsp>(fssql).FirstOrDefault();

            return new ResultModel<DCFormatRsp>().Success(steplist);


        }

        /// <summary>
        /// 获取OA预冻结信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOAFutureHoldMsg(OAFutureHoldMsgReq param)
        {

            FormattableString fssql = $@" 
                    select  
                    hr.holdreasonname as HoldReason
                    ,pb.productname AS PN
                    from cuoafutureholddetails cd 
                    left join product p on p.productid = cd.cupnid
                    left join productbase pb on p.productbaseid = pb.productbaseid
                    left join spec s on cd.cuspecid = s.specid
                    left join specbase sb on s.specbaseid = sb.specbaseid
                    left join holdreason hr on hr.holdreasonid = cd.cuholdreasonid
                    where nvl(cd.cuinactive,0)=0 and pb.productname = {param.PN} 
                    and sb.specname = {param.Spec} 
                    and cd.cufutureholdaction = {param.Action}  ";

            OAFutureHoldMsgRsp reason
                = db.OAFutureHoldMsgRsps.FromSql<OAFutureHoldMsgRsp>(fssql).FirstOrDefault();
            return new ResultModel<OAFutureHoldMsgRsp>().Success(reason);


        }

        /// <summary>
        /// 获取批次预冻结信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotsFutureHoldMsg(LotsFutureHoldReq param)
        {
            FormattableString fssql = $@" 
                        select 
                        c.containername as Lot
                        ,holdreasonname as HoldReason
                        ,sb.specname as Spec
                        ,lh.cufutureholdaction as Action
                        from a_Lotfuturehold lh
                        inner join container c on lh.containerid = c.containerid
                        left join holdreason hr on lh.holdreasonid = hr.holdreasonid
                        left join spec s on s.specid = lh.specid
                        left join specbase sb on s.specbaseid = sb.specbaseid
                        where lh.status ='ACTIVE' and sb.specname ={param.Spec}
                        and lh.cufutureholdaction = {param.Action}  ";

            List<LotsFutureHoldRsp> result
                = db.LotsFutureHoldRsps.FromSql<LotsFutureHoldRsp>(fssql).ToList();

            var reasonList = result.Where(x => param.Lots.Contains(x.Lot)).ToList();
            return new ResultModel<List<LotsFutureHoldRsp>>().Success(reasonList);


        }

        /// <summary>
        /// 重工：获取Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInfo(CreateNewInsertionReq param)
        {
            FormattableString fssql = $@" 
                        SELECT
                        C.ContainerName AS Lot,
                        C.Qty,
                        C.Qty2,
                        SB.SpecName || ':' || S.SpecRevision AS Spec,
                        TO_CHAR(
                            SYSDATE - NVL(C.MoveInTimestamp, SYSDATE),
                            '99990.999'
                        ) AS DaysHere,
                        CASE
                            WHEN WL2.WIPLotId IS NULL THEN TO_CHAR(SYSDATE - C.LastMoveOutTimestamp, '99990.999')
                            ELSE TO_CHAR(
                                WL2.CreationTimestamp - C.LastMoveOutTimestamp,
                                '99990.999'
                            )
                        END AS QueueTime,
                        PB.ProductName || ':' || P.ProductRevision AS Product,
                        CASE
                            WHEN C.Status = 1 THEN 'ACTIVE'
                            WHEN C.Status = 2 THEN 'TERMINATED'
                            WHEN C.Status = 5 THEN 'SHIPPED'
                            ELSE TO_CHAR(C.Status)
                        END AS Status,
                        CASE
                            WHEN NVL(C.CurrentHoldCount, 0) > 0 THEN 'YES ' || TO_CHAR(
                                SYSDATE - NVL(C.OnHoldDate, SYSDATE),
                                '99990.999'
                            ) || ' Days'
                            ELSE 'NO'
                        END AS IsOnHold,
                        CASE
                            WHEN NVL(CS.InRework, 0) > 0 THEN 'YES Loop ' || TO_CHAR(CS.ReworkLoopCount) || ' Total ' || TO_CHAR(CS.ReworkTotalCount)
                            ELSE 'NO'
                        END AS InRework,
                        C.InsertionNumber AS Insertion,
                        WL1.ProcessSpecName || ':' || WL1.ProcessSpecRevision AS InsertionProcessSpec,
                        WL1.SSName || ':' || WL1.SSRevision AS InsertionSS,
                        (
                            NVL(WL1.TotalRejectQty, 0) + NVL(WL1.TotalRejectBinsQty, 0) - NVL(WL1.TotalBonusBackRejectQty, 0)
                        ) AS Rejects,
                        (
                            C.Qty - NVL(WL1.TotalRejectQty, 0) - NVL(WL1.TotalRejectBinsQty, 0) - NVL(WL1.TotalBonusBackRejectQty, 0)
                        ) AS MoveOutQty,
                        WL1.WIPStatus AS WIPStatus,
                        WL1.WIPType AS WIPType,
                        WL1.WIPYieldResult AS WIPYieldResult,
                        C.BatchNo AS BatchNo,
                        C.EquipmentCount AS EqpCount,
                        C.EquipmentLoadingCount AS EqpLoadingCount,
                        CASE
                            WHEN NVL(C.FutureHoldCount, 0) > 0 THEN 'YES ' || TO_CHAR(C.FutureHoldCount)
                            ELSE 'NO'
                        END AS FutureHoldExists,
                        CASE
                            WHEN C.ScheduleDataId IS NOT NULL
                            OR NVL(C.ScheduleCount, 0) > 0 THEN 'YES'
                            ELSE 'NO'
                        END AS InSchedule,
                        CS.CurrentSpecPass AS SpecPass,
                        S.ObjectCategory AS SpecCategory,
                        S.ObjectType AS SpecType,
                        S.Description AS SpecDescription
                    FROM
                        Container C
                        INNER JOIN CurrentStatus CS ON C.CurrentStatusId = CS.CurrentStatusId
                        INNER JOIN Product P ON C.ProductId = P.ProductId
                        INNER JOIN ProductBase PB ON P.ProductBaseId = PB.ProductBaseId
                        INNER JOIN Spec S ON CS.SpecId = S.SpecId
                        INNER JOIN SpecBase SB ON S.SpecBaseId = SB.SpecBaseId
                        LEFT OUTER JOIN A_WIPLot WL1 ON C.CurrentWIPLotId = WL1.WIPLotId
                        LEFT OUTER JOIN A_WIPLot WL2 ON C.ContainerId = WL2.ContainerId
                        AND WL2.InsertionNumber = 1
                    WHERE
                        C.ContainerName = {param.Container}";

            List<LotInfoModel> result = db.LotInfoModel.FromSql<LotInfoModel>(fssql).ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到Lot信息");
            }
            else
            {
                return new ResultModel<LotInfoModel>().Success(result[0]);
            }
        }

        /// <summary>
        ///  重工：获取重工原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetInsertionReason()
        {
            //FormattableString fssql = $@"SELECT RA.INSERTIONREASONNAME AS InsertionReason FROM A_InsertionReason RA";

            //List<LotInfoModel> result = db.A_InsertionReason.FromSql<string>(fssql).ToList();

            List<string> result = (from r in db.A_InsertionReason select r.InsertionReasonName).ToList<string>();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到重工原因。");
            }
            else
            {
                return new ResultModel<List<string>>().Success(result);
            }
        }

        /// <summary>
        /// 重工：执行CreateNewInsertion事务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CreateNewInsertion(CreateNewInsertionReq param)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("CreateNewInsertion");
            var inputData = _helper.InputData();

            inputData.NamedObjectField("Container").SetRef(param.Container);
            inputData.NamedObjectField("InsertionReason").SetRef(param.InsertionReason);
            inputData.DataField("SelectionId").SetValue(param.SelectionId);
            if (param.Employee.Trim().Length > 0)
            {
                inputData.NamedObjectField("Employee").SetRef(param.Employee);
            }

            _helper.SetExecute();
            var _resDocument = _helper.Submit();

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 根据Lot获取当前工序设备列表信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetEquipmentListByLot(GetLotMsgReq param)
        {
            FormattableString fssql = $@" 
                        select rd.resourcename Equipment,rd.description EquipmentDesc
                        from container c
                        inner join currentstatus cs on c.currentstatusid = cs.currentstatusid
                        inner join spec s on s.specid = cs.specid
                        inner join resourcegroup rg on s.resourcegroupid = rg.resourcegroupid
                        inner join resourcegroupentries re on re.resourcegroupid = rg.resourcegroupid
                        inner join resourcedef rd on re.entriesid = rd.resourceid
                        where c.containername = {param.Lot}  ";

            List<EquipmentMsgRsp> result
                = db.EquipmentMsgRsps.FromSql<EquipmentMsgRsp>(fssql).ToList();

            return new ResultModel<List<EquipmentMsgRsp>>().Success(result);


        }

        /// <summary>
        /// 根据员工获取工序信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetSpecByEmployee(EmployeeSpecReq param)
        {
            FormattableString fssql = $@" 
                      select 
                      e.employeename Employee
                      ,e.description EmployeeDesc 
                      ,sb.specname Spec
                      ,s.description SpecDesc
                      ,e.fullname
                      from EmployeeahAuthorizedSpecs es
                      inner join employee e on es.employeeid = e.employeeid
                      inner join spec s on s.specid = es.cuauthorizedspecsid
                      inner join specbase sb on sb.specbaseid = s.specbaseid
                      where e.employeename ={param.Employee}  ";

            List<EmployeeSpecRsp> result
                = db.EmployeeSpecRsps.FromSql<EmployeeSpecRsp>(fssql).ToList();

            return new ResultModel<List<EmployeeSpecRsp>>().Success(result);
        }

        /// <summary>
        /// 根据连续线设备获取连续线工序
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetSpecByContinuousEquipment(LotMessage param)
        {
            FormattableString fssql = $@" 
                    select distinct sb.specname ,rd.resourcename Equipment
                    from resourcedef rd 
                    inner join resourcegroupentries re on re.entriesid = rd.resourceid
                    inner join resourcegroup rg on re.resourcegroupid = rg.resourcegroupid
                    inner join spec s on s.resourcegroupid = rg.resourcegroupid
                    inner join specbase sb on s.specbaseid = sb.specbaseid
                    where rd.resourcename =  {param.Equipment}  ";

            List<ContinuousSpecRsp> result
                = db.ContinuousSpecRsps.FromSql<ContinuousSpecRsp>(fssql).ToList();

            return new ResultModel<List<ContinuousSpecRsp>>().Success(result);




        }

        /// <summary>
        /// 获取当前工步的后续工步
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>

        public IResultModel GetFollowStep(LotMessage param)
        {
            FormattableString fssql = $@" 
                SELECT  wfs.workflowstepname Step
                ,sb.specname
                ,wfs.sequence
                ,nvl(s.automoveout,0) automoveout
                ,nvl(s.cuautomovein,0) automovein
                FROM WorkflowStep wfs 
                inner join specbase sb on sb.specbaseid =  wfs.specbaseid  
                inner join  spec s on  s.specbaseid = sb.specbaseid            
                WHERE wfs.WorkflowId = {param.workFlowId} and wfs.sequence> {param.Seq}
                order by  wfs.SEQUENCE";

            List<FollowStepRsp> result
                = db.FollowStepRsps.FromSql<FollowStepRsp>(fssql).ToList();

            return new ResultModel<List<FollowStepRsp>>().Success(result);




        }

        /// <summary>
        /// 获取Lot当前工序设备的物料信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotMeMaterialLotMsg(MaterialLotMsgReq param)
        {
            FormattableString fssql = $@" 
                    select 
                    pb.productname
                    ,c.containername
                    ,c.qty
                    ,mpb.productname Materailpart
                    ,pbl.consumefactor
                    ,rd.resourcename equipment
                    ,cm.containername MaterialLot
                    from container c
                    left join currentstatus cs on cs.currentstatusid = c.currentstatusid
                    left join mfgorder mo on c.cuworkorderid=mo.mfgorderid 
                    left join spec s on cs.specid = s.specid
                    left join specbase sb on sb.specbaseid = s.specbaseid
                    left join product p on p.productid = c.productid
                    left join productbase pb on p.productbaseid = pb.productbaseid
                    left join A_ProductBOMList pl on pl.productid = p.productid
                    left join A_ProductBOM ap on ap.productbomid = pl.bomid
                    left join A_ProductBOMMaterialList pbl on ap.productbomid = pbl.productbomid and s.specid = pbl.specid
                    left join product mp on mp.productid = pbl.materialpartid
                    left join productbase mpb on mp.productbaseid = mpb.productbaseid
                    left join a_Equipmentmaterials qm on qm.materialpartid = pbl.materialpartid
                    left join resourcedef rd on qm.resourceid = rd.resourceid
                    left join container cm on cm.containerid = qm.materiallotid
                    where mpb.productname is not null and  c.containername = {param.Lot} 
                    and rd.resourcename ={param.Equipment} ";

            List<MaterialLotMsgRsp> result
                = db.MaterialLotMsgRsps.FromSql<MaterialLotMsgRsp>(fssql).ToList();

            return new ResultModel<List<MaterialLotMsgRsp>>().Success(result);




        }

        /// <summary>
        /// 获取LotWIP在线信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotWIPTrackMsg(GetLotMsgReq param)
        {
            FormattableString fssql = $@" 
                    SELECT
                        StepSequence 
                        , STEP 
                        , IN_QTY 
                        , OUT_QTY 
                        , REJ_QTY 
                        , IN_TIME
                        , OUT_TIME
                        , OUT_USER 
                    FROM
                    (
                        SELECT
                            ST.StepSequence StepSequence
                            , ST.ProcessTypeSequence ProcessTypeSequence
                            , CASE WHEN ST.ProcessTypeName IS NULL THEN ST.WorkflowStepName
                                   ELSE ST.WorkflowStepName || ' (' + ST.ProcessTypeName || ')'
                              END STEP
                            , CASE WHEN HM.TxnDate IS NOT NULL AND SD.ScheduleQtyType = 'Qty' THEN HM.MoveInQty
                                   WHEN HM.TxnDate IS NOT NULL THEN HM.MoveInQty2
                                   WHEN ST.WorkflowStepId = CS.WorkflowStepId AND SD.ScheduleQtyType = 'Qty' THEN C.MoveInQty
                                   WHEN ST.WorkflowStepId = CS.WorkflowStepId THEN C.MoveInQty2
                                   ELSE NULL
                              END IN_QTY
                            , CASE WHEN HM.TxnDate IS NOT NULL AND SD.ScheduleQtyType = 'Qty' THEN HM.Qty
                                   WHEN HM.TxnDate IS NOT NULL THEN HM.Qty2
                                   ELSE NULL
                              END OUT_QTY
                            , CASE WHEN HM.TxnDate IS NOT NULL AND SD.ScheduleQtyType = 'Qty' THEN HM.MoveInQty - HM.Qty
                                   WHEN HM.TxnDate IS NOT NULL THEN HM.MoveInQty2 - HM.Qty2
                                   ELSE NULL
                              END REJ_QTY
                            , CASE WHEN HM.TxnDate IS NOT NULL AND SD.ScheduleQtyType = 'Qty' AND HM.MoveInQty > 0 THEN ROUND(100 * (1 - (HM.MoveInQty - HM.Qty) / HM.MoveInQty), 3)
                                   WHEN HM.TxnDate IS NOT NULL AND SD.ScheduleQtyType <> 'Qty' AND HM.MoveInQty2 > 0 THEN ROUND(100 * (1 - (HM.MoveInQty2 - HM.Qty2) / HM.MoveInQty2), 3)
                                   ELSE NULL
                              END YIELD
                            , CASE WHEN HM.MoveInTimeStamp IS NOT NULL THEN HM.MoveInTimeStamp
                                   WHEN ST.WorkflowStepId = CS.WorkflowStepId THEN C.MoveInTimeStamp
                                   ELSE NULL
                              END IN_TIME
                            , HM.TxnDate OUT_TIME
                            , HM.EmployeeName OUT_USER
                        FROM
                            Container C
                            INNER JOIN CurrentStatus CS ON C.CurrentStatusId = CS.CurrentStatusId
                            INNER JOIN A_ScheduleData SD ON C.ScheduleDataId = SD.ScheduleDataId
                            INNER JOIN A_ScheduleTraveler ST ON SD.ScheduleDataId = ST.ScheduleDataId
                            LEFT OUTER JOIN HistoryMainline HM ON C.ContainerId = HM.HistoryId AND HM.CDOName = 'MoveLot' AND HM.TxnDate >= SD.PreparationDate AND ST.WorkflowStepId = HM.WorkflowStepId
                        WHERE
                            C.ContainerName = {param.Lot}
                        UNION
                        SELECT
                            ST.StepSequence StepSequence
                            , ST.ProcessTypeSequence ProcessTypeSequence
                            , CASE WHEN ST.ProcessTypeName IS NULL THEN ST.WorkflowStepName
                                   ELSE ST.WorkflowStepName || ' (' + ST.ProcessTypeName || ')'
                              END STEP
                            , CASE WHEN SD.ScheduleQtyType = 'Qty' THEN C.MoveInQty
                                   ELSE C.MoveInQty2
                              END IN_QTY
                            , NULL OUT_QTY
                            , NULL REJ_QTY
                            , NULL YIELD
                            , C.MoveInTimeStamp IN_TIME
                            , NULL OUT_TIME
                            , NULL OUT_USER
                        FROM
                            Container C
                            INNER JOIN CurrentStatus CS ON C.CurrentStatusId = CS.CurrentStatusId
                            INNER JOIN A_ScheduleData SD ON C.ScheduleDataId = SD.ScheduleDataId
                            INNER JOIN A_ScheduleTraveler ST ON SD.ScheduleDataId = ST.ScheduleDataId AND ST.WorkflowStepId = CS.WorkflowStepId
                        WHERE
                            C.ContainerName = {param.Lot}
                    ) OnlineTraveler
                    ORDER BY
                          StepSequence ASC
                          , ProcessTypeSequence ASC
                          , IN_TIME ASC ";

            List<LotWIPTrackMsgRsp> result
                = db.LotWIPTrackMsgRsps.FromSql<LotWIPTrackMsgRsp>(fssql).ToList();
            if(result.Count==0)
                return new ResultModel<List<LotWIPTrackMsgRsp>>().Success(new List<LotWIPTrackMsgRsp>(),"无在制信息");

            return new ResultModel<List<LotWIPTrackMsgRsp>>().Success(result);
            //待修改



        }

        /// <summary>
        /// DateCode验证
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CheckDataCode(EntryDataCodeReq param)
        {
            ResultModel<string> resultModel = new ResultModel<string>();
            string peryear = DateTime.Now.AddDays(-14).Year.ToString().PadLeft(2, '0');
            string afteryear = DateTime.Now.AddDays(+14).Year.ToString().PadLeft(2, '0');
            string perday = DateTime.Now.AddDays(-14).DayOfYear.ToString().PadLeft(3, '0');
            string afterday = DateTime.Now.AddDays(+14).DayOfYear.ToString().PadLeft(3, '0');
            GregorianCalendar gc = new GregorianCalendar();
            //获取当前时间前后两周
            string perweek = gc.GetWeekOfYear(DateTime.Now.AddDays(-14), CalendarWeekRule.FirstDay, DayOfWeek.Sunday).ToString().PadLeft(2, '0');
            string afweek = gc.GetWeekOfYear(DateTime.Now.AddDays(+14), CalendarWeekRule.FirstDay, DayOfWeek.Sunday).ToString().PadLeft(2, '0');


            string data_fromt = param.DCFromt == null ? param.containers[0].DataCode_Format : param.DCFromt;
            if (string.IsNullOrEmpty(data_fromt)) return new ResultModel<string>().Failed("datacode_fromt 为空！");
            FormattableString sql = $@"select em.Employeeid,em.EmployeeName,em.FullName,emp.Employeegroupname,'' FactoryName from Employee em 
                                        left join a_employeeGroupentries an on an.Entriesid = em.employeeid
                                        left  join A_EMPLOYEEGROUP emp on emp.employeegroupid = an.employeegroupid
                                        where em.employeename = {param.Employee}";
            List<Employee> emp = db.Employees.FromSql<Employee>(sql).ToList();
            if (emp.Count <= 0) return new ResultModel<string>().Failed($@"{param.Employee.ToString()}员工数据未查询到数据！");
            var count = emp.Where(x => x.EmployeegroupName.Equals("DC")).ToList().Count();
            //员工组为DC
            if (count <= 0)
            {
                string ppattern = "^\\d{" + $@"{data_fromt.Length}" + "}$";
                if (!Regex.IsMatch(data_fromt, "^(?:[YWD]{3}|[YWD]{4})$")) return resultModel.Failed("datacode 格式不正确！");
                if (!Regex.IsMatch(param.DCValue, ppattern)) return resultModel.Failed("录入值与格式不一致");
                int dates = int.Parse(param.DCValue);
                switch (data_fromt)
                {
                    case "WWYY":
                        int perdate = int.Parse(string.Concat(perweek, peryear.Substring(2, 2)));
                        int afdate = int.Parse(string.Concat(afweek, afteryear.Substring(2, 2)));
                        if (perdate <= dates & dates <= afdate)
                        {

                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    case "YYWW":
                        int per = int.Parse(string.Concat(peryear.Substring(2, 2), perweek));
                        int after = int.Parse(string.Concat(afteryear.Substring(2, 2), afweek));
                        if (per <= dates & dates <= after)
                        {

                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    case "YWW":
                        int pers = int.Parse(string.Concat(peryear.Substring(3, 1), perweek));
                        int afterwek = int.Parse(string.Concat(afteryear.Substring(3, 1), afweek));
                        if (pers <= dates & dates <= afterwek)
                        {
                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    case "YDDD":
                        int perdays = int.Parse(string.Concat(peryear.Substring(3, 1), perday));
                        int afterdays = int.Parse(string.Concat(afteryear.Substring(3, 1), afterday));
                        if (perdays <= dates & dates <= afterdays)
                        {
                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    default:
                        return resultModel.Failed("datacode 格式不正确！");
                        break;
                }
            }

            return resultModel.Success();
        }

        /// <summary>
        /// 连续线Lot过站记录补齐
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>

        public IResultModel ContinuousLotCompletion(ContinuousLotCompletionReq param)
        {
            //连续线首工序调用Lot下机服务
            TrackOutReq LotTrackOut = new TrackOutReq();
            LotTrackOut.Lots = param.Lots;
            LotTrackOut.Operator = param.Operator;
            LotTrackOut.Factory = param.Factory;
            LotTrackOut.EquipmentName = param.EquipmentName;
            LotTrackOut.DateCode = param.DateCode;
            LotTrackOut.DateCodeFormat = param.DateCodeFormat;
            LotTrackOut.SpecName = param.SpecName;

            var trackout = TrackOut(LotTrackOut);
            if (!trackout.success)
                return new ResultModel<string>().Failed($"调用Lot下机服务失败：{trackout.msg}");

            var lot = param.Lots.FirstOrDefault();
            GetLotMsgReq lotMsgReq = new GetLotMsgReq();
            lotMsgReq.Lot = lot;

            //执行完下机查询Lot状态看是否为待出站
            var lotMessage1 = GetLotMsgInternal(lotMsgReq);
            if (lotMessage1 != null)
            {
                //当Lot处于待出站状态，为Lot执行出站
                if (4.Equals(lotMessage1.Cutrackflag))
                {
                    MoveOutReq mout = new MoveOutReq();
                    mout.Lots = param.Lots;
                    mout.Operator = param.Operator;
                    mout.Factory = param.Factory;
                    mout.EquipmentName = param.EquipmentName;
                    mout.SpecName = param.SpecName;
                    var moveout = MoveOut(mout);
                    if (!moveout.success)
                        return new ResultModel<string>().Failed($"调用Lot出站服务失败：{moveout.msg}");

                }
            }
            else
            {

                return new ResultModel<string>().Failed($"执行完下机查询Lot状态看是否为待出站时，获取Lot{lot}信息失败！");
            }

            //连续线后续工序执行过站
            var steplist = param.steplist;
            foreach (var item in steplist)
            {
                //判断是否为连续线最后一道工序
                if (item.StepName.Equals(param.nowstep.Step))
                {

                    #region 如果当前工序未勾选自动进站，则执行进站
                    if (0.Equals(item.automovein))
                    {
                        MoveInReq mi = new MoveInReq();
                        mi.Lots = new List<string>() { lot };
                        mi.Operator = param.Operator;
                        mi.Factory = param.Factory;
                        mi.EquipmentName = param.EquipmentName;
                        mi.SpecName = item.SpecName;
                        var moveinmsg = MoveIn(mi);
                        if (!moveinmsg.success)
                            return new ResultModel<string>().Failed($"调用Lot进站服务失败：{moveinmsg.msg}");

                    }
                    #endregion

                    #region 调用Lot上机服务
                    TrackInReq LotTrackIn = new TrackInReq();
                    LotTrackIn.Lots = new List<string>() { lot };
                    LotTrackIn.Operator = param.Operator;
                    LotTrackIn.Factory = param.Factory;
                    LotTrackIn.EquipmentName = param.EquipmentName;
                    LotTrackIn.SpecName = item.SpecName;
                    var trackin = TrackIn(LotTrackIn);
                    if (!trackin.success)
                        return new ResultModel<string>().Failed($"调用Lot上机服务失败：{trackin.msg}");
                    #endregion

                    #region 调用Lot下机服务
                    LotTrackOut.SpecName = item.SpecName;
                    var trackoutmsg = TrackOut(LotTrackOut);
                    if (!trackoutmsg.success)
                        return new ResultModel<string>().Failed($"调用Lot下机服务失败：{trackoutmsg.msg}");

                    #endregion

                }
                else
                {
                    #region 如果当前工序未勾选自动进站，则执行进站
                    if (0.Equals(item.automovein))
                    {
                        MoveInReq mi = new MoveInReq();
                        mi.Lots = new List<string>() { lot };
                        mi.Operator = param.Operator;
                        mi.Factory = param.Factory;
                        mi.EquipmentName = param.EquipmentName;
                        mi.SpecName = item.SpecName;
                        var moveinmsg = MoveIn(mi);
                        if (!moveinmsg.success)
                            return new ResultModel<string>().Failed($"调用Lot进站服务失败：{moveinmsg.msg}");
                    }
                    #endregion

                    #region 调用Lot上机服务
                    TrackInReq LotTrackIn = new TrackInReq();
                    LotTrackIn.Lots = new List<string>() { lot };
                    LotTrackIn.Operator = param.Operator;
                    LotTrackIn.Factory = param.Factory;
                    LotTrackIn.EquipmentName = param.EquipmentName;
                    LotTrackIn.SpecName = item.SpecName;

                    var trackin = TrackIn(LotTrackIn);
                    if (!trackin.success)
                        return new ResultModel<string>().Failed($"调用Lot上机服务失败：{trackin.msg}");
                    #endregion

                    #region 调用Lot下机服务
                    //调用Lot下机服务
                    LotTrackOut.SpecName = item.SpecName;
                    var trackoutmsg = TrackOut(LotTrackOut);
                    if (!trackoutmsg.success)
                        return new ResultModel<string>().Failed($"调用Lot下机服务失败：{trackoutmsg.msg}");
                    #endregion

                    #region 如果当前工序未勾选自动出站，则执行出站
                    if (0.Equals(item.automoveout))
                    {
                        MoveOutReq mout = new MoveOutReq();
                        mout.Lots = new List<string>() { lot };
                        mout.Operator = param.Operator;
                        mout.Factory = param.Factory;
                        mout.EquipmentName = param.EquipmentName;
                        mout.SpecName = item.SpecName;

                        var moveout = MoveOut(mout);
                        if (!moveout.success)
                            return new ResultModel<string>().Failed($"调用Lot出站服务失败：{moveout.msg}");

                    }

                    #endregion

                }


            }

            return new ResultModel<string>().Success("连续线Lot过站记录补齐成功！");

        }

        /// <summary>
        /// 获取Lot信息-内部用
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private LotMessage GetLotMsgInternal(GetLotMsgReq param)
        {
            FormattableString fssql = $@" 
                   select  
                     c.containername
                     ,c.qty
                     ,c.qty2
                      ,pb.productname
                     ,c.currentholdcount 
                     ,c.status
                     ,c.Cutrackflag
                     ,sb.specname
                     ,s.specrevision SpecVer
                     ,s.description SpecDesc
                    ,s.cu_isdrillingroom IsDrillRoom 
                    ,(case when s.resourcegroupid is null then 0 else 1 end) as IsHaveEquipment
                     ,sb1.specname ToSpecName
                     ,s1.specrevision ToSpecVer
                     ,wt.workflowstepname step
                     ,wt1.workflowstepname tostep
                     ,wt2.workflowstepname as ToNextStep
                     ,wt.sequence Seq
                     ,wt1.sequence toSeq
                     ,wt2.sequence ToNextSeq 
                     ,wt.workflowid
                      ,nvl(P.CUSTRIPPERPNL,0) S_QTY
                      ,nvl(P.CUPCSPERPNL,0) U_QTY
                      ,p.cudatacode_format DataCode_Format
                        ,（case when sb.specname = sb2.specname then 1
                        else 0
                          end) IsDtSpec
                      ,c.cudatecode DataCode_Value  
                      ,f.factoryname Factory
                      ,f.notes FactoryNotes
                      ,hd.holdreasonname
                      ,wb.workflowname
                      ,wf.workflowrevision
                      ,ae.equipmentname Equipment
                      ,nvl(rd.cu_iscontinuous,0) IsContinuous
                      ,mo.mfgordername 
                      ,WFS.WORKFLOWSTEPNAME as UnTerminateWorkflowStep
                      ,nvl(s.autocreatefirstinsertion,0) isFirstInsertion   
                      ,nvl(op.usequeue,0) cuusequeue
                      ,cc.custampcode
                      from container c
                      left  join currentstatus cs on cs.currentstatusid = c.currentstatusid
                      left join mfgorder mo on c.cuworkorderid=mo.mfgorderid 
                      left join culotcard cc on mo.mfgordername = cc.culotcardname
                      left join spec s on cs.specid = s.specid
                      left join operation op on s.operationid = op.operationid
                      left join specbase sb on sb.specbaseid = s.specbaseid
                      left join product p on p.productid = c.productid
                      left join productbase pb on p.productbaseid = pb.productbaseid
                      left join workflowstep wt on cs.workflowstepid = wt.workflowstepid
                      left  join path p1 on p1.fromstepid = wt.workflowstepid
                      left join workflowstep wt1 on wt1.workflowstepid = p1.tostepid
                      left join specbase sb1 on wt1.specbaseid = sb1.specbaseid
                      left join spec s1 on sb1.specbaseid = s1.specbaseid 
                      left join path p2 on p2.fromstepid = wt1.workflowstepid
                      left join workflowstep wt2 on wt2.workflowstepid = p2.tostepid
                      left join spec s2 on s2.specid = p.cudatecodespecid 
                      left join specbase sb2 on sb2.specbaseid = s2.specbaseid
                      left join factory f on cs.factoryid = f.factoryid
                      left join HOLDREASON hd on hd.holdreasonid = c.holdreasonid
                      left join workflow wf on wf.workflowid = wt.workflowid
                      left join workflowbase wb on wb.workflowbaseid = wf.workflowbaseid
                      left join a_Wipequipment ae on c.containerid = ae.containerid and ae.trackstatus = 'INPROCESS'
                      left join resourcedef rd on ae.equipmentid = rd.resourceid
                      left join WORKFLOWSTEP WFS ON WFS.WORKFLOWID = WF.WORKFLOWID and  WFS.CUSEQUENCE='901000'
                      where c.containername ={param.Lot} ";
            LotMessage LotMsg = db.LotMessage.FromSql<LotMessage>(fssql).AsNoTracking()?.FirstOrDefault();
            return LotMsg;
        }

    }
}
