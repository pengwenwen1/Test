﻿using Camstar.XMLClient.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.WIPData;
using Multek.Applications.Model.WIPMain;
using Multek.Applications.Services.CamstarApi;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Camstar.CamstarServer;
using Multek.Library_Core.Camstar.Constants;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using Nacos.V2.Utils;
using SqlSugar;
using System.Collections.Generic;
using System.Data;
using System.DirectoryServices.Protocols;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Http.Json;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using YamlDotNet.Core;
using static Multek.Applications.Model.Entities.Camstar.Dto.LotFirstInspect;

namespace Multek.Applications.Services.Impl.CamstarApi
{
    public class SWIPData : EFHelper<MultekCamstarDbContext>, IWIPData
    {
        public readonly ICamstarComm ICamstarComm;
        public readonly IWIPMain wIP ;


        public SWIPData(MultekCamstarDbContext tdb,ICamstarComm camstarComm, IWIPMain wIP) : base(tdb)
        {
            ICamstarComm = camstarComm;
            this.wIP = wIP;
        }

        /// <summary>
        /// 执行DataCode录入
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel EntryDataCode(EntryDataCodeReq param)
        {
            ResultModel<string> isEnrtyCode = (ResultModel<string>)CheckDataCode(param);
            if (isEnrtyCode.success)
            {
                CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                _helper.CreateService("cuDateCodeTxn");
                var _input = _helper.InputData();
                var conlist = _input.ContainerList("Containers");
                foreach (var con in param.containers) { conlist.AppendItem(con.ContainerName, null); };
                _input.DataField("cuDateCode").SetValue(param.DCValue);
                _helper.SetExecute();
                var _resDocument = _helper.Submit();
                var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

                _resDocument.CheckErrors();
                ResultModel<string> _error = new ResultModel<string>();
                _resDocument.CheckErrors(_error);
                return _error;
            }
            else
            {
                return isEnrtyCode;
            }
        }

        /// <summary>
        /// 执行跳站
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel MoveStd(MoevStdReq param)
        {
            ResultModel<string> _error = new ResultModel<string>();
            if (param==null||param.MoveStdReason ==null)
            {
                return _error.Failed("跳站批次或跳站原因为空！");
            }
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("AssemblyMotherLotWIPMoveNonStd");
            var _input = _helper.InputData();
            _input.ContainerField("Container").SetRef(param.Container,null);
            _input.NamedObjectField("cuMoveNonStdReason").SetRef(param.MoveStdReason);
            _input.DataField("CancelWIPTracking").SetValue(param.CancelWIPTracking);
            _input.DataField("SplitBins").SetValue(param.SplitBins);
            _input.DataField("TriggerMoveIn").SetValue(param.TriggerMoveIn);
            _input.DataField("YieldOffRejects").SetValue(param.YieldOffRejects);
            if (param.ToWorkflow != null) _input.RevisionedObjectField("ToWorkflow").SetRef(param.ToWorkflow.workflowname, param.ToWorkflow.workflowrevision, false);
            _input.NamedObjectField("ToWorkflowStep").SetRef(param.ToWorkflowStep);
            if(param.Path!= null) _input.NamedObjectField("path").SetRef(param.Path);
            if (param.ToStepType != null) _input.DataField("ToStepType").SetValue(param.ToStepType);
            if(param.Employee != null) _input.NamedObjectField("Employee").SetRef(param.Employee);
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);


            _resDocument.CheckErrors();
            
            _resDocument.CheckErrors(_error);

            return _error;
        }
        /// <summary>
        /// 获取跳站原因呢
        /// </summary>
        /// <returns></returns>

        public IResultModel GetMStdReason()
        {
            FormattableString sqlstr = $@"select re.cumovenonstdreasonid,re.cumovenonstdreasonname,re.description from cuMoveNonStdReason re";
            List<MoveStdReason> reList = db.moveStdReason.FromSql<MoveStdReason>(sqlstr)?.ToList();
            if (reList != null && reList.Count > 0)
            {
                return new ResultModel<List<MoveStdReason>>().Success(reList);
            }
            else
            {
                return new ResultModel<string>().Failed("没有查询到跳站原因：cuMoveNonStdReason");
            }
        }

        /// <summary>
        /// 获取Step
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetToStep(cuGetSetpTypeRsp param)
        {

            ResultModel<string> result = new ResultModel<string>();

            if (string.IsNullOrEmpty(param.container) || string.IsNullOrEmpty(param.pathOrstep) || string.IsNullOrEmpty(param.SetpTye))
            {
                return new ResultModel<string>().Failed("传入参数不能为空！");
            }
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("AssemblyMotherLotWIPMoveNonStd");
            //_helper.Perform("_GetToStepSelectionValuesEx");
            var _input = _helper.InputData();
            _input.ContainerField("Container").SetRef(param.container, null);
            _input.DataField("ToStepType").SetValue(param.SetpTye);
            var re = _helper.RequestData();
            var selvalue = re.RequestField(param.pathOrstep).RequestSelectionValuesEx();
            selvalue.SetStartRow(1);
            selvalue.SetResultsetSize(50);

            selvalue.SetParameter("NameFilter", "%");
            selvalue.SetParameter("SpecificTypeOnly", "0");
            ICsiDocument responseDoc = _helper.Submit();
            var respons = responseDoc.GetService();

            //ICsiResponseData responseData1 = respons.ResponseData();
            if (respons.ResponseData() == null || respons.ResponseData().GetResponseFieldByName(param.pathOrstep) == null || respons.ResponseData().GetResponseFieldByName(param.pathOrstep).GetSelectionValuesEx() == null || respons.ResponseData().GetResponseFieldByName(param.pathOrstep).GetSelectionValuesEx().GetRecordset() == null)
            {
                return new ResultModel<string>().Failed("查询返回结果为空!");
            }
            ICsiXmlElement[] st = respons.ResponseData().GetResponseFieldByName(param.pathOrstep).GetSelectionValuesEx().GetRecordset().GetChildrenByName("__row");
            List<string> list = new List<string>();
            foreach (var item in st)
            {
                string str = ((ICsiRecordsetField)item).GetChildValue();
                list.Add(str);
            }
            return new ResultModel<List<string>>().Success(list);
        }

        /// <summary>
        /// 检验datacode
        /// </summary>
        /// <param name="fromt"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public IResultModel CheckDataCode(EntryDataCodeReq param)
        //public IResultModel CheckDataCode(string fromt, string Value)
        {
            ResultModel<string> resultModel = new ResultModel<string>();
            string peryear = DateTime.Now.AddDays(-14).Year.ToString().PadLeft(2, '0');
            string afteryear = DateTime.Now.AddDays(+14).Year.ToString().PadLeft(2, '0');
            string perday = DateTime.Now.AddDays(-14).DayOfYear.ToString().PadLeft(3, '0');
            string afterday = DateTime.Now.AddDays(+14).DayOfYear.ToString().PadLeft(3, '0');
            GregorianCalendar gc = new GregorianCalendar();
            //获取当前时间前后两周
            string perweek = gc.GetWeekOfYear(DateTime.Now.AddDays(-14), CalendarWeekRule.FirstDay, DayOfWeek.Sunday).ToString().PadLeft(2, '0');
            string afweek = gc.GetWeekOfYear(DateTime.Now.AddDays(+14), CalendarWeekRule.FirstDay, DayOfWeek.Sunday).ToString().PadLeft(2, '0');


            string data_fromt = param.DCFromt == null ? param.containers[0].DataCode_Format : param.DCFromt;
            if (string.IsNullOrEmpty(data_fromt)) return new ResultModel<string>().Failed("datacode_fromt 为空！");
            FormattableString sql = $@"select em.Employeeid,em.EmployeeName,em.FullName,emp.Employeegroupname,'' FactoryName from Employee em 
                                        left join a_employeeGroupentries an on an.Entriesid = em.employeeid
                                        left  join A_EMPLOYEEGROUP emp on emp.employeegroupid = an.employeegroupid
                                        where em.employeename = {param.Employee}";
            List<Employee> emp = db.Employees.FromSql<Employee>(sql).ToList();
            if (emp.Count<= 0) return new ResultModel<string>().Failed($@"{param.Employee.ToString()}员工数据未查询到数据！");
            var count =emp.Where(x=>x.EmployeegroupName.Equals("DC")).ToList().Count();
            //员工组为DC
            if (count<=0)
            {
                string ppattern = "^\\d{" + $@"{data_fromt.Length}" + "}$";
                if (!Regex.IsMatch(data_fromt, "^(?:[YWD]{3}|[YWD]{4})$")) return resultModel.Failed("datacode 格式不正确！");
                if (!Regex.IsMatch(param.DCValue, ppattern)) return resultModel.Failed("录入值与格式不一致");
                int dates = int.Parse(param.DCValue);
                switch (data_fromt)
                {
                    case "WWYY":
                        int perdate = int.Parse(string.Concat(perweek, peryear.Substring(2, 2)));
                        int afdate = int.Parse(string.Concat(afweek, afteryear.Substring(2, 2)));
                        if (perdate <= dates & dates <= afdate)
                        {

                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    case "YYWW":
                        int per = int.Parse(string.Concat(peryear.Substring(2, 2), perweek));
                        int after = int.Parse(string.Concat(afteryear.Substring(2, 2), afweek));
                        if (per <= dates & dates <= after)
                        {

                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    case "YWW":
                        int pers = int.Parse(string.Concat(peryear.Substring(3, 1), perweek));
                        int afterwek = int.Parse(string.Concat(afteryear.Substring(3, 1), afweek));
                        if (pers <= dates & dates <= afterwek)
                        {
                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    case "YDDD":
                        int perdays = int.Parse(string.Concat(peryear.Substring(3, 1), perday));
                        int afterdays = int.Parse(string.Concat(afteryear.Substring(3, 1), afterday));
                        if (perdays <= dates & dates <= afterdays)
                        {
                            return resultModel.Success();
                        }
                        else
                        {
                            return resultModel.Failed("录入值验证不通过，不在当前时间前两周-后两周时间范围之内");
                        }
                        break;
                    default:
                        return resultModel.Failed("datacode 格式不正确！");
                        break;
                }
            }

            return resultModel.Success();
        }

        /// <summary>
        /// 执行ECN变更
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel ECNTxn(CuECNChangeReq param)
        {
            if (string.IsNullOrEmpty(param.cuECNNo)||param.CuECNChangeDetails.Count<=0)
            {
                return new ResultModel<string>().Failed("ECN序号或者ECNlot为空！");
            }
            List<ECNFunctionChangeDetails> eCNFunctionChangeDetails = param.CuECNChangeDetails;
            ECNFunctionChangeDetails count = eCNFunctionChangeDetails.Where(x => x.cuRrentHoldCount.Equals(1)).FirstOrDefault();
            if (count != null) { return new ResultModel<string>().Failed($@"{count.cuLot.ToString()}该批次当前因{count.HoldReasonName}被Hold,请解Hold后再执行ECN"); }

            ResultModel<string> resultModel = new ResultModel<string>();
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuECNFunctionChangeTxn");
            var _input = _helper.InputData();
            _input.NamedObjectField("cuECNCodeToJDENR").SetRef("cuECNCodeToJDENR");
             var _deails =_input.SubentityList("cuECNFunctionChangeDetails");
            foreach (var item in param.CuECNChangeDetails)
            {
                var _list = _deails.AppendItem();
                _list.RevisionedObjectField("cuAssemblyWorkflow").SetRef(item.CuAssemblyWorkflow.Split(":")[0], item.CuAssemblyWorkflow.Split(":")[1],false);
                _list.DataField("cuFactory").SetValue(item.cuFactory);
                _list.RevisionedObjectField("cuInfluenceSpec").SetRef(item.CuInfluenceSpec.Split(":")[0], item.CuInfluenceSpec.Split(":")[1],false);
                _list.DataField("cuIsExecHold").SetValue(item.cuIsExecHold);
                _list.DataField("cuJDE_PN").SetValue(item.CuJDE_PN);
                _list.DataField("cuJDE_Spec").SetValue(item.CuJDE_Spec);
                _list.DataField("cuLayerType").SetValue(item.CuLayerType);
                _list.ContainerField("cuLot").SetRef(item.cuLot, null);
                _list.DataField("cuMI_PN").SetValue(item.CuMI_PN);
                _list.DataField("cuNewMI_PN").SetValue(item.CuNewMI_PN);
                _list.RevisionedObjectField("cuNewPN").SetRef(item.cunewpn.Split(":")[0], item.cunewpn.Split(":")[1], false);
                _list.RevisionedObjectField("cuNewWorkflow").SetRef(item.CuNewWorkflow.Split(":")[0], item.CuNewWorkflow.Split(":")[1], false);
                _list.RevisionedObjectField("cuPN").SetRef(item.cupn.Split(":")[0], item.cupn.Split(":")[1], false);
                _list.NamedObjectField("cuOrderType").SetRef(item.cuOrderType);
                _list.DataField("cuPNLQty").SetValue(item.cuPNLQty);
                _list.DataField("cuproductiontypename").SetValue(item.CuProductiontypename);
                _list.DataField("cuQty").SetValue(item.cuQty);
                _list.DataField("cuRrentHoldCount").SetValue(item.cuRrentHoldCount);
                _list.DataField("cuSortNo").SetValue(item.CuSortNo);
                _list.RevisionedObjectField("cuSpec").SetRef(item.CuSpec.Split(":")[0], item.CuSpec.Split(":")[1], false);
                var step = _list.NamedSubentityField("cuStep");
                step.SetName(item.CuStep.Split(":")[0]);
                step.SetParentId(item.workflowid);
                _list.DataField("cuTrackFlag").SetValue(item.CuTrackFlag);
                _list.DataField("cuWOJDE_PN").SetValue(item.CuWOJDE_PN);
                _list.NamedObjectField("cuWorkOrder").SetRef(item.cuWorkOrder);
                _list.DataField("HoldReasonName").SetValue(item.HoldReasonName);

            }
            _input.DataField("cuECNNo").SetValue(param.cuECNNo);
            _input.NamedObjectField("cuECNWONR").SetRef("cuECNFunctionWONR");
            _input.DataField("cuOperationType").SetValue("1");
            _input.DataField("cuUpGradePNBOM").SetValue(true);
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            //var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);


            _resDocument.CheckErrors();

            _resDocument.CheckErrors(resultModel);
            if (resultModel.success)
            {
                GetLotMsgReq lot = new GetLotMsgReq()
                {
                    Lot = param.CuECNChangeDetails[0].cuLot
                };
               ResultModel<LotMessage> lotinfo = (ResultModel<LotMessage>)wIP.GetLotMsg(lot);
                return lotinfo;
            }
            return new ResultModel<LotMessage>().Failed(resultModel.msg);
        }

        /// <summary>
        /// 获取ECN信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetEcnInfo(GetECNInfoReq param)
        {
            
            FormattableString sql = $@"select em.Employeeid,em.EmployeeName,em.FullName,emp.Employeegroupname,f.factoryname from employee em 
                                        left join a_employeeGroupentries an on an.Entriesid = em.employeeid
                                        left  join A_EMPLOYEEGROUP emp on emp.employeegroupid = an.employeegroupid
                                inner join sessionvalues sv on sv.employeeid = em.employeeid
                                inner join factory f on f.factoryid = sv.factoryid
                                where em.employeename={param.Employee}";
            Employee emp = db.Employees.FromSql<Employee>(sql).FirstOrDefault();
            if (emp == null) return new ResultModel<string>().Failed("登陆用户查询不到信息！");
            string facName = string.IsNullOrEmpty(emp.FactoryName) ? "default" : emp.FactoryName;
            FormattableString strsql = $@"select fh.cuecnfutureholdname
                                        , fh.cupjten
                                        , p.culayerno
                                        ,fh.cunewpjten
                                        , ed.cunewproductid
                                        ,ed.isexecutehold cuIsExecHold
                                        , c.containername cuLot
                                        ,mo.mfgordername cuWorkOrder
                                        , pb.productname||':'||p.productrevision  cupn
                                        , pb2.productname||':'|| p2.productrevision cunewpn
                                        ,wfb.workflowname||':'||wf.workflowrevision cuAssemblyWorkflow
                                        , wfs.cusequence cuSortNo
                                        ,wfs.workflowstepname||':'|| vps.workflowname cuStep
                                        ,vps.workflowname||':'||vps.workflowrevision  newwfname
                                        ,vps.workflowname||':'||vps.workflowrevision cuNewWorkflow
                                        ,c.qty cuQty
                                        ,c.qty2 cuPNLQty
                                        ,p.cujde_pn cuJDE_PN
                                        , p.cumi_pn cuMI_PN
                                        ,p2.cujde_pn cuWOJDE_PN
                                        , p2.cumi_pn cuNewMI_PN
                                        ,f.description cuFactory
                                        ,sb.specname||':'||s.specrevision cuInfluenceSpec
                                        ,s.specrevision influrev
                                        , sb2.specname ||':'||s2.specrevision cuSpec
                                        , S2.CUJDE_SPEC cuJDE_Spec
                                        , ot.ordertypename cuOrderType
                                        ,c.cutrackflag cuTrackFlag 
                                        ,P.cuLayerType
                                        ,pt.cuproductiontypename 
                                        ,c.cuRrentHoldCount 
                                        ,hr.HoldReasonName
                                        ,wf.workflowid
                                         from cuecnfuturehold fh
                    inner join cuecnexecutedetail ed on ed.cuecnfutureholdid = fh.cuecnfutureholdid
                    inner join container c on c.containerid= ed.culotid
                    inner join mfgorder mo on mo.mfgorderid = ed.mfgorderid
                    inner join ORDERSTATUS os on mo.ORDERSTATUSID=os.ORDERSTATUSID 
                    inner join cuproductiontype pt on pt.cuproductiontypeid = mo.cuproductiontypeid
                    left join factory f on f.factoryid = mo.cufactoryid
                    inner join ordertype ot on ot.ordertypeid = mo.ordertypeid
                    inner join currentstatus cs on cs.currentstatusid = c.currentstatusid 
                    inner join workflowstep wfs on wfs.workflowstepid = cs.workflowstepid
                    inner join workflow wf on wf.workflowid = wfs.workflowid
                    inner join workflowbase wfb on wfb.workflowbaseid = wf.workflowbaseid
                    inner join product p on p.productid = c.productid
                    inner join productbase pb on pb.productbaseid = p.productbaseid
                    inner join product p2 on p2.productid = ed.cunewproductid and p2.productid != p.productid
                    inner join productbase pb2 on pb2.productbaseid = p2.productbaseid
                    inner join a_productprocessspeclist apl on apl.productid = p2.productid
                    inner join view_processspec vps on apl.processspecid = vps.processspecid and pb2.productname = vps.workflowname
                    inner join spec s on s.specid = ed.cuspecid
                    inner join specbase sb on sb.specbaseid = s.specbaseid
                    inner join specbase sb2 on sb2.specbaseid = wfs.specbaseid
                    inner join spec s2 on s2.specbaseid = sb2.specbaseid
                    inner join factory f on f.factoryid = cs.factoryid 
                    left JOIN HOLDREASON hr  ON hr.HOLDREASONID=c.HOLDREASONID
                    where ed.isexecutehold = 1 and NVL(c.cuIsExecuteECN ,1)=1 and os.ORDERSTATUSNAME='45' --and c.CURRENTHOLDCOUNT='0'
                                        and fh.cuecnfutureholdname = {param.cuECNNo} and f.factoryname={facName}";
            List<ECNFunctionChangeDetails> cuECNFunctionChangeDetails = db.cuECNFunctionChanges.FromSql<ECNFunctionChangeDetails>(strsql).ToList();
            if (cuECNFunctionChangeDetails.Count <= 0)
            {
                return new ResultModel<string>().Failed("查询数据为空！");
            }
            return new ResultModel<List<ECNFunctionChangeDetails>>().Success(cuECNFunctionChangeDetails);
        }
        /// <summary>
        /// OA预hold接口
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CuOAFutureHold(CuOAFutureHoldRep param)
        {
            ResultModel<string> resultModel = new ResultModel<string>();
            if (param == null || param.cuOAFutureHoldDetails.Count <= 0) { return new ResultModel<string>().Failed("传入参数不能为空"); }
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuOAFutureHoldMaint");
            var _input = _helper.InputData();
             var _objectChanges = _input.ObjectField("ObjectChanges");
            _objectChanges.DataField("Name").SetValue(param.cuOAFutureHoldName);
            var _cuOAFutureHoldDetails  = _objectChanges.SubentityList("cuOAFutureHoldDetails");
            //csiSubentityList _cuOAFutureHoldDetails = _objectChanges.subentityList("cuOAFutureHoldDetails");
            foreach (var _item in param.cuOAFutureHoldDetails)
            {
                var _cuOAFutureHoldDetailsitem = _cuOAFutureHoldDetails.AppendItem();
                _cuOAFutureHoldDetailsitem.DataField("cuFutureHoldAction").SetValue(_item.cuFutureHoldAction.ToString());
                _cuOAFutureHoldDetailsitem.NamedObjectField("cuHoldReason").SetRef(_item.cuHoldReason);
                _cuOAFutureHoldDetailsitem.DataField("cuInActive").SetValue("0");
                _cuOAFutureHoldDetailsitem.RevisionedObjectField("cuSpec").SetRef(_item.cuSpec, "1", false);
                _cuOAFutureHoldDetailsitem.RevisionedObjectField("cuPN").SetRef(_item.cuPN, _item.cuPNRev, false);
                _cuOAFutureHoldDetailsitem.DataField("cuLinkRelease").SetValue(_item.cuLinkRelease.ToString());

            }
            _helper.SetExecute("New");
            var _resDocument = _helper.Submit();
            _resDocument.CheckErrors();

            _resDocument.CheckErrors(resultModel);
            return resultModel;
        }
        /// <summary>
        /// OA释放接口
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>

        public IResultModel CuOAFutureHoldRelease(CuOAFutureHoldReleaseReq param)
        {
            ResultModel<string> resultModel = new ResultModel<string>();
            #region 服务数据
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuOAFutureHoldMaint");
            var _input = _helper.InputData();

            _input.NamedObjectField("ObjectToChange").SetRef(param.cuOAFutureHoldName);
            var _cuOAFutureHoldDetails = _input.SubentityList("cuOAFutureHoldDetailsChanges");

            //csiSubentityList _cuOAFutureHoldDetails = _csiObject.subentityList("cuOAFutureHoldDetailsChanges");
            foreach (var _item in param.cuOAFutureHoldReleaseDetails)
            {
                var _cuOAFutureHoldDetailsitem = _cuOAFutureHoldDetails.AppendItem();
                _cuOAFutureHoldDetailsitem.RevisionedObjectField("cuSpec").SetRef(_item.cuSpec, "1", false);
                _cuOAFutureHoldDetailsitem.RevisionedObjectField("cuPN").SetRef(_item.cuPN, _item.cuPNRev, false);
            }

            _helper.SetExecute("cuOAFutureHold_UpdateRelease");
            var _resDocument = _helper.Submit();
            _resDocument.CheckErrors();

            _resDocument.CheckErrors(resultModel);
            #endregion
            if (resultModel.success)
            {
                List<cuFutureHoldDetail> cuFuture = new List<cuFutureHoldDetail>();
                foreach (var item in param.cuOAFutureHoldReleaseDetails)
                {
                    FormattableString str = $@"  select distinct c.containername,sb.specname,sp.specrevision,pb.productname,p.productrevision,cd.cuinactive,cd.culinkrelease from cuoafutureholddetails cd
                                             inner join spec sp on sp.specid = cd.cuspecid
                                             inner join product p on p.productid = cd.cupnid
                                             inner join specbase sb on sb.specbaseid = sp.specbaseid
                                             inner join productbase pb on pb.productbaseid = p.productbaseid
                                             inner join container c on c.productid = p.productid
                                             INNER JOIN CURRENTSTATUS CS ON C.CURRENTSTATUSID = CS.CURRENTSTATUSID
                                             inner join A_LOTHOLDLOCATIONS L on L.CONTAINERID = C.CONTAINERID
                                             where 1=1
                                             and pb.productname = {item.cuPN}
                                             and p.productrevision = {item.cuPNRev}
                                             and sb.specname = {item.cuSpec}
                                             and sp.specrevision = 1";
                    List<cuFutureHoldDetail> specs = db.CuFutureHoldDetail.FromSql<cuFutureHoldDetail>(str).ToList();
                    cuFuture.AddRange(specs);
                }
                if (cuFuture.Count <= 0)
                {
                    return new ResultModel<List<cuFutureHoldDetail>>().Failed("查询数据为空！");
                }
                return new ResultModel<List<cuFutureHoldDetail>>().Success(cuFuture);
            }
            return resultModel;
        }
        /// <summary>
        /// OAECN接口
        /// </summary>
        /// <param name="ecnChangeParameter"></param>
        /// <returns></returns>

        public IResultModel SExecutecuEcnFutureHoldMaint(CuEcnChangeParameter ecnChangeParameter)
        {
            ResultModel<string> _resutlt = new ResultModel<string>();
            //bool _exsit= false;
            ResultModel<List<NameModeInfo>> name = (ResultModel<List<NameModeInfo>>)GetModelInfo(new GetModelInfo{ ModelName ="CK_ECNHOLD",paramentersDic = new Dictionary<string, string>()
            {
                ["@CUECNFUTUREHOLDNAME"] = ecnChangeParameter
                .cuECNNo
            } });
            if (!name.success) return _resutlt.Failed($"{ecnChangeParameter.cuECNNo} 查询数据失败！{name.msg}");
            bool _exist = name.data.Count > 0 ? true : false;

            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuEcnFutureHoldMaint");
 
            if (_exist)
            {
                var _input = _helper.InputData();
                _input.DataField("DataVersion").SetValue("1");
                 var objectToChange = _input.ObjectField("ObjectToChange");
                objectToChange.SetObjectId(name.data[0].InstanceID);
                objectToChange.DataField("__name").SetValue(ecnChangeParameter.cuECNNo);
                objectToChange.SetObjectType("cuEcnFutureHold");
                _helper.Perform("Load");
            }
            else
            {
                _helper.Perform("New");
            }
            var _csiObjectChanges = _helper.InputData().SubentityField("ObjectChanges");
            _csiObjectChanges.DataField("Name").SetValue(ecnChangeParameter.cuECNNo);
            _csiObjectChanges.DataField("cuNewPJTen").SetValue(ecnChangeParameter.cuNewPN);
            _csiObjectChanges.DataField("cuPJTen").SetValue(ecnChangeParameter.cuPN);
            var _cuEcnDetail = _csiObjectChanges.SubentityList("cuEcnExecuteDetail");
            int index = 0;
            foreach (EcuEcnExecuteDetail _item in ecnChangeParameter.ExecuteDetail)
            {
                var _ecnDetailItem = _cuEcnDetail.AppendItem();
                //if (_exist)
                //{
                //    _ecnDetailItem.SetAttribute("__listItemAction", "change");
                //    _ecnDetailItem.DataField("__index").SetValue(index.ToString());
                //}
                _ecnDetailItem.NamedObjectField("cuLot").SetRef(_item.cuLot);
                _ecnDetailItem.RevisionedObjectField("cuNewProduct").SetRef(_item.cuNewPN, _item.cuNewPNVersion, false);
                _ecnDetailItem.RevisionedObjectField("cuProduct").SetRef(_item.cuPN, _item.cuPNVersion, false);
                _ecnDetailItem.RevisionedObjectField("cuSpec").SetRef(_item.cuSpec, "1", false);
                _ecnDetailItem.DataField("IsExecuteHold").SetValue(_item.IsExecuteHoldStr);
                _ecnDetailItem.NamedObjectField("MfgOrder").SetRef(_item.MfgOrder);
                index ++;
            }
            _helper.SetExecute();
            var re = _helper.RequestData();
            re.RequestField("CompletionMsg");
            re.RequestField("DataVersion");
            re.RequestField("ObjectToChange");
            var oDocument = _helper.Submit();
            oDocument.CheckErrors(_resutlt);
            return _resutlt;
        }
        /// <summary>
        /// OA分段hold接口
        /// </summary>
        /// <param name="ecnChangeParameter"></param>
        /// <returns></returns>

        public  IResultModel SExecuteLotFutureHoldSetup(CuEcnChangeParameter ecnChangeParameter)
        {
            ResultModel<string> _resultModel = new ResultModel<string>();
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            // 构建XML
                foreach (EcnFutureHoldModel _ecnFutureHoldModel in ecnChangeParameter.ExecuteFutureHoldDetail)
                {
                    #region 服务数据
                    _helper.CreateService("LotFutureHoldSetup");
                    var _csiObject = _helper.InputData();
                    _csiObject.DataField("UpdateOnly").SetValue("False");
                     var _csiSubentityList = _csiObject.SubentityList("Containers");
                    foreach (var _item in _ecnFutureHoldModel.ContainerNames)
                    {
                        var _csiSubentity = _csiSubentityList.AppendItem();
                        _csiSubentity.DataField("__name").SetValue(_item.ContainerName);
                    }
                    var _csiDetailsList = _csiObject.SubentityList("Details");
                    foreach (var _item in _ecnFutureHoldModel.HoldCondition)
                    {
                        var _csiSubentity = _csiDetailsList.AppendItem();
                        _csiSubentity.DataField("Comments").SetValue(_item.Comments);
                        _csiSubentity.DataField("ExpectedHoldDays").SetValue("0");
                        _csiSubentity.NamedObjectField("HoldReason").SetRef(_item.HoldReason);
                        _csiSubentity.DataField("IncludeChildLots").SetValue("True");
                        _csiSubentity.RevisionedObjectField("Spec").SetRef(_item.Spec, _item.SpecVersion, false);
                    }
                    
                    #endregion
                    _helper.SetExecute();
                    var oDocument =_helper.Submit();
                    oDocument.CheckErrors(_resultModel);
                if (!_resultModel.success) return _resultModel;

                }
            return _resultModel.Success("执行LOT将来Hold成功！");
        }

        /// <summary>
        /// ERC重分类
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel ERCGradePN(ERCReq param)
        {
            ResultModel<string> _resultModel = new ResultModel<string>();
            if (param == null || param.cuNewProduct == null || param.LotDetail == null || param.LotDetail.Count <= 0) return _resultModel.Failed("数据为空！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuECNUpGradePN");
            var _input = _helper.InputData();
            var _cuECNUpGradePNDetails = _input.SubentityList("cuECNUpGradePNDetails");
            foreach (var item in param.LotDetail)
            {
                var _detail = _cuECNUpGradePNDetails.AppendItem();
                /*var con = _detail.NamedSubentityField("cuContainer");
                con.SetAttribute("__CDOTypeName", "Lot");
                con.SetName(item.Container);
                con.SetObjectId("4881038000014871");*/
                _detail.ContainerField("cuContainer").SetRef(item.Container, "LOT");
                
                _detail.DataField("cuPNLQty").SetValue(item.PNLQty);
                _detail.RevisionedObjectField("cuSpec").SetRef(item.Spec.Split(":")[0], item.Spec.Split(":")[1], false);
                /*var pro = _detail.RevisionedObjectField("cuProduct");
                pro.SetAttribute("__CDOTypeName", "DieBankInventorySpec");
                pro.SetObjectId("4881168000014f5f");
                pro.SetRef(item.Product.Split(":")[0], item.Product.Split(":")[1], false);*/
                _detail.DataField("cuQty").SetValue(item.PcsQty);
                _detail.RevisionedObjectField("cuProduct").SetRef(item.Product.Split(":")[0], item.Product.Split(":")[1], false);
                /*var sp = _detail.RevisionedObjectField("cuSpec");
                sp.SetAttribute("__CDOTypeName", "PN");
                sp.SetObjectId("4881228000000005");
                sp.SetRef(item.Spec.Split(":")[0], item.Spec.Split(":")[1], false);*/
                _detail.DataField("cuSpecType").SetValue(item.SpecType);
                _detail.DataField("cuStripQty").SetValue(item.StripQty);
                _detail.DataField("WaferMapDetailsType").SetValue(false);
            }
            _input.DataField("cuJDE_PN").SetValue(string.IsNullOrEmpty(param.cuJDE_PN) ? null : param.cuJDE_PN);
            _input.DataField("cuMI_PN").SetValue(string.IsNullOrEmpty(param.cuMI_PN) ? null : param.cuMI_PN);
            _input.DataField("cuNeedCreateNewWO").SetValue("False");
            _input.DataField("cuNewJDE_PN").SetValue(string.IsNullOrEmpty(param.cuNewJDE_PN) ? null : param.cuNewJDE_PN);
            _input.DataField("cuNewMI_PN").SetValue(string.IsNullOrEmpty(param.cuNewMI_PN) ? null : param.cuNewMI_PN);

            _input.RevisionedObjectField("cuNewProduct").SetRef(param.cuNewProduct.Split(":")[0], param.cuNewProduct.Split(":")[1], false);
            _input.NamedObjectField("cuNewProductType").SetRef(string.IsNullOrEmpty(param.cuNewProductType) ? null : param.cuNewProductType);
            _input.DataField("cuOperationType").SetValue(string.IsNullOrEmpty(param.cuOperationType) ? null : param.cuOperationType);
            _input.RevisionedObjectField("cuProduct").SetRef(param.cuProduct.Split(":")[0], param.cuProduct.Split(":")[1],false);

            _input.DataField("cuProductA").SetValue(param.cuProductA);
            _input.NamedObjectField("cuProductType").SetRef(string.IsNullOrEmpty(param.cuProductType) ? null : param.cuProductType);

            _input.DataField("cuSpecType").SetValue(string.IsNullOrEmpty(param.cuSpecType) ? null : param.cuSpecType);
            _input.DataField("cuUpGradePNBOM").SetValue("True");
            _helper.Execute();

            var re = _helper.RequestData();
            re.RequestField("cuContainerNameFirst");
            re.RequestField("cuContainerNameLast");
            re.RequestField("cuNewWorkOrder");
            re.RequestField("CompletionMsg");
            

            var _resDocument = _helper.Submit();
            //var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);


            _resDocument.CheckErrors();

            _resDocument.CheckErrors(_resultModel);
            return _resultModel;
        }
        /// <summary>
        /// 获取ERC信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetERCInfo(GetERCInfoReq param)
        {
            string pn = param.Prdouct + '%';
            FormattableString strsql = $"";
            if (param.CUALLOWERC)
            {
                strsql = $@" SELECT A.ContainerId as ""cuContainer""
,A.Qty as ""PcsQty""
,A.cuPNLQty as ""PNLQty""
,A.cuStripQty as ""StripQty""
,K.Specname||':'||J.Specrevision as ""Spec""
,J.ObjectCategory as ""SpecType"" 
,F.PRODUCTNAME||':'||E.Productrevision as ""Product""
,a.containername as ""Container""
,A.CUJDELOT
,E.Productrevision
,J.Specrevision
,0 WaferMapDetailsType
FROM CONTAINER A
JOIN CURRENTSTATUS B ON A.CURRENTSTATUSID=B.CURRENTSTATUSID
JOIN WORKFLOWSTEP      C ON B.WORKFLOWSTEPID= C.WORKFLOWSTEPID
JOIN MFGORDER          D ON A.Cuworkorderid=D.MFGORDERID
JOIN PRODUCT           E ON A.PRODUCTID=E.PRODUCTID
JOIN PRODUCTBASE       F ON E.PRODUCTBASEID=F.PRODUCTBASEID
JOIN A_PROCESSSPEC     H ON A.PROCESSSPECID=H.PROCESSSPECID
JOIN A_PROCESSSPECBASE I ON H.PROCESSSPECBASEID=I.PROCESSSPECBASEID 
JOIN SPEC              J ON B.SPECID=J.SPECID
JOIN SPECBASE          K ON J.SPECBASEID=K.SPECBASEID
left JOIN CUINNERLAYERLOTLIST L ON L.CUINNERLAYERLOTID=A.CONTAINERID  
LEFT JOIN CUINOUTLAYERLOTREL IL ON L.CUINOUTLAYERLOTRELID = IL.CUINOUTLAYERLOTRELID 
WHERE A.STATUS=1 
AND (L.CUINNERLAYERLOTID IS NULL OR IL.STATUS=2) 
 and F.PRODUCTNAME LIKE'%-%'  
 AND F.PRODUCTNAME LIKE {pn} 
 AND nvl(a.culayerattached,0) = 0 
 and a.cujdelot is null 
and J.CUALLOWERC = 1
ORDER BY A.CONTAINERNAME";
            }
            else
            {
                strsql = $@" SELECT A.ContainerId as ""cuContainer""
,A.Qty as ""PcsQty""
,A.cuPNLQty as ""PNLQty""
,A.cuStripQty as ""StripQty""
,K.Specname||':'||J.Specrevision as ""Spec""
,J.ObjectCategory as ""SpecType"" 
,F.PRODUCTNAME||':'||E.Productrevision as ""Product""
,a.containername as ""Container""
,A.CUJDELOT
,E.Productrevision
,J.Specrevision
,0 WaferMapDetailsType
FROM CONTAINER A
JOIN CURRENTSTATUS B ON A.CURRENTSTATUSID=B.CURRENTSTATUSID
JOIN WORKFLOWSTEP      C ON B.WORKFLOWSTEPID= C.WORKFLOWSTEPID
JOIN MFGORDER          D ON A.Cuworkorderid=D.MFGORDERID
JOIN PRODUCT           E ON A.PRODUCTID=E.PRODUCTID
JOIN PRODUCTBASE       F ON E.PRODUCTBASEID=F.PRODUCTBASEID
JOIN A_PROCESSSPEC     H ON A.PROCESSSPECID=H.PROCESSSPECID
JOIN A_PROCESSSPECBASE I ON H.PROCESSSPECBASEID=I.PROCESSSPECBASEID 
JOIN SPEC              J ON B.SPECID=J.SPECID
JOIN SPECBASE          K ON J.SPECBASEID=K.SPECBASEID
left JOIN CUINNERLAYERLOTLIST L ON L.CUINNERLAYERLOTID=A.CONTAINERID  
LEFT JOIN CUINOUTLAYERLOTREL IL ON L.CUINOUTLAYERLOTRELID = IL.CUINOUTLAYERLOTRELID 
WHERE A.STATUS=1 
AND (L.CUINNERLAYERLOTID IS NULL OR IL.STATUS=2) 
 AND J.OBJECTTYPE='DIEBANK' 
 and F.PRODUCTNAME LIKE'%-%'  
 AND F.PRODUCTNAME LIKE {pn} 
 AND nvl(a.culayerattached,0) = 0 
 and a.cujdelot is null 
ORDER BY A.CONTAINERNAME";
            }


            List<CuERCUpGradePNDetails> cuECNFunctionChangeDetails = db.ERCUpGradePNDetails.FromSql<CuERCUpGradePNDetails>(strsql).ToList();
            if (cuECNFunctionChangeDetails.Count <= 0)
            {
                return new ResultModel<string>().Failed("查询数据为空！");
            }
            return new ResultModel<List<CuERCUpGradePNDetails>>().Success(cuECNFunctionChangeDetails);
        }
        /// <summary>
        /// 获取ERCSpec
        /// </summary>
        /// <returns></returns>

        public IResultModel GetErcSpec()
        {
            FormattableString sql = @$"SELECT  SPEC.SPECID ,SPECBASE.SPECNAME ,SPEC.SPECREVISION  
                                        FROM SPEC 
                                        INNER JOIN SPECBASE ON SPEC.SPECBASEID = SPECBASE.SPECBASEID
                                        WHERE SPEC.CUALLOWERC =1";
            List<Spec> specs = db.Spec.FromSql<Spec>(sql).ToList();

            if (specs.Count <= 0)
            {
                return new ResultModel<string>().Failed("查询数据为空！");
            }
            return new ResultModel<List<Spec>>().Success(specs);
        }

        /// <summary>
        /// 获取查询信息
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel GetModelInfo(GetModelInfo param)
        {
            FormattableString sql = $@"";
            if (param.ModelName == null || param.ModelName.Length == 0) return new ResultModel<string>().Failed("参数不能为空！");
            ResultModel<List<NameModeInfo>> resultModel = new ResultModel<List<NameModeInfo>>();
            ResultModel<List<RevisionNameModeInfo>> resultRevisionModel = new ResultModel<List<RevisionNameModeInfo>>();
            List<NameModeInfo> result = new List<NameModeInfo>();
            List<RevisionNameModeInfo> resultRevision = new List<RevisionNameModeInfo>();
            List<ECNGetContainerInfoReq> resultecn = new List<ECNGetContainerInfoReq>();
            switch (param.ModelName)
            {
                case "O2M_CK_PJTEN":
                    if (param.paramentersDic.TryGetValue("@CUPJTENNAME", out string value))
                    {
                        sql = $@"SELECT CUPJTENID InstanceID,CUPJTENNAME Name,DESCRIPTION,ISFROZEN,ICONID FROM CUPJTEN 
                                WHERE CUPJTENNAME ={value}";
                        result = db.QueryData.FromSql<NameModeInfo>(sql).ToList();
                        return resultModel.Success(result);
                    }
                    else
                    {
                        return new ResultModel<NameModeInfo>().Failed("O2M_CK_PJTEN：参数没有传入！");
                    }
                    break;
                case "CK_PN_EXIST":
                    if (param.paramentersDic.TryGetValue("@PRODUCTNAME", out string Name)&& param.paramentersDic.TryGetValue("@PRODUCTREVISION", out string Revision))
                    {
                        sql = $@"SELECT PRODUCTID InstanceID,PRODUCTNAME Name,PRODUCTREVISION Revision,DESCRIPTION,ISFROZEN,PRODUCT.ICONID FROM PRODUCT
                                INNER JOIN PRODUCTBASE ON PRODUCT.PRODUCTBASEID = PRODUCTBASE.PRODUCTBASEID
                                WHERE PRODUCTBASE.PRODUCTNAME = {Name} AND PRODUCT.PRODUCTREVISION = {Revision}";
                        resultRevision = db.QueryRevisionData.FromSql<RevisionNameModeInfo>(sql).ToList();
                        return resultRevisionModel.Success(resultRevision);
                    }
                    else
                    {
                        return new ResultModel<RevisionNameModeInfo>().Failed("CK_PN_EXIST：参数没有传入！");
                    }
                    break;
                case "ECN_FTHOLE":
                    if (param.paramentersDic.TryGetValue("@PRODUCTNAME", out string N) && param.paramentersDic.TryGetValue("@PRODUCTREVISION", out string R)&& param.paramentersDic.TryGetValue("@WORKFLOWSTEPNAME", out string W))
                    {
                        sql = $@"SELECT WORKFLOWSTEP.CUSEQUENCE,
       C.CONTAINERNAME,
       C.QTY,
       C.QTY2,
       OT.ORDERTYPENAME,
       SB.SPECNAME,
       C.MFGORDERID,
       MO.MFGORDERNAME,
       MO.PROCESSSPECID,
       APB.PROCESSSPECNAME,
       AP.PROCESSSPECREVISION,
       AP.WORKFLOWID,
       S.SPECREVISION,
       TO_CHAR(SYSDATE - NVL(C.MOVEINTIMESTAMP, SYSDATE), '99990.999') AS DAYSHERE,
       PB.PRODUCTNAME ,P.PRODUCTREVISION,
       CASE
         WHEN C.STATUS = 1 THEN
          'ACTIVE'
         WHEN C.STATUS = 2 THEN
          'TERMINATED'
         WHEN C.STATUS = 5 THEN
          'SHIPPED'
         ELSE
          TO_CHAR(C.STATUS)
       END AS STATUS,
       CASE
         WHEN NVL(C.CURRENTHOLDCOUNT, 0) > 0 THEN
          'YES ' ||
          TO_CHAR(SYSDATE - NVL(C.ONHOLDDATE, SYSDATE), '99990.999') ||
          ' DAYS'
         ELSE
          'NO'
       END AS ISONHOLD,
       CASE
         WHEN NVL(CS.INREWORK, 0) > 0 THEN
          'YES LOOP ' || TO_CHAR(CS.REWORKLOOPCOUNT) || ' TOTAL ' ||
          TO_CHAR(CS.REWORKTOTALCOUNT)
         ELSE
          'NO'
       END AS INREWORK,
       CASE
         WHEN NVL(C.FUTUREHOLDCOUNT, 0) > 0 THEN
          'YES ' || TO_CHAR(C.FUTUREHOLDCOUNT)
         ELSE
          'NO'
       END AS FUTUREHOLDEXISTS,
       CASE
         WHEN NVL(C.LOANCOUNT, 0) > 0 THEN
          'YES'
         ELSE
          'NO'
       END AS ONLOAN,
       CASE
         WHEN C.SCHEDULEDATAID IS NOT NULL OR NVL(C.SCHEDULECOUNT, 0) > 0 THEN
          'YES'
         ELSE
          'NO'
       END AS INSCHEDULE,
       C.INSERTIONNUMBER AS INSERTION,
       C.BATCHNO AS BATCHNO,
       C.EQUIPMENTCOUNT AS EQPCOUNT,
       C.EQUIPMENTLOADINGCOUNT AS EQPLOADINGCOUNT,
       CS.CURRENTSPECPASS AS SPECPASS,
       S.OBJECTCATEGORY AS SPECCATEGORY,
       S.OBJECTTYPE AS SPECTYPE,
       S.DESCRIPTION AS SPECDESCRIPTION,
       CAST(ROW_NUMBER()
            OVER(ORDER BY MO.MFGORDERNAME, SB.SPECNAME, C.MOVEINTIMESTAMP) AS INT) AS NO
  FROM CONTAINER C
 INNER JOIN CURRENTSTATUS CS
    ON C.CURRENTSTATUSID = CS.CURRENTSTATUSID
 INNER JOIN WORKFLOWSTEP
    ON WORKFLOWSTEP.WORKFLOWSTEPID = CS.WORKFLOWSTEPID
 INNER JOIN WORKFLOW W ON WORKFLOWSTEP.WORKFLOWID = W.WORKFLOWID
 INNER JOIN PRODUCT P
    ON C.PRODUCTID = P.PRODUCTID
 INNER JOIN PRODUCTBASE PB
    ON P.PRODUCTBASEID = PB.PRODUCTBASEID
 INNER JOIN SPEC S
    ON CS.SPECID = S.SPECID
 INNER JOIN SPECBASE SB
    ON S.SPECBASEID = SB.SPECBASEID
 INNER JOIN MFGORDER MO
    ON C.MFGORDERID = MO.MFGORDERID
 INNER JOIN ORDERTYPE OT
    ON MO.ORDERTYPEID = OT.ORDERTYPEID
 INNER JOIN A_PROCESSSPEC AP
    ON MO.PROCESSSPECID = AP.PROCESSSPECID
 INNER JOIN A_PROCESSSPECBASE APB
    ON AP.PROCESSSPECBASEID = APB.PROCESSSPECBASEID
 INNER JOIN CONTAINERLEVEL CL
    ON C.LEVELID = CL.CONTAINERLEVELID
 WHERE C.STATUS = 1
   AND CL.CONTAINERLEVELNAME = 'LOT'
   AND S.OBJECTCATEGORY <> 'INTRANSIT'
   AND OT.ORDERTYPENAME NOT IN ('WH', 'WR')
   AND PB.PRODUCTNAME = {N}
   AND P.PRODUCTREVISION = {R}
   AND WORKFLOWSTEP.CUSEQUENCE <
       (SELECT WORKFLOWSTEP.CUSEQUENCE
          FROM WORKFLOWSTEP
         INNER JOIN WORKFLOW
            ON WORKFLOW.WORKFLOWID = W.WORKFLOWID--AP.WORKFLOWID串当前流程而非MI上的流程
           AND WORKFLOWSTEP.WORKFLOWID = WORKFLOW.WORKFLOWID
         WHERE WORKFLOWSTEP.WORKFLOWSTEPNAME ={W} )";
                        resultecn = db.eCNGetContainerInfoReqs.FromSql<ECNGetContainerInfoReq>(sql).ToList();
                        return new ResultModel<List<ECNGetContainerInfoReq>>().Success(resultecn);
                    }
                    else
                    {
                        return new ResultModel<ECNGetContainerInfoReq>().Failed("ECN_FTHOLE：参数没有传入！");
                    }
                    break;
                case "CK_ECNHOLD":
                    if (param.paramentersDic.TryGetValue("@CUECNFUTUREHOLDNAME", out Name) )
                    {
                        sql = $@"SELECT CUECNFUTUREHOLDID INSTANCEID,CUECNFUTUREHOLDNAME NAME,DESCRIPTION,ISFROZEN,ICONID FROM CUECNFUTUREHOLD
                                 WHERE CUECNFUTUREHOLD.CUECNFUTUREHOLDNAME ={Name}";
                        result = db.QueryData.FromSql<NameModeInfo>(sql).ToList();
                        return resultModel.Success(result);
                    }
                    else
                    {
                        return new ResultModel<NameModeInfo>().Failed("CK_ECNHOLD：参数没有传入！");
                    }
                    break;
                default:
                    return new ResultModel<string>().Failed($@"{param.ModelName} 没有找到！");

            }
        }

        /// <summary>
        /// 内层配单查询lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LayerGetContainerInfo(CuLayerGetContinerInfoReq param)
        {
            ResultModel<cuNextLayerRsq> resultModel = new ResultModel<cuNextLayerRsq>();
            cuNextLayerRsq cuNextLayer = new cuNextLayerRsq();
            FormattableString sql = $@"SELECT C.CONTAINERNAME CUCONTAINER,
                                       C.QTY2 CUPNLQTY,
                                       MO.MFGORDERNAME CUWORKORDER,
                                       PB.PRODUCTNAME || ':' || P.PRODUCTREVISION CUPN,
                                       P.CULAYERNUM,
                                       P.CULAYERNO,
                                       ST.CUINOUTLAYERLOTRELNAME CUINOUTLAYERLOTRELNAME,
                                       P.CULAYERSEQ,
                                       C.QTY CUQTY,
                                       C.QTY / P.CUPCSPERSTRIP CUSTRIPQTY,
                                       CS.SPECID,
                                       S.CUSEMIFINISHED,
                                       P.CUNEXTLAYERPNID,
                                       PB2.PRODUCTNAME CUNEXTLAYERPN,
                                       P2.Cuwomaxpnlqty cuNextwomaxpnlqty,
                                       P2.PRODUCTREVISION CUNEXTLAYERPNREV ,
                                       M.PRODUCTREVISION AS CUNEXTLAYERPNMAXREV, 
                                       F.FACTORYNAME,
                                       '' cuRequestRevision
                                  FROM CONTAINER C
                                 INNER JOIN CURRENTSTATUS CS
                                    ON CS.CURRENTSTATUSID = C.CURRENTSTATUSID
                                LEFT JOIN FACTORY F ON F.FACTORYID = CS.FACTORYID
                                 INNER JOIN MFGORDER MO
                                    ON MO.MFGORDERID = C.MFGORDERID
                                    OR MO.MFGORDERID = C.CUWORKORDERID
                                 INNER JOIN PRODUCT P
                                    ON P.PRODUCTID = C.PRODUCTID
                                 INNER JOIN PRODUCTBASE PB
                                    ON PB.PRODUCTBASEID = P.PRODUCTBASEID
                                 INNER JOIN SPEC S
                                    ON S.SPECID = CS.SPECID
                                 INNER JOIN SPECBASE SP
                                    ON SP.SPECBASEID = S.SPECBASEID
                                 INNER JOIN PRODUCT P2
                                    ON P2.PRODUCTID = P.CUNEXTLAYERPNID
                                 INNER JOIN PRODUCTBASE PB2
                                    ON PB2.PRODUCTBASEID = P2.PRODUCTBASEID
                                  LEFT JOIN 
                                  (SELECT ILLR.CUINOUTLAYERLOTRELNAME ,ILLL.CUINNERLAYERLOTID FROM CUINNERLAYERLOTLIST ILLL
                                  INNER JOIN CUINOUTLAYERLOTREL ILLR
                                    ON ILLR.CUINOUTLAYERLOTRELID = ILLL.CUINOUTLAYERLOTRELID AND ILLR.Status =1
                                    ) ST ON   ST.CUINNERLAYERLOTID = C.CONTAINERID
                                LEFT JOIN 
                                 (
                                      SELECT MAX(P2.PRODUCTREVISION) AS PRODUCTREVISION,PB2.PRODUCTNAME,PB2.PRODUCTBASEID
                                      FROM PRODUCT P2 
                                      INNER JOIN PRODUCTBASE PB2 ON P2.PRODUCTBASEID = PB2.PRODUCTBASEID
                                      GROUP BY PB2.PRODUCTNAME,PB2.PRODUCTBASEID
                                 ) M ON M.Productbaseid = PB2.Productbaseid
                                 WHERE S.CUSEMIFINISHED = 1
                                   AND C.CONTAINERNAME = {param.Container} ";
            CuLayerAttachDetails cLayers = db.cuLayers.FromSql<CuLayerAttachDetails>(sql).FirstOrDefault();
            if (cLayers == null) return resultModel.Failed("数据为空！");
            if (param.cuFactory!= cLayers.FACTORYNAME)return resultModel.Failed("工厂不一样！");
            if (!string.IsNullOrEmpty(cLayers.cuNextLayerPNMaxRev))
            {
                if (cLayers.cuNextLayerPNRev != cLayers.cuNextLayerPNMaxRev)
                {
                    //return resultModel.Failed("生成的外层PN已经有最新的版本！");
                    cLayers.cuRequestRevision = string.Concat("M", cLayers.cuNextLayerPNRev);
                }
                else
                {
                    cLayers.cuRequestRevision = string.Concat("M");
                }
            }
            cuNextLayer.attachDetails = cLayers;
            if (!string.IsNullOrEmpty(cLayers.cuInOutLayerLotRelName))
            {
                List<cuNexLayerWorkOrder> cuNexLayerWorks =  GetWorkOrderInfo(cLayers.cuInOutLayerLotRelName);
                cuNextLayer.cuNexLayerWorkOrders = cuNexLayerWorks;
            }
            
            cuNextLayer.NextLayerProductName = cLayers.cuNextLayerPN;
            cuNextLayer.NextLayerProductRevision = cLayers.cuNextLayerPNRev;
            cuNextLayer.NextLayerMaxPN = cLayers.cuNextLayerPN;
            cuNextLayer.NextLayerMaxPNRevision = cLayers.cuNextLayerPNMaxRev;
            cuNextLayer.cuNextwomaxpnlqty = cLayers.cuNextwomaxpnlqty;
            cuNextLayer.cuLayerNo = cLayers.cuLayerNo;
            cuNextLayer.cuLayerSeq = cLayers.cuLayerSeq;
            cuNextLayer.cuQty = cLayers.cuQty;
            cuNextLayer.cuInOutLayerLotRelName = cLayers.cuInOutLayerLotRelName;
            cuNextLayer.cuPNLQty = cLayers.cuPNLQty;
            cuNextLayer.cuWorkOrder = cLayers.cuWorkOrder;
            cuNextLayer.cuProduct = cLayers.cuPN;
            cuNextLayer.cuWorkFlow = param.cuFactory + "_DefaultDBInvWF:1";
            cuNextLayer.cuWorkFlowStep = param.cuFactory + "_开料线边仓";
            cuNextLayer.cuRequestRevision = cLayers.cuRequestRevision;
            return resultModel.Success(cuNextLayer);
        }
        /// <summary>
        /// 内层配单获取登录用户工厂
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LayerGetEmployeeInfo(GetEmployeeInfo param)
        {
            FormattableString empsql = $@"select em.Employeeid,em.EmployeeName,em.FullName,'' Employeegroupname,nvl(fa.factoryname,'default') FactoryName from Employee em 
                                        left join SessionValues se on se.employeeid = em.employeeid
                                        left join factory fa on fa.factoryid = se.factoryid
                                        where em.employeename = {param.Employee}";
            Employee emp = db.Employees.FromSql<Employee>(empsql).FirstOrDefault();

            if (emp == null) return new ResultModel<string>().Failed($@"{param.Employee.ToString()}员工数据未查询到数据！");
            ResultModel<Employee> result = new ResultModel<Employee>();
            return result.Success(emp);
        }

        /// <summary>
        /// 验证内层批次所有数量是否匹配
        /// </summary>
        /// <returns></returns>
        public bool VerifyLayerContainerList(List<CuLayerAttachDetails> oCurrentDetails, ref string strLayerPN,ref double dPNLQty,ref double dPCSQty )
        {
            Dictionary<string, double> list = new Dictionary<string, double>();
            bool b = true; string strPN = string.Empty;
            foreach (CuLayerAttachDetails details in oCurrentDetails)
            {
                // 当第一次循环时，记录当前料号，及PNL数量，PCS数量
                if (dPNLQty == 0)
                {
                    strPN = details.cuPN;
                    dPNLQty += details.cuPNLQty;
                    dPCSQty += details.cuQty;
                }
                else
                {
                    // 当后面循环时，当前料号与第一次的记录料号strPN相等，累计PNL数量，PCS数量
                    if (strPN == details.cuPN)
                    {
                        dPNLQty += details.cuPNLQty;
                        dPCSQty += details.cuQty;
                    }
                }

                double qty;
                if (list.TryGetValue(details.cuPN, out qty))
                {
                    list[details.cuPN] = details.cuQty + qty;
                }
                else
                {
                    list.Add(details.cuPN, details.cuQty);
                }
            }

            if (list.Count > 1)
            {
                double qty = 0;
                foreach (KeyValuePair<string, double> kvp in list)
                {
                    if (qty == 0)
                    { qty = kvp.Value; }
                    else
                    {
                        b = qty == kvp.Value;
                        if (!b) { strLayerPN = kvp.Key; return b; }
                    }
                }
            }
            //ViewState["PNLQty"] = dPNLQty;
            //ViewState["PCSQty"] = dPCSQty;

            return b;
        }

        /// <summary>
        /// 请求下层工单
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel RequestNextLayerWO(cuLayerReq param)
        {
            if (param.AttachDetails.Count<=0)
            {
                return new ResultModel<string>().Failed("参数不能为空！");
            }
            string strLayerPN =string.Empty ;
            double dPNLQty =0;
            double dPCSQty= 0;
            if (!VerifyLayerContainerList(param.AttachDetails,ref strLayerPN, ref dPNLQty, ref  dPCSQty))
            {
                return new ResultModel<string>().Failed($@"料号：[{strLayerPN}] 的内层批次数量不匹配!\");
            }
            foreach (var item in param.AttachDetails)
            {
                //实时获取内层批次的下层PN，如已升级小版本，报错提示
                string sql = $@"select  P2.PRODUCTREVISION CUNEXTLAYERPNREV,M.PRODUCTREVISION AS CUNEXTLAYERPNMAXREV 
                                from container c 
                                inner join product p on c.productid=p.productid
                                inner join product p2 on p2.productid=p.cunextlayerpnid
                                inner join productbase pb2 on p2.productbaseid=pb2.productbaseid
                                inner JOIN 
                                 (
                                      SELECT MAX(P2.PRODUCTREVISION) AS PRODUCTREVISION,PB2.PRODUCTNAME,PB2.PRODUCTBASEID
                                      FROM PRODUCT P2 
                                      INNER JOIN PRODUCTBASE PB2 ON P2.PRODUCTBASEID = PB2.PRODUCTBASEID
                                      GROUP BY PB2.PRODUCTNAME,PB2.PRODUCTBASEID
                                 ) M ON M.Productbaseid = PB2.Productbaseid 
                                where c.containername='{item.cuContainer}'";
                DataTable dt = db.GetTable(sql);
                string cuNextPNRev = "";
                string cusNextPNMaxRev = "";
                string strRequestRevision = "";
                if (dt.Rows.Count>0)
                {
                    if (!string.IsNullOrEmpty(dt.Rows[0]["cuNextLayerPNRev"]?.ToString()))
                    {
                        cuNextPNRev = dt.Rows[0]["cuNextLayerPNRev"].ToString();
                    }

                    if (!string.IsNullOrEmpty(dt.Rows[0]["cuNextLayerPNMaxRev"]?.ToString()))
                    {
                        cusNextPNMaxRev = dt.Rows[0]["cuNextLayerPNMaxRev"].ToString();
                    }
                    //获取应该请求的最新strRequestRevision  M    M1     M2........
                    if (!string.IsNullOrEmpty(cusNextPNMaxRev))
                    {
                        if (cuNextPNRev != cusNextPNMaxRev)
                        {
                            strRequestRevision = string.Concat("M", cuNextPNRev);
                        }
                        else
                        {
                            strRequestRevision = string.Concat("M");
                        }
                    }
                    if (strRequestRevision != item.cuRequestRevision)
                    {
                        return new ResultModel<string>().Failed("请求工单的版本有变，请刷新页面重新操作!");
                    }
                    if (dPNLQty == 0 || dPCSQty == 0)
                    {
                        return new ResultModel<string> ().Failed($@"{strLayerPN}内层批次数量为 0，不能请求外层工单!");
                    }
                }
            }
            List<cuNexLayerWorkOrder> cuNexLayerWorks = GetWorkOrderInfo(param.cuInOutLayerLotRelName);
            if (cuNexLayerWorks == null || cuNexLayerWorks.Count <= 0)
            {
                if (string.IsNullOrEmpty(param.cuInOutLayerLotRelName))
                {
                    string sqlStr = $@"select p.productid,pb.productname,p.ProductRevision,p2.CUPCSPERPNL from product p
                    inner join productbase pb on p.productbaseid=pb.productbaseid
                    inner join product p2 on p2.productid=p.cunextlayerpnid
                    inner join productbase pb2 on pb2.productbaseid=p2.productbaseid
                    where pb2.productname=N'{param.NextLayerProductName}' and p2.productrevision='{param.NextLayerProductRevision}'";
                    DataTable dt = db.GetTable(sqlStr);
                    DataTable dtLayerAttach = new DataTable();
                    DataColumn dcLayerAttach = null;
                    dcLayerAttach = dtLayerAttach.Columns.Add("ProductName", Type.GetType("System.String"));
                    dcLayerAttach = dtLayerAttach.Columns.Add("ProductRevision", Type.GetType("System.String"));

                    int _gridLayerAttachDetailsRow = param.AttachDetails.Count;
                    for (int row = 0; row < _gridLayerAttachDetailsRow; row++)
                    {
                        DataRow drLayerAttach;
                        drLayerAttach = dtLayerAttach.NewRow();
                        drLayerAttach["ProductName"] = param.AttachDetails[row].cuPN.Split(':')[0];
                        drLayerAttach["ProductRevision"] = param.AttachDetails[row].cuPN.Split(':')[1];
                        dtLayerAttach.Rows.Add(drLayerAttach);
                    }
                    string cuNotInOutLayerLot = string.Empty;
                    for (int i = 0; dt != null && dt.Rows.Count > 0 && i < dt.Rows.Count; i++)
                    {
                        bool flagLayerAttach = false;
                        for (int j = 0; dtLayerAttach != null && dtLayerAttach.Rows.Count > 0 && j < dtLayerAttach.Rows.Count; j++)
                        {
                            if ((dt.Rows[i]["ProductName"].Equals(dtLayerAttach.Rows[j]["ProductName"])) && (dt.Rows[i]["ProductRevision"].Equals(dtLayerAttach.Rows[j]["ProductRevision"])))
                                flagLayerAttach = true;
                        }

                        if (flagLayerAttach == false)
                            cuNotInOutLayerLot += "[" + dt.Rows[i]["ProductName"] + ":" + dt.Rows[i]["ProductRevision"] + "]";
                    }

                    if (!string.IsNullOrEmpty(cuNotInOutLayerLot))
                    {
                        return new ResultModel<string>().Failed($@"缺少内层批次信息{cuNotInOutLayerLot}");
                    }
                    //新增数量管控(生成外层的PNL数和外层最大PNL数比较)
                    if (Convert.ToDecimal(Convert.ToDecimal(dPCSQty) / Convert.ToDecimal(dt.Rows[0]["CUPCSPERPNL"]?.ToString())) > Convert.ToDecimal(param.cuNextwomaxpnlqty))
                    {
                        return new ResultModel<string>().Failed($@"请求外层工单不能超过[{param.cuNextwomaxpnlqty}]，不能请求外层工单!");
                    }
                    ResultModel<string> result = new ResultModel<string>();
                    result = (ResultModel<string>)CuLayerAttach(param);
                    if (result.success)
                    {
                        string cuReqWOOnly = result.data;
                        //请求工单时判断当前产品是否有升级版本，没有升级版本时传M，有升级版本时"弹框提示是否使用升级版本"，是"M"【M】，否"M+'版本'"【M版本】
                        if (string.IsNullOrEmpty(cuReqWOOnly))
                        {
                            return new ResultModel<string>().Failed("获取请求工单唯一编号失败");
                        }
                        else
                        {
                            string strsql = $@"select c.containername,mo.mfgordername,ot.ordertypename,c.qty,c.cupnlqty,pb.productname currentPN,p.productrevision currentPNRev
                                                        ,nextLayerPb.Productname,nextLayerP.Productrevision nextLayerPbRev,nextlayerP.Culeadtime,nextLayerP.Cushortpn,nextlayerP.Cujde_Pn,nextlayerP.Cushrinkfactor,nextlayerP.Cumi_Pn,cs.factoryid,f.factoryname,f.description,nextLayerP.CUPCSPERPNL  
                                                        from container c
                                                        inner join currentstatus cs on cs.currentstatusid=c.currentstatusid
                                                        inner join factory f on f.factoryid=cs.factoryid
                                                        inner join mfgorder mo on c.cuworkorderid=mo.mfgorderid or c.mfgorderid=mo.mfgorderid
                                                        inner join ordertype ot on ot.ordertypeid=mo.ordertypeid
                                                        inner join product p on p.productid=c.productid
                                                        inner join productbase pb on pb.productbaseid=p.productbaseid
                                                        inner join product nextLayerP on nextLayerP.Productid=p.cunextlayerpnid
                                                        inner join productbase nextLayerPb on nextLayerPb.Productbaseid=nextLayerP.Productbaseid
                                                        where c.containername=N'{param.AttachDetails.FirstOrDefault().cuContainer}'";
                            DataTable dtRequestInfo = db.GetTable(strsql);
                            #region C、发送工单请求数据赋值
                            DateTime dateTime = new DateTime();
                            dateTime = System.DateTime.Now;
                            MiddleCuIntOutwoapply objInOutWoApply = new MiddleCuIntOutwoapply();
                            objInOutWoApply.MMUKID = cuReqWOOnly;//请求唯一编码，最长15位，Decimal类型
                            objInOutWoApply.MMEDBT = cuReqWOOnly;//数据传入唯一编号，同请求唯一编码
                            objInOutWoApply.MMEDSP = "0";                 //结果处理标记，MES默认传空，JDE处理完成后设为“Y”
                            objInOutWoApply.MMEDLN = 1 * 1000;                  //MES传入批次序号,请求工单行号
                            objInOutWoApply.MMLOTN = "";                 //MESLot标记，默认为空
                            objInOutWoApply.MMITM = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? 0 : (string.IsNullOrEmpty(dtRequestInfo.Rows[0]["Cushortpn"]?.ToString()) ? 0 : Convert.ToDecimal(dtRequestInfo.Rows[0]["Cushortpn"]?.ToString()));//短料号Container.PN.NextLayerPN.cuShortPN，为空取0
                            objInOutWoApply.MMLITM = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? "" : dtRequestInfo.Rows[0]["Cujde_Pn"]?.ToString();//长料号Container.PN.NextLayerPN.cuJDE_PN
                            objInOutWoApply.MMMMCU = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? "" : dtRequestInfo.Rows[0]["description"]?.ToString();//分部（厂）Factory.description【MfgOrder.Factory】
                            objInOutWoApply.MMMSGT = "B";               //固定B
                            objInOutWoApply.MMMSGA = "";                //无用，默认空
                            objInOutWoApply.MMDCTO = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? "" : dtRequestInfo.Rows[0]["ordertypename"]?.ToString();//取内层工单类型OrderType
                            objInOutWoApply.MMDSC1 = "";               //默认空
                            objInOutWoApply.MMTRQT = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? 0 : Convert.ToDecimal((Convert.ToDecimal(param.cuQty?.ToString()) / (1 + (string.IsNullOrEmpty(dtRequestInfo.Rows[0]["Cushrinkfactor"]?.ToString()) ? 0 : Convert.ToDecimal(dtRequestInfo.Rows[0]["Cushrinkfactor"]?.ToString()))))) * 100000;    //良品数量。(请求外层PCS数/(1+Container.PN.Next Layer PN.cuShrinkFactor))*100000【取整*100000】，为空取0
                                                                                                                                                                                                                                                                                                                                                                          //objInOutWoApply.MMDRQJ = dateConvert.ConvertToJulianDate(dateTime.AddDays(string.IsNullOrEmpty(dtRequestInfo.Rows[0]["Culeadtime"]?.ToString()) ? 0 : Convert.ToDouble(dtRequestInfo.Rows[0]["Culeadtime"]?.ToString())));//当前日期+Container.PN.NextLayerPN.cuLeadTime    (世纪年日转Julian Day)【1，2，3】,cuLeadTime为空取 0
                            objInOutWoApply.MMDRQJ = string.IsNullOrEmpty(dtRequestInfo.Rows[0]["Culeadtime"]?.ToString()) ? ConvertToJulianDate(dateTime) : ConvertToJulianDate(dateTime.AddDays(Convert.ToDouble(dtRequestInfo.Rows[0]["Culeadtime"]?.ToString())));
                            objInOutWoApply.MMSTRT = ConvertToJulianDate(dateTime);           //(世纪年日转Julian Day)【1，2，3】
                            objInOutWoApply.MMUPMJ = ConvertToJulianDate(dateTime);                //(世纪年日转Julian Day)【1，2，3】
                            objInOutWoApply.MMUPMT = ConvertToJulianTime(dateTime);               //(时分秒转Julian Day）
                            objInOutWoApply.MMTRDJ = ConvertToJulianDate(dateTime);                //(世纪年日转Julian Day)【1，2，3】
                            objInOutWoApply.MMTDAY = ConvertToJulianTime(dateTime);               //(时分秒转Julian Day）
                            objInOutWoApply.MMTBM = param.cuRequestRevision.ToString();//BOM版本号
                            objInOutWoApply.MMTRT = param.cuRequestRevision.ToString();//Routing版本号
                            objInOutWoApply.MMVR01 = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? "" : dtRequestInfo.Rows[0]["Cumi_Pn"]?.ToString();      //生产型号，Container.PN.NextLayerPN.cuMI_PN(先取默认值：A08X240CM3-00)
                            objInOutWoApply.MMUORG = Convert.ToDecimal(param.cuQty?.ToString()) * 100000;//生产数量（serviceData.cuQty.Value数量*100000）
                            objInOutWoApply.MMURAB = Convert.ToDecimal(Convert.ToDecimal(param.cuQty?.ToString()) / Convert.ToDecimal(dtRequestInfo.Rows[0]["CUPCSPERPNL"]?.ToString()));//PNL数量 Convert.ToDecimal(serviceData.cuPNLQty.Value);
                            objInOutWoApply.MMBREV = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? "" : dtRequestInfo.Rows[0]["nextLayerPbRev"]?.ToString();          //下层产品BOM版本号(BOM、产品、Routingg 版本一致)
                            objInOutWoApply.MMRREV = (dtRequestInfo == null || dtRequestInfo.Rows.Count == 0) ? "" : dtRequestInfo.Rows[0]["nextLayerPbRev"]?.ToString();          //下层产品Routing版本号
                            #endregion
                            HttpResponseMessage httpResponseMessage = WebApiHandler.PostOriginalAsync<MiddleCuIntOutwoapply>("http://10.201.49.130:8888", "/webapi/JDE/SaveOutWOApplyBaseInfo", objInOutWoApply);
                            if (httpResponseMessage.IsSuccessStatusCode)
                            {
                               string _result = httpResponseMessage.Content.ReadAsStringAsync().Result;
                                return new ResultModel<string>().Failed("调用'工单请求'接口成功" + _result);
                            }
                            else
                            {
                                //string _result = httpResponseMessage.Content.ReadAsStringAsync().Result;
                                return new ResultModel<string>().Failed("调用'工单请求'接口失败");
                            }

                        }
                    }
                    else
                    {
                        return result;
                    }
                }
                else
                {
                    return new ResultModel<string>().Failed($"批次次[{param.AttachDetails[0].cuContainer}]已经请求过唯一单号！");
                }
            }
            return new ResultModel<string>().Success("内存配单成功！");
        }

        /// <summary>
        /// 获取最新的下层工单
        /// </summary>
        /// <param name="cuInOutLayerLotRel"></param>
        /// <returns></returns>
        public List<cuNexLayerWorkOrder> GetWorkOrderInfo(string cuInOutLayerLotRel)
        {
            FormattableString sql = $@"SELECT DISTINCT MO.MFGORDERNAME,MO.CUPNLQTY PNLQTY,MO.CUSTRIPQTY SETQTY,MO.QTY PCSQTY
                            ,PB.PRODUCTNAME,P.PRODUCTREVISION,P.CULAYERNUM LAYERNUM,P.CULAYERNO LAYERNO,ILL.CUINOUTLAYERLOTRELNAME INOUTLAYERLOTRELNAME 
                            FROM MFGORDER MO
                            INNER JOIN PRODUCT P ON MO.PRODUCTID=P.PRODUCTID
                            INNER JOIN PRODUCTBASE PB ON PB.PRODUCTBASEID=P.PRODUCTBASEID 
                            INNER JOIN CUINOUTLAYERLOTREL ILL ON ILL.CUINOUTLAYERLOTRELNAME=MO.CUWOAPPLYID AND ILL.STATUS=1 
                            INNER JOIN CUINNERLAYERLOTLIST ILLIST ON  ILLIST.CUINOUTLAYERLOTRELID=ILL.CUINOUTLAYERLOTRELID 
                            INNER JOIN CONTAINER C ON C.CONTAINERID=ILLIST.CUINNERLAYERLOTID 
                            WHERE MO.CUWOAPPLYID = {cuInOutLayerLotRel}";
            List<cuNexLayerWorkOrder> nexLayers = db.cuNexLayerWorks.FromSql<cuNexLayerWorkOrder>(sql).ToList();

            return nexLayers;
        }

        public IResultModel CuLayerAttach(cuLayerReq param)
        {
            ResultModel<string> _result = new ResultModel<string>();
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuLayerAttach");
            var _input = _helper.InputData();
            //_input.ContainerField("cuContainer").SetRef(param.AttachDetails.LastOrDefault().cuContainer, "Lot");
            _input.NamedObjectField("cuContainer").SetRef(param.AttachDetails.LastOrDefault().cuContainer);
            _input.NamedObjectField("cuContainerLevel").SetRef("LOT");
            var _cuLayerAttachDetails = _input.SubentityList("cuLayerAttachDetails");
            foreach (var item in param.AttachDetails)
            {
                var detail = _cuLayerAttachDetails.AppendItem();
                detail.NamedObjectField("cuContainer").SetRef(item.cuContainer);
                //detail.DataField("cuContainerLevel").SetValue("LOT");
                //detail.ContainerField("cuContainer").SetRef(item.cuContainer, "Lot");
                detail.DataField("cuInOutLayerLotRelName").SetValue(item.cuInOutLayerLotRelName);
                detail.DataField("cuLayerNo").SetValue(item.cuLayerNo);
                detail.DataField("cuLayerSeq").SetValue(item.cuLayerSeq);
                detail.DataField("cuPNLQty").SetValue(item.cuPNLQty);
                detail.DataField("cuQty").SetValue(item.cuQty);
                detail.RevisionedObjectField("cuPN").SetRef(item.cuPN.Split(':')[0], item.cuPN.Split(':')[1], false);
                detail.DataField("cuStripQty").SetValue(item.cuStripQty);
                detail.NamedObjectField("cuWorkOrder").SetRef(item.cuWorkOrder);
            }
            _input.DataField("cuLayerNo").SetValue(param.cuLayerNo);
            _input.DataField("cuLayerSeq").SetValue(param.cuLayerSeq);
            _input.RevisionedObjectField("cuNextLayerMaxPN").SetRef(param.NextLayerMaxPN, param.NextLayerMaxPNRevision, false);
            _input.RevisionedObjectField("cuNextLayerPN").SetRef(param.NextLayerProductName, param.NextLayerProductRevision, false);
            _input.DataField("cuNextWOMaxPNLQty").SetValue(param.cuNextwomaxpnlqty);
            _input.DataField("cuOuterLotName").SetValue(DateTime.Now.ToString("yyyyMMddHHmmssfff").Substring(2, 15));
            _input.DataField("cuPNLQty").SetValue(param.cuPNLQty);
            _input.RevisionedObjectField("cuProduct").SetRef(param.cuProduct.Split(':')[0], param.cuProduct.Split(':')[1], false);
            _input.DataField("cuQty").SetValue(param.cuQty);
            _input.DataField("cuRequestWOOnly").SetValue(true);
            _input.RevisionedObjectField("cuWorkflow").SetRef(param.cuWorkFlow.Split(':')[0], param.cuWorkFlow.Split(':')[1],false);
            var step = _input.NamedSubentityField("cuWorkflowStep");
            step.SetName(param.cuWorkFlowStep);
            step.RevisionedObjectField("__parent").SetRef(param.cuWorkFlow.Split(':')[0], param.cuWorkFlow.Split(':')[1], false);
            _input.NamedObjectField("cuWorkOrder").SetRef(param.cuWorkOrder);
            _input.NamedObjectField("Factory").SetRef(param.cuFactory);
            _helper.Execute();

            var re = _helper.RequestData();
            re.RequestField("CompletionMsg");
            re.RequestField("cuLayerAttachDetails");
            re.RequestField("cuReqWOOnly");
            var _rDocument = _helper.Submit();

            //var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);


            _rDocument.CheckErrors();

            _rDocument.CheckErrors(_result);
            if (_result.success)
            {
                string cuDeliveryOrderNo = ((ICsiDataField)_rDocument.GetService().ResponseData().FindChildByName("cuReqWOOnly")).GetValue();
                return new ResultModel<string>().Success(cuDeliveryOrderNo);
            }

            return _result;
        }

        /// <summary>
        /// 当前日期-世纪年日转JulianDate
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int ConvertToJulianDate(DateTime dt)
        {
            int yearday = Convert.ToInt32(dt.Year + "" + dt.DayOfYear.ToString().PadLeft(3, '0'));
            int jdeDate = yearday - 1900000;
            return jdeDate;
        }

        /// <summary>
        /// 当前日期-时分秒转JulianDate
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int ConvertToJulianTime(DateTime dt)
        {
            int jdeTime = Convert.ToInt32(dt.ToString("HHmmss"));
            return jdeTime;
        }

    }
}
