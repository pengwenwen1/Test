﻿using AutoMapper;
using Azure;
using Azure.Core.GeoJson;
using Camstar.XMLClient.Interface;
using Grpc.Core;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.Multek;
using Multek.Applications.Model.WIPMain;
using Multek.Applications.Services.CamstarApi;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Camstar.Constants;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Spire.Pdf.Exporting.XPS.Schema;
using Spire.Pdf.Lists;
using Spire.Presentation.Collections;
using Spire.Xls.Core.Interfaces;
using SqlSugar;
using SqlSugar.ClickHouse;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.DirectoryServices.Protocols;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static Multek.Applications.Model.Entities.Camstar.Dto.CuOARejectProcess;
using static Multek.Applications.Model.Entities.Camstar.Dto.cuStartDefect;

namespace Multek.Applications.Services.Impl.CamstarApi
{
    public class SDefect : EFHelper<MultekCamstarDbContext>, IDefect
    {
        public readonly ICamstarComm ICamstarComm;
        private readonly IMapper _mapper;
        public SDefect(MultekCamstarDbContext tdb, ICamstarComm camstarComm) : base(tdb)
        {
            ICamstarComm = camstarComm;
        }


        /// <summary>
        /// Camstar发起报废流程请求
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CuOA_RejectProcess(CuOARejectProcess cuOARejectProcesses)
        {
            //btnRefresh_Click();
            if (cuOARejectProcesses.mainTable.FD_FACTORYNAME == "B5" || cuOARejectProcesses.mainTable.FD_FACTORYNAME == "B1" || cuOARejectProcesses.mainTable.FD_FACTORYNAME == "B2F" || cuOARejectProcesses.mainTable.FD_FACTORYNAME == "BT")
            {
                //测试环境
                cuOARejectProcesses.workflowId = int.Parse("176241");
                ////正式环境
                //cuOARejectProcesses.workflowId = int.Parse("246241");
            }
            else if (cuOARejectProcesses.mainTable.FD_FACTORYNAME == "B3")
            {
                //测试环境
                cuOARejectProcesses.workflowId = int.Parse("206741");
                ////正式环境
                //cuOARejectProcesses.workflowId = int.Parse("302241");
            }
            else
            {
                return new ResultModel<string>().Failed("请检查工厂");
            }
            //测试环境
            HttpResponseMessage httpResponseMessage = WebApiHandler.PostOriginalAsync<CuOARejectProcess>("https://172.16.89.194:8081", "/process/auto/request", cuOARejectProcesses);
            //正式环境
            //HttpResponseMessage httpResponseMessage = WebApiHandler.PostOriginalAsync<CuOARejectProcess>("http://172.16.89.193:8081", "/process/auto/request", cuOARejectProcesses);
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                //// 记录调用信息
                //new IntTable(DataAccess.EDatabaseType.ReadWrite).InserLogData(cuOARejectProcesses.mainTable.FD_BH, MethodInfo.GetCurrentMethod().Name);
                //处理OA返回信息
                string _resultStr = httpResponseMessage.Content.ReadAsStringAsync().Result;
                ResultModel<string> _resultModel = JsonConvert.DeserializeObject<ResultModel<string>>(_resultStr);
                if (!_resultModel.success)
                {
                    //ExceptionEmailSender.RecordLog(string.Format("@CUMES(I) Exception Message[OA报废返回异常][0]", IPAddressHelper.GetComputerName()),
                    //    string.Format("请求数据<BR>{0}<BR> 返回信息<BR>{1}<BR>", JsonConvert.SerializeObject(cuOARejectProcesses), _resultStr));
                }
                return _resultModel;
            }
            else
            {
                //ExceptionEmailSender.RecordLog(string.Format("@CUMES(I) Exception Message[访问OA网络异常][0]", IPAddressHelper.GetComputerName()), JsonConvert.SerializeObject(cuOARejectProcesses) + httpResponseMessage.ReasonPhrase);
                return new ResultModel<string>().Failed("访问OA异常：" + httpResponseMessage.ReasonPhrase);
            }
        }

        /// <summary>
        /// 获取报废信息
        /// </summary>
        /// <param name="cuOARejectInfo"></param>
        /// <returns></returns>
        public IResultModel RefreshDefectInfo(CuOARejectInfo cuOARejectInfo)
        {
            #region 开始处理
            //卡控当前登录人员不能使用公共账号
            if (cuOARejectInfo.EmployeeNo.Contains("MCN_B5") || cuOARejectInfo.EmployeeNo.Contains("MCN_B1") || cuOARejectInfo.EmployeeNo.Contains("MCN_B2F"))
            {
                return new ResultModel<string>().Failed($"不能使用公共账号提交报废,请使用个人帐号重新登录系统再操作！！！!");
            }
            #region  查出当前登录人员对应工厂
            FormattableString sqlstr = $@" 
                            select f.factoryname,f.factoryid from employee e 
                            inner join sessionvalues sv on sv.employeeid = e.employeeid
                            inner join factory f on f.factoryid = sv.factoryid
                            where e.employeename={cuOARejectInfo.EmployeeNo} ";
            List<Factory> result = db.Factories.FromSql<Factory>(sqlstr).ToList();

            if (result == null && result.Count <= 0) return new ResultModel<string>().Failed("没有查询到当前登录人员对应工厂");
            string FactoryNameA = result[0].FactoryName;
            #endregion
            //根据所有的Lot列表 查询PN 的单位面积 PCS数量
            List<string> QueryStr = new List<string>();
            foreach (var detailItem in cuOARejectInfo.detailTable)
            {
                QueryStr.Add(detailItem.cuLotNo);
            }
            List<cuOARejectTable> containerResult = (from c in db.Containers
                                                        join p in db.Products on c.ProductId equals p.ProductId
                                                        join pb in db.ProductBases on p.ProductBaseId equals pb.ProductBaseId
                                                        join cs in db.CurrentStatus on c.currentStatusId equals cs.CURRENTSTATUSID
                                                        join mo in db.Mfgorders on c.cuWorkOrderId equals mo.MFGORDERID
                                                        join os in db.OrderStatus on mo.OrderStatusId equals os.OrderStatusId
                                                        join wfs in db.WorkFlowSteps on cs.WorkFlowStepId equals wfs.WorkFlowStepId
                                                        join wf in db.WorkFlows on wfs.WorkFlowId equals wf.WorkFlowId
                                                        join wfb in db.WorkFlowBases on wf.WorkFlowBaseId equals wfb.WorkFlowBaseId
                                                        join cuoem in db.Cuoems on p.CUOEMID equals cuoem.CUOEMID
                                                        join f in db.Factories on mo.cuFactoryId equals f.FactoryId
                                                        where QueryStr.Contains(c.ContainerName)
                                        select new cuOARejectTable()
                                        {
                                            cuLotNo = c.ContainerName,
                                            cuPCSArea = p.cuPCSArea,
                                            cuPCSPerPNL = p.cuPCSPerPNL,
                                            cuPNLArea = p.cuPNLArea,
                                            productName = pb.ProductName,
                                            PRODUCTREVISION = p.PRODUCTREVISION,
                                            mfgOrder = mo.MfgorderName,
                                            workFlowName = wfb.WorkFlowName,
                                            workflowStep = wfs.WorkFlowStepName,
                                            cuPCSQty = c.QTY.ToString(),
                                            cuPanelQty = c.QTY2.ToString(),
                                            CUTRACKFLAG = c.CUTRACKFLAG,
                                            CURRENTHOLDCOUNT = c.CURRENTHOLDCOUNT,
                                            cuStampcode = mo.CUSTAMPCODE,
                                            OUTER = p.CuMI_PN.Substring(p.CuMI_PN.Length - 1, 2).ToString() == "00" ? "Outer" : "Inner",
                                            DESCRIPTION = cuoem.DESCRIPTION,
                                            Cuoemname = cuoem.CUOEMNAME,
                                            FACTORYNAME = f.FactoryName,
                                            CUECNSTATUS = c.CUECNSTATUS,
                                            ORDERSTATUSNAME = os.ORDERSTATUSNAME,
                                            status = c.status
                                        }).ToList();
                   
            if (containerResult != null && containerResult.Count > 0)
            {
                foreach (var drDetail in containerResult)
                {
                    foreach (var dr in cuOARejectInfo.detailTable)
                    {
                        if (dr.cuDefectType.ToString() == "1")//报废类型填写”1“时,数量是1PNL ，1*CUPCSPERPNL pcs
                        {
                            dr.cuPCSQty = drDetail.cuPCSPerPNL;
                            dr.cuPanelQty = "1";
                        }
                        if (dr.cuDefectType.ToString() == "3" && string.IsNullOrEmpty(dr.cuPanelQty.ToString()))//报废类型填写”3“时数量填写PNL栏
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo + ","+"定义的报废类型与报废数量不一致，请确认！");
                        }
                        if (dr.cuDefectType.ToString() == "4"  && string.IsNullOrEmpty(dr.cuPCSQty.ToString()))//报废类型填”4“时数量填PCS栏
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo + "," + "定义的报废类型与报废数量不一致，请确认！");
                        }
                        if ((dr.cuDefectType.ToString() == "3" || dr.cuDefectType.ToString() == "4") && string.IsNullOrEmpty(dr.cuPanelQty.ToString()) && string.IsNullOrEmpty(dr.cuPCSQty.ToString()))//数量为空
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo + "," + "报废数量不能为空，请确认！");
                        }
                        if (string.IsNullOrEmpty(dr.cuDefectType.ToString()))//报废类型为空
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo + "," + "定义的报废类型不能为空，请确认！");
                        }
                        if (string.IsNullOrEmpty(dr.cuLossReason.ToString()) || dr.cuLossReason.ToString().IndexOf(".") > 0)//缺陷代码为空或者包含小数点的错误格式
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo + "," + "缺陷代码不能为空，请确认！");
                        }
                        if (string.IsNullOrEmpty(dr.cuProcesSpec.ToString()) || dr.cuProcesSpec.ToString().Contains("."))//责任工序代码为空或者包含小数点的错误格式
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo + "," + "责任工序代码不能为空，请确认！");
                        }
                        if (dr.cuLotNo.ToString() == drDetail.cuLotNo.ToString())
                        {
                            dr.cuPCSArea = drDetail.cuPCSArea;
                            //取pnl面积20210721
                            dr.cuPNLArea = drDetail.cuPNLArea;
                            dr.cuPCSPerPNL = drDetail.cuPCSPerPNL;
                            dr.productName = drDetail.productName;
                            dr.PRODUCTREVISION = drDetail.PRODUCTREVISION;
                            dr.workFlowName = drDetail.workFlowName;
                            dr.mfgOrder = drDetail.mfgOrder;
                            dr.workflowStep = drDetail.workflowStep;
                            dr.cuStampcode = drDetail.cuStampcode;
                            dr.CURRENTHOLDCOUNT = drDetail.CURRENTHOLDCOUNT;
                            dr.OUTER = drDetail.OUTER;
                            dr.DESCRIPTION = drDetail.DESCRIPTION;
                            dr.FACTORYNAME = drDetail.FACTORYNAME;
                            dr.CUECNSTATUS = drDetail.CUECNSTATUS;
                            dr.Cuoemname = drDetail.Cuoemname;
                            dr.ORDERSTATUSNAME = drDetail.ORDERSTATUSNAME;


                            if (drDetail.workflowStep.ToString() == "PAOI_M")
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "WIP在PAOI工序，PAOI工序不能执行报废申请，请确认！");
                            }
                            else if (drDetail.workflowStep.ToString().Contains("成品") || drDetail.workflowStep.ToString().Contains("MAL") || drDetail.workflowStep.ToString().Contains("PAOI"))
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "WIP在MAL / PAOI / 半成品 / 成品仓工序，MAL / PAOI / 半成品 / 成品仓工序不能执行报废申请，请确认！");  
                            }
                            if (!string.IsNullOrEmpty(dr.cuPCSQty.ToString()))
                            {
                                decimal TotalPCSQty = 0;
                                foreach (var dd in cuOARejectInfo.detailTable)
                                {
                                    if (dr.cuLotNo.ToString() == dd.cuLotNo.ToString())
                                    {
                                        if (string.IsNullOrEmpty(dd.cuPCSQty)) { dd.cuPCSQty = "0"; }
                                        TotalPCSQty = Convert.ToDecimal(dd.cuPCSQty) + TotalPCSQty;
                                    }
                                }
                                if (TotalPCSQty > Convert.ToDecimal(drDetail.cuPCSQty))
                                {
                                    return new ResultModel<string>().Failed(dr.cuLotNo + "," + "报废PCS数量大于原Lot数，请确认！");
                                }
                            }
                            if (!string.IsNullOrEmpty(dr.cuPanelQty))
                            {
                                decimal TotalPanelQty = 0;
                                foreach (var dd in cuOARejectInfo.detailTable)
                                {
                                    if (dr.cuLotNo.ToString() == dd.cuLotNo.ToString())
                                    {
                                        if (string.IsNullOrEmpty(dd.cuPanelQty)) { dd.cuPanelQty = "0"; }
                                        TotalPanelQty = Convert.ToDecimal(dd.cuPanelQty) + TotalPanelQty;
                                    }
                                }
                                if (TotalPanelQty > Convert.ToDecimal(drDetail.cuPanelQty))
                                {
                                    return new ResultModel<string>().Failed(dr.cuLotNo + "," + "报废PNL数量大于原Lot数，请确认！");
                                }
                            }
                            if (drDetail.CURRENTHOLDCOUNT.ToString() != "0")
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "已经Hold，不能执行报废申请，请确认！");
                            }
                            if (drDetail.CUTRACKFLAG.ToString() == "1" || drDetail.CUTRACKFLAG.ToString() == "2")
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "在上机状态，不能执行报废申请，请确认！");
                            }
                            if (string.IsNullOrEmpty(dr.cuworkflowStep.ToString()))
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "WIP结存工站不能为空，请填写！");
                            }
                            if (dr.cuworkflowStep.ToString().Trim() != drDetail.workflowStep.ToString())
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "WIP不在当前工序，不能提报废，请确认！");
                            }
                            if (dr.FACTORYNAME.ToString() != FactoryNameA)//不允许提交其他厂区的报废
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "不是您所在厂区的批次，不允许提交报废，请确认！");
                            }
                            if (!string.IsNullOrEmpty(dr.CUECNSTATUS))//做了ECN或ERC的，没有重打LOT卡不允许提交报废
                            {
                                if (dr.CUECNSTATUS.ToString() == "1") { return new ResultModel<string>().Failed(dr.cuLotNo + "," + "执行完ECN或ERC未重打LOT卡，不允许提交报废，请确认！"); }
                            }
                            if ((dr.FACTORYNAME.ToString() == "B5" || dr.FACTORYNAME.ToString() == "B1" || dr.FACTORYNAME.ToString() == "B2F") && dr.Cuoemname.ToString() == "581" && dr.OUTER.ToString() == "Outer" && string.IsNullOrEmpty(dr.cuPanelPCSNo.ToString()))//B5,B1,B2F的华为型号提交报废单时外层卡PCS/PNL码栏位无内容不允许提交
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "华为型号的PCS/PNL码栏位无内容时，不允许提交报废，请确认！");
                            }
                            if (dr.ORDERSTATUSNAME.ToString() == "40")//工单40状态不允许打报废
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "工单40状态不允许提交报废，请确认！");
                            }
                            if (drDetail.status.ToString() != "1")
                            {
                                return new ResultModel<string>().Failed(dr.cuLotNo + "," + "批次状态不是活动的，不允许提报废，请进行确认！");
                            }
                        }
                    }
                }
            }
            else 
            {
                return new ResultModel<string>().Failed("查询信息失败");
            }


            //已经查出缺陷描述 反写dataTable
            FormattableString lossReasonSql = $@" 
                            SELECT Lossreason.Lossreasonname, Lossreason.Description,Lossreason.lossreasonid FROM Lossreason";
            List<Lossreason> lossreasonResult = db.lossreasons.FromSql<Lossreason>(lossReasonSql).ToList();
            if (lossreasonResult != null && lossreasonResult.Count > 0)
            {
                foreach (var drLossreason in lossreasonResult)
                {
                    foreach (var dr in cuOARejectInfo.detailTable)
                    {
                        if (dr.cuLossReason.ToString() == drLossreason.Lossreasonname.ToString())
                        {
                            dr.DefectDesc = drLossreason.Description;
                        }
                    }
                }
            }

            //已经查出责任工序 反写dataTable
            FormattableString procesSpecsql = $@" 
                            select cuProcesSpecName,DESCRIPTION from cuProcesSpec ";
            List<cuProcesSpec> procesSpecResult = db.cuProcesSpecs.FromSql<cuProcesSpec>(procesSpecsql).ToList();

            if (procesSpecResult != null && procesSpecResult.Count > 0)
            {
                foreach (var drProcesSpec in procesSpecResult)
                {
                    foreach (var dr in cuOARejectInfo.detailTable)
                    {
                        if (dr.cuProcesSpec.ToString() == drProcesSpec.cuProcesSpecName.ToString())
                        {
                            dr.ProcesDesc = drProcesSpec.DESCRIPTION;
                        }
                    }
                }
            }
            //检查填写的工号是否一致;样板和生产板请分开提单;内、外层批次不能在同一张MRB单进行提交申请
            foreach (var dr in cuOARejectInfo.detailTable)
            {
                foreach (var dd in cuOARejectInfo.detailTable)
                {
                    if (string.IsNullOrEmpty(dr.cuEmployeeNo.ToString().Trim()) != string.IsNullOrEmpty(dd.cuEmployeeNo.ToString().Trim()))
                    {
                        return new ResultModel<string>().Failed("同一张报废单的员工工号必须填写一致！");
                    }
                    //B2F样板型号首位是8，9，P   其他厂Q,H
                    var aa = dr.productName.ToString().Trim().Substring(0, 1);
                    var bb = dd.productName.ToString().Trim().Substring(0, 1);
                    List<string> list1 = new List<string>() { "8", "9", "P" };
                    List<string> list2 = new List<string>() { "Q", "H" };
                    //var isContain = list1.Contains(aa);
                    if (dr.FACTORYNAME.ToString() == "B2F" && dd.cuLotNo.ToString() != dr.cuLotNo.ToString() && (list1.Contains(aa) && !list1.Contains(bb)))
                    {
                        return new ResultModel<string>().Failed("样板和生产板请分开提单！");
                    }
                    if (dr.FACTORYNAME.ToString() == "B1" && dr.cuLotNo.ToString() != dd.cuLotNo.ToString() && (list2.Contains(aa) && !list2.Contains(bb)))
                    {
                        return new ResultModel<string>().Failed("样板和生产板请分开提单！");
                    }
                    if (string.IsNullOrEmpty(dr.OUTER.ToString().Trim()) != string.IsNullOrEmpty(dd.OUTER.ToString().Trim()))
                    {
                        return new ResultModel<string>().Failed("内、外层批次不能在同一张MRB单进行提交申请！");
                    }

                }
            }
            string strCuScrapType = "";
            string strLossReason = "";
            string strProcesSpec = "";
            string strLotNo = "";
            //将dt里的数据按照cuDefectType进行区分124为PCSQty*Area 3 为PNL*Area
            foreach (var dr in cuOARejectInfo.detailTable)
            {
                // 检验LOT是否存在 
                if (dr.cuLotNo != null)
                    strLotNo = dr.cuLotNo.ToString();
                if (!string.IsNullOrEmpty(strLotNo))
                {
                    List<string> DescResult = (from r in db.Containers where r.ContainerName.Equals(strLotNo)
                    select r.ContainerName).ToList<string>();
                    if (DescResult == null && DescResult.Count <= 0)
                    {
                        return new ResultModel<string>().Failed("请检查输入的批次 " + dr.cuLotNo.ToString() + " 是否存在或者输入格式是否错误！");
                    }
                }
                //报废类型
                if (dr.cuScrapType != null)
                    strCuScrapType = dr.cuScrapType.ToString();
                if (!string.IsNullOrEmpty(strCuScrapType))
                {
                    FormattableString sqlDesc = $@" 
                            SELECT T.DESCRIPTION FROM CUSCRAPTYPE T WHERE T.CUSCRAPTYPENAME ={strCuScrapType}";
                    List<CuScraptype> DescResult = db.cuScraptypes.FromSql<CuScraptype>(sqlDesc).ToList();
                    if (DescResult != null && DescResult.Count > 0)
                    {
                        dr.cuScrapTypeDesp = DescResult[0].DESCRIPTION.ToString();
                    }
                    else
                    {
                        return new ResultModel<string>().Failed("请检查输入的报废类型(Scap Type) " + dr.cuScrapTypeDesp.ToString() + " 是否存在！");
                    }
                }
                // 检验缺陷代码是否存在 
                if (dr.cuLossReason != null)
                    strLossReason = dr.cuLossReason.ToString();
                if (!string.IsNullOrEmpty(strLossReason))
                {
                    FormattableString sqlDesc = $@" 
                            SELECT Lossreason.Lossreasonname, Lossreason.Description,Lossreason.lossreasonid FROM Lossreason WHERE Lossreason.Lossreasonname ={strLossReason}";
                    List<Lossreason> lossResult = db.lossreasons.FromSql<Lossreason>(sqlDesc).ToList();
                    if (lossResult == null && lossResult.Count < 1)
                    {
                        return new ResultModel<string>().Failed("请检查输入的缺陷代码 " + dr.cuLossReason.ToString() + " 是否存在或者输入格式是否错误！");
                    }
                }
                // 检验责任工序代码是否存在 
                if (dr.cuProcesSpec != null)
                    strProcesSpec = dr.cuProcesSpec.ToString();
                if (!string.IsNullOrEmpty(strProcesSpec))
                {
                    FormattableString checkProcesSpecSql = $@" 
                            select cuProcesSpecName,DESCRIPTION from cuProcesSpec WHERE cuProcesSpecName ={strProcesSpec} ";
                    List<cuProcesSpec> checkProcesSpecResult = db.cuProcesSpecs.FromSql<cuProcesSpec>(checkProcesSpecSql).ToList();

                    if (checkProcesSpecResult == null && checkProcesSpecResult.Count <1)
                    {
                        return new ResultModel<string>().Failed("请检查输入的责任工序代码 " + dr.cuProcesSpec.ToString() + " 是否存在或者输入格式是否错误！");
                    }
                }
                if (dr.cuDefectType.ToString() == "1")
                {
                    if (!string.IsNullOrEmpty(dr.cuPCSArea.ToString()) && !string.IsNullOrEmpty(dr.cuPCSQty.ToString()))
                    {
                        //PCS * cuPCSArea
                        dr.cuTotalArea = (double.Parse(dr.cuPCSArea.ToString()) * double.Parse(dr.cuPCSQty.ToString())).ToString();
                    }
                }
                else if (dr.cuDefectType.ToString() == "2")
                {
                    if (!string.IsNullOrEmpty(dr.cuPCSArea.ToString()) && !string.IsNullOrEmpty(dr.cuPCSQty.ToString()))
                    {
                        //PCS * cuPCSArea
                        dr.cuTotalArea = (double.Parse(dr.cuPCSArea.ToString()) * double.Parse(dr.cuPCSQty.ToString())).ToString();
                    }
                }
                else if (dr.cuDefectType.ToString() == "3")
                {
                    if (!string.IsNullOrEmpty(dr.cuPNLArea.ToString()) && !string.IsNullOrEmpty(dr.cuPCSPerPNL.ToString()))
                    {
                        //cuPCSPerPNL * cuPCSArea * cuPanelQty
                        dr.cuPCSQty = (double.Parse(dr.cuPanelQty.ToString()) * double.Parse(dr.cuPCSPerPNL.ToString())).ToString();
                        //计算报废面积，PNL面积/cuPCSPerPNL*PCS数
                        dr.cuTotalArea = (double.Parse(dr.cuPNLArea.ToString()) * (double.Parse(dr.cuPCSQty.ToString())) / double.Parse(dr.cuPCSPerPNL.ToString())).ToString();
                    }
                }
                else if (dr.cuDefectType.ToString() == "4")
                {
                    if (!string.IsNullOrEmpty(dr.cuPNLArea.ToString()) && !string.IsNullOrEmpty(dr.cuPCSQty.ToString()))
                    {
                        //PCS * cuPCSArea
                        dr.cuTotalArea = (double.Parse(dr.cuPNLArea.ToString()) * (double.Parse(dr.cuPCSQty.ToString())) / double.Parse(dr.cuPCSPerPNL.ToString())).ToString();
                    }
                }

                //计算同工单同缺陷累计报废数量
                string strmfgorder = "";
                string strlossreasonname = "";
                string strproductname = "";
                if (dr.mfgOrder != null)
                    strmfgorder = dr.mfgOrder.ToString();
                if (dr.cuLossReason != null)
                    strlossreasonname = dr.cuLossReason.ToString();
                if (dr.productName != null)
                    strproductname = dr.productName.ToString();
                if (!string.IsNullOrEmpty(strmfgorder) && !string.IsNullOrEmpty(strlossreasonname))
                {
                    string sqlBaofei = $@" 
                    select sum (dbd.cuPCSArea) DefectArea 
                    from cudefectrecord dc  
                    inner join cuDefectBackDetails dbd on dbd.cudefectrecordid = dc.cudefectrecordid  
                    left join Container C on dbd.culotid = c.containerid 
                    left join mfgorder mo on c.cuworkorderid = mo.mfgorderid 
                    left join cuproductiontype cpt on mo.cuproductiontypeid = cpt.cuproductiontypeid  
                    left join lossreason lr on dbd.culossreasonid = lr.lossreasonid 
                    left join Product p on c.productid = p.productid  
                    left join ProductBase pb on p.productbaseid = pb.productbaseid  
                    where dc.custatus='2'  and mo.mfgordername='{strmfgorder}'   and lr.lossreasonname='{strlossreasonname}'";

                    var dtBaofeiResult = db.GetTable(sqlBaofei);
                    if (dtBaofeiResult != null && dtBaofeiResult.Rows.Count > 0)
                     {
                        dr.cuDefectArea = dtBaofeiResult.Rows[0][0].ToString();
                        //不含本次报废面积
                        dr.cuDefectTotalArea = double.Parse(string.IsNullOrEmpty(dr.cuDefectArea.ToString()) ? "0" : dr.cuDefectArea.ToString()).ToString();
                        //含本次报废面积
                        dr.cuNewDefectTotalArea = (double.Parse(string.IsNullOrEmpty(dr.cuDefectArea.ToString()) ? "0" : dr.cuDefectArea.ToString()) + double.Parse(dr.cuTotalArea.ToString())).ToString();
                    }
                    else
                    {
                        dr.cuDefectArea = "";
                        dr.cuDefectTotalArea = "0";
                        dr.cuNewDefectTotalArea = double.Parse(dr.cuTotalArea.ToString()).ToString();
                    }
                    if (FactoryNameA == "B5" && Convert.ToDouble(dr.cuNewDefectTotalArea.ToString()) > 20 && dr.OUTER.ToString() == "Inner")
                    {
                        return new ResultModel<string>().Failed("同型号同工单同缺陷累计报废数量超过60尺！请确认是否继续报废，如继续报废可忽略此提示！");
                    }
                    if (FactoryNameA == "B5" && Convert.ToDouble(dr.cuNewDefectTotalArea.ToString()) > 60 && dr.OUTER.ToString() == "Outer")
                    {
                        return new ResultModel<string>().Failed("同型号同工单同缺陷累计报废数量超过20尺！请确认是否继续报废，如继续报废可忽略此提示！");
                    }
                    if (FactoryNameA == "B1" && Convert.ToDouble(dr.cuNewDefectTotalArea.ToString()) > 20)
                    {
                        return new ResultModel<string>().Failed("同型号同工单同缺陷累计报废数量超过20尺！请确认是否继续报废，如继续报废可忽略此提示！");
                    }
                    if (FactoryNameA == "B2F" && Convert.ToDouble(dr.cuNewDefectTotalArea.ToString()) > 10)
                    {
                        return new ResultModel<string>().Failed("同型号同工单同缺陷累计报废数量超过10尺！请确认是否继续报废，如继续报废可忽略此提示！");
                    }
                }
            }
            #endregion
            //gridDetails.Data = dt;
            // 超尺报废和未超尺报废不能同时提交报废（B5: 外层：> 20尺，内层 > 60  B1: 内外层 > 20);样板不走这段逻辑
            var cc = cuOARejectInfo.detailTable[0].productName.ToString().Trim().Substring(0, 1);
            if (cc != "8" || cc != "9" || cc != "P" || cc != "Q" || cc != "H")
            {
                foreach (var dr in cuOARejectInfo.detailTable)
                {
                    foreach (var dd in cuOARejectInfo.detailTable)
                    {
                        if (FactoryNameA == "B1" && ((Convert.ToDouble(dr.cuDefectTotalArea.ToString()) > 20 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) <= 20) || (Convert.ToDouble(dr.cuDefectTotalArea.ToString()) <= 20 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) > 20)))
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo.ToString() + ',' + dd.cuLotNo + ",超尺报废和未超尺报废不能同时提交报废！");
                        }
                        else if (FactoryNameA == "B5" && dr.OUTER.ToString() == "Outer" && ((Convert.ToDouble(dr.cuDefectTotalArea.ToString()) > 20 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) <= 20) || (Convert.ToDouble(dr.cuDefectTotalArea.ToString()) <= 20 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) > 20)))
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo.ToString() + ',' + dd.cuLotNo + ",超尺报废和未超尺不能同时提交报废！");
                        }
                        else if (FactoryNameA == "B5" && dr.OUTER.ToString() == "Inner" && ((Convert.ToDouble(dr.cuDefectTotalArea.ToString()) > 60 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) <= 60) || (Convert.ToDouble(dr.cuDefectTotalArea.ToString()) <= 60 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) > 60)))
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo.ToString() + ',' + dd.cuLotNo + ",超尺报废和未超尺报废不能同时提交报废！");
                        }
                        else if (FactoryNameA == "B2F" && ((Convert.ToDouble(dr.cuDefectTotalArea.ToString()) > 10 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) <= 10) || (Convert.ToDouble(dr.cuDefectTotalArea.ToString()) <= 72 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) > 72) || ((Convert.ToDouble(dr.cuDefectTotalArea.ToString()) <= 10 || Convert.ToDouble(dr.cuDefectTotalArea.ToString()) > 72) && (Convert.ToDouble(dd.cuDefectTotalArea.ToString()) > 10 && Convert.ToDouble(dd.cuDefectTotalArea.ToString()) <= 72))))
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo.ToString() + ',' + dd.cuLotNo + ",超尺报废和未超尺不能同时提交报废！");
                        }
                    }
                }
            }
            return new ResultModel<CuOARejectInfo>().Success(cuOARejectInfo);
                
        }

        /// <summary>
        /// 提交报废
        /// </summary>
        /// <param name="cuOARejectInfo"></param>
        /// <returns></returns>
        public IResultModel SubmitDefect(CuOARejectInfo cuOARejectInfo)
        {
            ResultModel<string> _resultModel = new ResultModel<string>();
            if (cuOARejectInfo == null && cuOARejectInfo.detailTable.Count < 1)
            {
                return new ResultModel<string>().Failed("Grid Data is Null");
            }
            cuStartDefect defect = new cuStartDefect();
            #region  查出当前登录人员对应工厂
            FormattableString sqlstr = $@" 
                            select f.factoryname,f.factoryid from employee e 
                            inner join sessionvalues sv on sv.employeeid = e.employeeid
                            inner join factory f on f.factoryid = sv.factoryid
                            where e.employeename={cuOARejectInfo.EmployeeNo} ";
            List<Factory> result = db.Factories.FromSql<Factory>(sqlstr).ToList();

            if (result == null && result.Count <= 0) return new ResultModel<string>().Failed("没有查询到当前登录人员对应工厂");
            string FactoryName = result[0].FactoryName;
            FactoryName = string.IsNullOrEmpty(FactoryName) ? "default" : FactoryName;
            #endregion
            string strDefectRecordName = "MRB_" + FactoryName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
            defect.cuDefectRecordName = strDefectRecordName;
            defect.cuFactoryName = FactoryName;
            defect.cuEmployeeNo = cuOARejectInfo.EmployeeNo.ToString();
            defect.cuHoldReason = "DEFECT";
            List<cuStartDefectDetails> details = new List<cuStartDefectDetails>();
            if ((FactoryName == "B5" || FactoryName == "B1") && cuOARejectInfo.detailTable.Count > 20)
            {
                return new ResultModel<string>().Failed("提交报废数量不能超过20条，请确认！");
            }
            else if (FactoryName == "B2F" && cuOARejectInfo.detailTable.Count > 50)
            {
                return new ResultModel<string>().Failed("提交报废数量不能超过50条，请确认！");
            }
            //B3计算当前报废单的同批次报废平方数，以下三种情况不能同时存在一个报废单中：
            //1、每LOT单个缺陷报废报废累计 < 150平方尺的报废
            //2、每LOT单个缺陷报废累计大于等于150且小于等于250平方尺的报废
            //3、每LOT单个缺陷报废累计大于250平方尺的报废
            if (FactoryName == "B3")
            {
                //将报废面积放在LIST中
                List<double> Area = new List<double>();
                double LotArea = 0;
                double TotalLotArea = 0;
                foreach (var dr in cuOARejectInfo.detailTable)
                {
                    foreach (var dd in cuOARejectInfo.detailTable)
                    {
                        if ((dr.mfgOrder.ToString() == dd.mfgOrder.ToString()) && (dr.cuLossReason.ToString() == dd.cuLossReason.ToString()))
                        {
                            LotArea = Convert.ToDouble(dd.cuTotalArea.ToString().Trim()) + LotArea;
                        }
                    }
                    if (!String.IsNullOrEmpty(dr.cuDefectArea.ToString()))
                    {
                        TotalLotArea = Convert.ToDouble(dr.cuDefectArea.ToString().Trim()) + LotArea;
                    }
                    else
                    {
                        TotalLotArea = LotArea;
                    }
                    Area.Add(TotalLotArea);
                    LotArea = 0;
                    TotalLotArea = 0;
                }
                //以第一个面积为标准，和其他面积比对是否在一个范围
                int min = 0;
                int med = 0;
                int max = 0;
                Double firstAear = Area[0];
                if (firstAear < 150)
                {
                    min = 1;
                }
                else if ((firstAear >= 150) && (firstAear <= 250))
                {
                    med = 1;
                }
                else if (firstAear > 250)
                {
                    max = 1;
                }
                for (int n = 0; n < Area.Count; n++)
                {
                    if (min == 1)
                    {
                        if (Area[n] < 150)
                        {
                        }
                        else
                        {
                            return new ResultModel<string>().Failed("同工单同缺陷报废累计面积（含本次）需要在同一范围内，请检查数据");
                        }
                    }
                    else if (med == 1)
                    {
                        if ((Area[n] >= 150) && (Area[n] <= 250))
                        {

                        }
                        else
                        {
                            return new ResultModel<string>().Failed("同工单同缺陷报废累计面积（含本次）需要在同一范围内，请检查数据");
                        }
                    }
                    else if (max == 1)
                    {
                        if (Area[n] > 250)
                        {

                        }
                        else
                        {
                            return new ResultModel<string>().Failed("同工单同缺陷报废累计面积（含本次）需要在同一范围内，请检查数据");
                        }
                    }
                }
            }
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuStartDefect");
            var _input = _helper.InputData();
            _input.DataField("cuDefectRecordName").SetValue(strDefectRecordName);
            _input.DataField("cuEmployeeNo").SetValue(cuOARejectInfo.EmployeeNo);
            _input.DataField("cuFactoryName").SetValue(FactoryName);
            _input.NamedObjectField("cuHoldReason").SetRef("DEFECT");
            var detail = _input.SubentityList("cuStartDefectDetails");
            foreach (var dr in cuOARejectInfo.detailTable)
            {
                StringBuilder _errorHold = new StringBuilder();
                if (!string.IsNullOrEmpty(dr.cuLotNo.ToString()))
                {
                    string strcuLotNo = dr.cuLotNo.ToString();
                    List<string> containerResult = (from c in db.Containers
                                                    where c.ContainerName.Equals(strcuLotNo)
                                                    select c.CURRENTHOLDCOUNT).Distinct().ToList();
                    if (containerResult != null && containerResult.Count > 0)
                    {
                        dr.CURRENTHOLDCOUNT = containerResult[0].ToString();
                        if (dr.CURRENTHOLDCOUNT.ToString() != "0")
                        {
                            return new ResultModel<string>().Failed(dr.cuLotNo + "已经Hold，不能执行报废申请，请确认！");
                        }
                    }
                }
                if (string.IsNullOrEmpty(dr.cuLotNo.ToString()))
                {
                    return new ResultModel<string>().Failed(dr.cuLotNo + "报废批次不能为空");
                }
                if (string.IsNullOrEmpty(dr.cuPCSQty.ToString()))
                {
                    return new ResultModel<string>().Failed(dr.cuLotNo + "cuPCSQty不能为空");
                }
                if (Convert.ToDouble(dr.cuPCSQty.ToString()) <= 0)
                {
                    return new ResultModel<string>().Failed(dr.cuLotNo + "报废数量不能小于等于0，请重新核实！");
                }
                if (string.IsNullOrEmpty(dr.cuTotalArea.ToString()))
                {
                    return new ResultModel<string>().Failed(dr.cuLotNo + "cuTotalArea不能为空");
                }
                //B3的需要填写工号
                if (FactoryName == "B3" && string.IsNullOrEmpty(dr.cuEmployeeNo.ToString().Trim()))
                {
                    return new ResultModel<string>().Failed(dr.cuLotNo + "工号不能为空，请填写您的工号");
                }
                var list = detail.AppendItem();
                list.DataField("cuDefectTotalArea").SetValue(float.Parse(dr.cuDefectTotalArea.ToString()));
                list.DataField("cuDefectType").SetValue(dr.cuDefectType);
                list.DataField("cuDescription").SetValue(dr.DESCRIPTION);
                list.DataField("cuEmployeeNo").SetValue(dr.cuEmployeeNo);
                list.NamedObjectField("cuLossReason").SetRef(dr.cuLossReason);
                list.NamedObjectField("cuLot").SetRef(dr.cuLotNo);
                list.DataField("cuPanelPCSNo").SetValue(dr.cuPanelPCSNo);
                list.DataField("cuPanelQty").SetValue((float)(string.IsNullOrEmpty(dr.cuPanelQty.ToString()) ? 0 : double.Parse(dr.cuPanelQty.ToString())));
                list.DataField("cuPCSArea").SetValue(float.Parse(dr.cuTotalArea.ToString()));
                list.DataField("cuPCSQty").SetValue(float.Parse(dr.cuPCSQty.ToString()));
                list.NamedObjectField("cuProcesSpec").SetRef(dr.cuProcesSpec);
                if (!string.IsNullOrEmpty(dr.cuScrapType.ToString())) { list.NamedObjectField("cuScrapType").SetRef(dr.cuScrapType); }
                list.NamedObjectField("cuTrackingLevel").SetRef(dr.cuTrackingLevel);
            }
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            if (_error.success)
            {
                CuOARejectProcess Info = new CuOARejectProcess();
                Info.creator = cuOARejectInfo.EmployeeNo; //增加创建人
                DateTime dateTime = new DateTime();
                dateTime = System.DateTime.Now;

                //表头
                maintable head = new maintable();
                head.FD_BH = strDefectRecordName;//报废单号
                head.FD_SQR = cuOARejectInfo.EmployeeNo;//填写人(流程MRB预审员）
                head.FD_RQ = dateTime.ToString("yyyy-MM-dd");//日期
                head.FD_BFYY = "";//报废原因；非必填
                head.FD_GSCS = "";//改善措施；非必填
                head.FD_FACTORYNAME = FactoryName;
                head.FD_CUEMPLOYEENO = cuOARejectInfo.EmployeeNo.ToString();

                int i = 1;
                List<RejectProcessdetailTable> bodydeatail = new List<RejectProcessdetailTable>();
                foreach (var drt in cuOARejectInfo.detailTable)
                {
                    string MX_PanS = string.IsNullOrEmpty(drt.cuPanelQty.ToString()) ? "0" : drt.cuPanelQty.ToString();
                    if (drt.cuDefectType.ToString() == "4")
                    {
                        MX_PanS = null;
                    }
                    //item
                    RejectProcessdetailTable itemnew = new RejectProcessdetailTable
                    {
                        MX_WorkOrder = drt.mfgOrder.ToString(),//工单号
                        MX_GX = drt.workflowStep.ToString(),//工序
                        MX_CPBH = drt.productName.ToString(),//产品编号
                        MX_SCPH = drt.cuLotNo.ToString(),//生产批号
                        MX_PPH = drt.cuPanelPCSNo.ToString(),//dr["cuPanelPCSNo"].ToString(),//Panel/PCS号
                        MX_QXDM = drt.cuLossReason.ToString(),//缺陷代码
                        MX_PanS = MX_PanS,//Panel数
                        MX_PCSS = drt.cuPCSQty.ToString(),//PCS数
                        MX_QXMC = drt.DefectDesc.ToString(),//缺陷名称
                        MX_BZ = "MES报废",//备注
                        MX_BFMJ = drt.cuTotalArea.ToString(),//报废面积 
                        MX_WOBFMJ = drt.cuDefectTotalArea.ToString(),//工单总报废面积 
                        MX_ProcCode = drt.cuProcesSpec.ToString(),//责任工序代码  
                        MX_ProcSpec = drt.ProcesDesc.ToString(),//责任工序 
                        MX_SCRAPTYPENAME = drt.cuScrapType.ToString(),
                        MX_SCRAPTYPEDESCRIPTION = drt.cuScrapTypeDesp.ToString(),
                        MX_Stampcode = drt.cuStampcode.ToString(),
                        MX_DESCRIPTION = drt.DESCRIPTION.ToString(),//客户信息
                    };
                    bodydeatail.Add(itemnew);
                }

                Info.mainTable = head;
                IList<IList<RejectProcessdetailTable>> bodydeatailList = new List<IList<RejectProcessdetailTable>>();
                bodydeatailList.Add(bodydeatail);
                Info.detailTable = bodydeatailList;
                IResultModel requestResult = CuOA_RejectProcess(Info);
                if (requestResult.success)
                {
                    _resultModel.Success(requestResult.msg);
                    return new ResultModel<string>().Success("调用OA报废接口成功！");
                }
                else
                {
                    _resultModel.Failed(requestResult.msg);
                    return new ResultModel<string>().Failed("调用OA报废接口失败：" + requestResult.msg);
                }

            }
            else
            {
                return new ResultModel<string>().Failed();
            }
            return _resultModel;

        }

        /// <summary>
        /// 执行报废结果
        /// </summary>
        /// <param name="cuOARejectProcessResult"></param>
        /// <returns></returns>
        public IResultModel SExcuteRejectToMES( CuOARejectProcessResult cuOARejectProcessResult)
        {
            if (cuOARejectProcessResult.detailTable.Count <= 0)
            return new ResultModel<string>().Failed("无执行报废数据！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuRejectLot");
            _helper.InputData().DataField("cuIsReject").SetValue(cuOARejectProcessResult.Status);
            _helper.InputData().NamedObjectField("cuDefectRecord").SetRef(cuOARejectProcessResult.FD_BH);
            var details = _helper.InputData().SubentityList("cuRejectLotBackDetails");
            foreach (var item in cuOARejectProcessResult.detailTable)
            {
                var _rejectLot = details.AppendItem();
                var _tbRejectLot = GetRejectLotInfo(item.MX_SCPH);
                string _cuPNLArea = "";
                string _cuPcsPerPnl = "";
                if (_tbRejectLot != null && _tbRejectLot.Count > 0)
                {
                    _cuPNLArea = _tbRejectLot[0].cuPNLArea.ToString();
                    _cuPcsPerPnl = _tbRejectLot[0].cuPCSPerPNL.ToString();
                }
                _rejectLot.DataField("cuActPCSQty").SetValue(item.MX_ActRejPCSS.ToString());
                _rejectLot.NamedObjectField("cuLossReason").SetRef(item.MX_QXDM);
                _rejectLot.NamedObjectField("cuLot").SetRef(item.MX_SCPH);
                _rejectLot.DataField("cuPanelPCSNo").SetValue(item.MX_PPH);
                _rejectLot.DataField("cuPanelQty").SetValue(item.MX_PanS);
                _rejectLot.DataField("cuPCSArea").SetValue(((double.Parse(_cuPNLArea.ToString())) * (double.Parse(item.MX_ActRejPCSS.ToString())) / (double.Parse(_cuPcsPerPnl.ToString()))).ToString());
                _rejectLot.DataField("cuPCSQty").SetValue(item.MX_AppRejPCSS);
                _rejectLot.NamedObjectField("cuProcesSpec").SetRef(item.MX_ProcCode);
                _rejectLot.DataField("cuScrapTypeName").SetValue(item.MX_SCRAPTYPENAME);
                _rejectLot.DataField("cuScrapTypeDescription").SetValue(item.MX_SCRAPTYPEDESCRIPTION);
            }
            _helper.InputData().NamedObjectField("cuReleaseReason").SetRef("DEFECT");
            _helper.InputData().DataField("cuResult").SetValue(cuOARejectProcessResult.Status);
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 获取Container信息
        /// <para>-------------------- 返回 --------------------</para>
        /// <para>_containerName</para>
        /// </summary>
        /// <returns>根据ContainerNam获取RejectLot信息</returns>
        public List<Product> GetRejectLotInfo(string MX_SCPH)
        {
            List<Product> lotResult = (from c in db.Containers
                                       join p in db.Products on c.ProductId equals p.ProductId 
                                       where c.ContainerName.Equals(MX_SCPH)
                                        select new Product()
                                        {
                                            cuPCSPerPNL = p.cuPCSPerPNL,
                                            cuPNLArea = p.cuPNLArea
                                        }).ToList();
            return lotResult;
        }

        /// <summary>
        /// Lot关闭
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotClose(LotStatusUpdateRsp param)
        {
            if (param.Container == null)
                return new ResultModel<string>().Failed("没有需要关闭的LOT！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("Close");
            var _input = _helper.InputData();
            _input.ContainerField("Container").SetRef(param.Container, "LOT");
            _input.NamedObjectField("Factory").SetRef(param.Factory);
            _input.NamedObjectField("TaskContainer").SetRef(param.TaskContainer);
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// Lot打开
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotOpen(LotStatusUpdateRsp param)
        {
            if (param.Container == null)
                return new ResultModel<string>().Failed("没有需要打开的LOT！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("Open");
            var _input = _helper.InputData();
            _input.ContainerField("Container").SetRef(param.Container, "LOT");
            _input.NamedObjectField("Factory").SetRef(param.Factory);
            _input.NamedObjectField("TaskContainer").SetRef(param.TaskContainer);
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// Lot激活信息查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotStatusInfo(GetLotMsgReq param)
        {
            FormattableString fssql = $@" 
                   select  
                     c.containername
                     ,c.qty
                     ,c.qty2
                      ,pb.productname
                     ,c.currentholdcount 
                     ,c.status
                     ,c.Cutrackflag
                     ,sb.specname
                     ,s.specrevision SpecVer
                     ,s.description SpecDesc
                    ,s.cu_isdrillingroom IsDrillRoom 
                    ,(case when s.resourcegroupid is null then 0 else 1 end) as IsHaveEquipment
                     ,sb1.specname ToSpecName
                     ,s1.specrevision ToSpecVer
                     ,wt.workflowstepname step
                     ,wt1.workflowstepname tostep
                     ,wt2.workflowstepname as ToNextStep
                     ,wt.sequence Seq
                     ,wt1.sequence toSeq
                     ,wt2.sequence ToNextSeq 
                     ,wt.workflowid
                      ,nvl(P.CUSTRIPPERPNL,0) S_QTY
                      ,nvl(P.CUPCSPERPNL,0) U_QTY
                      ,p.cudatacode_format DataCode_Format
                        ,（case when sb.specname = sb2.specname then 1
                        else 0
                          end) IsDtSpec
                      ,c.cudatecode DataCode_Value  
                      ,f.factoryname Factory
                      ,f.notes FactoryNotes
                      ,hd.holdreasonname
                      ,wb.workflowname
                      ,wf.workflowrevision
                      ,ae.equipmentname Equipment
                      ,nvl(rd.cu_iscontinuous,0) IsContinuous
                      ,mo.mfgordername 
                      ,WFS.WORKFLOWSTEPNAME as UnTerminateWorkflowStep
                      ,nvl(s.autocreatefirstinsertion,0) isFirstInsertion   
                      ,nvl(op.usequeue,0) cuusequeue
                      ,cc.custampcode
                      from container c
                      left  join currentstatus cs on cs.currentstatusid = c.currentstatusid
                      left join mfgorder mo on c.cuworkorderid=mo.mfgorderid 
                      left join culotcard cc on mo.mfgordername = cc.culotcardname
                      left join spec s on cs.specid = s.specid
                      left join operation op on s.operationid = op.operationid
                      left join specbase sb on sb.specbaseid = s.specbaseid
                      left join product p on p.productid = c.productid
                      left join productbase pb on p.productbaseid = pb.productbaseid
                      left join workflowstep wt on cs.workflowstepid = wt.workflowstepid
                      left  join path p1 on p1.fromstepid = wt.workflowstepid
                      left join workflowstep wt1 on wt1.workflowstepid = p1.tostepid
                      left join specbase sb1 on wt1.specbaseid = sb1.specbaseid
                      left join spec s1 on sb1.specbaseid = s1.specbaseid 
                      left join path p2 on p2.fromstepid = wt1.workflowstepid
                      left join workflowstep wt2 on wt2.workflowstepid = p2.tostepid
                      left join spec s2 on s2.specid = p.cudatecodespecid 
                      left join specbase sb2 on sb2.specbaseid = s2.specbaseid
                      left join factory f on cs.factoryid = f.factoryid
                      left join HOLDREASON hd on hd.holdreasonid = c.holdreasonid
                      left join workflow wf on wf.workflowid = wt.workflowid
                      left join workflowbase wb on wb.workflowbaseid = wf.workflowbaseid
                      left join a_Wipequipment ae on c.containerid = ae.containerid
                      left join resourcedef rd on ae.equipmentid = rd.resourceid
                      left join WORKFLOWSTEP WFS ON WFS.WORKFLOWID = WF.WORKFLOWID and  WFS.CUSEQUENCE='901000'
                      where c.containername ={param.Lot} ";


            LotMessage LotMsg = db.LotMessage.FromSql<LotMessage>(fssql)?.FirstOrDefault();
            if (LotMsg == null)
                return new ResultModel<LotMessage>().Failed();
            return new ResultModel<LotMessage>().Success(LotMsg);


        }

        /// <summary>
        /// Lot终止
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotTerminate(LotStatus param)
        {
            if (param.Container == null)
                return new ResultModel<string>().Failed("没有需要终止的LOT！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotTerminate");
            string ComputerName = System.Environment.MachineName;
            var _input = _helper.InputData();
            _input.DataField("ComputerName").SetValue(ComputerName);
            var list = _input.ContainerList("Containers");
            foreach (var item in param.Container)
            {
                list.AppendItem(item.ContainerName, "LOT");
            }
            _input.NamedObjectField("TerminateReason").SetRef(param.TerminateReason);

            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// Lot激活
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotUnTerminate(LotStatus param)
        {
            if (param.Container == null)
                return new ResultModel<string>().Failed("没有需要激活的LOT！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotUnTerminate");
            string ComputerName = System.Environment.MachineName;
            var _input = _helper.InputData();

            _input.DataField("ComputerName").SetValue(ComputerName);
            _input.NamedObjectField("Container").SetRef(param.Container[0].ContainerName);
            var containerlist = _input.ContainerList("Containers");
            foreach (var item in param.Container)
            { containerlist.AppendItem(item.ContainerName, null); }
            _input.NamedObjectField("UnTerminateReason").SetRef(param.TerminateReason);
            //UnTerminateWorkflow
            _input.RevisionedObjectField("UnTerminateWorkflow").SetRef(param.UnTerminateWorkflow, param.UnTerminateWorkflowRevision, false);
            _input.NamedObjectField("UnTerminateWorkflowStep").SetRef(param.UnTerminateWorkflowStep);

            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// Lot激活流程下拉选
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotUnTerminateWorkflow(GetLotMsgReq param)
        {
            FormattableString fssql = $@" 
                     select  
                     c.containername
                      ,wb.workflowname as UnTerminateWorkflow 
                      ,wf.workflowrevision as UnTerminateWorkflowRevision 
                      ,WFS.WORKFLOWSTEPNAME as UnTerminateWorkflowStep
                      from container c
                      left join currentstatus cs on cs.currentstatusid = c.currentstatusid
                      left join workflowstep wt on cs.workflowstepid = wt.workflowstepid
                      left join workflow wf on wf.workflowid = wt.workflowid
                      left join workflowbase wb on wb.workflowbaseid = wf.workflowbaseid
                      left join WORKFLOWSTEP WFS ON WFS.WORKFLOWID = WF.WORKFLOWID and  WFS.CUSEQUENCE='901000'
                      where c.containername ={param.Lot}              
                      union 
                      select  
                     c.containername                    
                      ,wb.workflowname as UnTerminateWorkflow 
                      ,w.workflowrevision as UnTerminateWorkflowRevision                   
                      ,WFS.WORKFLOWSTEPNAME as UnTerminateWorkflowStep
                      from container c
                      left join currentstatus cs on cs.currentstatusid = c.currentstatusid
                      --left join workflowstep wt on cs.workflowstepid = wt.workflowstepid
                      LEFT JOIN workflow W ON W.FIRSTSTEPID = C.LASTINVENTORYSTEPID
                      left join workflowbase wb on wb.workflowbaseid = w.workflowbaseid
                      left join WORKFLOWSTEP WFS ON WFS.WORKFLOWID = w.WORKFLOWID --and  WFS.CUSEQUENCE='901000'
                      where c.containername ={param.Lot} ";


            List<LotUnTerminateWorkflow> LotMsg = db.LotUnTerminateWorkflows.FromSql<LotUnTerminateWorkflow>(fssql)?.ToList();
            if (LotMsg == null)
                return new ResultModel<List<LotUnTerminateWorkflow>>().Failed();
            return new ResultModel<List<LotUnTerminateWorkflow>>().Success(LotMsg);
        }

        /// <summary>
        /// Lot继续
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel cuUnTerminate(LotStatus param)
        {
            if (param.cuLot == null)
                return new ResultModel<string>().Failed("没有需要执行继续的LOT！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuUnTerminate");
            string ComputerName = System.Environment.MachineName;
            var _input = _helper.InputData();
            _input.NamedObjectField("cuLot").SetRef(param.cuLot);
            _input.NamedObjectField("cuUnTerminateReason").SetRef(param.TerminateReason);
          
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 批次计划激活
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotSchedule(LotStatus param)
        {
            if (param.Container == null)
                return new ResultModel<string>().Failed("没有需要计划激活的LOT！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotUnTerminate");
            string ComputerName = System.Environment.MachineName;
            var _input = _helper.InputData();

            _input.DataField("ComputerName").SetValue(ComputerName);
            _input.NamedObjectField("Container").SetRef(param.Container[0].ContainerName);
            foreach (var item in param.Container)
            {
                _input.ContainerField("Containers").SetRef(item.ContainerName, "LOT");
            }
            _input.NamedObjectField("UnTerminateReason").SetRef(param.TerminateReason);
            //UnTerminateWorkflow
            var unTerminateWorkflow = _input.NamedSubentityField("UnTerminateWorkflow");
            unTerminateWorkflow.SetName(param.UnTerminateWorkflow);
            unTerminateWorkflow.ParentInfo().SetRevisionedObjectRef(param.UnTerminateWorkflow, "1", false);

            _input.NamedObjectField("UnTerminateWorkflowStep").SetRef(param.UnTerminateWorkflowStep);

            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 批次首末检启动
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotFirstInspectStart(LotInspect param)
        {
            if (string.IsNullOrEmpty(param.Container))
                return new ResultModel<string>().Failed("没有需要首末检启动的LOT！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuLotFirstInspectStart");
            string ComputerName = System.Environment.MachineName;
            var _input = _helper.InputData();
            _input.DataField("ComputerName").SetValue(ComputerName);
            _input.ContainerField("Container").SetRef(param.Container, "LOT");
            _input.DataField("cuIsDynamic").SetValue(param.cuIsDynamic);
            _input.DataField("cuIsFirstInspect").SetValue(param.cuIsFirstInspect);
            _input.DataField("cuIsLastInspect").SetValue(param.cuIsLastInspect);
            _input.DataField("SelectionId").SetValue(param.SelectionId);

            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 批次首检
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotFirstInspect(LotFirstInspect param)
        {
            if (param.Container == null)
                return new ResultModel<string>().Failed("没有批次首检数据！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuLotFirstInspect");
            var _input = _helper.InputData();
            _input.DataField("cuIsDynamic").SetValue(param.CuIsDynamic);
            _input.DataField("cuIsFirstInspect").SetValue(param.CuIsFirstInspect);

            var csiDataList = _input.NamedSubentityField("cuWorkflowStep");
            csiDataList.SetObjectType("SpecStep");
            csiDataList.SetName(param.SpecName);
            csiDataList.ParentInfo().SetObjectType("AssemblyWorkflow");
            csiDataList.ParentInfo().SetObjectId(param.WorkflowID);
            csiDataList.ParentInfo().SetRevisionedObjectRef(param.CuWorkflowStep, param.CuWorkflowStepRevision, false);


            var details = _helper.InputData().SubentityList("Details");
            foreach (var item in param.detailTable)
            {
                var items = details.AppendItem();
                items.DataField("ForProcessType").SetValue("False");
                var uomList = items.NamedSubentityField("ss_UOM");
                uomList.SetObjectType("UOM");
                uomList.SetObjectId(item.UOMID);
                uomList.SetName(item.UOMName);
                var WIPDataNameList = items.NamedSubentityField("WIPDataName");
                WIPDataNameList.SetObjectType("WIPDataName");
                WIPDataNameList.SetObjectId(item.WIPDATANAMEID);
                WIPDataNameList.SetName(item.WIPDATANAMENAME);
                items.DataField("WIPDataValue").SetValue(item.WIPDATAVALUE);
            }
            _input.DataField("ObjectName").SetValue(param.Container);
            _input.NamedObjectField("ObjectType").SetRef("Lot");
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 批次末检
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel cuLotLastInspect(LotFirstInspect param)
        {
            if (param.Container == null)
                return new ResultModel<string>().Failed("没有批次末检数据！");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuLotFirstInspect");
            var _input = _helper.InputData();

            string ComputerName = System.Environment.MachineName;
            _input.DataField("ComputerName").SetValue(ComputerName);
            _input.DataField("cuFirstInspectQty").SetValue(param.Qty);
            _input.DataField("cuIsDynamic").SetValue(param.CuIsDynamic);
            _input.DataField("cuIsFirstInspect").SetValue(param.CuIsFirstInspect);

            var csiDataList = _input.NamedSubentityField("cuWorkflowStep");
            csiDataList.SetObjectType("SpecStep");
            csiDataList.SetName(param.SpecName);
            csiDataList.ParentInfo().SetObjectType("AssemblyWorkflow");
            csiDataList.ParentInfo().SetObjectId(param.WorkflowID);
            csiDataList.ParentInfo().SetRevisionedObjectRef(param.CuWorkflowStep, param.CuWorkflowStepRevision, false);

            var details = _helper.InputData().SubentityList("Details");
            foreach (var item in param.detailTable)
            {
                var items = details.AppendItem();
                items.DataField("ForProcessType").SetValue("False");
                var uomList = items.NamedSubentityField("ss_UOM");
                uomList.SetObjectType("UOM");
                uomList.SetObjectId(item.UOMID);
                uomList.SetName(item.UOMName);
                var WIPDataNameList = items.NamedSubentityField("WIPDataName");
                WIPDataNameList.SetObjectType("WIPDataName");
                WIPDataNameList.SetObjectId(item.WIPDATANAMEID);
                WIPDataNameList.SetName(item.WIPDATANAMENAME);
                items.DataField("WIPDataValue").SetValue(item.WIPDATAVALUE);
            }
            _input.DataField("ObjectName").SetValue(param.Container);
            _input.NamedObjectField("ObjectType").SetRef("Lot");
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// Lot终止原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetTerminateReason()
        {
            List<string> result = (from r in db.TerminateReasons select r.TerminateReasonName).ToList<string>();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("没有查询到批次终止原因。");
            }
            else
            {
                return new ResultModel<List<string>>().Success(result);
            }
        }

        /// <summary>
        /// Lot激活原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetUnTerminateReason()
        {
            List<string> result = (from r in db.UnTerminateReasons select r.UnTerminateReasonName).ToList<string>();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("没有查询到批次激活原因。");
            }
            else
            {
                return new ResultModel<List<string>>().Success(result);
            }
        }

        /// <summary>
        /// 外协物料消耗（手工）
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel cuOutsouringConsumedMaterial(cuOutsouringLot param)
        {
            if (param.cuOutsourcingLot == null)
                return new ResultModel<string>().Failed("没有需要扣料的外发批次数据！");

            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuOutsouringConsumedMaterial");
            var _input = _helper.InputData();
            _input.DataField("cuOutsourcingLot").SetValue(param.cuOutsourcingLot);

            var details = _input.SubentityList("cuOutsouringHistoryList");
            foreach (var item in param.detailTable)
            {
                var csiDataList = details.AppendItem();
                csiDataList.NamedObjectField("cuAutoContainer").SetRef(item.cuAutoContainer);
                csiDataList.DataField("cuAutoQty").SetValue(item.cuAutoQty);
                csiDataList.DataField("cuConsume").SetValue(item.cuConsume);
                //var Container = csiDataList.NamedSubentityField("cuContainer");
                //Container.SetObjectType("Lot");
                //Container.SetObjectId(item.containerid);
                //Container.ContainerField("Container").SetRef(item.containerName, "LOT");
                csiDataList.ContainerField("cuContainer").SetRef(item.containerName, "LOT");
                csiDataList.DataField("cuLotAlt").SetValue(item.cuLotAlt);
                csiDataList.RevisionedObjectField("cuProduct").SetRef(item.cuProductName, item.ProductRevision, false);
                csiDataList.DataField("cuProductName").SetValue(item.cuProductName);
                csiDataList.DataField("cuQty").SetValue(item.cuQty);
                csiDataList.RevisionedObjectField("cuSpec").SetRef(item.cuSpec, item.specRevision, false);
                csiDataList.DataField("WaferMapDetailsType").SetValue(0);
            }
            _helper.SetExecute();
            var _resDocument = _helper.Submit();
            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 查询外协扣料批次信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOutsourcingLot(cuOutsouringLotInfo param)
        {
            FormattableString fssql = $@" 
                          select container.containerid,container.containername AS cuOutsourcingLot,PRODUCTBASE.PRODUCTNAME cuProductName,PRODUCT.ProductRevision,CONTAINER.QTY cuQty,
                           A_PRODUCTBOMMATERIALLIST.CONSUMEFACTOR cuConsume,specbase.specname cuSpec ,SPEC.SPECREVISION
                           from cuOutsourceLotList
                           inner join spec on cuOutsourceLotList.Cuspecid = spec.specid
                           inner join specbase on specbase.specbaseid = spec.specbaseid
                           INNER join container on container.containerid = cuoutsourcelotlist.culotid
                           INNER JOIN cuOutsourcingLotInfor ON cuOutsourcingLotInfor.Cuoutsourcinglotinforid = cuOutsourceLotList.Cuoutsourcinglotinforid
                           INNER JOIN A_PRODUCTBOMMATERIALLIST ON A_PRODUCTBOMMATERIALLIST.SPECID=SPEC.SPECID  
                           INNER JOIN A_PRODUCTBOM ON A_PRODUCTBOMMATERIALLIST.PRODUCTBOMID=A_PRODUCTBOM.PRODUCTBOMID 
                           --INNER JOIN A_PRODUCTBOMBASE ON A_PRODUCTBOMBASE.PRODUCTBOMBASEID=A_PRODUCTBOM.PRODUCTBOMBASEID
                           INNER JOIN PRODUCT ON PRODUCT.PRODUCTID = A_PRODUCTBOMMATERIALLIST.MATERIALPARTID
                           INNER JOIN PRODUCTBASE ON PRODUCTBASE.PRODUCTBASEID = PRODUCT.PRODUCTBASEID
                           INNER JOIN A_SCHEDULEDATA ON A_SCHEDULEDATA.Scheduledataid= CONTAINER.Scheduledataid and A_PRODUCTBOM.Productbomid =A_SCHEDULEDATA.Productbomid 
                           where container.containername ={param.cuOutsourcingLot}
                           and cuOutsourcingLotInfor.Cuoutsourcinglotinforname = container.cuOutsourcingNo
                           and  A_PRODUCTBOMMATERIALLIST.CUISCONSUME='1'
                           and (spec.cuAutoConsume =1 or (NVL(spec.cuAutoConsume,0)!=1 and spec.resourcegroupid is not null)) ";

            cuOutsouringLotInfo LotInfo = db.cuOutsouringLotInfos.FromSql<cuOutsouringLotInfo>(fssql)?.FirstOrDefault();
            if (LotInfo == null)
                return new ResultModel<cuOutsouringLotInfo>().Failed("没有查到数据");
            return new ResultModel<cuOutsouringLotInfo>().Success(LotInfo);
        }

        /// <summary>
        /// 查询批次首末检任务信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInspectMsg(GetLotInspect param)
        {
            string QueryStr = string.Empty;
            if (!param.ContainerName.IsNullOrEmpty())
            {
                QueryStr += string.Format(" AND C.CONTAINERNAME ='{0}'", param.ContainerName);
            }
            if (!param.CUISFIRSTINSPECT.IsNullOrEmpty())
            {
                QueryStr += string.Format(" AND F.CUISFIRSTINSPECT ='{0}'", param.CUISFIRSTINSPECT);
            }
            if (!param.CUISLASTINSPECT.IsNullOrEmpty())
            {
                QueryStr += string.Format(" AND F.CUISLASTINSPECT ='{0}'", param.CUISLASTINSPECT);
            }
            string fssql = $@" 
                    SELECT distinct C.CONTAINERNAME,A.WIPDATASETUPNAME,nvl(W.WORKFLOWSTEPNAME,sb.specname) AS WORKFLOWSTEPNAME,F.CUFIRSTINSPECTQTY as Qty,F.CUFIRSTINSPECTSTATUS as InspectStatus,
                    F.CUISDYNAMIC,F.CUISFIRSTINSPECT,F.CUISLASTINSPECT,W.WORKFLOWID,WB.WORKFLOWNAME,WF.WORKFLOWREVISION,C.CONTAINERID 
                    FROM CONTAINER C 
                    LEFT JOIN CUFIRSTINSPECTDETAILS F ON C. CONTAINERID=F.LOTID
                    LEFT JOIN A_WIPDATASETUP A ON F.CUWIPDATASETUPID =A.WIPDATASETUPID 
                    LEFT JOIN WORKFLOWSTEP W ON W.WORKFLOWSTEPID=F.CUWORKFLOWSTEPID 
                    LEFT JOIN WORKFLOW WF ON WF.WORKFLOWID=W.WORKFLOWID
                    LEFT JOIN WORKFLOWBASE WB ON WB.WORKFLOWBASEID=WF.WORKFLOWBASEID
                    left  join currentstatus cs on cs.currentstatusid = c.currentstatusid
                    left join spec s on cs.specid = s.specid
                    left join specbase sb on sb.specbaseid = s.specbaseid
                    where 1=1      
            {QueryStr}";
            var LotMsg = db.GetTable(fssql);
            if (LotMsg.Rows.Count == 0) 
                return new ResultModel<DataRow>().Success();
            return new ResultModel<DataRow>().Success(LotMsg.Rows[0]);
        }

        /// <summary>
        /// 查询批次首末检检验历史记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInspectRecord(GetLotInspect param)
        {
            string QueryStr = string.Empty;
            if (!param.ContainerName.IsNullOrEmpty())
            {
                QueryStr += string.Format(" AND C.CONTAINERNAME ='{0}'", param.ContainerName);
            }
            if (!param.CUISFIRSTINSPECT.IsNullOrEmpty())
            {
                QueryStr += string.Format(" AND F.CUISFIRSTINSPECT ='{0}'", param.CUISFIRSTINSPECT);
            }
            if (!param.CUISLASTINSPECT.IsNullOrEmpty())
            {
                QueryStr += string.Format(" AND F.CUISLASTINSPECT ='{0}'", param.CUISLASTINSPECT);
            }
            string fssql = $@" 
                    SELECT DISTINCT AR.RECORDSEQUENCE,AR.OBJECTNAME as ContainerName,'' AS VER,AR.CREATIONTIMESTAMP,AR.CREATIONUSERNAME,
                    AR.TXNTIMESTAMP,AR.TXNUSERNAME,F.CUFIRSTINSPECTQTY,F.CUFIRSTINSPECTSTATUS,W.WORKFLOWSTEPNAME,ARD.WIPDATAVALUE 
                    FROM CONTAINER C 
                    LEFT JOIN CUFIRSTINSPECTDETAILS F ON C. CONTAINERID=F.LOTID
                    LEFT JOIN A_AdHocWIPDataRecord AR ON C.CONTAINERNAME = AR.OBJECTNAME  AND AR.CUISFIRSTINSPECT =F.CUISFIRSTINSPECT
                    LEFT JOIN A_ADHOCWIPDATARECORDDETAILS ARD ON AR.ADHOCWIPDATARECORDID = ARD.ADHOCWIPDATARECORDID
                    LEFT JOIN WORKFLOWSTEP W ON W.WORKFLOWSTEPID=F.CUWORKFLOWSTEPID 
                    where 1=1      
            {QueryStr}";
            var LotMsg = db.GetTable(fssql);
            return new ResultModel<DataTable>().Success(LotMsg);
        }

        /// <summary>
        ///查询批次首末检数据采集信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotWipDataName(GetLotInspect param)
        {
            string QueryStr = string.Empty;
            if (!param.ContainerName.IsNullOrEmpty())
            {
                QueryStr += string.Format(" AND C.CONTAINERNAME ='{0}'", param.ContainerName);
            }
            string fssql = $@" 
                    SELECT DISTINCT AN.WIPDATANAMEID,AN.WIPDATANAMENAME,U.UOMNAME,U.UOMID
                    FROM CONTAINER C 
                    LEFT JOIN CUFIRSTINSPECTDETAILS F ON C. CONTAINERID=F.LOTID
                    LEFT JOIN A_WIPDATASETUP A ON F.CUWIPDATASETUPID =A.WIPDATASETUPID 
                    LEFT JOIN A_WIPDataSetupDetails AD ON A.WIPDATASETUPID=AD.WIPDATASETUPID
                    LEFT JOIN A_WIPDataName AN ON AN.WIPDATANAMEID=AD.WIPDATANAMEID
                    LEFT JOIN UOM U ON U.UOMID =AN.SS_UOMID
                    where 1=1      
            {QueryStr}";
            var LotMsg = db.GetTable(fssql);
            return new ResultModel<DataTable>().Success(LotMsg);
        }
    }
}
