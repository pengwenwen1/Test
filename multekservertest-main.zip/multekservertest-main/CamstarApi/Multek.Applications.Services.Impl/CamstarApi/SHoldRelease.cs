﻿using Microsoft.AspNetCore.Components.Forms;
using Microsoft.EntityFrameworkCore;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.HoldRelease;
using Multek.Applications.Services.CamstarApi;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Camstar.CamstarServer;
using Multek.Library_Core.Camstar.Constants;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.CamstarApi
{
    public class SHoldRelease : EFHelper<MultekCamstarDbContext>, IHoldReleaseService
    {
        public readonly ICamstarComm ICamstarComm;
        public SHoldRelease(MultekCamstarDbContext tdb, ICamstarComm camstarComm) : base(tdb)
        {
            ICamstarComm = camstarComm;
        }

        /// <summary>
        /// 执行hold服务
        /// </summary>
        /// <returns></returns>
        public IResultModel HoldLot(HoldLotInfoRsp param)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotHold");
            var _input = _helper.InputData();
            _input.NamedObjectField("Employee").SetRef(param.HoldUser);
            var conList = _input.ContainerList("Containers");
            var detail = _input.SubentityList("Details");
            foreach (var item in param.holdLists)
            {
                conList.AppendItem(item.ContainerName, null);
                var list = detail.AppendItem();
                list.DataField("ApplyToChildLots").SetValue("False");
                list.ContainerField("Container").SetRef(item.ContainerName, null);
                list.DataField("cuComments").SetValue(item.cuComments);
                list.NamedObjectField("HoldReason").SetRef(string.IsNullOrEmpty(item.HoldReason)? param.cuDefultHoldReason : item.HoldReason);
                list.DataField("HoldUsername").SetValue(param.HoldUser);
            }
            _helper.SetExecute();
            var _resDocument = _helper.Submit();


            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 获取释放原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetHoldReason()
        {
            FormattableString sqlstr = $@"SELECT HR.HOLDREASONID,HR.HOLDREASONNAME,HR.DESCRIPTION FROM HOLDREASON HR
                                            INNER JOIN CUSPLITREASON SRE ON SRE.CUSPLITREASONNAME = HR.HOLDREASONNAME";
            List<HoldReason> holdReasons = db.holdReason.FromSql<HoldReason>(sqlstr).ToList();
            if (holdReasons == null &&holdReasons.Count<=0) return new ResultModel<string>().Failed("没有查询到冻结原因建模");

            return new ResultModel<List<HoldReason>>().Success(holdReasons);
        }

        public IResultModel GetHoldReasonPC()
        {
            FormattableString sqlstr = $@"SELECT HR.HOLDREASONID,HR.HOLDREASONNAME,HR.DESCRIPTION FROM HOLDREASON HR 
                                            WHERE HR.HOLDREASONNAME IS NOT NULL
                                            ORDER BY HR.HOLDREASONNAME ASC";
            List<HoldReason> holdReasons = db.holdReason.FromSql<HoldReason>(sqlstr).ToList();
            if (holdReasons == null && holdReasons.Count <= 0) return new ResultModel<string>().Failed("没有查询到冻结原因建模");

            return new ResultModel<List<HoldReason>>().Success(holdReasons);
        }

        public IResultModel LotRelease(LotReleaseReq param)
        {
            if (param == null|| param.containers ==null ||param.containers.Count<=0) return new ResultModel<string>().Failed("释放批次不能为空");
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotRelease");
            var input = _helper.InputData();
            var conList = input.ContainerList("Containers");
            var detail = input.SubentityList("Details");
            foreach (var item in param.containers)
            {
                conList.AppendItem(item.ContainerName, "LOT");
                var list = detail.AppendItem();
                list.DataField("ApplyToChildLots").SetValue("False");
                list.ContainerField("Container").SetRef(item.ContainerName, null);
                list.NamedObjectField("ReleaseReason").SetRef(string.IsNullOrEmpty(item.ReleaseReason)?param.cuDefultReleaseReason:item.ReleaseReason);
            }
            if (param.ReleaseUser !=null)
            {
                input.NamedObjectField("Employee").SetRef(param.ReleaseUser);
            }
            _helper.SetExecute();
            var _resDocument = _helper.Submit();


            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 获取释放原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetReleaseReason()
        {
            FormattableString sqlstr = $@"SELECT HR.RELEASEREASONID,HR.RELEASEREASONNAME,HR.DESCRIPTION FROM RELEASEREASON HR";
            List<Releasereason> releaseReasons = db.releasereasons.FromSql<Releasereason>(sqlstr).ToList();
            if (releaseReasons == null && releaseReasons.Count <= 0) return new ResultModel<string>().Failed("没有查询到释放原因建模");

            return new ResultModel<List<Releasereason>>().Success(releaseReasons);
        }
    }
}
