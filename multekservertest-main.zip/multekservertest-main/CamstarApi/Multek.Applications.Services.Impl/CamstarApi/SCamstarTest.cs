﻿using Autofac.Extras.DynamicProxy;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;
using Multek.Applications.Services.Barcode;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.AOP;
using Multek.Library_Core.Redis;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Text.Json.Nodes;
using Nacos.V2.Utils;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SqlSugar;
using NetTaste;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Multek.Library_Core.EntitiesRedis;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Camstar.CamstarServer;
using Multek.Library_Core.Camstar.Constants;
using static Multek.Library_Core.Camstar.CamstarHelper;
using System.Xml.Linq;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Camstar.XMLClient.Interface;
using Microsoft.AspNetCore.Components.Forms;
using System.Runtime;

namespace Multek.Applications.Services.Impl.Barcode
{
    public class SCamstarTest : EFHelper<MultekServerDbContext>, ICamstarTest
    {
        public readonly ICamstarComm ICamstarComm;
        public SCamstarTest(MultekServerDbContext tdb, ICamstarComm camstarComm) : base(tdb)
        {

            ICamstarComm = camstarComm;
        }


        /// <summary>
        /// 新增工厂
        /// </summary>
        /// <param name="factoryName">新增工厂信息</param>
        /// <returns></returns>
        public IResultModel AddFactory(string factoryName)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("FactoryMaint");
            var _objectChanges = _helper.New(factoryName);
            _objectChanges.DataField("Description").SetValue("123");
            return _helper.ExecuteResult();

        }
        /// <summary>
        /// 删除工厂
        /// </summary>
        /// <param name="factoryName"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel DeleteFactory(string factoryName)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("FactoryMaint");
            return _helper.Delete(factoryName);
        }
        /// <summary>
        /// 查看工厂
        /// </summary>
        /// <param name="factoryName">工厂信息</param>
        /// <returns></returns>
        public IResultModel LoadFactory(string factoryName)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("FactoryMaint");
            _helper.InputData().NamedObjectField("ObjectToChange").SetRef(factoryName);
            Dictionary<string, List<string>> _requestFieldNames = new Dictionary<string, List<string>>();
            _requestFieldNames["ObjectChanges"] = new List<string>() { "cuFactoryDescription" };
            _helper.SetExecute(InSiteEventConst.Load, _requestFieldNames);
            var _resDocument = _helper.Submit();

            var _str1 = _resDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            var _str = _resDocument.GetService().ResponseData().GetResponseFieldByName("ObjectChanges").FindChildByName("cuFactoryDescription").AsDataField().GetValue();

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }
    }
}
