﻿using Camstar.XMLClient.Interface;
using Microsoft.EntityFrameworkCore;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.SplitAndCombine;
using Multek.Applications.Services.CamstarApi;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Camstar.Constants;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.CamstarApi
{
    public class SSplitCombine : EFHelper<MultekCamstarDbContext>, ISplitCombine
    {
        public readonly ICamstarComm ICamstarComm;
        public SSplitCombine(MultekCamstarDbContext tdb, ICamstarComm camstarComm) : base(tdb)
        {
            ICamstarComm = camstarComm;
        }

        /// <summary>
        /// 执行合批
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel Combine(CombineLotReq param)
        {
            if (param.FromContainer.Count <= 1)
            {
                return new ResultModel<string>().Failed("合批批次不能为空!");
            }
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotCombine");
            var _input = _helper.InputData();
            _input.ContainerField("Container").SetRef(param.Container,null);
            _input.DataField("cuCheckCorrelateLot").SetValue("True");
            if (param.Carrier !=null)
            {
                _input.NamedObjectField("Carrier").SetRef(param.Carrier);
            }
            var detail = _input.SubentityList("Details");
            foreach (var item in param.FromContainer)
            {
                var list = detail.AppendItem();
                list.NamedObjectField("FromContainer").SetRef(item.Name);
                switch (param.WIP_stutas )
                {
                    case 5:
                        list.DataField("StandbyQty").SetValue(item.Qty); break;
                    case 0:
                        list.DataField("QtyToProcess").SetValue(item.Qty); break;
                    case 4:
                        list.DataField("QtyToProcess").SetValue(item.Qty); break;
                    case 2:
                        list.DataField("InProcessQty").SetValue(item.Qty); break;
                        list.DataField("QtyToProcess").SetValue(item.Qty); break;
                };

            }
            if (param.WIP_stutas == 2)
            {
                _input.NamedObjectField("Equipment").SetRef(param.Equipment);
                _input.NamedObjectField("ProcessType").SetRef("NORMAL");
            }
            else if (param.WIP_stutas != 5)
            {
                _input.NamedObjectField("ProcessType").SetRef("NORMAL");
            }
            _helper.SetExecute();
            var _rDocument = _helper.Submit();
            var _str1 = _rDocument.GetService().ResponseData().GetResponseFieldByName(InSiteFieldConst.CompletionMsg);
            _rDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _rDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 获取拆批后新批次
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel GetSplitNewLot(GetLotMsgReq param)
        {
            if (param == null)
            {
                return new ResultModel<string>().Failed("没有传入批次信息!");
            }
            FormattableString strsql = $@"SELECT
    ""Level"" AS ""Level"", FromContainer, ToContainer, Systemdate, ToContainerSequence,Employeename,status  FROM
(
    SELECT
        0 - Level AS ""Level""
         ,HM.ContainerName FromContainer
        , SHD.ToContainerName ToContainer
        , SHD.ToContainerSequence ToContainerSequence
        ,HM.Systemdate
        ,HM.Employeename
,c.status 
    FROM
        Container C
        INNER JOIN HistoryMainline HM ON C.ContainerId = HM.HistoryId
        INNER JOIN SplitHistory SH ON HM.HistoryMainlineId = SH.HistoryMainlineId
        INNER JOIN SplitHistoryDetails SHD ON SH.SplitHistoryId = SHD.SplitHistoryId
    START WITH
        C.ContainerName = {param.Lot} CONNECT BY
        C.ContainerId = PRIOR SHD.ToContainerId
    UNION
    SELECT
        Level - 1 AS ""Level""
         ,HM.ContainerName FromContainer
        , SHD.ToContainerName ToContainer
        , SHD.ToContainerSequence ToContainerSequence
        ,HM.Systemdate
        ,HM.Employeename
,c.status 
    FROM
        Container C
        INNER JOIN SplitHistoryDetails SHD ON C.ContainerId = SHD.ToContainerId
        INNER JOIN SplitHistory SH ON SHD.SplitHistoryId = SH.SplitHistoryId
        INNER JOIN HistoryMainline HM ON SH.HistoryMainlineId = HM.HistoryMainlineId
    START WITH
        C.ContainerName = {param.Lot} CONNECT BY
        C.ContainerId = PRIOR SHD.HistoryId
) A
ORDER BY
    ""Level"" DESC";
            GetNewLotRsp newlotinfo = db.GetNewLotRsps.FromSql<GetNewLotRsp>(strsql)?.FirstOrDefault();
            if (newlotinfo == null) return new ResultModel<string>().Failed($@"{param.Lot}未查询到新批次请检查数据");
            return new ResultModel<GetNewLotRsp>().Success(newlotinfo);
        }

        /// <summary>
        /// 执行拆批服务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel Split(SplitLotMsgReq param)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotSplit");
            var _input = _helper.InputData();
            _input.ContainerField("Container").SetRef(param.lot,"LOT");
            _input.DataField("CreateNewSchedule").SetValue("True");
            _input.DataField("cuCheckCorrelateLot").SetValue("True");
            var detail = _input.SubentityList("Details").AppendItem();
            detail.DataField("cuSplitApplicant").SetValue(param.SplitUser);
            detail.NamedObjectField("cuSplitReason").SetRef(param.SplitReason);
            detail.DataField(param.QtyName).SetValue(param.Qty);
            detail.DataField("TransferRejectsToThisContainer").SetValue("False");
            _input.NamedObjectField("Employee").SetRef(param.SplitUser);
            _helper.SetExecute();
            var tl = _helper.RequestData().RequestField("Details");
            var _rDocument = _helper.Submit();
            //var _str1 = _rDocument.GetService().ResponseData().GetResponseFieldByName("Details");
            ResultModel<string> _error = new ResultModel<string>();
            _rDocument.CheckErrors( _error);
            if (_error.success)
            {
                string cuDeliveryOrderNo = ((ICsiDataField)_rDocument.GetService().ResponseData().GetResponseFieldByName("Details").FindChildByName("__listItem").GetChildrenByName("ToContainerName").FirstOrDefault()).GetValue();
                return new ResultModel<string>().Success(cuDeliveryOrderNo);
            }
            return _error;
        }

        /// <summary>
        /// 查询拆批原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetSplitReason()
        {
            FormattableString sql = $@"select re.cusplitreasonid,re.cusplitreasonname,re.description from cusplitreason re;
";
            List<cuSplitReason> reList = db.SplitReason.FromSql<cuSplitReason>(sql)?.ToList();
            if (reList!=null && reList.Count>0)
            {
                return new ResultModel<List<cuSplitReason>>().Success(reList);
            }
            else
            {
                return new ResultModel<string>().Failed("没有查询到拆批原因：cusplitreason");
            }
        }

        public IResultModel GetCarrier()
        {
            FormattableString strsql = $@"SELECT  ResourceDef.ResourceName  , ResourceDef.IsFrozen  , ResourceDef.ResourceId  , ResourceDef.Description  , ChangeStatus.LastChangeDate AS ""LastEditTime"", ChangeStatus.LastChangeDateGMT AS ""LastEditTimeGMT"", E.EmployeeName AS ""LastEditedBy"" 
                                            FROM    
                                            ResourceDef LEFT JOIN ChangeStatus ON ResourceDef.ChangeStatusId  = ChangeStatus.ChangeStatusId
                                            LEFT JOIN Employee E ON ChangeStatus.UserId = E.EmployeeId
                                            WHERE   (ResourceDef.CDOTypeId  = 7902 OR 0 <> 1)
                                            AND     ResourceDef.CDOTypeId  IN (7902,4753052 )
                                            AND     ResourceDef.ResourceName  LIKE '%'
                                            ORDER BY ResourceDef.ResourceName  ";
            List<Carrier> carrierList = db.getCarrier.FromSql<Carrier>(strsql)?.ToList();

            return new ResultModel<List<Carrier>>().Success(carrierList);
        }
    }
}
