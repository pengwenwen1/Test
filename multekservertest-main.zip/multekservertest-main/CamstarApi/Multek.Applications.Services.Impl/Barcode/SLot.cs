﻿using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Barcode
{
    public class SLot : EFHelper<MultekCamstarDbContext>, ILot
    {
        public SLot(MultekCamstarDbContext tdb) : base(tdb)
        {
           
        }

        /// <summary>
        /// 获取Lot的基础信息用于下码
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        public Container GetLotInfo(string lotName)
        {
            Container _container = (from c in db.Containers
                                    join p in db.Products on c.ProductId equals p.ProductId
                                    join f in db.Factories on c.OriginalFactoryId equals f.FactoryId
                                    join m in db.Mfgorders on c.cuWorkOrderId equals m.MFGORDERID
                                    join o in db.Cuoems on p.CUOEMID equals o.CUOEMID
                                    where c.ContainerName == lotName
                                    select new Container { ContainerName = c.ContainerName, QTY2 = c.QTY2, CUMI_PN = p.CuMI_PN, FactoryName = f.FactoryName, cuPCSPerPnl = p.cuPCSPerPnl, CuStripPerPnl = p.CuStripPerPnl, CuPCSPerStrip = p.CuPCSPerStrip, cuCustomerPN = p.CUCUSTOMERPN, cuCustomerVersion = p.CUCUSTOMERVERSION, cuSolutionVersion = p.cuSolutionVersion, cuStampCode = m.CUSTAMPCODE, cuOEMName = o.CUOEMNAME, CuIsPnl = p.CuIsPnl, cuPcsCodeRule = p.cuPcsCodeRule, cuSetCodeRule = p.cuSetCodeRule, cuPnlCodeRule = p.cuPnlCodeRule}).SingleOrDefault();

            return _container;
        }
    }
}
