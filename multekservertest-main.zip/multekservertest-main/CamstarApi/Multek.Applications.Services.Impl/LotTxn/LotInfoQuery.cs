﻿using Autofac.Core;
using Camstar.XMLClient.Enum;
using Camstar.XMLClient.Interface;
using Google.Protobuf.WellKnownTypes;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR.Protocol;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Microsoft.IdentityModel.Tokens;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.LotTxn;
using Multek.Applications.Model.Entities.Multek;
using Multek.Library_Core.Camstar;
using Multek.Library_Core.Camstar.Constants;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Barcode
{
    public class LotInfoQuery : EFHelper<MultekCamstarDbContext>, ILotInfoQuery
    {
        public readonly ICamstarComm ICamstarComm;

        public LotInfoQuery(MultekCamstarDbContext tdb) : base(tdb)
        {

        }

        public LotInfoQuery(MultekCamstarDbContext tdb, ICamstarComm camstarComm) : base(tdb)
        {
            ICamstarComm = camstarComm;
        }

        /// <summary>
        /// 获取Lot的基础信息用于下码
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        public TrackALLInfo GetLotInfo(string lotName)
        {
            //TrackALLInfo _container = (from c in db.Containers
            //                           join p in db.Products on c.ProductId equals p.ProductId
            //                           join f in db.Factories on c.OriginalFactoryId equals f.FactoryId
            //                           join m in db.Mfgorders on c.cuWorkOrderId equals m.MFGORDERID
            //                           join o in db.Cuoems on p.CUOEMID equals o.CUOEMID
            //                           where c.ContainerName == lotName
            //                           select new Container { ContainerName = c.ContainerName, QTY2 = c.QTY2, CUMI_PN = p.CuMI_PN, FactoryName = f.FactoryName, cuPCSPerPnl = p.cuPCSPerPnl, CuStripPerPnl = p.CuStripPerPnl, CuPCSPerStrip = p.CuPCSPerStrip, cuCustomerPN = p.CUCUSTOMERPN, cuCustomerVersion = p.CUCUSTOMERVERSION, cuSolutionVersion = p.cuSolutionVersion, cuStampCode = m.CUSTAMPCODE, cuOEMName = o.CUOEMNAME, CuIsPnl = p.CuIsPnl, cuPcsCodeRule = p.cuPcsCodeRule, cuSetCodeRule = p.cuSetCodeRule, cuPnlCodeRule = p.cuPnlCodeRule }).SingleOrDefault();
            FormattableString fssql = $@" 
SELECT '' as INFO_ID,
       '' as  TRACKID,
        c.qty2,
       PB.PRODUCTNAME as PN,
       P.PRODUCTREVISION  as PN_VER,
       PT.PRODUCTTYPENAME as PRODUCT_TYPE,
       P.CUJDE_FGPN as  PARENT_MASTER_NUM,
        '' ERP_PN,
       P.CUCUSTOMERPN as  CUSTOMER_PRODUCT_NAME,
       
       BB.BOMNAME  as MBOM_ID,
       '' as PROD_ORDER,
       1 as P_CUTTING_QTY,
       P.CUSTRIPPERPNL S_CUTTING_QTY,
       nvl(P.CUPCSPERPNL,0) U_CUTTING_QTY,
       '' DELIVERY_UNIT,
       '' DELIVERY_DATE,
       OT.ORDERTYPENAME ORDER_TYPE,
       '' CUSTOMER_ID,
       '' LOT_PRIORITY_ID,
       F.FACTORYNAME FACTORY,
       '' IS_SUPPLY,
       1   P_QTY,
       P.CUSTRIPPERPNL S_QTY,
       nvl(P.CUPCSPERPNL,0) U_QTY,
       '' CUR_STEP,
       '' REMARK1,
       '' REMARK2,
       '' REMARK3,
       '' REMARK4,
       '' REMARK5,
       '' ISREWORK,
       '' WIPDETAILS_ID,
       WFB.WORKFLOWNAME WORKFLOW_NAME,
       WF.WORKFLOWID WORKFLOW_ID,
       '' CUR_STEP_SEQ,
       '' CUR_STEP_NAME,
       1 WIP_STATUS,
       C.STATUS,
       '' NG_STATUS,
       '' EQUIPMENT_ID,
       '' TOOL_ID,
       '' RFID,
       S.SPECREVISION SPEC_CONFIG_VER,
       SB.SPECNAME SPEC_CONFIG,
       1 PARENT_LOT,
       C.CONTAINERNAME PARENT_TRACKID,
       '' NEXT_STEP_SEQ,
       '' NEXT_STEP_NAME,
       '' DATECODE,
       '' CARRIER_ID,
       '' LAYER_MARK,
       WS1.WORKFLOWSTEPNAME NEXTSTEP,
       WS.WORKFLOWSTEPNAME STEP
  FROM CONTAINER C
  LEFT JOIN SALESORDER SO
    ON SO.SALESORDERID = C.SALESORDERID
  LEFT JOIN MFGORDER MO
    ON MO.MFGORDERID = C.MFGORDERID
  LEFT JOIN CURRENTSTATUS CS
    ON CS.CURRENTSTATUSID = C.CURRENTSTATUSID
  LEFT JOIN HOLDREASON HR
    ON HR.HOLDREASONID = C.HOLDREASONID
  LEFT JOIN WORKFLOWSTEP WS
    ON WS.WORKFLOWSTEPID = CS.WORKFLOWSTEPID
  LEFT JOIN WORKFLOWSTEP WS1
    ON WS1.WORKFLOWID = WS.WORKFLOWID
   AND WS1.SEQUENCE = (WS.SEQUENCE + 1)
 INNER JOIN PRODUCT P
    ON C.PRODUCTID = P.PRODUCTID
 INNER JOIN PRODUCTBASE PB
    ON P.PRODUCTBASEID = PB.PRODUCTBASEID
 INNER JOIN PRODUCTTYPE PT
    ON PT.PRODUCTTYPEID = P.PRODUCTTYPEID
  LEFT JOIN BOM B
    ON B.BOMID = C.BOMID
  LEFT JOIN BOMBASE BB
    ON BB.BOMBASEID = B.BOMBASEID
  LEFT JOIN ORDERTYPE OT
    ON OT.ORDERTYPEID = MO.ORDERTYPEID
  LEFT JOIN FACTORY F
    ON F.FACTORYID = CS.FACTORYID
 INNER JOIN WORKFLOWSTEP WFS
    ON WFS.WORKFLOWSTEPID = CS.WORKFLOWSTEPID
  LEFT JOIN WORKFLOW WF
    ON WF.WORKFLOWID = WFS.WORKFLOWID
  LEFT JOIN WORKFLOWBASE WFB
    ON WFB.WORKFLOWBASEID = WFB.WORKFLOWBASEID
  LEFT JOIN SPEC S
    ON S.SPECID = WFS.SPECID
  LEFT JOIN SPECBASE SB
    ON SB.SPECBASEID = S.SPECBASEID
 where c.containername = {lotName}

";


            TrackALLInfo _container = db.TrackALLInfo.FromSql<TrackALLInfo>(fssql).FirstOrDefault();

            return _container;
        }

        /// <summary>
        /// Gets the lot information.
        /// 包装领域模型为参数
        /// </summary>
        /// <param name="lotName">Name of the lot.</param>
        /// <returns></returns>
        public TrackALLInfo GetLotInfo(GetLotMsgReq lotName)
        {
            if (lotName.Lot != null && lotName.Lot.ToString().Length > 0)
            {


                FormattableString fssql = $@" 
                            SELECT '' as INFO_ID,
                                   '' as  TRACKID,
                                    c.qty2,
                                   PB.PRODUCTNAME as PN,
                                   P.PRODUCTREVISION  as PN_VER,
                                   PT.PRODUCTTYPENAME as PRODUCT_TYPE,
                                   P.CUJDE_FGPN as  PARENT_MASTER_NUM,
                                    '' ERP_PN,
                                   P.CUCUSTOMERPN as  CUSTOMER_PRODUCT_NAME,     
                                   BB.BOMNAME  as MBOM_ID,
                                   mo.mfgordername as PROD_ORDER,
                                   1 as P_CUTTING_QTY,
                                   P.CUSTRIPPERPNL S_CUTTING_QTY,
                                   nvl(P.CUPCSPERPNL,0) U_CUTTING_QTY,
                                   '' DELIVERY_UNIT,
                                   '' DELIVERY_DATE,
                                   OT.ORDERTYPENAME ORDER_TYPE,
                                   '' CUSTOMER_ID,
                                   '' LOT_PRIORITY_ID,
                                   F.FACTORYNAME FACTORY,
                                   '' IS_SUPPLY,
                                   1   P_QTY,
                                   P.CUSTRIPPERPNL S_QTY,
                                   nvl(P.CUPCSPERPNL,0) U_QTY,
                                   WS.WORKFLOWSTEPNAME CUR_STEP,
                                   hr.holdreasonname REMARK1,
                                   '' REMARK2,
                                   '' REMARK3,
                                   '' REMARK4,
                                   '' REMARK5,
                                   '' ISREWORK,
                                   '' WIPDETAILS_ID,
                                   WFB.WORKFLOWNAME WORKFLOW_NAME,
                                   WF.WORKFLOWID WORKFLOW_ID,
                                   ws.sequence CUR_STEP_SEQ,
                                   WS.WORKFLOWSTEPNAME CUR_STEP_NAME,
                                   c.cutrackflag WIP_STATUS,
                                   C.STATUS,
                                   '' NG_STATUS,
                                   '' EQUIPMENT_ID,
                                   '' TOOL_ID,
                                   '' RFID,
                                   S.SPECREVISION SPEC_CONFIG_VER,
                                   SB.SPECNAME SPEC_CONFIG,
                                   c.containername PARENT_LOT,
                                   C.CONTAINERNAME PARENT_TRACKID,
                                   ws1.sequence NEXT_STEP_SEQ,
                                   ws1.workflowstepname NEXT_STEP_NAME,
                                   c.cudatecode DATECODE,
                                   '' CARRIER_ID,
                                   '' LAYER_MARK,
                                   WS1.WORKFLOWSTEPNAME NEXTSTEP,
                                   WS.WORKFLOWSTEPNAME STEP,
                                   c.currentholdcount as ishold
                              FROM CONTAINER C
                              LEFT JOIN SALESORDER SO ON SO.SALESORDERID = C.SALESORDERID
                              LEFT JOIN MFGORDER MO ON MO.MFGORDERID = C.MFGORDERID
                              LEFT JOIN CURRENTSTATUS CS ON CS.CURRENTSTATUSID = C.CURRENTSTATUSID
                              LEFT JOIN HOLDREASON HR ON HR.HOLDREASONID = C.HOLDREASONID
                              LEFT JOIN WORKFLOWSTEP WS ON WS.WORKFLOWSTEPID = CS.WORKFLOWSTEPID
                              LEFT JOIN WORKFLOWSTEP WS1 ON WS1.WORKFLOWID = WS.WORKFLOWID AND WS1.SEQUENCE = (WS.SEQUENCE + 1)
                             INNER JOIN PRODUCT P ON C.PRODUCTID = P.PRODUCTID
                             INNER JOIN PRODUCTBASE PB ON P.PRODUCTBASEID = PB.PRODUCTBASEID
                             INNER JOIN PRODUCTTYPE PT ON PT.PRODUCTTYPEID = P.PRODUCTTYPEID
                              LEFT JOIN BOM B ON B.BOMID = C.BOMID
                              LEFT JOIN BOMBASE BB ON BB.BOMBASEID = B.BOMBASEID
                              LEFT JOIN ORDERTYPE OT ON OT.ORDERTYPEID = MO.ORDERTYPEID
                              LEFT JOIN FACTORY F ON F.FACTORYID = CS.FACTORYID
                              LEFT JOIN WORKFLOW WF ON WF.WORKFLOWID = WS.WORKFLOWID
                              LEFT JOIN WORKFLOWBASE WFB ON WFB.WORKFLOWBASEID = WF.WORKFLOWBASEID
                              LEFT JOIN SPEC S ON S.SPECID = cs.SPECID
                              LEFT JOIN SPECBASE SB ON SB.SPECBASEID = S.SPECBASEID
                             where c.containername = {lotName.Lot} ";

                try
                {
                    TrackALLInfo _container = db.TrackALLInfo.FromSql<TrackALLInfo>(fssql).FirstOrDefault();

                    return _container;
                }
                catch (Exception ex)
                {

                    //日志记录
                }
                return new TrackALLInfo();
            }
            else
            {
                return new TrackALLInfo();
            }
        }

        /// <summary>
        /// Gets the lot information.
        /// 批量查询存在BUG 。EF 的 in语法无法支持。
        /// </summary>
        /// <param name="lotName">Name of the lot.</param>
        /// <returns></returns>
        public List<TrackALLInfo> GetLotInfo(List<TrackALLInfo> lotName)
        {
            var Lots = (from i in lotName select i.PARENT_LOT).ToList();
            string wheresql = "where c.containername  in  (";
            foreach (var item in Lots)
            {
                wheresql = wheresql + ($"'{item}',");
            }
            wheresql = wheresql.TrimEnd('"');
            wheresql = wheresql.TrimEnd(',');
            wheresql = wheresql + ")";
            FormattableString fssql = $@" 
SELECT '' as INFO_ID,
       '' as  TRACKID,
    c.qty2,
       PB.PRODUCTNAME as PN,
       P.PRODUCTREVISION  as PN_VER,
       PT.PRODUCTTYPENAME as PRODUCT_TYPE,
       P.CUJDE_FGPN as  PARENT_MASTER_NUM,
        '' ERP_PN,
       P.CUCUSTOMERPN as  CUSTOMER_PRODUCT_NAME,
       
       BB.BOMNAME  as MBOM_ID,
       '' as PROD_ORDER,
       1 as P_CUTTING_QTY,
       P.CUSTRIPPERPNL S_CUTTING_QTY,
       nvl(P.CUPCSPERPNL,0) U_CUTTING_QTY,
       '' DELIVERY_UNIT,
       '' DELIVERY_DATE,
       OT.ORDERTYPENAME ORDER_TYPE,
       '' CUSTOMER_ID,
       '' LOT_PRIORITY_ID,
       F.FACTORYNAME FACTORY,
       '' IS_SUPPLY,
       1   P_QTY,
       P.CUSTRIPPERPNL S_QTY,
       nvl(P.CUPCSPERPNL,0) U_QTY,
       '' CUR_STEP,
       '' REMARK1,
       '' REMARK2,
       '' REMARK3,
       '' REMARK4,
       '' REMARK5,
       '' ISREWORK,
       '' WIPDETAILS_ID,
       WFB.WORKFLOWNAME WORKFLOW_NAME,
       WF.WORKFLOWID WORKFLOW_ID,
       '' CUR_STEP_SEQ,
       '' CUR_STEP_NAME,
       1 WIP_STATUS,
       C.STATUS,
       '' NG_STATUS,
       '' EQUIPMENT_ID,
       '' TOOL_ID,
       '' RFID,
       S.SPECREVISION SPEC_CONFIG_VER,
       SB.SPECNAME SPEC_CONFIG,
       1 PARENT_LOT,
       C.CONTAINERNAME PARENT_TRACKID,
       '' NEXT_STEP_SEQ,
       '' NEXT_STEP_NAME,
       '' DATECODE,
       '' CARRIER_ID,
       '' LAYER_MARK,
       WS1.WORKFLOWSTEPNAME NEXTSTEP,
       WS.WORKFLOWSTEPNAME STEP
  FROM CONTAINER C
  LEFT JOIN SALESORDER SO
    ON SO.SALESORDERID = C.SALESORDERID
  LEFT JOIN MFGORDER MO
    ON MO.MFGORDERID = C.MFGORDERID
  LEFT JOIN CURRENTSTATUS CS
    ON CS.CURRENTSTATUSID = C.CURRENTSTATUSID
  LEFT JOIN HOLDREASON HR
    ON HR.HOLDREASONID = C.HOLDREASONID
  LEFT JOIN WORKFLOWSTEP WS
    ON WS.WORKFLOWSTEPID = CS.WORKFLOWSTEPID
  LEFT JOIN WORKFLOWSTEP WS1
    ON WS1.WORKFLOWID = WS.WORKFLOWID
   AND WS1.SEQUENCE = (WS.SEQUENCE + 1)
 INNER JOIN PRODUCT P
    ON C.PRODUCTID = P.PRODUCTID
 INNER JOIN PRODUCTBASE PB
    ON P.PRODUCTBASEID = PB.PRODUCTBASEID
 INNER JOIN PRODUCTTYPE PT
    ON PT.PRODUCTTYPEID = P.PRODUCTTYPEID
  LEFT JOIN BOM B
    ON B.BOMID = C.BOMID
  LEFT JOIN BOMBASE BB
    ON BB.BOMBASEID = B.BOMBASEID
  LEFT JOIN ORDERTYPE OT
    ON OT.ORDERTYPEID = MO.ORDERTYPEID
  LEFT JOIN FACTORY F
    ON F.FACTORYID = CS.FACTORYID
 INNER JOIN WORKFLOWSTEP WFS
    ON WFS.WORKFLOWSTEPID = CS.WORKFLOWSTEPID
  LEFT JOIN WORKFLOW WF
     ON WF.WORKFLOWID = WS.WORKFLOWID AND WF.WORKFLOWID=WS1.WORKFLOWID AND WS.WORKFLOWID=WS1.WORKFLOWID
  LEFT JOIN WORKFLOWBASE WFB
    ON WFB.WORKFLOWBASEID = WFB.WORKFLOWBASEID
  LEFT JOIN SPEC S
    ON S.SPECID = WFS.SPECID
  LEFT JOIN SPECBASE SB
    ON SB.SPECBASEID = S.SPECBASEID
  
{wheresql}
";

            try
            {
                List<TrackALLInfo> _container = db.TrackALLInfo.FromSql<TrackALLInfo>(fssql).ToList();
                //List<TrackALLInfo> _container2 = db.TrackALLInfo.FromSql<TrackALLInfo>(fssql).Where(x => x.PARENT_LOT.Contains(Lots));

                return _container;
            }
            catch (Exception ex)
            {

                //日志记录
            }
            return new List<TrackALLInfo>();


        }

        /// <summary>
        ///  返修：获取返修方法
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetRepairMethod()
        {
            List<string> result = (from r in db.CURepairMethod select r.cuRepairMethodName).ToList<string>();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到返修方法。");
            }
            else
            {
                return new ResultModel<List<string>>().Success(result);
            }
        }

        /// <summary>
        /// 返修：获取返修Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetReworkLotInfo(SingleLotReq param)
        {
            FormattableString fssql = $@" 
                    SELECT
                        C.ContainerName AS Lot,
                        C.Qty,
                        C.Qty2,
                        SB.SpecName || ':' || S.SpecRevision AS Spec,
                        TO_CHAR(
                            SYSDATE - NVL(C.MoveInTimestamp, SYSDATE),
                            '99990.999'
                        ) AS DaysHere,
                        CASE
                            WHEN WL2.WIPLotId IS NULL THEN TO_CHAR(SYSDATE - C.LastMoveOutTimestamp, '99990.999')
                            ELSE TO_CHAR(
                                WL2.CreationTimestamp - C.LastMoveOutTimestamp,
                                '99990.999'
                            )
                        END AS QueueTime,
                        PB.ProductName || ':' || P.ProductRevision AS Product,
                        CASE
                            WHEN C.Status = 1 THEN 'ACTIVE'
                            WHEN C.Status = 2 THEN 'TERMINATED'
                            WHEN C.Status = 5 THEN 'SHIPPED'
                            ELSE TO_CHAR(C.Status)
                        END AS Status,
                        CASE
                            WHEN NVL(C.CurrentHoldCount, 0) > 0 THEN 'YES ' || TO_CHAR(
                                SYSDATE - NVL(C.OnHoldDate, SYSDATE),
                                '99990.999'
                            ) || ' Days'
                            ELSE 'NO'
                        END AS IsOnHold,
                        CASE
                            WHEN NVL(CS.InRework, 0) > 0 THEN 'YES Loop ' || TO_CHAR(CS.ReworkLoopCount) || ' Total ' || TO_CHAR(CS.ReworkTotalCount)
                            ELSE 'NO'
                        END AS InRework,
                        C.InsertionNumber AS Insertion,
                        WL1.ProcessSpecName || ':' || WL1.ProcessSpecRevision AS InsertionProcessSpec,
                        WL1.SSName || ':' || WL1.SSRevision AS InsertionSS,
                        (
                            NVL(WL1.TotalRejectQty, 0) + NVL(WL1.TotalRejectBinsQty, 0) - NVL(WL1.TotalBonusBackRejectQty, 0)
                        ) AS Rejects,
                        (
                            C.Qty - NVL(WL1.TotalRejectQty, 0) - NVL(WL1.TotalRejectBinsQty, 0) - NVL(WL1.TotalBonusBackRejectQty, 0)
                        ) AS MoveOutQty,
                        WL1.WIPStatus AS WIPStatus,
                        WL1.WIPType AS WIPType,
                        WL1.WIPYieldResult AS WIPYieldResult,
                        C.BatchNo AS BatchNo,
                        C.EquipmentCount AS EqpCount,
                        C.EquipmentLoadingCount AS EqpLoadingCount,
                        CASE
                            WHEN NVL(C.FutureHoldCount, 0) > 0 THEN 'YES ' || TO_CHAR(C.FutureHoldCount)
                            ELSE 'NO'
                        END AS FutureHoldExists,
                        CASE
                            WHEN C.ScheduleDataId IS NOT NULL
                            OR NVL(C.ScheduleCount, 0) > 0 THEN 'YES'
                            ELSE 'NO'
                        END AS InSchedule,
                        CS.CurrentSpecPass AS SpecPass,
                        S.ObjectCategory AS SpecCategory,
                        S.ObjectType AS SpecType,
                        S.Description AS SpecDescription,
                        WFS.Workflowstepname,
                        WFS.SEQUENCE AS WorkflowstepSeq,
                        WF.Workflowrevision,
                        WFB.Workflowname,
                        WFS2.WORKFLOWSTEPNAME RepairStepName,
                        WFS2.SEQUENCE AS RepairStepSeq,
                        c.CUTrackFlag
                    FROM
                        Container C
                        INNER JOIN CurrentStatus CS ON C.CurrentStatusId = CS.CurrentStatusId
                        INNER JOIN WORKFLOWSTEP WFS ON CS.WORKFLOWSTEPID = WFS.WORKFLOWSTEPID
                        INNER JOIN WORKFLOW WF ON WFS.WORKFLOWID = WF.WORKFLOWID 
                        INNER JOIN WORKFLOWBASE WFB ON WF.WORKFLOWBASEID = WFB.WORKFLOWBASEID 
                        INNER JOIN WORKFLOWSTEP WFS2 ON WF.WORKFLOWID = WFS2.WORKFLOWID
                        INNER JOIN Product P ON C.ProductId = P.ProductId
                        INNER JOIN ProductBase PB ON P.ProductBaseId = PB.ProductBaseId
                        INNER JOIN Spec S ON CS.SpecId = S.SpecId
                        INNER JOIN SpecBase SB ON S.SpecBaseId = SB.SpecBaseId
                        LEFT OUTER JOIN A_WIPLot WL1 ON C.CurrentWIPLotId = WL1.WIPLotId
                        LEFT OUTER JOIN A_WIPLot WL2 ON C.ContainerId = WL2.ContainerId
                        AND WL2.InsertionNumber = 1
                    WHERE WFS2.WORKFLOWSTEPNAME LIKE 'REPAIR%'  
                    AND C.ContainerName = {param.Lot}";

            List<ReworkLotInfoModel> result = db.ReworkLotInfoModel.FromSql<ReworkLotInfoModel>(fssql).ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到Lot信息");
            }
            else
            {
                if (result[0].Workflowstepname.Contains("REPAIR"))
                {
                    return new ResultModel<string>().Failed("该批次已在返修工站，不允许返修。");
                }
                else
                {
                    return new ResultModel<ReworkLotInfoModel>().Success(result[0]);
                }
            }
        }

        /// <summary>
        /// 返修：调用LotRework服务
        /// </summary>
        /// <returns></returns>
        public IResultModel CULotRepair(ReworkInfoReq param)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("LotRework");

             var inputData = _helper.InputData();

            inputData.DataField("CancelWIPTracking").SetValue(param.CancelWIPTracking);
            inputData.NamedObjectField("Container").SetRef(param.Container);
            inputData.DataField("cuReMark").SetValue(param.cuReMark);
            inputData.NamedObjectField("cuRepairMethod").SetRef(param.cuRepairMethod);
            inputData.NamedObjectField("Employee").SetRef(param.Employee);

            var subEndStep = inputData.NamedSubentityField("ReworkEndStep");
            subEndStep.SetName(param.ReworkEndStep);
            subEndStep.ParentInfo().SetRevisionedObjectRef(param.Workflowname, param.Workflowrevision, false);
            var subReEntryStep = inputData.NamedSubentityField("ReworkReEntryStep");
            subReEntryStep.SetName(param.ReworkReEntryStep);
            subReEntryStep.ParentInfo().SetRevisionedObjectRef(param.Workflowname, param.Workflowrevision, false);
            var subToWorkflow = inputData.NamedSubentityField("ToWorkflowStep");
            subToWorkflow.SetName(param.ReworkEndStep);
            subToWorkflow.ParentInfo().SetRevisionedObjectRef(param.Workflowname, param.Workflowrevision, false);

            inputData.NamedObjectField("ReworkReason").SetRef(param.ReworkReason);
            inputData.DataField("SelectionId").SetValue(param.SelectionId);
            inputData.DataField("SplitBins").SetValue(param.SplitBins);
            inputData.DataField("ToStepType").SetValue(param.ToStepType);
            inputData.DataField("TriggerMoveIn").SetValue(param.TriggerMoveIn);
            inputData.DataField("YieldOffRejects").SetValue(param.YieldOffRejects);

            _helper.SetExecute();
            var _resDocument = _helper.Submit();

            _resDocument.CheckErrors();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        ///  外协发送：获取供应商名字和描述
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetVendor(string param)
        {
            FormattableString fssql = $@"select vendorname, description from vendor v where v.vendorname like {param}";

            List<VerdorModel> result = db.Verdor.FromSql<VerdorModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到供应商。");
            }
            else
            {
                return new ResultModel<List<VerdorModel>>().Success(result);
            }
        }

        /// <summary>
        ///  外协发送：获取外协Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSLotInfo(OSLotReq param)
        {
            FormattableString fssql = $@"select p.productrevision,
                       mo.mfgordername cuWorkOrder,
                       c.containername cuLot,
                       c.qty2 cuPNLQty,
                       (c.qty / (p.cupcsperpnl / p.custripperpnl)) cuSETQty,
                       c.qty cuNeedProcessQty,
                       c.qty cuPCSQty,
                       pb.productname cuPN,
                       sb.specname cuSpec,
                       wf.workflowrevision,
                       p.cupcsarea cuperpcsarea,
                       wfb.workflowname,
                       wfs.workflowstepname,
                       wfs.sequence,
                       f.factoryname
                  from container c
                 inner join mfgorder mo
                    on mo.mfgorderid = c.cuworkorderid
                 inner join product p
                    on p.productid = c.productid
                 inner join productbase pb
                    on pb.productbaseid = p.productbaseid
                 inner join currentstatus cs
                    on cs.currentstatusid = c.currentstatusid
                 inner join workflowstep wfs
                    on wfs.workflowstepid = cs.workflowstepid
                 inner join spec s
                    on s.specid = cs.specid
                 inner join specbase sb
                    on sb.specbaseid = s.specbaseid
                 inner join workflow wf
                    on wf.workflowid = wfs.workflowid
                 inner join workflowbase wfb
                    on wfb.workflowbaseid = wf.workflowbaseid
                  left join factory f
                    on mo.cufactoryid = f.factoryid
                 where c.qty > 0
                   and c.containerid not in
                       (select cl.culotid
                          from cuoutsourcelotlist cl
                         inner join cuoutsourcinglotinfor co
                            on co.cuoutsourcinglotinforid = cl.cuoutsourcinglotinforid
                         where co.cureceivetime is null
                           and NVL(co.custatus, '-1') <> '2')
                   and c.CURRENTHOLDCOUNT = 0
                   and nvl(c.cuoutsourcing, 0) <> 1
                   and sb.specname not like '%DieBank%'
                   and c.containername like {'%' +param.LotName + '%'}
                   and pb.productname like {'%' + param.PN + '%'}
                   and sb.specname like {'%' + param.Spec + '%'}";

            List<OSLotInfoModel> result = db.OSLotInfoModel.FromSql<OSLotInfoModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到Lot。");
            }
            else
            {
                return new ResultModel<List<OSLotInfoModel>>().Success(result);
            }
        }

        /// <summary>
        ///  外协发送： 获取外协工序
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSSpecInfo(OSSpecReq param)
        {
            FormattableString fssql = $@"select wfs.sequence,
                       WF.WORKFLOWREVISION,
                       wfb.workflowname,
                       wfs.workflowstepname stepname,
                       sb.specname workflowstepname,
                       row_number() over(partition by wfb.workflowname order by wfs.sequence) rn
                  from workflow wf
                 inner join workflowbase wfb
                    on wfb.workflowbaseid = wf.workflowbaseid
                 inner join workflowstep wfs
                    on wfs.workflowid = wf.workflowid
                 inner join specbase sb
                    on sb.specbaseid = wfs.specbaseid
                 where wfs.workflowstepname not like N'%成品仓%'
                   and wfs.workflowstepname not like N'%REPAIR%'
                   and wfs.workflowstepname not like N'%PAOI%'
                   and wfb.workflowname = {param.WorkflowName}
                   and wfs.sequence >= {param.Sequence}
                   and wf.workflowrevision = {param.WorkflowRevision}
                 order by wfs.sequence";

            List<OSSpecInfoModel> result = db.OSSpecInfoModel.FromSql<OSSpecInfoModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到外协工序。");
            }
            else
            {
                return new ResultModel<List<OSSpecInfoModel>>().Success(result);
            }
        }

        /// <summary>
        ///  外协发送： 根据外协单号获取外协批次信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInfoByOSOrder(string param)
        {
            FormattableString fssql = $@"select rownum, co.cuoutsourcinglotinforname,
                   co.cupo,
                   c.containername,
                   co.cucustomsno,
                   co.cudeliverytime,
                   MO.MFGORDERNAME,
                   PB.PRODUCTNAME,
                   p.productrevision,
                   CL.CUNEEDPROCESSQTY,
                   row_number() over(partition by c.containername order by cl.cuspecstepno) cuIndex,
                   co.cureceivetime,
                   co.curemarks,
                   v.vendorname,
                   v.description,
                   v.cuisexternalsuppliers,
                   SB.SPECNAME,
                   wf.workflowrevision,
                   wfb.workflowname,
                   wfs.workflowstepname,
                   cl.cupcsqty,
                   cl.cupnlqty,
                   cl.cureturnqty,
                   cl.cusetqty,
                   cl.cuspecstepno,
                   cl.cusquare,
                   cl.cuunprocessqty,
                   f.factoryname
              from cuoutsourcinglotinfor co
             inner join cuoutsourcelotlist cl
                on cl.cuoutsourcinglotinforid = co.cuoutsourcinglotinforid
             inner join container c
                on c.containerid = cl.culotid
             inner join product p
                on p.productid = cl.cupnid
             inner join productbase pb
                on pb.productbaseid = p.productbaseid
             inner join mfgorder mo
                on mo.mfgorderid = cl.cuworkorderid
             inner join spec s
                on s.specid = cl.cuspecid
             inner join specbase sb
                on sb.specbaseid = s.specbaseid
              left join workflowstep wfs
                on wfs.workflowstepid = cl.cuspecstepid
              left join workflow wf
                on wf.workflowid = wfs.workflowid
              left join workflowbase wfb
                on wfb.workflowbaseid = wf.workflowbaseid
             inner join vendor v
                on v.vendorid = co.cuvendorid
              left join factory f
                on mo.cufactoryid = f.factoryid
             where co.cureceivetime is null
               and nvl(co.custatus, '-1') <> '2'
               and co.cuoutsourcinglotinforname like {param}
             order by c.containername, cl.cuspecstepno";

            List<OSOrderInfoModel> result = db.OSOrderInfoModel.FromSql<OSOrderInfoModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("查询结果为空，单号是否为空或已接收或已取消。");
            }
            else
            {
                return new ResultModel<List<OSOrderInfoModel>>().Success(result);
            }
        }

        /// <summary>
        /// 外协发送：调用cuOutsourcingLotTxn服务
        /// </summary>
        /// <returns></returns>
        public IResultModel CUOutsourcingLotTxn(OSLotSendReq param)
        {
            foreach (CUOutSouringLotDetails drDetail in param.cuOutSouringLotDetails)
            {
                FormattableString fssql = $@"select co.cuoutsourcinglotinforname
                            --,co.cupo, c.containername ,co.cucustomsno, co.cudeliverytime, MO.MFGORDERNAME, PB.PRODUCTNAME,   CL.CUNEEDPROCESSQTY,row_number() over(partition by c.containername order by cl.cuspecstepno) cuIndex,
                            --co.cureceivetime, co.curemarks, v.vendorname, v.description, v.cuisexternalsuppliers, SB.SPECNAME,
                            --wf.workflowrevision,wfb.workflowname,wfs.workflowstepname,
                            --cl.cupcsqty, cl.cupnlqty, cl.cureturnqty, cl.cusetqty, cl.cuspecstepno , cl.cusquare, cl.cuunprocessqty
                            from cuoutsourcinglotinfor co
                            inner join cuoutsourcelotlist cl on cl.cuoutsourcinglotinforid = co.cuoutsourcinglotinforid
                            inner join container c on c.containerid = cl.culotid
                            inner join product p on p.productid = cl.cupnid
                            inner join productbase pb on pb.productbaseid = p.productbaseid
                            inner join mfgorder mo on mo.mfgorderid = cl.cuworkorderid
                            inner join spec s on s.specid = cl.cuspecid 
                            inner join specbase sb on sb.specbaseid = s.specbaseid
                            left join workflowstep wfs on wfs.workflowstepid = cl.cuspecstepid
                            left join workflow wf on wf.workflowid = wfs.workflowid
                            left join workflowbase wfb on wfb.workflowbaseid = wf.workflowbaseid
                            inner join vendor v on v.vendorid = co.cuvendorid
                            where  cl.cureceivetime is  null   and  nvl(co.custatus,'-1') <> '2'
                            and c.containername  = {drDetail.cuLot}
                            --order by co.cudeliverytime  desc, c.containername, cl.cuspecstepno";

                List<CheckSendLotModel> result = db.CheckSendLotModel.FromSql<CheckSendLotModel>(fssql)?.ToList();
                if (result.Count > 0)
                {
                    return new ResultModel<string>().Failed(drDetail.cuLot + "存在批次外发未接受,不允许再次提交，请重新核实！");
                }
            }

            if (String.IsNullOrEmpty(param.cuIsExternalSuppliers)) { param.cuIsExternalSuppliers = "false"; }
            if (String.IsNullOrEmpty(param.cuOutsourcingOrderNR)) { param.cuOutsourcingOrderNR = "cuOutsouringSendingNumber"; }

            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuOutsourcingLotTxn");

            var inputData = _helper.InputData();

            if (param.cuDeliveryOrderNo.Trim().Length > 0)
            {
                inputData.DataField("cuDeliveryOrderNo").SetValue(param.cuDeliveryOrderNo);
            }
            else
            {
                inputData.NamedObjectField("cuOutsourcingOrderNR").SetRef(param.cuOutsourcingOrderNR);
            }
            inputData.NamedObjectField("cuVendor").SetRef(param.cuVendor);
            inputData.DataField("cuVendorDescription").SetValue(param.cuVendorDescription);
            inputData.DataField("cuPO").SetValue(param.cuPO);
            inputData.DataField("cuPRF").SetValue(param.cuPRF);
            inputData.DataField("cuCustomsNo").SetValue(param.cuCustomsNo);
            inputData.DataField("cuRemarks").SetValue(param.cuRemarks);
            inputData.DataField("cuIsExternalSuppliers").SetValue(param.cuIsExternalSuppliers);
            inputData.DataField("cuDeliveryTime").SetFormattedValue(DateTime.Now.ToString(), DataFormats.FormatDateAndTime);
            inputData.NamedObjectField("cuSendingEmployee").SetRef(param.cuSendingEmployee);

            var subOSLotDetails = inputData.SubentityList("cuOutSouringLotDetails");
            foreach (var item in param.cuOutSouringLotDetails)
            {
                var subItem = subOSLotDetails.AppendItem();
                subItem.DataField("cuIndex").SetValue(item.cuIndex);
                subItem.NamedObjectField("cuLot").SetRef(item.cuLot);
                subItem.DataField("cuNeedProcessQty").SetValue(item.cuNeedProcessQty);
                subItem.DataField("cuPCSQty").SetValue(item.cuPCSQty);
                subItem.RevisionedObjectField("cuPN").SetRef(item.cuPN, "", true);
                subItem.DataField("cuPNLQty").SetValue(item.cuPNLQty);
                subItem.DataField("cuReturnQty").SetValue(item.cuReturnQty);
                subItem.DataField("cuSETQty").SetValue(item.cuSETQty);
                subItem.RevisionedObjectField("cuSpec").SetRef(item.cuSpec, "", true);

                var subSpecStep = subItem.NamedSubentityField("cuSpecStep");
                subSpecStep.SetName(item.cuSpecStep);
                subSpecStep.ParentInfo().SetRevisionedObjectRef(item.WorkflowName, item.WorkflowRevision, false);

                subItem.DataField("cuSpecStepNo").SetValue(item.cuSpecStepNo);
                subItem.DataField("cuSquare").SetValue(item.cuSquare);
                subItem.DataField("cuUnPnlQty").SetValue(item.cuUnPnlQty);
                subItem.DataField("cuUnProcessQty").SetValue(item.cuUnProcessQty);
                subItem.NamedObjectField("cuWorkOrder").SetRef(item.cuWorkOrder);
            }

            var subLotDetails = inputData.SubentityList("cuLotDetails");
            foreach (var item in param.cuLotDetails)
            {
                var subItem = subLotDetails.AppendItem();
                subItem.NamedObjectField("cuLot").SetRef(item.cuLot);
                subItem.DataField("cuSpecNo").SetValue(item.cuSpecNo);
            }

            _helper.SetExecute();
            var requestData = _helper.RequestData();
            requestData.RequestField("cuDeliveryOrderNo");
            requestData.RequestField("CompletionMsg");
            var _resDocument = _helper.Submit();
            //OSRSOrderModel _reValue = new OSRSOrderModel();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            if (_error.success)
            {
                string cuDeliveryOrderNo = ((ICsiDataField)_resDocument.GetService().ResponseData().GetResponseFieldByName("cuDeliveryOrderNo")).GetValue();
                //_reValue.TempValue = cuDeliveryOrderNo;
                //_reValue.CompletionMsg = _error.msg;
                _error.msg = cuDeliveryOrderNo;
            }
            return _error;
        }

        /// <summary>
        ///  外协取消： 查询外协单号
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSROrder(SingleLotReq param)
        {
            FormattableString fssql = $@"SELECT DISTINCT L.CUOUTSOURCINGLOTINFORNAME AS Lot
              FROM cuOutSourcingLotInfor L
             INNER JOIN cuoutsourcelotlist CL
                on CL.cuoutsourcinglotinforid = L.cuoutsourcinglotinforid
             WHERE L.CUOUTSOURCINGLOTINFORNAME LIKE {'%' + param.Lot + '%'}
               AND NVL(L.cuStatus, '0') <> '2'
               AND L.CURECEIVETIME IS NULL
             ORDER BY L.CUOUTSOURCINGLOTINFORNAME DESC";

            List<OSROrderInfo> result = db.GetOSOrder.FromSql<OSROrderInfo>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("查询结果为空。");
            }
            else
            {
                return new ResultModel<List<OSROrderInfo>>().Success(result);
            }
        }

        /// <summary>
        ///  外协取消： 查询Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSRLotByOrder(SingleLotReq param)
        {
            FormattableString fssql = $@"select co.cuoutsourcinglotinforname AS cuOutSouringNo,
                   co.cupo,
                   c.containername AS cuLot,
                   co.cucustomsno,
                   co.cudeliverytime,
                   MO.MFGORDERNAME,
                   PB.PRODUCTNAME AS cuPN,
                   p.productrevision,
                   CL.CUNEEDPROCESSQTY,
                   row_number() over(partition by c.containername order by cl.cuspecstepno) cuIndex,
                   co.cureceivetime,
                   co.curemarks,
                   v.vendorname,
                   v.description,
                   v.cuisexternalsuppliers,
                   SB.SPECNAME AS cuSpec,
                   s.specrevision,
                   wf.workflowrevision,
                   wfb.workflowname,
                   wfs.workflowstepname,
                   cl.cupcsqty,
                   cl.cupnlqty,
                   cl.cureturnqty,
                   cl.cusetqty,
                   cl.cuspecstepno,
                   cl.cusquare,
                   cl.cuunprocessqty
              from cuoutsourcinglotinfor co
             inner join cuoutsourcelotlist cl
                on cl.cuoutsourcinglotinforid = co.cuoutsourcinglotinforid
             inner join container c
                on c.containerid = cl.culotid
             inner join product p
                on p.productid = cl.cupnid
             inner join productbase pb
                on pb.productbaseid = p.productbaseid
             inner join mfgorder mo
                on mo.mfgorderid = cl.cuworkorderid
             inner join spec s
                on s.specid = cl.cuspecid
             inner join specbase sb
                on sb.specbaseid = s.specbaseid
              left join workflowstep wfs
                on wfs.workflowstepid = cl.cuspecstepid
              left join workflow wf
                on wf.workflowid = wfs.workflowid
              left join workflowbase wfb
                on wfb.workflowbaseid = wf.workflowbaseid
             inner join vendor v
                on v.vendorid = co.cuvendorid
             where cl.cureceivetime is null
               AND co.cuoutsourcinglotinforname like {param.Lot}
             order by c.containername, cl.cuspecstepno";

            List<OSRLotInfo> result = db.OSRLotInfo.FromSql<OSRLotInfo>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("查询结果为空。");
            }
            else
            {
                return new ResultModel<List<OSRLotInfo>>().Success(result);
            }
        }

        /// <summary>
        /// 外协取消： 放行Lot
        /// </summary>
        /// <returns></returns>
        public IResultModel CUOutSourcingLotRepealTxn(OSRLotRepealReq param)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuOutSourcingLotRepealTxn");

            var inputData = _helper.InputData();
            inputData.NamedObjectField("Employee").SetRef(param.Employee);
            if (!string.IsNullOrEmpty(param.CURepealRemark))
            {
                inputData.DataField("cuRepealRemark").SetValue(param.CURepealRemark);
            }
            var subOSLotDetails = inputData.NamedObjectList("cuOutSourcingLotInforList");
            foreach (var item in param.CUOutSourcingLotInforList)
            {
                subOSLotDetails.AppendItem(item.CUOUTSOURINGNO);
            }

            _helper.SetExecute();
            var requestData = _helper.RequestData();
            requestData.RequestField("CompletionMsg");
            var _resDocument = _helper.Submit();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        ///  外协接收： 查询Lot信息  
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSRELotInfo(OSRELotReq param)
        {
            FormattableString fssql = $@"SELECT *
                  FROM (Select f.factoryname,
                               co.cuoutsourcinglotinforname,
                               co.cupo,
                               c.containername,
                               co.cucustomsno,
                               co.cudeliverytime,
                               MO.MFGORDERNAME,
                               PB.PRODUCTNAME,
                               CL.CUNEEDPROCESSQTY,
                               row_number() over(partition by c.containername order by cl.cuspecstepno) cuIndex,
                               co.cureceivetime,
                               co.curemarks,
                               v.vendorname,
                               v.description,
                               v.cuisexternalsuppliers,
                               SB.SPECNAME,
                               wf.workflowrevision,
                               wfb.workflowname,
                               wfs.workflowstepname,
                               cl.cupcsqty,
                               cl.cupnlqty,
                               cl.cureturnqty,
                               cl.cusetqty,
                               cl.cuspecstepno,
                               cl.cusquare,
                               cl.cuunprocessqty,
                               row_number() over(partition BY c.containername ORDER BY cl.cuindex desc) RN
                          from cuoutsourcinglotinfor co
                         inner join cuoutsourcelotlist cl
                            on cl.cuoutsourcinglotinforid = co.cuoutsourcinglotinforid
                         inner join container c
                            on c.containerid = cl.culotid
                         inner join product p
                            on p.productid = cl.cupnid
                         inner join productbase pb
                            on pb.productbaseid = p.productbaseid
                         inner join mfgorder mo
                            on mo.mfgorderid = cl.cuworkorderid
                         inner join spec s
                            on s.specid = cl.cuspecid
                         inner join specbase sb
                            on sb.specbaseid = s.specbaseid
                          left join workflowstep wfs
                            on wfs.workflowstepid = cl.cuspecstepid
                          left join workflow wf
                            on wf.workflowid = wfs.workflowid
                          left join workflowbase wfb
                            on wfb.workflowbaseid = wf.workflowbaseid
                         inner join vendor v
                            on v.vendorid = co.cuvendorid
                          left join factory f
                            on mo.cufactoryid = f.factoryid
                         where cl.cureceivetime is null
                           AND NVL(co.custatus, '-1') <> '2'
                           and c.containername like {param.Lot})
                 WHERE RN = 1";

            List<OSRELotInfoModel> result = db.OSRELotInfoModel.FromSql<OSRELotInfoModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("查询结果为空。");
            }
            else
            {
                //对比工厂
                FormattableString facsql = $@"select f.factoryname from employee e 
                inner join sessionvalues sv on sv.employeeid = e.employeeid
                inner join factory f on f.factoryid = sv.factoryid
                where e.employeename={param.Employee}";

                List<OSREFactoryModel> facResult = db.OSREFactoryModel.FromSql<OSREFactoryModel>(facsql)?.ToList();
                if (facResult.Count == 0)
                {
                    return new ResultModel<string>().Failed("工厂查询结果为空。");
                }
                else
                {
                    if (result[0].Factoryname == facResult[0].FactoryName)
                    {
                        return new ResultModel<List<OSRELotInfoModel>>().Success(result);
                    }
                    else
                    {
                        return new ResultModel<string>().Failed("不允许接收其他厂区的批次。");
                    }
                }
            }
        }

        /// <summary>
        ///  外协接收：提交服务
        /// </summary>
        /// <returns></returns>
        public IResultModel CUOSRELotTxn(OSRESubmitReq param)
        {
            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
            _helper.CreateService("cuOutsourcingLotTxn");

            var inputData = _helper.InputData();

            if (param.CUoutsourcinglotinforname.Trim().Length > 0)
            {
                inputData.DataField("cuDeliveryOrderNo").SetValue(param.CUoutsourcinglotinforname);
            }
            inputData.DataField("cuIsExternalSuppliers").SetValue(param.cuIsExternalSuppliers);
            inputData.NamedObjectField("cuReceiveEmployee").SetRef(param.cuReceiveEmployee);
            inputData.DataField("cuReceiveTime").SetFormattedValue(DateTime.Now.ToString(), DataFormats.FormatDateAndTime);
            inputData.NamedObjectField("cuVendor").SetRef(param.cuVendor);
            inputData.DataField("cuVendorDescription").SetValue(param.cuVendorDescription);
            inputData.DataField("cuRemarks").SetValue(param.cuRemarks);

            var subOSLotDetails = inputData.SubentityList("cuOutSouringLotDetails");
            foreach (var item in param.cuOutSouringLotDetails)
            {
                var subItem = subOSLotDetails.AppendItem();
                subItem.DataField("cuIndex").SetValue(item.cuIndex);
                subItem.NamedObjectField("cuLot").SetRef(item.Containername);
                subItem.DataField("cuNeedProcessQty").SetValue(item.cuNeedProcessQty);
                subItem.DataField("cuPCSQty").SetValue(item.cuPCSQty);
                subItem.RevisionedObjectField("cuPN").SetRef(item.cuPN, "", true);
                subItem.DataField("cuPNLQty").SetValue(item.cuPNLQty);
                subItem.DataField("cuReturnQty").SetValue(item.cuReturnQty);
                subItem.DataField("cuSETQty").SetValue(item.cuSetQty);
                subItem.RevisionedObjectField("cuSpec").SetRef(item.cuSpec, "", true);
                //subItem.NamedObjectField("cuSpecStep").SetRef(item.cuSpecStep);
                subItem.DataField("cuSpecStepNo").SetValue(item.cuSpecStepNo);
                subItem.DataField("cuSquare").SetValue(item.cuSquare);
                subItem.DataField("cuUnPnlQty").SetValue(item.cuUnPnlQty);
                subItem.DataField("cuUnProcessQty").SetValue(item.cuUnProcessQty);
                subItem.NamedObjectField("cuWorkOrder").SetRef(item.cuWorkOrder);
            }

            var subLotDetails = inputData.SubentityList("cuLotDetails");
            foreach (var item in param.cuLotDetails)
            {
                var subItem = subLotDetails.AppendItem();
                subItem.NamedObjectField("cuLot").SetRef(item.cuLot);
                subItem.DataField("cuSpecNo").SetValue(item.cuSpecNo);
            }

            _helper.SetExecute();
            var requestData = _helper.RequestData();
            requestData.RequestField("CompletionMsg");
            var _resDocument = _helper.Submit();
            ResultModel<string> _error = new ResultModel<string>();
            _resDocument.CheckErrors(_error);
            return _error;
        }

        /// <summary>
        /// 抽检-手动： 查询Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetLotSamplingTask(STCreateLotReq param)
        {
            FormattableString fssql = $@"SELECT NVL(C.CURRENTHOLDCOUNT, 0) AS HoldCount,
                               NVL(C.STATUS, '-1') AS ContainerStatus,
                               C.Containerid AS cuLotId,
                               C.ContainerName AS cuLot,
                               P.PRODUCTID AS cuPN,
                               S.SPECID AS cuSpecId,
                               P.PRODUCTREVISION AS cuPNRevision,
                               PB.PRODUCTNAME AS cuPNName,
                               SB.SPECNAME AS cuSpecName,
                               S.SPECREVISION AS cuSpecRevision,
                               CASE NVL(C.CUTRACKFLAG, 0)
                                 WHEN 0 THEN
                                  'Move In '
                                 WHEN 1 THEN
                                  'Track In Part'
                                 WHEN 2 THEN
                                  'Track In Complete'
                                 WHEN 3 THEN
                                  'Track Out Part'
                                 WHEN 4 THEN
                                  'Track Out Complete'
                                 WHEN 5 THEN
                                  'Move Out'
                               END AS cuTrackFlag
                          FROM CONTAINER C
                         INNER JOIN CURRENTSTATUS CS
                            ON CS.CURRENTSTATUSID = C.CURRENTSTATUSID
                         INNER JOIN PRODUCT P
                            ON C.PRODUCTID = P.PRODUCTID
                         INNER JOIN PRODUCTBASE PB
                            ON P.PRODUCTBASEID = PB.PRODUCTBASEID
                         INNER JOIN SPEC S
                            ON S.SPECID = CS.SPECID
                         INNER JOIN SPECBASE SB
                            ON S.SPECBASEID = SB.SPECBASEID
                         WHERE C.CONTAINERNAME = {param.Lot}
                           AND NOT EXISTS (SELECT 0
                                  FROM CUSAMPLINGLOTHISTORY H
                                 WHERE S.SPECID = H.CUSPECID
                                   AND C.CONTAINERID = H.Cucreatelotid
                                   AND NVL(H.CULOTID, ' ') = ' ')";
            List<STCreateLotInfoModel> result = db.STCreateLotInfoModel.FromSql<STCreateLotInfoModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("批次不存在或检验尚未完成");
            }
            else
            {
                if (result[0].HoldCount > 0)
                {
                    return new ResultModel<string>().Failed("批次被Hold");
                }
                else if (result[0].ContainerStatus == "2")
                {
                    return new ResultModel<string>().Failed("批次必须为Active状态");
                }
                else
                {
                    return new ResultModel<List<STCreateLotInfoModel>>().Success(result);
                }
            }
        }

        /// <summary>
        /// 抽检-手动： 查询抽检种类
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetSamplingCategory(STCreateLotReq param)
        {
            FormattableString fssql;
            if (string.IsNullOrEmpty(param.Lot))
            {
                fssql = $@"SELECT T.CUSAMPLINGCATEGORYNAME AS CateGoryName FROM CUSAMPLINGCATEGORY T WHERE 1=1";
            }
            else
            {
                fssql = $@"SELECT DISTINCT ca.cusamplingcategoryname AS CateGoryName
                    FROM CONTAINER con
                    INNER JOIN CURRENTSTATUS CS ON con.CURRENTSTATUSID = CS.CURRENTSTATUSID
                    inner join cusamplingmatrix c on c.CUSPECID=CS.SPECID
                    INNER JOIN cuSamplingCategory ca ON C.CUSAMPLINGCATEGORYID = CA.CUSAMPLINGCATEGORYID
                    WHERE con.containername = {param.Lot}";
            }

            List<STCreateCategoryModel> result = db.STCreateCategoryModel.FromSql<STCreateCategoryModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未查到抽检种类数据");
            }
            else
            {
                return new ResultModel<List<STCreateCategoryModel>>().Success(result);
            }
        }

        /// <summary>
        /// 抽检-手动： 查询检验矩阵
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetCheckMatrix(STCreateLotReq param)
        {
            FormattableString fssql = $@"SELECT M.CUSAMPLINGMATRIXNAME,
                M.Cusamplingweight,T2.Productid AS RefPN,M.CUPNID AS MatrixPN,T2.CUOEMID AS RefOEM, 
                M.CUOEMID MatrixOEM, T2.CUPRODUCTIONTYPEID AS RefProductionType,
                M.CUPRODUCTIONTYPEID AS MatrixProductionType,T2.CUCEMID AS RefCEM, M.Cucemid AS MatrixCEM
                FROM CUSAMPLINGMATRIX M
                INNER JOIN CUSAMPLINGCATEGORY CT ON M.CUSAMPLINGCATEGORYID = CT.CUSAMPLINGCATEGORYID
                INNER JOIN 
                (
                    SELECT DISTINCT SP.SPECID,OEM.CUOEMID,MO.CUPRODUCTIONTYPEID,P.PRODUCTID,CEM.CUCEMID
                    FROM CONTAINER C 
                    INNER JOIN PRODUCT P ON C.PRODUCTID = P.PRODUCTID
                    INNER JOIN MFGORDER MO on MO.MFGORDERID = C.CUWORKORDERID
                    LEFT JOIN CUOEM OEM ON OEM.CUOEMID = P.CUOEMID  
                    LEFT JOIN CUCEM CEM ON CEM.CUCEMID = P.CUCEMID 
                    INNER JOIN CURRENTSTATUS CS ON C.CURRENTSTATUSID = CS.CURRENTSTATUSID
                    INNER JOIN CUPRODUCTIONTYPE TP ON MO.CUPRODUCTIONTYPEID = TP.CUPRODUCTIONTYPEID
                    INNER JOIN SPEC SP ON CS.SPECID = SP.SPECID
                    INNER JOIN SPECBASE SB ON SP.SPECBASEID = SB.SPECBASEID
                    WHERE C.CONTAINERNAME = {param.Lot}
                ) T2 ON  T2.SPECID = M.CUSPECID 
                WHERE CT.CUSAMPLINGCATEGORYNAME = {param.SamplingCategoryName}
                AND NVL(M.CUMANUALFLAG,'0') = '1' AND NVL(M.CUISACTIVE,'0') = '1' 
                ORDER BY M.Cusamplingweight DESC";

            List<STCreateCheckMatrixModel> result = db.STCreateCheckMatrixModel.FromSql<STCreateCheckMatrixModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到符合要求的检验矩阵");
            }
            else
            {
                //--1).如果矩阵里面有维护PN，则必须PN一致(只取MatrixPN为空 或(MatrixPN不为空 && MatrixPN == RefPN的数据)
                result.RemoveAll(c => !string.IsNullOrEmpty(c.MatrixPN) && c.MatrixPN != c.RefPN);
                //--2).如果矩阵里面有维护ProductionType，则必须ProductionType一致 （在1基础上过滤后的数据，再过滤 MatrixProductionType为空或(MatrixProductionType不为空 && MatrixProductionType == RefProductionType)的数据)
                result.RemoveAll(c => !string.IsNullOrEmpty(c.MatrixProductionType) && c.MatrixProductionType != c.RefProductionType);
                //--3).如果矩阵里面有维护CEM，则必须CEM一致 （在2基础上过滤后的数据，再过滤 MatrixCEM为空或(MatrixCEM不为空 && MatrixCEM == RefCEM)的数据)
                result.RemoveAll(c => !string.IsNullOrEmpty(c.MatrixCEM) && c.MatrixCEM != c.RefCEM);
                // --4).如果矩阵里面有维护OEM，则必须OEM一致（在3基础上过滤后的数据，再过滤 MatrixOEM为空或(MatrixOEM不为空 && MatrixOEM == RefOEM)的数据)
                result.RemoveAll(c => !string.IsNullOrEmpty(c.MatrixOEM) && c.MatrixOEM != c.RefOEM);

                return new ResultModel<List<STCreateCheckMatrixModel>>().Success(result);
            }
        }

        /// <summary>
        ///  抽检-手动：提交手动创建的抽检任务
        /// </summary>
        /// <returns></returns>
        public IResultModel APP_PostCreateSamplingTask(PostSamplingTask_Req param)
        {
            //判断是否已经有检验任务
            var lots = param.SamplingTasks.Select(c => "'" + c.cuLot + "'");
            FormattableString fssql = $@"SELECT c.containerid,c.containername,S.SPECID  --488103800000003b
                    FROM CONTAINER C 
                    INNER JOIN CURRENTSTATUS CS ON CS.CURRENTSTATUSID = C.CURRENTSTATUSID
                    INNER JOIN SPEC S ON S.SPECID = CS.SPECID
                    INNER JOIN SPECBASE SB ON S.SPECBASEID = SB.SPECBASEID
                    WHERE EXISTS
                    (
                        SELECT 0 FROM 
                        (
                            SELECT M.CUSPECID,H.CUCREATELOTID FROM CUSAMPLINGLOTHISTORY H
                            INNER JOIN CONTAINER C1 ON H.CUCREATELOTID = C1.CONTAINERID
                            INNER JOIN CUSAMPLINGTASK T ON H.CUSAMPLINGTASKID = T.CUSAMPLINGTASKID
                            INNER JOIN CUSAMPLINGCATEGORY C2 ON T.CUSAMPLINGCATEGORYID = C2.CUSAMPLINGCATEGORYID
                            INNER JOIN CUSAMPLINGMATRIX M ON C2.CUSAMPLINGCATEGORYID = M.CUSAMPLINGCATEGORYID
                            WHERE 1=1 AND NVL(M.CUMANUALFLAG,'0') = '1' AND NVL(M.CUISACTIVE,'0') = '1'
                            AND C1.CONTAINERNAME IN({string.Join(",", lots)})
                            AND C2.CUSAMPLINGCATEGORYNAME = '{param.CategoryName}'
                            AND M.CUSAMPLINGMATRIXNAME = '{param.CheckMatrixName}'
                            AND NVL(H.CULOTID,' ') = ' '
                        ) TMP WHERE TMP.CUSPECID = S.SPECID AND C.CONTAINERID = TMP.CUCREATELOTID
                    ) AND C.CONTAINERNAME IN({string.Join(",", lots)})";

            List<STCreateCheckMultTaskModel> result = db.STCreateCheckMultTaskModel
                .FromSql<STCreateCheckMultTaskModel>(fssql)?.ToList();
            if (result.Count > 0)
            {
                var exlots = result.Select(c => c.ContainerName);
                return new ResultModel<string>().Failed($@"保存失败,{string.Join(",", exlots)} 已有同样的抽检任务");
            }
            else
            {
                //调用服务
                CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                _helper.CreateService("cuManualSamplingTxn");
                var inputData = _helper.InputData();

                inputData.NamedObjectField("cuSamplingCategory").SetRef(param.CategoryName);
                var details = inputData.NamedObjectList("cuSamplingLotSrvData");
                foreach (var i in param.SamplingTasks)
                {
                    var csiNamedObject = details.AppendItem("");
                    csiNamedObject.NamedObjectField("cuLot").SetRef(i.cuLot);
                    csiNamedObject.RevisionedObjectField("cuPN").SetRef(i.cuPNName, i.cuPNRevision, false);
                    csiNamedObject.RevisionedObjectField("cuSpec").SetRef(i.cuSpecName, i.cuSpecRevision, false);
                    csiNamedObject.DataField("cuTrackFlag").SetValue(i.cuTrackFlag);
                }
                inputData.NamedObjectField("cuSamplingMatrix").SetRef(param.CheckMatrixName);

                _helper.SetExecute();
                var requestData = _helper.RequestData();
                requestData.RequestField("CompletionMsg");
                var _resDocument = _helper.Submit();
                _resDocument.CheckErrors();
                ResultModel<string> _error = new ResultModel<string>();
                _resDocument.CheckErrors(_error);
                return _error;
            }
        }

        /// <summary>
        /// 抽检-查询： 查询抽检任务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetSamplingCheckTasks(SamplingCheckTasks_Req param)
        {
            FormattableString fssql;
            //string sql = string.Empty;

            if (param.Spec.Length == 0){param.Spec = "%";}
            if (param.Lot.Length == 0){param.Lot = "%";}
            if (param.Product.Length == 0){param.Product = "%";}
            if (param.Category.Length == 0){param.Category = "%";}

            if (param.HandFlag == "1")
            {
                fssql = $@"SELECT PRODUCTBASE.PRODUCTNAME,SPECBASE.SPECNAME,RESOURCEDEF.RESOURCENAME,CUSAMPLINGTASK.CULAYERNUMMIN,
            CUSAMPLINGTASK.CULAYERNUMMAX,CUSAMPLINGTASK.CUCYCLE,CUSAMPLINGTASK.CUQTY,CUSAMPLINGTASK.cuSamplingTaskName,
            CUSAMPLINGRULE.CUWIPDATASETUPID,CUCEM.CUCEMNAME,CUOEM.CUOEMNAME,CONTAINER.CONTAINERNAME CUCREATELOT,
            CONTAINER.CUDATECODE,CONTAINER2.CONTAINERNAME AS CULOT,
            CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYNAME,CUSAMPLINGTASK.CUCREATEDATE,
            CASE WHEN CUSAMPLINGTASK.CUISSENDSAMPLING = 1 THEN 'Y' ELSE 'N' END CUISSENDSAMPLING,
            EMPLOYEE.EMPLOYEENAME CUSENDSAMPLINGERNAME, H.CUSENDSAMPLINGDATE,
            CASE CUSAMPLINGTASK.CUSTATUS WHEN 1 THEN 'Y' WHEN 2 THEN 'Y' ELSE 'N' END CUISRECORD, EMPLOYEECHECKER.EMPLOYEENAME CUCHECKERNAME,H.CUCHECKDATE CUCHECKDATE,
            CUSAMPLINGCATEGORY.CUISFIRSTCHECK,CUSAMPLINGCATEGORY.CUISSENDSAMPLING CUISSENDSAMPLINGTASK,A_WIPDATASETUP.WIPDATASETUPNAME,
            CUSAMPLINGTYPE.CUSAMPLINGTYPENAME,(CASE WHEN CUDOCUMENTDETAIL.CUSAMPLINGTASKID IS NULL THEN 'N' ELSE 'Y' END) CUISUPLOADFILE,
            CUDOCUMENTDETAIL.CUCREATEUSERID CUUPLOADERNAME, CUDOCUMENTDETAIL.CUCREATETIME CUUPLOADTIME, NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') CUMANUALFLAG
            FROM CUSAMPLINGTASK
            INNER JOIN CUSAMPLINGLOTHISTORY H ON CUSAMPLINGTASK.CUSAMPLINGTASKID = H.CUSAMPLINGTASKID
            LEFT JOIN CONTAINER ON CONTAINER.CONTAINERID = H.CUCREATELOTID
            LEFT JOIN PRODUCT ON H.CUPNID = PRODUCT.PRODUCTID
            LEFT JOIN PRODUCTBASE ON PRODUCT.PRODUCTBASEID = PRODUCTBASE.PRODUCTBASEID
            LEFT JOIN SPEC ON H.CUSPECID = SPEC.SPECID
            LEFT JOIN SPECBASE ON SPEC.SPECBASEID = SPECBASE.SPECBASEID
            LEFT JOIN RESOURCEDEF ON CUSAMPLINGTASK.CUEQUIPMENTID = RESOURCEDEF.RESOURCEID
            LEFT JOIN CUCEM ON CUSAMPLINGTASK.CUCEMID = CUCEM.CUCEMID
            LEFT JOIN CUOEM ON CUSAMPLINGTASK.CUOEMID = CUOEM.CUOEMID
            LEFT JOIN CUSAMPLINGRULE ON CUSAMPLINGRULE.CUSAMPLINGRULEID = CUSAMPLINGTASK.CUSAMPLINGRULEID
            LEFT JOIN CUSAMPLINGCATEGORY ON CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYID = CUSAMPLINGTASK.CUSAMPLINGCATEGORYID
            LEFT JOIN EMPLOYEE ON EMPLOYEE.EMPLOYEEID = H.CUSENDSAMPLINGERID
            LEFT JOIN EMPLOYEE EMPLOYEECHECKER ON EMPLOYEECHECKER.EMPLOYEEID = H.CUCHECKERID
            LEFT JOIN EMPLOYEE EMPLOYEEUPLOADER ON EMPLOYEEUPLOADER.EMPLOYEEID = CUSAMPLINGTASK.CUUPLOADERID
            LEFT JOIN CUSAMPLINGMATRIX ON CUSAMPLINGMATRIX.CUSAMPLINGMATRIXID = CUSAMPLINGTASK.CUSAMPLINGMATRIXID
            LEFT JOIN A_WIPDATASETUP ON A_WIPDATASETUP.WIPDATASETUPID = CUSAMPLINGRULE.CUWIPDATASETUPID
            LEFT JOIN CUSAMPLINGTYPE ON CUSAMPLINGTYPE.CUSAMPLINGTYPEID = CUSAMPLINGTASK.CUSAMPLINGTYPEID
            LEFT JOIN CONTAINER CONTAINER2 ON CONTAINER2.CONTAINERID = H.CULOTID
            LEFT JOIN CUDOCUMENTDETAIL ON CUSAMPLINGTASK.CUSAMPLINGTASKID = CUDOCUMENTDETAIL.CUSAMPLINGTASKID
            LEFT JOIN CUPRODUCTIONTYPE ON CUSAMPLINGTASK.CUPRODUCTIONTYPEID = CUPRODUCTIONTYPE.CUPRODUCTIONTYPEID
            WHERE CUSAMPLINGTASK.CUSTATUS != -1 AND NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') = '1'
             AND CusamplingTask.cuCreateDate >=to_date({param.StartDate}, 'yyyy-mm-dd hh24:mi:ss')
             AND CusamplingTask.cuCreateDate <=to_date({param.Endate}, 'yyyy-mm-dd hh24:mi:ss')
             AND SPECBASE.Specname like {param.Spec}
             AND CONTAINER.CONTAINERNAME like {param.Lot}
             AND PRODUCTBASE.Productname like {param.Product}
             AND CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYNAME like {param.Category}
            ORDER BY CusamplingTask.Cucreatedate DESC 
                ";
            }
            else
            {
                fssql = $@"SELECT PRODUCTBASE.PRODUCTNAME,SPECBASE.SPECNAME,RESOURCEDEF.RESOURCENAME,CUSAMPLINGTASK.CULAYERNUMMIN,
            CUSAMPLINGTASK.CULAYERNUMMAX,CUSAMPLINGTASK.CUCYCLE,CUSAMPLINGTASK.CUQTY,CUSAMPLINGTASK.cuSamplingTaskName,
            CUSAMPLINGRULE.CUWIPDATASETUPID,CUCEM.CUCEMNAME,CUOEM.CUOEMNAME,CONTAINER.CONTAINERNAME CUCREATELOT,
            CONTAINER.CUDATECODE,CONTAINER2.CONTAINERNAME CULOT,CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYNAME,
            CUSAMPLINGTASK.CUCREATEDATE,CASE WHEN CUSAMPLINGTASK.CUISSENDSAMPLING = 1 THEN 'Y' ELSE 'N' END CUISSENDSAMPLING,
            EMPLOYEE.EMPLOYEENAME CUSENDSAMPLINGERNAME,CUSAMPLINGTASK.CUSENDSAMPLINGDATE,
            CASE CUSAMPLINGTASK.CUSTATUS WHEN 1 THEN 'Y' WHEN 2 THEN 'Y' ELSE 'N' END CUISRECORD,
            EMPLOYEECHECKER.EMPLOYEENAME CUCHECKERNAME, CUSAMPLINGTASK.CUCHECKDATE CUCHECKDATE, CUSAMPLINGCATEGORY.CUISFIRSTCHECK,
            CUSAMPLINGCATEGORY.CUISSENDSAMPLING CUISSENDSAMPLINGTASK,A_WIPDATASETUP.WIPDATASETUPNAME,CUSAMPLINGTYPE.CUSAMPLINGTYPENAME,
            (CASE WHEN CUDOCUMENTDETAIL.CUSAMPLINGTASKID IS NULL THEN 'N' ELSE 'Y' END) CUISUPLOADFILE,CUDOCUMENTDETAIL.CUCREATEUSERID CUUPLOADERNAME,
            CUDOCUMENTDETAIL.CUCREATETIME CUUPLOADTIME, NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') CUMANUALFLAG
            FROM CUSAMPLINGTASK
            LEFT JOIN PRODUCT ON CUSAMPLINGTASK.CUPNID = PRODUCT.PRODUCTID
            LEFT JOIN PRODUCTBASE ON PRODUCT.PRODUCTBASEID = PRODUCTBASE.PRODUCTBASEID
            LEFT JOIN SPEC ON CUSAMPLINGTASK.CUSPECID = SPEC.SPECID
            LEFT JOIN SPECBASE ON SPEC.SPECBASEID = SPECBASE.SPECBASEID
            LEFT JOIN RESOURCEDEF ON CUSAMPLINGTASK.CUEQUIPMENTID = RESOURCEDEF.RESOURCEID
            LEFT JOIN CUCEM ON CUSAMPLINGTASK.CUCEMID = CUCEM.CUCEMID
            LEFT JOIN CUOEM ON CUSAMPLINGTASK.CUOEMID = CUOEM.CUOEMID
            LEFT JOIN CUSAMPLINGRULE ON CUSAMPLINGRULE.CUSAMPLINGRULEID = CUSAMPLINGTASK.CUSAMPLINGRULEID
            LEFT JOIN CUSAMPLINGCATEGORY ON CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYID = CUSAMPLINGTASK.CUSAMPLINGCATEGORYID
            LEFT JOIN EMPLOYEE ON EMPLOYEE.EMPLOYEEID = CUSAMPLINGTASK.CUSENDSAMPLINGERID
            LEFT JOIN CONTAINER ON CONTAINER.CONTAINERID = CUSAMPLINGTASK.CUCREATELOTID
            LEFT JOIN EMPLOYEE EMPLOYEECHECKER ON EMPLOYEECHECKER.EMPLOYEEID = CUSAMPLINGTASK.CUCHECKERID
            LEFT JOIN EMPLOYEE EMPLOYEEUPLOADER ON EMPLOYEEUPLOADER.EMPLOYEEID = CUSAMPLINGTASK.CUUPLOADERID
            LEFT JOIN CUSAMPLINGMATRIX ON CUSAMPLINGMATRIX.CUSAMPLINGMATRIXID = CUSAMPLINGTASK.CUSAMPLINGMATRIXID
            LEFT JOIN A_WIPDATASETUP ON A_WIPDATASETUP.WIPDATASETUPID = CUSAMPLINGRULE.CUWIPDATASETUPID
            LEFT JOIN CUSAMPLINGTYPE ON CUSAMPLINGTYPE.CUSAMPLINGTYPEID = CUSAMPLINGTASK.CUSAMPLINGTYPEID
            LEFT JOIN CONTAINER CONTAINER2 ON CONTAINER2.CONTAINERID = CUSAMPLINGTASK.CULOTID
            LEFT JOIN CUDOCUMENTDETAIL ON CUSAMPLINGTASK.CUSAMPLINGTASKID = CUDOCUMENTDETAIL.CUSAMPLINGTASKID
            LEFT JOIN CUPRODUCTIONTYPE ON CUSAMPLINGTASK.CUPRODUCTIONTYPEID = CUPRODUCTIONTYPE.CUPRODUCTIONTYPEID
            WHERE CUSAMPLINGTASK.CUSTATUS != -1 AND NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') = '0' 
             AND CusamplingTask.cuCreateDate >=to_date({param.StartDate}, 'yyyy-mm-dd hh24:mi:ss')
             AND CusamplingTask.cuCreateDate <=to_date({param.Endate}, 'yyyy-mm-dd hh24:mi:ss')
             AND SPECBASE.Specname like {param.Spec}
             AND CONTAINER.CONTAINERNAME like {param.Lot}
             AND PRODUCTBASE.Productname like {param.Product}
             AND CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYNAME like {param.Category}
            ORDER BY CusamplingTask.Cucreatedate DESC ";
            }
            //if (!string.IsNullOrEmpty(param.Spec))
            //{
            //    sql += @" AND SPECBASE.Specname like '"+param.Spec+"'";
            //}
            //if (!string.IsNullOrEmpty(param.Lot))
            //{
            //    sql += $@" AND CONTAINER.CONTAINERNAME like '{param.Lot}'";
            //}
            //if (!string.IsNullOrEmpty(param.Product))
            //{
            //    sql += $@" AND PRODUCTBASE.Productname like '{param.Product}'";
            //}
            //if (!string.IsNullOrEmpty(param.Category))
            //{
            //    sql += $@" AND CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYNAME like '{param.Category}'";
            //}
            //if (!string.IsNullOrEmpty(param.StartDate))
            //{
            //    sql += $@" AND CusamplingTask.cuCreateDate >=to_date('{param.StartDate}', 'yyyy-mm-dd hh24:mi:ss')";
            //}
            //if (!string.IsNullOrEmpty(param.Endate))
            //{
            //    sql += $@" AND CusamplingTask.cuCreateDate <=to_date('{param.Endate}', 'yyyy-mm-dd hh24:mi:ss')";
            //}

            //sql += " ORDER BY CusamplingTask.Cucreatedate DESC";

            List<TaskList> result = db.TaskList.FromSql<TaskList>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到相关数据");
            }
            else
            {
                return new ResultModel<List<TaskList>>().Success(result);
            }
        }

        /// <summary>
        /// 抽检-查询：上传图片
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public IResultModel APP_FileUpload(HttpContext httpContext)
        {
                return new ResultModel<string>().Success("");
        }

        /// <summary>
        ///  抽检-查询：抽检任务提交
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_PostSamplingCheckTask(PostSamplingCheckTask_Req param)
        {
            var msg = "";

            if (param.IsHand == "1")
            {
                //批量录入手动抽检结果
                foreach (var i in param.PostSamplingCheckTask)
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(i.Lot))
                        {
                            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                            _helper.CreateService("cuSamplingCheckBatchTxn");

                            var inputData = _helper.InputData();
                            var srvdatas = inputData.SubentityList("cuCheckBatchSrvDatas");
                            var child = srvdatas.AppendItem();
                            child.NamedObjectField("cuLot").SetRef(i.Lot);
                            child.NamedObjectField("cuSamplingTask").SetRef(i.TaskName);
                            var pass = param.IsPass ? "True" : "False";
                            inputData.DataField("cuIsPass").SetValue(pass);
                            inputData.DataField("cuStatus").SetValue("1");
                            inputData.NamedObjectField("cuChecker").SetRef(param.Employee);
                            inputData.DataField("cuType").SetValue("1");

                            _helper.SetExecute();
                            var requestData = _helper.RequestData();
                            requestData.RequestField("CompletionMsg");
                            var _resDocument = _helper.Submit();
                            ResultModel<string> _error = new ResultModel<string>();
                            _resDocument.CheckErrors(_error);
                            if (_error.success)
                            {
                                msg += i.Lot + " 录入成功.";
                            }
                            else
                            {
                                msg += i.Lot + " 录入失败：" + _error.msg;
                                return new ResultModel<string>().Failed(msg);
                            }
                            if (i.UploadFile != null && i.UploadFile.Count > 0)
                            {
                                foreach (var file in i.UploadFile)
                                {
                                    byte[] arr = Convert.FromBase64String(file);
                                    MemoryStream ms = new MemoryStream(arr);
                                    string url = "";
                                    string boundary = DateTime.Now.Ticks.ToString("X");
                                    var formData = new MultipartFormDataContent();
                                    formData.Add(new StringContent("mcnlshen"), "cuCreator");
                                    formData.Add(new StringContent(i.Lot), "cuFileRelatedNo");
                                    formData.Add(new StringContent("jpg"), "cuFileRelatedType");
                                    var filename = i.TaskName + "-" + i.Lot + Guid.NewGuid().ToString() + ".jpg";
                                    ByteArrayContent imageContent = new ByteArrayContent(arr);
                                    formData.Add(imageContent, "imgs", filename);
                                    HttpClient httpClient = new HttpClient();
                                    var resu = httpClient.PostAsync(url, formData).Result;
                                }
                            }
                        }

                    }
                    catch (Exception e)
                    {
                        msg += i.Lot + $@" {e.Message}.";
                        return new ResultModel<string>().Failed(msg);
                    }
                }
            }
            else
            {
                //批量录入抽检结果
                foreach (var i in param.PostSamplingCheckTask)
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(i.Lot))
                        {
                            CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                            _helper.CreateService("cuSamplingTaskMaint");

                            var inputData = _helper.InputData();
                            inputData.NamedObjectField("ObjectToChange").SetRef(i.TaskName);
                            _helper.Perform("Load");
                            var inputData2 = _helper.InputData();
                            var child = inputData2.SubentityField("ObjectChanges");
                            var pass = param.IsPass ? "True" : "False";
                            child.DataField("cuCheckDate").SetValue(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz"));
                            child.DataField("cuIsPass").SetValue(pass);
                            child.DataField("cuStatus").SetValue("1");
                            child.NamedObjectField("cuChecker").SetRef(param.Employee);
                            child.NamedObjectField("cuLot").SetRef(i.Lot);

                            _helper.SetExecute();
                            var requestData = _helper.RequestData();
                            requestData.RequestField("CompletionMsg");
                            var _resDocument = _helper.Submit();
                            ResultModel<string> _error = new ResultModel<string>();
                            _resDocument.CheckErrors(_error);

                            if (_error.success)
                            {
                                msg += i.Lot + " 录入成功.";
                            }
                            else
                            {
                                msg += i.Lot + " 录入失败：" + _error.msg;
                                return new ResultModel<string>().Failed(msg);
                            }
                            if (i.UploadFile != null && i.UploadFile.Count > 0)
                            {
                                foreach (var file in i.UploadFile)
                                {
                                    byte[] arr = Convert.FromBase64String(file);
                                    MemoryStream ms = new MemoryStream(arr);
                                    string url = "";
                                    string boundary = DateTime.Now.Ticks.ToString("X");
                                    var formData = new MultipartFormDataContent();
                                    formData.Add(new StringContent("mcnlshen"), "cuCreator");
                                    formData.Add(new StringContent(i.Lot), "cuFileRelatedNo");
                                    formData.Add(new StringContent("jpg"), "cuFileRelatedType");
                                    var filename = i.TaskName + "-" + i.Lot + Guid.NewGuid().ToString() + ".jpg";
                                    ByteArrayContent imageContent = new ByteArrayContent(arr);
                                    formData.Add(imageContent, "imgs", filename);
                                    HttpClient httpClient = new HttpClient();
                                    var resu = httpClient.PostAsync(url, formData).Result;
                                }
                            }
                        }

                    }
                    catch (Exception e)
                    {
                        msg += i.Lot + $@" {e.Message}.";
                        return new ResultModel<string>().Failed(msg);
                    }
                }
            }

            return new ResultModel<string>().Success(msg);
        }

        /// <summary>
        /// 检验：查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadTaskList(LoadTaskListReq param)
        {
            #region 查用户组
            string employGroupIds = string.Empty;
            FormattableString emsql = $@"SELECT a_employeeGroupentries.EmployeeGroupId
                        FROM a_employeeGroupentries
                        LEFT join Employee ON Employee.Employeeid = a_employeeGroupentries.Entriesid
                        WHERE Employee.Employeename = {param.Employee}";
            List<EmployeeGroup> eg_result = db.EmployeeGroup.FromSql<EmployeeGroup>(emsql)?.ToList();
            if (eg_result.Count == 0)
            {
                return new ResultModel<string>().Failed("不在员工组，不允许抽检。");
            }
            //else
            //{
            //    foreach (var item in eg_result)
            //    {
            //        employGroupIds += "','" + item.EmployeeGroupId;
            //    }
            //    employGroupIds = employGroupIds.Substring(2) + "'";
            //}

            #endregion
            //处理勾选项数据
            //if (param.IsSendSampling)
            //{
            //    strSQL += "AND NVL(CusamplingTask.cuIsSendSampling,0) = 0";
            //}

            //if (param.IsRecord)
            //{
            //    strSQL += "AND CusamplingTask.CuStatus = 0 ";
            //}

            //// if (IsPcs)
            ////{
            //// strSQL += "AND CUSAMPLINGTASK.Cupanelpcsno is  null";
            ////}

            //if (param.IsUploadFile)
            //{
            //    strSQL += "AND NVL(CusamplingTask.cuIsUploadFile,0) = 0 ";
            //}
            //int isSend = 0;
            //int isRecord = 0;
            //int isUploadFile = 0;
            //if (param.IsSendSampling){  isSend = 0; }
            //if (param.IsRecord) { isRecord =  0; }
            //if (param.IsUploadFile) { isUploadFile = 0; }

            FormattableString fssql;
            //string strSQL = string.Empty;
            if (param.ManualFlag)
            {
                fssql = $@"SELECT CUPRODUCTIONTYPE.CUPRODUCTIONTYPENAME,
                            CusamplingTask.CuStatus, PRODUCTBASE.PRODUCTNAME,SPECBASE.SPECNAME,
                            RESOURCEDEF.RESOURCENAME,CUSAMPLINGTASK.CULAYERNUMMIN,CUSAMPLINGTASK.CULAYERNUMMAX,CUSAMPLINGTASK.CUCYCLE,CUSAMPLINGTASK.CUQTY,CUSAMPLINGTASK.cuSamplingTaskName,CUSAMPLINGRULE.CUWIPDATASETUPID,CUCEM.CUCEMNAME,CUOEM.CUOEMNAME,CONTAINER.CONTAINERNAME CUCREATELOT,CONTAINER.CUDATECODE,CONTAINER2.CONTAINERNAME AS CULOT, CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYNAME,CUSAMPLINGTASK.CUCREATEDATE,CASE WHEN CUSAMPLINGTASK.CUISSENDSAMPLING = 1 THEN 'Y' ELSE 'N' END CUISSENDSAMPLING,EMPLOYEE.EMPLOYEENAME CUSENDSAMPLINGERNAME, H.CUSENDSAMPLINGDATE,CASE CUSAMPLINGTASK.CUSTATUS WHEN 1 THEN 'Y' WHEN 2 THEN 'Y' ELSE 'N' END CUISRECORD, EMPLOYEECHECKER.EMPLOYEENAME CUCHECKERNAME,H.CUCHECKDATE CUCHECKDATE, CUSAMPLINGCATEGORY.CUISFIRSTCHECK,CUSAMPLINGCATEGORY.CUISSENDSAMPLING CUISSENDSAMPLINGTASK,A_WIPDATASETUP.WIPDATASETUPNAME,CUSAMPLINGTYPE.CUSAMPLINGTYPENAME,(CASE WHEN CUDOCUMENTDETAIL.CUSAMPLINGTASKID IS NULL THEN 'N' ELSE 'Y' END) CUISUPLOADFILE,CUDOCUMENTDETAIL.CUCREATEUSERID CUUPLOADERNAME,CUDOCUMENTDETAIL.CUCREATETIME CUUPLOADTIME, NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') CUMANUALFLAG,CUSAMPLINGTASK.Cupanelpcsno,CUOEM.cuischeckrecord
                            FROM CUSAMPLINGTASK
                            INNER JOIN CUSAMPLINGLOTHISTORY H ON CUSAMPLINGTASK.CUSAMPLINGTASKID = H.CUSAMPLINGTASKID
                            LEFT JOIN CONTAINER ON CONTAINER.CONTAINERID = H.CUCREATELOTID
                            LEFT JOIN PRODUCT ON H.CUPNID = PRODUCT.PRODUCTID
                            LEFT JOIN PRODUCTBASE ON PRODUCT.PRODUCTBASEID = PRODUCTBASE.PRODUCTBASEID
                            LEFT JOIN SPEC ON H.CUSPECID = SPEC.SPECID
                            LEFT JOIN SPECBASE ON SPEC.SPECBASEID = SPECBASE.SPECBASEID
                            LEFT JOIN RESOURCEDEF ON CUSAMPLINGTASK.CUEQUIPMENTID = RESOURCEDEF.RESOURCEID
                            LEFT JOIN CUCEM ON CUSAMPLINGTASK.CUCEMID = CUCEM.CUCEMID
                            LEFT JOIN CUOEM ON CUSAMPLINGTASK.CUOEMID = CUOEM.CUOEMID
                            LEFT JOIN CUSAMPLINGRULE ON CUSAMPLINGRULE.CUSAMPLINGRULEID = CUSAMPLINGTASK.CUSAMPLINGRULEID
                            LEFT JOIN CUSAMPLINGCATEGORY ON CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYID = CUSAMPLINGTASK.CUSAMPLINGCATEGORYID
                            LEFT JOIN EMPLOYEE ON EMPLOYEE.EMPLOYEEID = H.CUSENDSAMPLINGERID
                            LEFT JOIN EMPLOYEE EMPLOYEECHECKER ON EMPLOYEECHECKER.EMPLOYEEID = H.CUCHECKERID
                            LEFT JOIN EMPLOYEE EMPLOYEEUPLOADER ON EMPLOYEEUPLOADER.EMPLOYEEID = CUSAMPLINGTASK.CUUPLOADERID
                            LEFT JOIN CUSAMPLINGMATRIX ON CUSAMPLINGMATRIX.CUSAMPLINGMATRIXID = CUSAMPLINGTASK.CUSAMPLINGMATRIXID
                            LEFT JOIN A_WIPDATASETUP ON A_WIPDATASETUP.WIPDATASETUPID = CUSAMPLINGRULE.CUWIPDATASETUPID
                            LEFT JOIN CUSAMPLINGTYPE ON CUSAMPLINGTYPE.CUSAMPLINGTYPEID = CUSAMPLINGTASK.CUSAMPLINGTYPEID
                            LEFT JOIN CONTAINER CONTAINER2 ON CONTAINER2.CONTAINERID = H.CULOTID
                            LEFT JOIN CUDOCUMENTDETAIL ON CUSAMPLINGTASK.CUSAMPLINGTASKID = CUDOCUMENTDETAIL.CUSAMPLINGTASKID
                            LEFT JOIN CUPRODUCTIONTYPE ON CUSAMPLINGTASK.CUPRODUCTIONTYPEID = CUPRODUCTIONTYPE.CUPRODUCTIONTYPEID
                            WHERE CUSAMPLINGTASK.CUSTATUS != -1 AND NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') = '1' 
                            AND Cusamplingmatrix.cuEmployeeGoupId in (SELECT a_employeeGroupentries.EmployeeGroupId
                            FROM a_employeeGroupentries
                            LEFT join Employee ON Employee.Employeeid = a_employeeGroupentries.Entriesid
                            WHERE Employee.Employeename = {param.Employee})
                            AND CusamplingTask.cuCreateDate >=to_date( {param.CuCreateDateFrom}, 'yyyy-mm-dd HH24:MI:SS')
                            AND CusamplingTask.cuCreateDate <=to_date( {param.CuCreateDateTo}, 'yyyy-mm-dd HH24:MI:SS') 
                            ORDER BY CusamplingTask.Cucreatedate DESC ";
            }
            else
            {
                fssql = $@"SELECT CUPRODUCTIONTYPE.CUPRODUCTIONTYPENAME, 
                            CusamplingTask.CuStatus, PRODUCTBASE.PRODUCTNAME,SPECBASE.SPECNAME,RESOURCEDEF.RESOURCENAME,CUSAMPLINGTASK.CULAYERNUMMIN,CUSAMPLINGTASK.CULAYERNUMMAX,CUSAMPLINGTASK.CUCYCLE,CUSAMPLINGTASK.CUQTY,CUSAMPLINGTASK.cuSamplingTaskName,CUSAMPLINGRULE.CUWIPDATASETUPID,CUCEM.CUCEMNAME,CUOEM.CUOEMNAME,CONTAINER.CONTAINERNAME CUCREATELOT,
                            CONTAINER.CUDATECODE,CONTAINER2.CONTAINERNAME CULOT,CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYNAME,
                            CUSAMPLINGTASK.CUCREATEDATE,CASE WHEN CUSAMPLINGTASK.CUISSENDSAMPLING = 1 THEN 'Y' ELSE 'N' END CUISSENDSAMPLING,
                            EMPLOYEE.EMPLOYEENAME CUSENDSAMPLINGERNAME,CUSAMPLINGTASK.CUSENDSAMPLINGDATE,
                            CASE CUSAMPLINGTASK.CUSTATUS WHEN 1 THEN 'Y' WHEN 2 THEN 'Y' ELSE 'N' END CUISRECORD,
                            EMPLOYEECHECKER.EMPLOYEENAME CUCHECKERNAME, CUSAMPLINGTASK.CUCHECKDATE CUCHECKDATE, CUSAMPLINGCATEGORY.CUISFIRSTCHECK,
                            CUSAMPLINGCATEGORY.CUISSENDSAMPLING CUISSENDSAMPLINGTASK,A_WIPDATASETUP.WIPDATASETUPNAME,CUSAMPLINGTYPE.CUSAMPLINGTYPENAME,
                            (CASE WHEN CUDOCUMENTDETAIL.CUSAMPLINGTASKID IS NULL THEN 'N' ELSE 'Y' END) CUISUPLOADFILE,CUDOCUMENTDETAIL.CUCREATEUSERID CUUPLOADERNAME,
                            CUDOCUMENTDETAIL.CUCREATETIME CUUPLOADTIME, NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') CUMANUALFLAG,CUSAMPLINGTASK.Cupanelpcsno,CUOEM.cuischeckrecord
                            FROM CUSAMPLINGTASK
                            LEFT JOIN PRODUCT ON CUSAMPLINGTASK.CUPNID = PRODUCT.PRODUCTID
                            LEFT JOIN PRODUCTBASE ON PRODUCT.PRODUCTBASEID = PRODUCTBASE.PRODUCTBASEID
                            LEFT JOIN SPEC ON CUSAMPLINGTASK.CUSPECID = SPEC.SPECID
                            LEFT JOIN SPECBASE ON SPEC.SPECBASEID = SPECBASE.SPECBASEID
                            LEFT JOIN RESOURCEDEF ON CUSAMPLINGTASK.CUEQUIPMENTID = RESOURCEDEF.RESOURCEID
                            LEFT JOIN CUCEM ON CUSAMPLINGTASK.CUCEMID = CUCEM.CUCEMID
                            LEFT JOIN CUOEM ON CUSAMPLINGTASK.CUOEMID = CUOEM.CUOEMID
                            LEFT JOIN CUSAMPLINGRULE ON CUSAMPLINGRULE.CUSAMPLINGRULEID = CUSAMPLINGTASK.CUSAMPLINGRULEID
                            LEFT JOIN CUSAMPLINGCATEGORY ON CUSAMPLINGCATEGORY.CUSAMPLINGCATEGORYID = CUSAMPLINGTASK.CUSAMPLINGCATEGORYID
                            LEFT JOIN EMPLOYEE ON EMPLOYEE.EMPLOYEEID = CUSAMPLINGTASK.CUSENDSAMPLINGERID
                            LEFT JOIN CONTAINER ON CONTAINER.CONTAINERID = CUSAMPLINGTASK.CUCREATELOTID
                            LEFT JOIN EMPLOYEE EMPLOYEECHECKER ON EMPLOYEECHECKER.EMPLOYEEID = CUSAMPLINGTASK.CUCHECKERID
                            LEFT JOIN EMPLOYEE EMPLOYEEUPLOADER ON EMPLOYEEUPLOADER.EMPLOYEEID = CUSAMPLINGTASK.CUUPLOADERID
                            LEFT JOIN CUSAMPLINGMATRIX ON CUSAMPLINGMATRIX.CUSAMPLINGMATRIXID = CUSAMPLINGTASK.CUSAMPLINGMATRIXID
                            LEFT JOIN A_WIPDATASETUP ON A_WIPDATASETUP.WIPDATASETUPID = CUSAMPLINGRULE.CUWIPDATASETUPID
                            LEFT JOIN CUSAMPLINGTYPE ON CUSAMPLINGTYPE.CUSAMPLINGTYPEID = CUSAMPLINGTASK.CUSAMPLINGTYPEID
                            LEFT JOIN CONTAINER CONTAINER2 ON CONTAINER2.CONTAINERID = CUSAMPLINGTASK.CULOTID
                            LEFT JOIN CUDOCUMENTDETAIL ON CUSAMPLINGTASK.CUSAMPLINGTASKID = CUDOCUMENTDETAIL.CUSAMPLINGTASKID
                            LEFT JOIN CUPRODUCTIONTYPE ON CUSAMPLINGTASK.CUPRODUCTIONTYPEID = CUPRODUCTIONTYPE.CUPRODUCTIONTYPEID
                            WHERE CUSAMPLINGTASK.CUSTATUS != -1 AND NVL(CUSAMPLINGTASK.CUMANUALFLAG,'0') = '0' 
                            AND Cusamplingmatrix.cuEmployeeGoupId in ((SELECT a_employeeGroupentries.EmployeeGroupId
                            FROM a_employeeGroupentries
                            LEFT join Employee ON Employee.Employeeid = a_employeeGroupentries.Entriesid
                            WHERE Employee.Employeename = {param.Employee}))
                            AND CusamplingTask.cuCreateDate >=to_date( {param.CuCreateDateFrom}, 'yyyy-mm-dd HH24:MI:SS')
                            AND CusamplingTask.cuCreateDate <=to_date( {param.CuCreateDateTo}, 'yyyy-mm-dd HH24:MI:SS') 
                            ORDER BY CusamplingTask.Cucreatedate DESC ";
            }

            List<TaskDetails> result = db.TaskDetails.FromSql<TaskDetails>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到相关数据");
            }
            else
            {
                //处理数据
                if (!string.IsNullOrEmpty(param.PN))
                {
                    result = result.Where(x => x.PRODUCTNAME == param.PN).ToList();
                }

                if (!string.IsNullOrEmpty(param.Spec))
                {
                    result = result.Where(x => x.SPECNAME == param.PN).ToList();
                }

                if (!string.IsNullOrEmpty(param.Eqp))
                {
                    result = result.Where(x => x.RESOURCENAME == param.Eqp).ToList();
                }
                //根据批次查询
                if (!string.IsNullOrEmpty(param.Lot))
                {
                    result = result.Where(x => x.CULOT == param.Lot).ToList();
                }
                if (!string.IsNullOrEmpty(param.LayerMin))
                {
                    result = result.Where(x => x.CULAYERNUMMIN == param.LayerMin).ToList();
                }

                if (!string.IsNullOrEmpty(param.LayerMax))
                {
                    result = result.Where(x => x.CULAYERNUMMAX == param.LayerMax).ToList();
                }

                if (!string.IsNullOrEmpty(param.CuCEM))
                {
                    result = result.Where(x => x.CUCEMNAME == param.CuCEM).ToList();
                }

                if (!string.IsNullOrEmpty(param.CuOEM))
                {
                    result = result.Where(x => x.CUOEMNAME == param.CuOEM).ToList();
                }

                if (param.IsSendSampling)
                {
                    result = result.Where(x => x.CUISSENDSAMPLING == "0" || x.CUISSENDSAMPLING == null).ToList();
                }

                if (param.IsRecord)
                {
                    result = result.Where(x => x.CUSTATUS == "0").ToList();
                }

                if (param.IsUploadFile)
                {
                    result = result.Where(x => x.CUISUPLOADFILE == "0" || x.CUISUPLOADFILE == null).ToList();
                }

                if (!string.IsNullOrEmpty(param.DateCode))
                {
                    result = result.Where(x => x.CUDATECODE == param.DateCode).ToList();
                }

                if (param.ManualFlag)
                {
                    if (!string.IsNullOrEmpty(param.SamplingCategory))
                    {
                        result = result.Where(x => x.CUSAMPLINGCATEGORYNAME == param.SamplingCategory).ToList();
                    }

                    if (!string.IsNullOrEmpty(param.ProductionType))
                    {
                        result = result.Where(x => x.CUPRODUCTIONTYPENAME == param.ProductionType).ToList();
                    }
                }

                return new ResultModel<List<TaskDetails>>().Success(result);
            }
        }

        /// <summary>
        /// 检验：送样
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel SendSampling(SendSamplingReq param)
        {
            if (param.ManualFlag)
            {
                CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                _helper.CreateService("cuSamplingCheckBatchTxn");
                var inputData = _helper.InputData();

                inputData.NamedObjectField("cuSendSamplinger").SetRef(param.Employee);
                inputData.DataField("cuType").SetValue("0");
                inputData.DataField("cuIsSendSampling").SetValue("true");

                var subOSLotDetails = inputData.SubentityList("cuCheckBatchSrvDatas");
                foreach (var item in param.cuCheckBatchSrvDatas)
                {
                    var subItem = subOSLotDetails.AppendItem();
                    subItem.NamedObjectField("cuLot").SetRef(item.CreateLot);
                    subItem.NamedObjectField("cuSamplingTask").SetRef(item.SamplingTaskName);
                }

                _helper.SetExecute();
                var requestData = _helper.RequestData();
                requestData.RequestField("CompletionMsg");
                var _resDocument = _helper.Submit();
                ResultModel<string> _error = new ResultModel<string>();
                _resDocument.CheckErrors(_error);
                if (_error.success)
                {
                    return new ResultModel<string>().Success(_error.msg);
                }
                else
                {
                    return new ResultModel<string>().Failed(_error.msg);
                }
            }
            else
            {
                string msg = string.Empty;
                foreach (var item in param.cuCheckBatchSrvDatas)
                {
                    CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                    _helper.CreateService("cuSamplingTaskMaint");
                    var inputData = _helper.InputData();

                    inputData.NamedObjectField("ObjectToChange").SetRef(item.SamplingTaskName);
                    _helper.Perform("Load");
                    var inputData2 = _helper.InputData();
                    var child = inputData2.SubentityField("ObjectChanges");
                    child.DataField("cuSendSamplingDate").SetValue(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz"));
                    child.DataField("cuIsSendSampling").SetValue("true");
                    child.NamedObjectField("cuSendSamplinger").SetRef(param.Employee);

                    _helper.SetExecute();
                    var requestData = _helper.RequestData();
                    requestData.RequestField("CompletionMsg");
                    var _resDocument = _helper.Submit();
                    ResultModel<string> _error = new ResultModel<string>();
                    _resDocument.CheckErrors(_error);
                    if (!_error.success)
                    {
                        msg = _error.msg;
                        break;
                    }
                }

                if (msg.Length > 0)
                {
                    return new ResultModel<string>().Failed(msg);
                }
                else
                {
                    return new ResultModel<string>().Success("送样成功");
                }
            }
        }

        /// <summary>
        /// 检验：扫描lot获取明细
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadLotDetail(SingleLotReq param)
        {
            FormattableString fssql = $@"SELECT C.PRODUCTID,C.CONTAINERNAME,PB.PRODUCTNAME,p.culayernum,SB.SPECNAME,
                            A_WIPEquipment.EQUIPMENTNAME,cuCEM.cuCEMName,cuOEM.cuOEMName,Resourcedef.Resourcename
                            FROM CONTAINER C
                            INNER JOIN CURRENTSTATUS CS ON CS.CURRENTSTATUSID = C.CURRENTSTATUSID
                            INNER JOIN Product P on P.productid = C.productid
                            INNER JOIN Productbase PB ON PB.ProductbaseID = P.ProductbaseID
                            LEFT JOIN SPEC S ON S.SPECID = CS.SPECID
                            LEFT JOIN SPECBASE SB ON SB.SPECBASEID = S.SPECBASEID
                            LEFT JOIN cuCEM ON cuCEM.cuCEMId = P.cuCEMId
                            LEFT JOIN cuOEM ON cuOEM.cuOEMId = P.cuOEMId
                            LEFT JOIN A_WIPEquipment ON C.CONTAINERID = A_WIPEquipment.CONTAINERID
                            LEFT JOIN Resourcedef ON A_WIPEquipment.EQUIPMENTID = Resourcedef.ResourceId
                            WHERE C.CONTAINERNAME = {param.Lot}";

            List<LoadLotDetailModel> result = db.LoadLotDetailModel.FromSql<LoadLotDetailModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("扫描批次号不存在或者已关闭");
            }
            else
            {
                return new ResultModel<List<LoadLotDetailModel>>().Success(result);
            }
        }

        /// <summary>
        /// 检验：获取检验项
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetCheckItem(string param)
        {
            FormattableString fssql = $@"SELECT a_WIPDataSetupDetails.Displaysequence as cuSamplingNO, a_wipdataname.Wipdatanamename as cuCheckItemName,
                a_WIPDataSetupDetails.Lowerlimit as cuLowerLimit,'' AS CUSTANDARDVALUE,
                   a_WIPDataSetupDetails.Upperlimit as cuUpperLimit,cuSamplingDetailNew.CURESULT,cusamplingtask.cupanelpcsno,CUOEM.cuischeckrecord
                   FROM  cusamplingtask  inner join cusamplingRule on cusamplingtask.cusamplingruleid = cusamplingRule.Cusamplingruleid 
                   left join  cuSamplingDetailNew on  cusamplingtask.cusamplingtaskid = cuSamplingDetailNew.Cusamplingtaskid
                      INNER JOIN a_WIPDataSetupDetails   ON    cusamplingRule.Cuwipdatasetupid=a_WIPDataSetupDetails.Wipdatasetupid 
                   INNER JOIN a_wipdataname ON a_WIPDataSetupDetails.Wipdatanameid = a_wipdataname.Wipdatanameid 
                left JOIN CUOEM  ON cusamplingtask.CUOEMID=CUOEM.CUOEMID
                   WHERE cusamplingtask.cusamplingtaskname = {param}
                ORDER BY a_WIPDataSetupDetails.Displaysequence  ";

            List<CheckItemModel> result = db.CheckItemModel.FromSql<CheckItemModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<CheckItemModel>>().Success(result);
            }
        }

        /// <summary>
        ///  检验：保存结果
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel SaveSamplingTask(SamplingTaskReq param)
        {
            if (!param.ManualFlag)//自动
            {
                CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                _helper.CreateService("cuSamplingTaskMaint");
                var inputData = _helper.InputData();

                inputData.NamedObjectField("ObjectToChange").SetRef(param.CUSamplingTaskName);
                _helper.Perform("Load");
                var inputData2 = _helper.InputData();
                var child = inputData2.SubentityField("ObjectChanges");
                child.DataField("cuCheckDate").SetValue(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz"));
                child.DataField("cuIsPass").SetValue(param.IsPass);
                child.NamedObjectField("cuLot").SetRef(param.Lot);
                child.NamedObjectField("cuChecker").SetRef(param.Employee);

                var subLotDetails = inputData.SubentityList("cuSamplingDetailNew");
                foreach (var item in param.CUSamplingDetailNew)
                {
                    var subItem = subLotDetails.AppendItem();
                    subItem.DataField("cuSamplingNo").SetValue(item.CUSamplingNo);
                    subItem.DataField("cuCheckItemName").SetValue(item.CUCheckItemName);
                    subItem.DataField("cuLowerLimit").SetValue(item.CULowerLimit);
                    subItem.DataField("cuUpperLimit").SetValue(item.CUUpperLimit);
                    subItem.DataField("cuStandardValue").SetValue(item.CUStandardValue);
                    subItem.DataField("cuResult").SetValue(item.CUResult);
                }

                _helper.SetExecute();
                var requestData = _helper.RequestData();
                requestData.RequestField("CompletionMsg");
                var _resDocument = _helper.Submit();
                ResultModel<string> _error = new ResultModel<string>();
                _resDocument.CheckErrors(_error);
                if (!_error.success)
                {
                    return new ResultModel<string>().Failed(_error.msg);
                }
                else
                {
                    return new ResultModel<string>().Success("录入成功");
                }
            }
            else//手动
            {
                CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                _helper.CreateService("cuSamplingCheckBatchTxn");
                var inputData = _helper.InputData();

                inputData.DataField("cuIsPass").SetValue(param.IsPass);
                inputData.DataField("cuType").SetValue("1");
                inputData.DataField("cuStatus").SetValue("1");
                inputData.NamedObjectField("cuChecker").SetRef(param.Employee);

                var SrvDatas = inputData.SubentityList("cuCheckBatchSrvDatas");
                var subItem = SrvDatas.AppendItem();
                subItem.NamedObjectField("cuLot").SetRef(param.Lot);
                subItem.NamedObjectField("cuSamplingTask").SetRef(param.CUSamplingTaskName);

                var subLotDetails = inputData.SubentityList("cuSamplingDetailSrvData");
                foreach (var item in param.CUSamplingDetailNew)
                {
                    var SrvItem = subLotDetails.AppendItem();
                    SrvItem.DataField("cuSamplingNo").SetValue(item.CUSamplingNo);
                    SrvItem.DataField("cuCheckItemName").SetValue(item.CUCheckItemName);
                    SrvItem.DataField("cuLowerLimit").SetValue(item.CULowerLimit);
                    SrvItem.DataField("cuUpperLimit").SetValue(item.CUUpperLimit);
                    SrvItem.DataField("cuStandardValue").SetValue(item.CUStandardValue);
                    SrvItem.DataField("cuResult").SetValue(item.CUResult);
                }

                _helper.SetExecute();
                var requestData = _helper.RequestData();
                requestData.RequestField("CompletionMsg");
                var _resDocument = _helper.Submit();
                ResultModel<string> _error = new ResultModel<string>();
                _resDocument.CheckErrors(_error);
                if (_error.success)
                {
                    return new ResultModel<string>().Failed(_error.msg);
                }
                else
                {
                    return new ResultModel<string>().Success("录入成功");
                }
            }
        }

        /// <summary>
        /// 获取HOLD原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetHoldReason(string param)
        {
            FormattableString fssql = $@"select hr.holdreasonname from holdreason HR
                                                        where  hr.holdreasonname like {param}
                                                        AND hr.holdreasonname IS NOT NULL
                                                        and rownum < 500";

            List<HoldReasonModel> result = db.HoldReasonModel.FromSql<HoldReasonModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<HoldReasonModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取检验失败原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetFailReason(string param)
        {
            FormattableString fssql = $@"select FR.CUSAMPLINGFAILREASONNAME AS FailReason 
                    from cuSamplingFailReason FR
                     where FR.CUSAMPLINGFAILREASONNAME like {param}
                    AND FR.CUSAMPLINGFAILREASONNAME IS NOT NULL
                    and rownum < 500";

            List<FailReasonModel> result = db.FailReasonModel.FromSql<FailReasonModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<FailReasonModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取PN
        /// </summary>
        /// <returns></returns>
        public IResultModel GetPN(string param)
        {
            FormattableString fssql = $@"select pb.productname as Name, p.productrevision AS Revison 
                    from product p, productbase pb
                    where p.productbaseid = pb.productbaseid
                    and pb.productname like {param}
                    and rownum < 500";

            List<RevisionObjectModel> result = db.RevisionObjectModel.FromSql<RevisionObjectModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<RevisionObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取工序
        /// </summary>
        /// <returns></returns>
        public IResultModel GetSpec(string param)
        {
            FormattableString fssql = $@"select sb.specname as Name, s.specrevision AS Revison 
                    from spec s, specbase sb
                    where s.specbaseid = sb.specbaseid
                    and sb.specname like {param}
                    and rownum < 500";

            List<RevisionObjectModel> result = db.RevisionObjectModel.FromSql<RevisionObjectModel>(fssql)?.ToList();

            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<RevisionObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取设备
        /// </summary>
        /// <returns></returns>
        public IResultModel GetEqp(string param)
        {
            FormattableString fssql = $@"select re.resourcename as Name from resourcedef re 
            where re.objecttype = 'ASSEMBLY'
            and re.resourcename like {param}
            and rownum < 500";

            List<NameObjectModel> result = db.NameObjectModel.FromSql<NameObjectModel>(fssql)?.ToList();

            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<NameObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取检验种类
        /// </summary>
        /// <returns></returns>
        public IResultModel GetSamplingCategory(string param)
        {
            FormattableString fssql = $@"select SC.CUSAMPLINGCATEGORYNAME AS Name from cusamplingcategory SC
            where SC.CUSAMPLINGCATEGORYNAME like {param}
            and rownum < 500";

            List<NameObjectModel> result = db.NameObjectModel.FromSql<NameObjectModel>(fssql)?.ToList();

            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<NameObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取OEM
        /// </summary>
        /// <returns></returns>
        public IResultModel GetOEM(string param)
        {
            FormattableString fssql = $@"select oem.cuoemname as Name from cuoem OEM
            where oem.cuoemname like {param}
            and rownum < 500";

            List<NameObjectModel> result = db.NameObjectModel.FromSql<NameObjectModel>(fssql)?.ToList();

            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<NameObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取CEM
        /// </summary>
        /// <returns></returns>
        public IResultModel GetCEM(string param)
        {
            FormattableString fssql = $@"select CEM.cuCemname as Name from CUCEM CEM
            where CEM.cuCemname like {param}
            and rownum < 500";

            List<NameObjectModel> result = db.NameObjectModel.FromSql<NameObjectModel>(fssql)?.ToList();

            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<NameObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 获取版样
        /// </summary>
        /// <returns></returns>
        public IResultModel GetProductionType(string param)
        {
            FormattableString fssql = $@"select PT.Cuproductiontypename as Name from cuproductiontype PT
            where PT.Cuproductiontypename like {param}
            and rownum < 500";

            List<NameObjectModel> result = db.NameObjectModel.FromSql<NameObjectModel>(fssql)?.ToList();

            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<NameObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 检验失败处理：查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadTaskListForFail(LoadTaskListForFailReq param)
        {
            #region 查用户组
            List<string> emIDS = new List<string>();
            string employGroupIds = string.Empty;
            FormattableString emsql = $@"SELECT a_employeeGroupentries.EmployeeGroupId
                        FROM a_employeeGroupentries
                        LEFT join Employee ON Employee.Employeeid = a_employeeGroupentries.Entriesid
                        WHERE Employee.Employeename = {param.Employee}";
            List<EmployeeGroup> eg_result = db.EmployeeGroup.FromSql<EmployeeGroup>(emsql)?.ToList();
            if (eg_result.Count == 0)
            {
                //return new ResultModel<string>().Failed("不在员工组，不允许处理检验。");//去除校验
            }
            else
            {
                foreach (var item in eg_result)
                {
                    emIDS.Add(item.EmployeeGroupId);
                    employGroupIds += "','" + item.EmployeeGroupId;
                }
                employGroupIds = employGroupIds.Substring(2) + "'";//作为查询条件
            }

            #endregion

            FormattableString fssql;
            if (!param.ManualFlag)
            {
                fssql = $@"SELECT  rownum, cuSamplingTask.CuStatus, Cusamplingmatrix.cuEmployeeGoupId,
                            Productbase.Productname, Specbase.Specname, Resourcedef.Resourcename,
                            CusamplingTask.Culayernummin, CusamplingTask.Culayernummax, 
                            cuCEM.CUCEMName,cuOEM.CUOEMName,
                            CusamplingTask.Cucycle, CusamplingTask.Cuqty, Employee.Fullname, 
                            DocumentBase.Documentname, Document.Documentrevision, Document.Identifier,                                         
                            DECODE(CusamplingTask.Cuispass,1, 'Pass',0,'Fail') AS Cuispass, Container.Containername,
                            LotPNBase.Productname AS LotPNName, LotSpecBase.Specname AS LotSpecName,
                            ContainerCreate.containerName cuCreateLot,ContainerCreate.cudatecode,
                            cuSamplingCategory.cuSamplingCategoryName,CusamplingTask.cuCreateDate,
                            A_WIPDataSetup.WIPDataSetupName ,cuSamplingType.cuSamplingTypeName,
                            CusamplingTask.cuIsSendSampling,EmployeeSend.EmployeeName cuSendSamplingerName,
                            CusamplingTask.cuSendSamplingDate,
                            case CusamplingTask.cuStatus when 1 then 1 else 0 end  cuIsRecord , 
                            EmployeeChecker.EmployeeName cuCheckerName,
                            CusamplingTask.cuIsUploadFile,EmployeeUploader.EmployeeName cuUploaderName,CusamplingTask.cuUploadTime ,
                            TO_CHAR(CusamplingTask.Cucheckdate, 'RRRR-MM-DD HH24:MI:SS') AS Cucheckdate, CusamplingTask.Cusamplingtaskname
                            FROM CusamplingTask
                            LEFT JOIN Product ON CusamplingTask.Cupnid = Product.Productid
                            LEFT JOIN Productbase ON Product.Productbaseid = Productbase.Productbaseid
                            LEFT JOIN Spec ON CusamplingTask.Cuspecid = Spec.Specid
                            LEFT JOIN Specbase ON Spec.Specbaseid = Specbase.Specbaseid
                            LEFT JOIN Resourcedef ON CusamplingTask.Cuequipmentid = Resourcedef.Resourceid
                            LEFT JOIN cuCEM ON CusamplingTask.cuCEMId = cuCEM.cuCEMId
                            LEFT JOIN cuOEM ON CusamplingTask.cuOEMId = cuOEM.cuOEMId 
                            LEFT JOIN Employee ON CusamplingTask.Cucheckerid = Employee.Employeeid
                            LEFT JOIN Product LotPN ON CusamplingTask.Culotpnid = LotPN.Productid
                            LEFT JOIN Productbase LotPNBase ON LotPN.Productbaseid = LotPNBase.Productbaseid
                            LEFT JOIN Spec LotSpec ON CusamplingTask.Cuspecid = LotSpec.Specid
                            LEFT JOIN Specbase LotSpecBase ON LotSpec.Specbaseid = LotSpecBase.Specbaseid
                            LEFT JOIN Container ON Container.Containerid = CusamplingTask.Culotid
                            LEFT JOIN Container ContainerCreate ON ContainerCreate.Containerid = CusamplingTask.cuCreateLotId
                            LEFT JOIN Document ON CusamplingTask.cuDocumentid = Document.Documentid
                            LEFT JOIN DocumentBase ON DocumentBase.Documentbaseid = Document.Documentbaseid
                            LEFT JOIN  cuSamplingCategory  ON cuSamplingCategory.cuSamplingCategoryId= CusamplingTask.cuSamplingCategoryId 
                            LEFT JOIN  Cusamplingrule  ON Cusamplingrule.cusamplingruleId= CusamplingTask.cusamplingruleId 
                            LEFT JOIN  A_WIPDataSetup   ON A_WIPDataSetup.WIPDataSetupId= Cusamplingrule.cuWIPDataSetupiD
                            LEFT JOIN  cuSamplingType   ON cuSamplingType.cuSamplingTypeId = CusamplingTask.cuSamplingTypeId
                            LEFT JOIN Employee EmployeeSend  ON EmployeeSend.EmployeeId= CusamplingTask.cuSendSamplingerId 
                            LEFT JOIN  Employee EmployeeChecker  ON  EmployeeChecker.EmployeeId= CusamplingTask.cuCheckerId
                            LEFT JOIN  Employee EmployeeUploader  ON EmployeeUploader.EmployeeId= CusamplingTask.cuUploaderId
                            LEFT JOIN  Cusamplingmatrix  ON Cusamplingmatrix.CusamplingmatrixId = CusamplingTask.CusamplingmatrixId
                            WHERE CusamplingTask.CuStatus !=0  AND NVL(cuSamplingTask.Cumanualflag,'0') = '0'
                            AND CusamplingTask.cuCreateDate >=to_date({param.CuCreateDateFrom}, 'yyyy-mm-dd hh24:mi:ss')
                            AND CusamplingTask.cuCreateDate <=to_date({param.CuCreateDateTo}, 'yyyy-mm-dd hh24:mi:ss')
                            ORDER BY CusamplingTask.Cucheckdate desc
                            ";
            }
            else
            {
                fssql = $@"SELECT rownum, cuSamplingTask.CuStatus, Cusamplingmatrix.cuEmployeeGoupId,
                            ProductBase.Productname, SpecBase.SpecName, Resourcedef.Resourcename,
                            H.Culayernummin, H.Culayernummax, cuCEM.CUCEMName,cuOEM.CUOEMName,
                            H.Cucycle, H.Cuqty, Employee.Fullname, DocumentBase.Documentname, Document.Documentrevision, Document.Identifier,
                            DECODE(H.cuIsPass, 1, 'Pass', 0, 'Fail') AS cuIsPass, Container.Containername,
                            LotPNBase.Productname AS LotPNName, LotSpecBase.SpecName AS LotSpecName,
                            ContainerCreate.containerName cuCreateLot, ContainerCreate.cudatecode,
                            cuSamplingCategory.cuSamplingCategoryName,cuSamplingTask.cuCreateDate,
                            A_WIPDataSetup.WIPDataSetupName ,cuSamplingType.cuSamplingTypeName,
                            H.cuIsSendSampling,EmployeeSend.EmployeeName cuSendSamplingerName, H.cuSendSamplingDate,
                            CASE H.cuStatus WHEN 1 THEN 1 ELSE 0 END cuIsRecord, EmployeeChecker.EmployeeName cuCheckerName,
                            H.cuIsUploadFile,EmployeeUploader.EmployeeName cuUploaderName, H.cuUploadTime ,
                            TO_CHAR(H.Cucheckdate, 'RRRR-MM-DD HH24:MI:SS') AS cuCheckDate, cuSamplingTask.cuSamplingTaskname
                            FROM cuSamplingTask
                            INNER JOIN cuSamplingLotHistory H ON cuSamplingTask.cuSamplingTaskId = H.cuSamplingTaskId
                            LEFT JOIN Product ON H.cuPNId = Product.Productid
                            LEFT JOIN ProductBase ON Product.ProductBaseid = ProductBase.ProductBaseid
                            LEFT JOIN Spec ON H.cuSpecId = Spec.Specid
                            LEFT JOIN Specbase ON Spec.Specbaseid = Specbase.Specbaseid
                            LEFT JOIN Resourcedef ON cuSamplingTask.Cuequipmentid = Resourcedef.Resourceid
                            LEFT JOIN cuCEM ON cuSamplingTask.cuCEMId = cuCEM.cuCEMId
                            LEFT JOIN cuOEM ON cuSamplingTask.cuOEMId = cuOEM.cuOEMId
                            LEFT JOIN Employee ON H.cuCheckerId = Employee.Employeeid
                            LEFT JOIN Product LotPN ON H.cuLotPNId = LotPN.Productid
                            LEFT JOIN ProductBase LotPNBase ON LotPN.ProductBaseid = LotPNBase.ProductBaseid
                            LEFT JOIN Spec LotSpec ON H.cuSpecId = LotSpec.Specid
                            LEFT JOIN Specbase LotSpecBase ON LotSpec.Specbaseid = LotSpecBase.Specbaseid
                            LEFT JOIN Container ON Container.Containerid = H.cuLotId
                            LEFT JOIN Container ContainerCreate ON ContainerCreate.containerId = H.cuCreateLotId
                            LEFT JOIN Document ON H.cuDocumentId = Document.Documentid
                            LEFT JOIN DocumentBase ON DocumentBase.Documentbaseid = Document.Documentbaseid
                            LEFT JOIN cuSamplingCategory ON cuSamplingCategory.cuSamplingCategoryId = cuSamplingTask.cuSamplingCategoryId
                            LEFT JOIN cuSamplingRule ON Cusamplingrule.cusamplingruleId = cuSamplingTask.cusamplingruleId
                            LEFT JOIN A_WIPDataSetup ON A_WIPDataSetup.WIPDataSetupId = Cusamplingrule.cuWIPDataSetupiD
                            LEFT JOIN cuSamplingType ON cuSamplingType.cuSamplingTypeId = cuSamplingTask.cuSamplingTypeId
                            LEFT JOIN Employee EmployeeSend  ON EmployeeSend.EmployeeId = H.cuSendSamplingerId
                            LEFT JOIN Employee EmployeeChecker  ON EmployeeChecker.EmployeeId = H.cuCheckerId
                            LEFT JOIN Employee EmployeeUploader  ON EmployeeUploader.EmployeeId = H.cuUploaderId
                            LEFT JOIN cuSamplingMatrix ON cuSamplingMatrix.cuSamplingMatrixId = cuSamplingTask.cuSamplingMatrixId
                            WHERE 1 = 1 AND cuSamplingTask.cuStatus != 0 AND NVL(cuSamplingTask.Cumanualflag,'0') = '1' 
                            AND CusamplingTask.cuCreateDate >=to_date({param.CuCreateDateFrom}, 'yyyy-mm-dd hh24:mi:ss')
                            AND CusamplingTask.cuCreateDate <=to_date({param.CuCreateDateTo}, 'yyyy-mm-dd hh24:mi:ss')
                            ORDER BY CusamplingTask.Cucheckdate desc
                            ";
            }

            List<TaskDetailsV2> result = db.TaskDetailsV2.FromSql<TaskDetailsV2>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("未找到相关数据");
            }
            else
            {
                //if (emIDS.Count > 0)
                //{
                //    result = result.Where(x => emIDS.Contains(x.CUEMPLOYEEGOUPID)).ToList();
                //}

                if (param.Disposed && !param.NotDispose)//未处理
                {
                    result = result.Where(x => x.CUSTATUS == "1" && x.CUISPASS == "0").ToList();
                }
                else
                 if (param.NotDispose && !param.Disposed)//已处理
                {
                    result = result.Where(x => x.CUSTATUS == "2").ToList();
                }
                else
                {
                    result = result.Where(x => x.CUSTATUS == "2" || (x.CUSTATUS == "1" && x.CUISPASS == "Fail")).ToList();
                }
                if (!string.IsNullOrEmpty(param.PN))
                {
                    result = result.Where(x => x.PRODUCTNAME == param.PN).ToList();
                }
                if (!string.IsNullOrEmpty(param.Spec))
                {
                    result = result.Where(x => x.SPECNAME == param.Spec).ToList();
                }
                if (!string.IsNullOrEmpty(param.Eqp))
                {
                    result = result.Where(x => x.RESOURCENAME == param.Eqp).ToList();
                }
                if (!string.IsNullOrEmpty(param.LayerMin))
                {
                    result = result.Where(x => x.CULAYERNUMMIN == param.LayerMin).ToList();
                }
                if (!string.IsNullOrEmpty(param.LayerMax))
                {
                    result = result.Where(x => x.CULAYERNUMMAX == param.LayerMax).ToList();
                }
                if (!string.IsNullOrEmpty(param.CuCEM))
                {
                    result = result.Where(x => x.CUCEMNAME == param.CuCEM).ToList();
                }
                if (!string.IsNullOrEmpty(param.CuOEM))
                {
                    result = result.Where(x => x.CUOEMNAME == param.CuOEM).ToList();
                }
                if (!string.IsNullOrEmpty(param.DateCode))
                {
                    result = result.Where(x => x.CUDATECODE == param.DateCode).ToList();
                }

                return new ResultModel<List<TaskDetailsV2>>().Success(result);
            }
        }

        /// <summary>
        ///  检验失败处理：提交处理结果
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel SaveSamplingTaskForFail(SamplingTaskForFailReq param)
        {
            if (!param.ManualFlag)//自动
            {
                CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                _helper.CreateService("cuSamplingTaskMaint");
                var inputData = _helper.InputData();

                inputData.NamedObjectField("ObjectToChange").SetRef(param.CUSamplingTaskName);
                _helper.Perform("Load");
                var inputData2 = _helper.InputData();
                var child = inputData2.SubentityField("ObjectChanges");

                var lots = child.NamedObjectList("cuHoldLots");
                foreach (var item in param.CUHoldLots)
                {
                    lots.AppendItem(item);
                }

                var reasons = child.NamedObjectList("cuFailReasons");
                foreach (var item in param.CUFailReasons)
                {
                    reasons.AppendItem(item);
                }

                child.DataField("cuDisposeDate").SetValue(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz"));
                child.DataField("cuIsPass").SetValue(param.CUIsPass);
                child.DataField("cuStatus").SetValue("2");
                child.NamedObjectField("cuDisposeNote").SetRef(param.CUDisposeNote);
                child.NamedObjectField("cuDisposeUser").SetRef(param.Employee);

                _helper.SetExecute();
                var requestData = _helper.RequestData();
                requestData.RequestField("CompletionMsg");
                var _resDocument = _helper.Submit();
                ResultModel<string> _error = new ResultModel<string>();
                _resDocument.CheckErrors(_error);
                if (_error.success)
                {
                    return new ResultModel<string>().Failed(_error.msg);
                }
                else
                {
                    return new ResultModel<string>().Success("成功处理抽检任务");
                }
            }
            else//手动
            {
                CamstarHelper _helper = ICamstarComm.GetCamstarHelper();
                _helper.CreateService("cuSamplingCheckBatchTxn");
                var inputData = _helper.InputData();

                var lots = inputData.NamedObjectList("cuHoldLots");
                foreach (var item in param.CUHoldLots)
                {
                    lots.AppendItem(item);
                }

                var reasons = inputData.NamedObjectList("cuFailReasons");
                foreach (var item in param.CUFailReasons)
                {
                    reasons.AppendItem(item);
                }

                inputData.DataField("cuIsPass").SetValue(param.CUIsPass);
                inputData.DataField("cuType").SetValue("2");
                inputData.DataField("cuStatus").SetValue("2");
                inputData.NamedObjectField("cuDisposeNote").SetRef(param.CUDisposeNote);
                inputData.NamedObjectField("cuDisposeUser").SetRef(param.Employee);

                var SrvDatas = inputData.SubentityList("cuCheckBatchSrvDatas");
                var subItem = SrvDatas.AppendItem();
                subItem.NamedObjectField("cuLot").SetRef(param.CUTaskLot);
                subItem.NamedObjectField("cuSamplingTask").SetRef(param.CUSamplingTaskName);

                _helper.SetExecute();
                var requestData = _helper.RequestData();
                requestData.RequestField("CompletionMsg");
                var _resDocument = _helper.Submit();
                ResultModel<string> _error = new ResultModel<string>();
                _resDocument.CheckErrors(_error);
                if (_error.success)
                {
                    return new ResultModel<string>().Failed(_error.msg);
                }
                else
                {
                    return new ResultModel<string>().Success("成功处理抽检任务");
                }
            }
        }

        /// <summary>
        /// 检验失败处理：扫描Lot校验状态
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CheckFailLot(string param)
        {
            FormattableString fssql = $@"SELECT Container.ContainerName as Name
                                             FROM Container
                                             WHERE Container.Status = 1 AND Container.ContainerName = {param}";

            List<NameObjectModel> result = db.NameObjectModel.FromSql<NameObjectModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Failed("扫描批次号不存在或者已关闭！");
            }
            else
            {
                return new ResultModel<List<NameObjectModel>>().Success(result);
            }
        }

        /// <summary>
        /// 检验失败处理：查看检验明细
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadTaskList(string param)
        {
            FormattableString fssql = $@"SELECT Cusamplingdetailnew.Cusamplingno,
                           Cusamplingdetailnew.Cucheckitemname,
                           Cusamplingdetailnew.Cudatatype,
                           Cusamplingdetailnew.Culowerlimit,
                           Cusamplingdetailnew.Cuupperlimit,
                           Cusamplingdetailnew.Custandardvalue,
                           Cusamplingdetailnew.Curesult,
                           Uom.Uomname
                      FROM CusamplingTask
                     INNER JOIN Cusamplingdetailnew
                        ON Cusamplingdetailnew.Cusamplingtaskid =
                           CusamplingTask.Cusamplingtaskid
                      LEFT JOIN Uom
                        ON Cusamplingdetailnew.Cuuomid = Uom.Uomid
                     WHERE CusamplingTask.Cusamplingtaskname = {param}
                     ORDER BY Cusamplingdetailnew.Cusamplingno,
                              Cusamplingdetailnew.Cucheckitemname";

            List<LoadTaskListModel> result = db.LoadTaskListModel.FromSql<LoadTaskListModel>(fssql)?.ToList();
            if (result.Count == 0)
            {
                return new ResultModel<string>().Success();
            }
            else
            {
                return new ResultModel<List<LoadTaskListModel>>().Success(result);
            }
        }

    }
}
