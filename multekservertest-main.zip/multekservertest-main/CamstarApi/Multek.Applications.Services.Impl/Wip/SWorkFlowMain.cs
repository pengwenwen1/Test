﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities;
using Multek.Applications.Model.DrillingMachine;
using Multek.Applications.Model.DrillingMachine.Rsp;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Services.CamstarApi;
using Multek.Applications.Services.Wip;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.Wip
{
    public class SWorkFlowMain : EFHelper<MultekCamstarDbContext>, IWorkFlowMain
    {
        public IMapper _mapper;
        public SWorkFlowMain(MultekCamstarDbContext tdb, IMapper Mapper) : base(tdb)
        {
            _mapper = Mapper;
        }

        /// <summary>
        /// 工序是否存在
        /// </summary>
        /// <param name="lot"></param>
        /// <param name="spec"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IResultModel SpecIsExist(LotAndSpecDto lotAndSpecDto)
        {
            var _container = (from c in db.Containers
                                    join p in db.a_ProcessSpecs on c.ProcessSpecId equals p.ProcessSpecId
                                    join w in db.WorkFlows on p.WorkflowId equals w.WorkFlowId
                                    join f in db.WorkFlowSteps on w.WorkFlowId equals f.WorkFlowId
                                    where c.ContainerName == lotAndSpecDto.LotName && f.WorkFlowStepName == lotAndSpecDto.specName
                                    select c).SingleOrDefault();

            if (_container == null)
            {
                return new ResultModel<bool>().Failed("false");
            }
            return new ResultModel<bool>().Success(true);
        }
    }
}
