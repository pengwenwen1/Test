﻿using AutoMapper;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Model.DrillingMachine;
using Multek.Applications.Model.DrillingMachine.Rsp;
using Multek.Applications.Services.CamstarApi;
using Multek.Applications.Services.Wip;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Impl.Wip
{
    public class SDrillingMachineWIPMain : EFHelper<MultekCamstarDbContext>, IDrillingMachineWIPMain
    {
        public IMapper _mapper;
        public SDrillingMachineWIPMain(MultekCamstarDbContext tdb, IMapper Mapper) : base(tdb)
        {
            _mapper = Mapper;
        }

        /// <summary>
        /// MES过数信息记录
        /// </summary>
        /// <param name="wipCountDto"></param>
        /// <returns></returns>
        public IResultModel MESTransferRecord(WipCountDto wipCountDto)
        {
            List<WipCount> _wipCounts = db.wipCounts.Where(x => x.factoryName == wipCountDto.factoryName && x.cutrackflag == wipCountDto.cuTrackFlag && x.lastActivityDate >= wipCountDto.startTime && x.lastActivityDate <= wipCountDto.endTime 
                && wipCountDto.specName.Contains(x.specName)
            ).ToList();

            //输入产品型号
            if (wipCountDto.productName.Count> 0)
            {
                _wipCounts = _wipCounts.Where(x => wipCountDto.productName.Contains(x.productName)).ToList();
            }

            //已进站
            if (wipCountDto.cuTrackFlag == 0)
            {
                return new ResultModel<List<MESMoveInRsp>>().Success(_mapper.Map<List<MESMoveInRsp>>(_wipCounts));
            }
            else
            {
                return new ResultModel<List<MESTrackRsp>>().Success(_mapper.Map<List<MESTrackRsp>>(_wipCounts));
            }
        }
    }
}
