﻿namespace Multek.Applications.WebApi.COM
{
    /// <summary>
    /// 模块常量定义类
    /// </summary>
    public class SawaggerGroupName
    {
        public const string CAM = "CAM";
        public const string SYS = "SYS";
        public const string LOT = "LOT";
        public const string WIP = "WIP";
    }
}
