using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Multek.Applications.WebApi.COM;
using Multek.Applications.WebApi.Config;
using Multek.Applications.WebApi.Middlewares;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.Const;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    foreach (var fieldInfo in typeof( SawaggerGroupName).GetFields())
    {
        options.SwaggerDoc(fieldInfo.Name, new OpenApiInfo
        {
            Version = "v1",
            Title = $"donet-{AppSettings.ManagementOption.ProjectName}",
            Description = $"Multek.Net [{fieldInfo.Name}]�Ľӿ��ĵ�"
        });
    }
    var xmlFilename = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    options.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFilename),true);
    options.OrderActionsBy(x=>x.RelativePath);
});
builder.Services.AddControllersWithViews()
                .AddNewtonsoftJson(options =>
                {
                    // ����ĸСд(�շ���ʽ)
                    options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                    // ʱ���ʽ��
                    options.SerializerSettings.DateFormatString = "yyyy-MM-dd HH:mm:ss";
                    // ����ѭ������
                    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                    // ���Կ�ֵ
                    // options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                });
builder.Register();
builder.RegisterNacos();
var app = builder.Build();
app.UseMiddleware<ExceptionMiddleware>();

// Configure the HTTP request pipeline.

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    foreach (var fieldInfo in typeof(SawaggerGroupName).GetFields())
    {
        c.SwaggerEndpoint($"/swagger/{fieldInfo.Name}/swagger.json", fieldInfo.Name);
        ApplicationConst.SwaggerDoc.Add($"/swagger/{fieldInfo.Name}/swagger.json");
    }
    c.DocExpansion(Swashbuckle.AspNetCore.SwaggerUI.DocExpansion.None);
    c.DefaultModelsExpandDepth(-1);
});

app.UseAuthorization();

app.MapControllers();

app.Run();
