﻿using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Services.Auth;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Services.Impl.Sample;
using Multek.Applications.Services.Sample;
using Multek.Applications.WebApi.COM;
using Multek.Applications.WebApi.Filters;
using Multek.Library_Core.COM;
using Multek.Library_Core.ResultModel;


namespace Multek.Applications.WebApi.Controllers
{
    [ApiExplorerSettings(GroupName = SawaggerGroupName.CAM)]
    [Route($"{SawaggerGroupName.CAM}/[controller]/[action]")]
    [ApiController]
    public class AuthController : Controller
    {
        private readonly IAuth _auth;
        public AuthController(IAuth auth)
        {
            _auth = auth;
        }

        /// <summary>
        /// 员工资质验证
        /// </summary>
        /// <param name="verifyOperatorDto"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel VerifyOperator1(VerifyOperatorDto verifyOperatorDto)
        {
            return _auth.VerifyOperator1(verifyOperatorDto);
        }

        /// <summary>
        /// 员工资质验证(根据员工号和密码验证)
        /// </summary>
        /// <param name="verifyDto"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel VerifyOperator2(VerifyDto verifyDto)
        {
            return _auth.VerifyOperator2(verifyDto);
        }

    }
}
