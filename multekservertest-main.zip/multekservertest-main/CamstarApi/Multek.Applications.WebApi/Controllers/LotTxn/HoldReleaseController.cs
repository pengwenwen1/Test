﻿using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.HoldRelease;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Services.CamstarApi;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.ResultModel;

namespace Multek.Applications.WebApi.Controllers.LotTxn
{
    /// <summary>
    /// 批次冻结和释放
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.LOT)]
    [Route($"{SawaggerGroupName.LOT}/[controller]/[action]")]
    [ApiController]
    public class HoldReleaseController :Controller
    {
        private readonly IHoldReleaseService _txn;

        public HoldReleaseController(IHoldReleaseService barcode)
        {
            _txn = barcode;
        }
        
        /// <summary>
        /// 执行LOTHold
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel HoldLot(HoldLotInfoRsp param)
        {
            return _txn.HoldLot(param);
        }

        /// <summary>
        /// 获取Hold原因
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetHoldReason() { return _txn.GetHoldReason(); }


        /// <summary>
        /// 批次释放
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotRelease(LotReleaseReq param)
        {
            return _txn.LotRelease(param);
        }

        /// <summary>
        /// 获取释放原因
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetReleaseReason()
        {
            return _txn.GetReleaseReason();
        }

        /// <summary>
        /// 查询PC端Hol原因建模
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetHoldReasonPC()
        {
            return _txn.GetHoldReasonPC();
        }
    }
}
