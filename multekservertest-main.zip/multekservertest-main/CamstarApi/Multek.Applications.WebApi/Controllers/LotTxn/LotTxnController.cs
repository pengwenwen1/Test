﻿using Autofac.Extras.DynamicProxy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Caching.Distributed;
using Multek.Applications.Data.DbContexts.Sample;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.LotTxn;
using Multek.Applications.Model.Entities.Multek;
using Multek.Applications.Model.Entities.TRC;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Services.Impl.Sample;
using Multek.Applications.Services.Sample;
using Multek.Applications.WebApi.COM;
using Multek.Applications.WebApi.Filters;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.AOP;
using Multek.Library_Core.Redis;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Multek.Applications.WebApi.Controllers
{
    /// <summary>
    /// Lot信息查询及返修外协
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.LOT)]
    [Route($"{SawaggerGroupName.CAM}/[controller]/[action]")]
    [ApiController]
    public class LotTxnController : Controller
    {
        private readonly ILotInfoQuery _txn;

        public LotTxnController(ILotInfoQuery barcode)
        {
            _txn = barcode;
        }
        /// <summary>
        /// 按批获取Panel码
        /// </summary>
        /// <param name="GetPanelsCodeByLotDto"></param>
        /// <returns></returns>
        [HttpPost]
        public TrackALLInfo GetLotInfoByLotName(string LotName)
        {
            GetLotMsgReq qryCondition = new GetLotMsgReq();
            qryCondition.Lot = LotName;
            return _txn.GetLotInfo(qryCondition);
        }

        /// <summary>
        /// 获取下码Lot信息
        /// </summary>
        /// <param name="TrackLot"></param>
        /// <returns></returns>
        [HttpPost]
        public TrackALLInfo GetLotInfo(GetLotMsgReq TrackLot)
        {

            return _txn.GetLotInfo(TrackLot);
        }


        //[HttpPost]
        //public List<TrackALLInfo> GetLotInfos(List<string> LotNames)
        //{
        //    List<TrackALLInfo> listqryCondition = new List<TrackALLInfo>();
        //    foreach (var item in LotNames)
        //    {
        //        listqryCondition.Add(new TrackALLInfo() { PARENT_LOT = item });
        //    }


        //    return _txn.GetLotInfo(listqryCondition);
        //}

        /// <summary>
        /// 返修：获取返修方法
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetRepairMethod()
        {
            return _txn.GetRepairMethod();
        }

        /// <summary>
        /// 返修：获取返修Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetReworkLotInfo(SingleLotReq param)
        {
            return _txn.GetReworkLotInfo(param);
        }

        /// <summary>
        /// 返修：调用LotRework服务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CULotRepair(ReworkInfoReq param)
        {
            return _txn.CULotRepair(param);
        }

        /// <summary>
        /// 外协发送：获取供应商名字和描述
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetVendor(string param)
        {
            return _txn.GetVendor(param);
        }

        /// <summary>
        /// 外协发送：获取外协Lot信息
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetOSLotInfo(OSLotReq param)
        {
            return _txn.GetOSLotInfo(param);
        }

        /// <summary>
        ///  外协发送：获取外协工序
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetOSSpecInfo(OSSpecReq param)
        {
            return _txn.GetOSSpecInfo(param);
        }

        /// <summary>
        ///  外协发送： 根据外协单号获取外协批次信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetLotInfoByOSOrder(string param)
        {
            return _txn.GetLotInfoByOSOrder(param);
        }

        /// <summary>
        /// 外协发送：调用cuOutsourcingLotTxn服务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CUOutsourcingLotTxn(OSLotSendReq param)
        {
            return _txn.CUOutsourcingLotTxn(param);
        }

        /// <summary>
        ///  外协取消： 查询外协单号
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetOSROrder(SingleLotReq param)
        {
            return _txn.GetOSROrder(param);
        }

        /// <summary>
        ///  外协取消： 查询Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetOSRLotByOrder(SingleLotReq param)
        {
            return _txn.GetOSRLotByOrder(param);
        }

        /// <summary>
        /// 外协取消：放行Lot
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CUOutSourcingLotRepealTxn(OSRLotRepealReq param)
        {
            return _txn.CUOutSourcingLotRepealTxn(param);
        }

        /// <summary>
        ///  外协接收： 查询Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetOSRELotInfo(OSRELotReq param)
        {
            return _txn.GetOSRELotInfo(param);
        }

        /// <summary>
        /// 外协接收：提交服务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CUOSRELotTxn(OSRESubmitReq param)
        {
            return _txn.CUOSRELotTxn(param);
        }

        /// <summary>
        ///  抽检-手动： 查询Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel APP_GetLotSamplingTask(STCreateLotReq param)
        {
            return _txn.APP_GetLotSamplingTask(param);
        }

        /// <summary>
        ///  抽检-手动： 查询抽检种类
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel APP_GetSamplingCategory(STCreateLotReq param)
        {
            return _txn.APP_GetSamplingCategory(param);
        }

        /// <summary>
        ///  抽检-手动： 查询检验矩阵
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel APP_GetCheckMatrix(STCreateLotReq param)
        {
            return _txn.APP_GetCheckMatrix(param);
        }

        /// <summary>
        /// 抽检-手动：提交手动创建的抽检任务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel APP_PostCreateSamplingTask(PostSamplingTask_Req param)
        {
            return _txn.APP_PostCreateSamplingTask(param);
        }

        /// <summary>
        ///  抽检-查询： 查询抽检任务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel APP_GetSamplingCheckTasks(SamplingCheckTasks_Req param)
        {
            return _txn.APP_GetSamplingCheckTasks(param);
        }

        /// <summary>
        /// 抽检-查询：抽检任务提交
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel APP_PostSamplingCheckTask(PostSamplingCheckTask_Req param)
        {
            return _txn.APP_PostSamplingCheckTask(param);
        }

        /// <summary>
        /// 检验：查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LoadTaskList(LoadTaskListReq param)
        {
            return _txn.LoadTaskList(param);
        }

        /// <summary>
        /// 检验：送样
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SendSampling(SendSamplingReq param)
        {
            return _txn.SendSampling(param);
        }

        /// <summary>
        /// 检验：扫描lot获取明细
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LoadLotDetail(SingleLotReq param)
        {
            return _txn.LoadLotDetail(param);
        }

        /// <summary>
        /// 检验：获取检验项
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetCheckItem(string param)
        {
            return _txn.GetCheckItem(param);
        }

        /// <summary>
        /// 检验：保存结果
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SaveSamplingTask(SamplingTaskReq param)
        {
            return _txn.SaveSamplingTask(param);
        }

        /// <summary>
        /// 获取HOLD原因
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetHoldReason(string param)
        {
            return _txn.GetHoldReason(param);
        }

        /// <summary>
        /// 获取检验失败原因
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetFailReason(string param)
        {
            return _txn.GetFailReason(param);
        }

        /// <summary>
        /// 获取产品
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetPN(string param)
        {
            return _txn.GetPN(param);
        }

        /// <summary>
        /// 获取工序
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetSpec(string param)
        {
            return _txn.GetSpec(param);
        }

        /// <summary>
        /// 获取设备
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetEqp(string param)
        {
            return _txn.GetEqp(param);
        }

        /// <summary>
        /// 获取检验种类
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetSamplingCategory(string param)
        {
            return _txn.GetSamplingCategory(param);
        }

        /// <summary>
        /// 获取OEM
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetOEM(string param)
        {
            return _txn.GetOEM(param);
        }

        /// <summary>
        /// 获取CEM
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetCEM(string param)
        {
            return _txn.GetCEM(param);
        }

        /// <summary>
        /// 获取版样
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetProductionType(string param)
        {
            return _txn.GetProductionType(param);
        }

        /// <summary>
        /// 检验失败处理：查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LoadTaskListForFail(LoadTaskListForFailReq param)
        {
            return _txn.LoadTaskListForFail(param);
        }

        /// <summary>
        /// 检验失败处理：提交处理结果
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SaveSamplingTaskForFail(SamplingTaskForFailReq param)
        {
            return _txn.SaveSamplingTaskForFail(param);
        }

        /// <summary>
        /// 检验失败处理：扫描Lot校验状态
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public IResultModel CheckFailLot(string param) 
        {
            return _txn.CheckFailLot(param);
        }

        /// <summary>
        /// 检验失败处理：查看检验明细
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public IResultModel LoadTaskList(string param)
        {
            return _txn.LoadTaskList(param);
        }
    }
}
