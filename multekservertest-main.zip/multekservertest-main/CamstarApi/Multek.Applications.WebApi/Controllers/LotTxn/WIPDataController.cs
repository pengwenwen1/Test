﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.WIPData;
using Multek.Applications.Services.CamstarApi;
using Multek.Applications.Services.Impl.CamstarApi;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.ResultModel;

namespace Multek.Applications.WebApi.Controllers.LotTxn
{
    /// <summary>
    /// wip 批次的数据录入和 跳站，批次的数据修改 ECN，ERC，内外层配单
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.LOT)]
    [Route($"{SawaggerGroupName.LOT}/[controller]/[action]")]
    [ApiController]
    public class WIPDataController : Controller
    {
        private readonly IWIPData _IWIPdata;
        public WIPDataController(IWIPData iWIPData)
        {
            _IWIPdata = iWIPData;
        }

        /// <summary>
        /// LotDataCode录入
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel EntryDataCode(EntryDataCodeReq param)
        {
            return _IWIPdata.EntryDataCode(param);
        }

        /// <summary>
        /// 跳站接口
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel MoveStd(MoevStdReq param)
        {
            return _IWIPdata.MoveStd(param);
        }

        /// <summary>
        /// 获得跳站原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetMStdReason()
        {
            return _IWIPdata.GetMStdReason();
        }

        /// <summary>
        /// 获取step
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetToStep(cuGetSetpTypeRsp param)
        {
            return _IWIPdata.GetToStep(param);
        }


        /// <summary>
        /// 获取Path
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetPath(cuGetSetpTypeRsp param)
        {
            return _IWIPdata.GetToStep(param);
        }

        /// <summary>
        /// ECN执行
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel ECNTxn(CuECNChangeReq param)
        {
            return _IWIPdata.ECNTxn(param);
        }
        /// <summary>
        /// 获取ECN信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetEcnInfo(GetECNInfoReq param)
        {
            return _IWIPdata.GetEcnInfo(param);
        }
        /// <summary>
        /// OA预Hold新增的功能
        /// </summary>
        /// <param name="userLoginInfo"></param>
        /// <param name="cuOAFutureHold"></param>
        [HttpPost]
        public IResultModel CuOAFutureHold(CuOAFutureHoldRep param)
        {
            return _IWIPdata.CuOAFutureHold(param);
        }
        /// <summary>
        /// OA释放FutureHold
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CuOAFutureHoldRelease(CuOAFutureHoldReleaseReq param)
        {
            return _IWIPdata.CuOAFutureHoldRelease(param);
        }

        /// <summary>
        /// 执行OAFutureHold
        /// </summary>
        /// <param name="ecnChangeParameter"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SExecutecuEcnFutureHoldMaint(CuEcnChangeParameter ecnChangeParameter)
        {
            return _IWIPdata.SExecutecuEcnFutureHoldMaint(ecnChangeParameter);
        }

        /// <summary>
        /// 执行OALotFutureHold
        /// </summary>
        /// <param name="ecnChangeParameter"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SExecuteLotFutureHoldSetup(CuEcnChangeParameter ecnChangeParameter)
        {
            return _IWIPdata.SExecuteLotFutureHoldSetup(ecnChangeParameter);
        }

        /// <summary>
        /// ERC重分类
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel ERCGradePN(ERCReq param)
        {
            return _IWIPdata.ERCGradePN(param);
        }

        /// <summary>
        /// ERC查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetERCInfo(GetERCInfoReq param)
        {
            return _IWIPdata.GetERCInfo(param);
        }
        /// <summary>
        /// 获取ERC工序
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetErcSpec()
        {
            return _IWIPdata.GetErcSpec();
        }

        /// <summary>GetModelInfo
        /// OA接口查询数据是否存在
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetModelInfo(GetModelInfo param)
        {
            return _IWIPdata.GetModelInfo(param);
        }
        /// <summary>
        /// 内外层配单查询lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LayerGetContainerInfo(CuLayerGetContinerInfoReq param)
        {
            return _IWIPdata.LayerGetContainerInfo(param);
        }
        /// <summary>
        /// 内层配单获取用户信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LayerGetEmployeeInfo(GetEmployeeInfo param)
        {
            return _IWIPdata.LayerGetEmployeeInfo(param);
        }

        /// <summary>
        /// 执行内存配单
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel RequestNextLayerWO(cuLayerReq param)
        {
            return _IWIPdata.RequestNextLayerWO(param);
        }
    }
}
