﻿using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.SplitAndCombine;
using Multek.Applications.Services.CamstarApi;
using Multek.Applications.Services.Impl.CamstarApi;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.ResultModel;

namespace Multek.Applications.WebApi.Controllers.LotTxn
{
    /// <summary>
    /// 批次拆批合批
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.LOT)]
    [Route($"{SawaggerGroupName.LOT}/[controller]/[action]")]
    [ApiController]
    public class SplitCombineController :Controller
    {

        private readonly ISplitCombine _splitCombine;

        public SplitCombineController(ISplitCombine splitCombine)
        {
            _splitCombine = splitCombine;
        }

        /// <summary>
        /// 执行拆批服务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SplitTxn(SplitLotMsgReq param)
        {
            return _splitCombine.Split(param);
        }

        /// <summary>
        /// 获取拆批后的新批次
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetSplitNewLotMsg(GetLotMsgReq param)
        {
            return _splitCombine.GetSplitNewLot(param);
        }

        /// <summary>
        /// 合批
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CombineTxn(CombineLotReq param)
        {
            return _splitCombine.Combine(param);
        }

        /// <summary>
        /// 获取拆批原因
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetSplitReason()
        {
            return _splitCombine.GetSplitReason();
        }
        /// <summary>
        /// 获取Carrier
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetCarrier()
        {
            return _splitCombine.GetCarrier();
        }
    }



}
