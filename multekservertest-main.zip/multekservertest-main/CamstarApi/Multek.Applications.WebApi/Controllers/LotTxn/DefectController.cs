﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.WIPMain;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Services.CamstarApi;
using Multek.Applications.Services.Impl.Barcode;
using Multek.Applications.Services.Impl.CamstarApi;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.ResultModel;

namespace Multek.Applications.WebApi.Controllers.LotTxn
{
    [ApiExplorerSettings(GroupName = SawaggerGroupName.CAM)]
    [Route($"{SawaggerGroupName.CAM}/[controller]/[action]")]
    [ApiController]
    public class DefectController : Controller
    {
        private readonly IDefect _Defect;

        public DefectController(IDefect defect)
        {
            _Defect = defect;
        }
        ///// <summary>
        ///// Camstar发起报废流程请求
        ///// </summary>
        ///// <param name="cuOARejectProcesses"></param>
        ///// <returns></returns>
        //[HttpPost]
        //public IResultModel CuOA_RejectProcess(CuOARejectProcess cuOARejectProcesses)
        //{
        //    return _Defect.CuOA_RejectProcess(cuOARejectProcesses);
        //}


        /// <summary>
        /// 获取报废信息
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel RefreshDefectInfo(CuOARejectInfo cuOARejectInfo)
        {
            return _Defect.RefreshDefectInfo(cuOARejectInfo);
        }

        /// <summary>
        /// Camstar提交报废
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SubmitDefect(CuOARejectInfo cuOARejectInfo)
        {
            return _Defect.SubmitDefect(cuOARejectInfo);
        }

        /// <summary>
        /// OA返回报废审核结果，执行报废   CuOA_RejectProcessResult
        /// </summary>
        /// <param name="cuOARejectProcessResult"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CuOA_RejectProcessResult(CuOARejectProcessResult cuOARejectProcessResult)
        {
            return _Defect.SExcuteRejectToMES(cuOARejectProcessResult);
        }

        /// <summary>
        /// 批次关闭
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotClose(LotStatusUpdateRsp param)
        {
            return _Defect.LotClose(param);
        }

        /// <summary>
        /// 批次打开
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotOpen(LotStatusUpdateRsp param)
        {
            return _Defect.LotOpen(param);
        }

        /// <summary>
        /// Lot信息查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotStatusInfo(GetLotMsgReq param)
        {
            return _Defect.GetLotStatusInfo(param);
        }

        /// <summary>
        /// Lot终止
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotTerminate(LotStatus param)
        {
            return _Defect.LotTerminate(param);
        }

        /// <summary>
        /// Lot激活
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotUnTerminate(LotStatus param)
        {
            return _Defect.LotUnTerminate(param);
        }

        /// <summary>
        /// Lot激活流程信息查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotUnTerminateWorkflow(GetLotMsgReq param)
        {
            return _Defect.GetLotUnTerminateWorkflow(param);
        }

        /// <summary>
        /// Lot继续
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel cuUnTerminate(LotStatus param)
        {
            return _Defect.cuUnTerminate(param);
        }

        /// <summary>
        /// 批次首末检启动
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotFirstInspectStart(LotInspect param)
        {
            return _Defect.LotFirstInspectStart(param);
        }

        /// <summary>
        /// 批次首检
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotFirstInspect(LotFirstInspect param)
        {
            return _Defect.LotFirstInspect(param);
        }

        /// <summary>
        /// 批次末检
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel cuLotLastInspect(LotFirstInspect param)
        {
            return _Defect.cuLotLastInspect(param);
        }

        /// <summary>
        /// 批次终止原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetTerminateReason()
        {
            return _Defect.GetTerminateReason();
        }

        /// <summary>
        /// 批次激活原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetUnTerminateReason()
        {
            return _Defect.GetUnTerminateReason();
        }

        /// <summary>
        /// 外协物料消耗（手工）
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel cuOutsouringConsumedMaterial(cuOutsouringLot param)
        {
            return _Defect.cuOutsouringConsumedMaterial(param);
        }

        /// <summary>
        /// 查询外协扣料批次信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetOutsourcingLot(cuOutsouringLotInfo param)
        {
            return _Defect.GetOutsourcingLot(param);
        }

        /// <summary>
        ///  查询批次首末检任务信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotInspectMsg(GetLotInspect param)
        {
            return _Defect.GetLotInspectMsg(param);
        }

        /// <summary>
        ///  查询批次首末检检验历史记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotInspectRecord(GetLotInspect param)
        {
            return _Defect.GetLotInspectRecord(param);
        }

        /// <summary>
        ///  查询批次首末检数据采集信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotWipDataName(GetLotInspect param)
        {
            return _Defect.GetLotWipDataName(param);
        }
    }
}
