﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.WIPMain;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Services.CamstarApi;
using Multek.Applications.Services.Impl.Barcode;
using Multek.Applications.WebApi.COM;
using Multek.Library_Core.ResultModel;
using System.Diagnostics;

namespace Multek.Applications.WebApi.Controllers.LotTxn
{
    /// <summary>
    /// Lot层过站及WIP信息查询
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.CAM)]
    [Route($"{SawaggerGroupName.CAM}/[controller]/[action]")]
    [ApiController]
    public class WIPMainController : Controller
    {
        private readonly IWIPMain _WIPMain;

        public WIPMainController(IWIPMain wIPMain)
        {
            _WIPMain = wIPMain;
        }


        #region Move in
        /// <summary>
        /// PNls Movein
        /// </summary>
        /// <param name="factoryName"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel MoveIn(MoveInReq param)
        {
            return _WIPMain.MoveIn(param);
        }
        #endregion

        #region  Move out
        [HttpPost]
        public IResultModel GetMoveOutNextStep(GetLotMsgReq param)
        {
            return _WIPMain.GetMoveOutNextStep(param);
        }

        /// <summary>
        /// PNls MoveOut
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel MoveOut(MoveOutReq param)
        {
            return _WIPMain.MoveOut(param);
        }
        #endregion

        /// <summary>
        /// 获取Lot信息
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotMsg(GetLotMsgReq param)
        {
            return _WIPMain.GetLotMsg(param);

            //Stopwatch sw = new Stopwatch();          
            //sw.Start();
            //var result = _WIPMain.GetLotMsg(param);
            //Console.WriteLine("总运行时间：" + sw.Elapsed);
            //Console.WriteLine("测量实例得出的总运行时间（毫秒为单位）：" + sw.ElapsedMilliseconds);
            //Console.WriteLine("总运行时间(计时器刻度标识)：" + sw.ElapsedTicks);
            //Console.WriteLine("计时器是否运行：" + sw.IsRunning.ToString());
            //return result;
        }


        /// <summary>
        /// 获取Lot信息-新
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        [HttpPost]
       // public IResultModel GetLotMsgNew(GetLotMsgReq param)
        public IResultModel GetLotMsgNew(GetLotMsgReq param)
        {
            //Stopwatch sw = new Stopwatch();         
            //sw.Start();
            //var result = _WIPMain.GetLotMsgNew(param);
            //Console.WriteLine("总运行时间：" + sw.Elapsed);
            //Console.WriteLine("测量实例得出的总运行时间（毫秒为单位）：" + sw.ElapsedMilliseconds);
            //Console.WriteLine("总运行时间(计时器刻度标识)：" + sw.ElapsedTicks);
            //Console.WriteLine("计时器是否运行：" + sw.IsRunning.ToString());
            //return result;
            return _WIPMain.GetLotMsgNew(param);
        }


        #region Track in
        /// <summary>
        /// 批量Lot Track in
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel TrackIn(TrackInReq param)
        {
            return _WIPMain.TrackIn(param);
        }

        #endregion

        #region
        /// <summary>
        /// 批量Lot Track Out
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel TrackOut(TrackOutReq param)
        {
            return _WIPMain.TrackOut(param);
        }
        #endregion

        /// <summary>
        /// 钻孔工序上下机
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel TrackInOut(TrackInReq param)
        {
            var ti = _WIPMain.TrackIn(param);
            if (!ti.success)
                return _WIPMain.TrackIn(param);
            TrackOutReq to = new TrackOutReq();
            to.Lots = param.Lots;
            to.Operator = param.Operator;
            to.SpecName = param.SpecName;
            to.TrackOutQty = param.TrackInQty;
            to.EquipmentName = param.EquipmentName;
            to.Factory = param.Factory;
            return _WIPMain.TrackOut(to);
        }


        //[HttpPost]
        //public string GetWIPMainAttribute(string LotName, string field)
        //{
        //   return _WIPMain.GetWIPMainAttribute(LotName, field);
        //}

        /// <summary>
        /// 获取需要补录过站信息的工步列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetStepMsg(GetStepInfo param)
        {
            return _WIPMain.GetStepMsg(param);
        }

        /// <summary>
        /// 根据结束工序获取HoldingTime信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetHoldingTimeMsg(HoldingTimeReq param)
        {
            return _WIPMain.GetHoldingTimeMsg(param);
        }

        /// <summary>
        /// 获取Lot集合未关闭的定时器
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotsTimerMsg(HoldingTimeReq param)
        {
            return _WIPMain.GetLotsTimerMsg(param);
        }

        /// <summary>
        /// 批量Lot冻结
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LotsHold(HoldLots param)
        {
            return _WIPMain.LotsHold(param);
        }

        /// <summary>
        /// 获取Lot当前工序及DataCode格式信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetDataCodeFormat(GetLotMsgReq param)
        {
            return _WIPMain.GetDataCodeFormat(param);
        }

        /// <summary>
        /// 获取OA预冻结信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetOAFutureHoldMsg(OAFutureHoldMsgReq param)
        {
            return _WIPMain.GetOAFutureHoldMsg(param);
        }

        /// <summary>
        /// 获取批次预冻结信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotsFutureHoldMsg(LotsFutureHoldReq param)
        {
            return _WIPMain.GetLotsFutureHoldMsg(param);
        }

        /// <summary>
        /// 重工：获取Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotInfo(CreateNewInsertionReq param)
        {
            return _WIPMain.GetLotInfo(param);
        }

        /// <summary>
        /// 重工：获取重工原因
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResultModel GetInsertionReason()
        {
            return _WIPMain.GetInsertionReason();
        }

        /// <summary>
        /// 重工：执行CreateNewInsertion事务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel CreateNewInsertion(CreateNewInsertionReq param)
        {
            return _WIPMain.CreateNewInsertion(param);
        }

        /// <summary>
        /// 根据Lot获取当前工序设备列表信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetEquipmentListByLot(GetLotMsgReq param)
        {
            return _WIPMain.GetEquipmentListByLot(param);
        }

        /// <summary>
        /// 根据员工获取工序信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetSpecByEmployee(EmployeeSpecReq param)
        {
            return _WIPMain.GetSpecByEmployee(param);
        }

        /// <summary>
        /// 根据连续线设备获取连续线工序
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetSpecByContinuousEquipment(LotMessage param)
        {
            return _WIPMain.GetSpecByContinuousEquipment(param);
        }

        /// <summary>
        /// 获取当前工步的后续工步
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetFollowStep(LotMessage param)
        {
            return _WIPMain.GetFollowStep(param);
        }

        /// <summary>
        /// 获取Lot当前工序设备的物料信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotMeMaterialLotMsg(MaterialLotMsgReq param)
        {
            return _WIPMain.GetLotMeMaterialLotMsg(param);
        }

        /// <summary>
        /// 获取LotWIP在线信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetLotWIPTrackMsg(GetLotMsgReq param)
        {
            return _WIPMain.GetLotWIPTrackMsg(param);
        }

        /// <summary>
        /// 获取WIPMain属性-在制状态
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public string GetWIPMainAttribute(string LotName)
        {
            var a =  _WIPMain.GetWIPMainAttributeNew(LotName, "WIPFlagSelection");
            string r = string.Empty;
            if (a == "1")
                r = "待上机";
            else if (a == "2"|| a == "3")
                r = "待下机";
            else if (a == "4")
                r = "待出站";
            else if (a == "5")
                r = "待进站";
            else
                r = "非在制状态";
            return r;
        }

        /// <summary>
        /// 连续线Lot过站记录补齐
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel ContinuousLotCompletion(ContinuousLotCompletionReq param)
        {
            return _WIPMain.ContinuousLotCompletion(param);
        }

    }
}
