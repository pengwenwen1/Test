﻿using Autofac.Extras.DynamicProxy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Caching.Distributed;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.DrillingMachine;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Services.Impl.Sample;
using Multek.Applications.Services.Sample;
using Multek.Applications.Services.Wip;
using Multek.Applications.WebApi.COM;
using Multek.Applications.WebApi.Filters;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.AOP;
using Multek.Library_Core.Redis;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Multek.Applications.WebApi.Controllers
{
    /// <summary>
    /// MES工艺流程信息
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.WIP)]
    [Route($"{SawaggerGroupName.WIP}/[controller]/[action]")]
    [ApiController]
    public class WorkFlowController : Controller
    {
        private readonly IWorkFlowMain _workFlowMain;

        public WorkFlowController(IWorkFlowMain workFlowMain)
        {
            _workFlowMain = workFlowMain;
        }

        /// <summary>
        /// 工序是否存在
        /// </summary>
        /// <param name="wipCountDto"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel SpecIsExist(LotAndSpecDto lotAndSpecDto)
        {
            return _workFlowMain.SpecIsExist(lotAndSpecDto);
        }

    }
}
