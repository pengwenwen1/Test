﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using System.Configuration;
using System.Diagnostics;
using Multek.Library_Core.Redis;
using Multek.Library_Core.ServicesInface;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Model.Entities.Camstar.Dto;

namespace Multek.Applications.WebApi.Controllers.SYS
{
    /// <summary>
    /// Camstar测试
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class CamstarTestController : Controller
    {
        private readonly ICamstarTest _IcamstarTest;
        /// <summary>
        /// Camstar 测试
        /// </summary>
        /// <param name="camstarTest"></param>
        public CamstarTestController(ICamstarTest camstarTest)
        {
            _IcamstarTest = camstarTest;
        }

        /// <summary>
        /// 新增工厂
        /// </summary>
        /// <param name="factoryName">新增工厂信息</param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel AddFactory(string factoryName)
        {
            return _IcamstarTest.AddFactory(factoryName);
        }

        /// <summary>
        /// 删除工厂
        /// </summary>
        /// <param name="factoryName">工厂信息</param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel DeleteFactory(string factoryName)
        {
            return _IcamstarTest.DeleteFactory(factoryName);
        }

        /// <summary>
        /// 加载工厂
        /// </summary>
        /// <param name="factoryName">工厂信息</param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel LoadFactory(string factoryName)
        {
            return _IcamstarTest.LoadFactory(factoryName);
        }
    }
}
