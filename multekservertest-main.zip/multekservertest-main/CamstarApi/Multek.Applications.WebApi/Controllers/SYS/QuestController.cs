﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using System.Configuration;
using System.Diagnostics;
using Multek.Library_Core.COM.Const;
using Multek.Library_Core.COM;
using Multek.Library_Core.Model.Token;
using Newtonsoft.Json;
using Multek.Library_Core.ServicesInface;
using System.Net;
using Multek.Library_Core.Redis;
using Multek.Library_Core.WebApi.Filters;
using Microsoft.Extensions.Caching.Memory;
using Multek.Library_Core.Quest.QuestInterface;

namespace Multek.Applications.WebApi.Controllers.SYS
{
    /// <summary>
    /// 系统
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class QuestController : Controller
    {
        private readonly IQuest _quest;
        public QuestController(IQuest quest)
        {
            _quest = quest;
        }
        /// <summary>
        /// 初始化表
        /// </summary>
        [HttpPost]
        public void InitTable() { 
            _quest.InitTable();
        }
        /// <summary>
        /// 新增测试数据
        /// </summary>
        [HttpPost]
        public void AddData()
        {
            _quest.AddData();
        }
      
    }
}
