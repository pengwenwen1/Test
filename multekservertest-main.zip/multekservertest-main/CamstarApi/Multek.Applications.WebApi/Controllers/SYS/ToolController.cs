﻿using Microsoft.AspNetCore.Mvc;
using Multek.Library_Core.ResultModel;
using Multek.Applications.WebApi.COM;
using System.Configuration;
using System.Diagnostics;
using Multek.Library_Core.Redis;
using Multek.Library_Core.ServicesInface;
using Multek.Applications.Services.Barcode;

namespace Multek.Applications.WebApi.Controllers.SYS
{
    /// <summary>
    /// 系统
    /// </summary>
    [ApiExplorerSettings(GroupName = SawaggerGroupName.SYS)]
    [Route($"{SawaggerGroupName.SYS}/[controller]/[action]")]
    [ApiController]
    public class ToolController : Controller
    {
        private readonly IConfiguration _Configuration;
        private readonly INacos _nacos;
        private readonly ICSharpScript _ICSharpScript;
        public ToolController(IConfiguration configuration, INacos nacos, ICSharpScript iCSharpScript)
        {
            _Configuration = configuration;
            _nacos = nacos;
            _ICSharpScript = iCSharpScript;
        }

        /// <summary>
        /// 获取进程ID
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public int GetProcessId()
        {
            return Process.GetCurrentProcess().Id;
        }

        /// <summary>
        /// 配置信息
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public String GetConfig()
        {
            return  $" Port:{_Configuration["port"]} </br>IP:{ _Configuration["ip"]}</br>ASPNETCORE_ENVIRONMENT :{_Configuration["ASPNETCORE_ENVIRONMENT"]} CamstarIp：{_Configuration.GetConnectionString("CamstarIP")}";
        }
        /// <summary>
        /// 获取系统当前时间
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public String GetDate()
        {
            return "UtcNow:"+ DateTime.UtcNow.ToShortTimeString() + "Now:"+DateTime.Now.ToShortTimeString();
        }

        /// <summary>
        /// 动态生成值
        /// </summary>
        /// <param name="codeExpression">表达式</param>
        /// <param name="parameters">表达式的参数集合</param>
        /// <returns></returns>
        [HttpPost]
        public string Run(string codeExpression, Dictionary<string, string> parameters)
        {
            return _ICSharpScript.Run(codeExpression, parameters);
        }
    }
}
