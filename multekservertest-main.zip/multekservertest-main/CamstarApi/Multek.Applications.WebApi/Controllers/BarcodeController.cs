﻿using Autofac.Extras.DynamicProxy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Caching.Distributed;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;
using Multek.Applications.Services.Barcode;
using Multek.Applications.Services.Impl.Sample;
using Multek.Applications.Services.Sample;
using Multek.Applications.WebApi.COM;
using Multek.Applications.WebApi.Filters;
using Multek.Library_Core.COM;
using Multek.Library_Core.COM.AOP;
using Multek.Library_Core.Redis;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Multek.Applications.WebApi.Controllers
{
    [ApiExplorerSettings(GroupName = SawaggerGroupName.CAM)]
    [Route($"{SawaggerGroupName.CAM}/[controller]/[action]")]
    [ApiController]
    public class BarcodeController : Controller
    {
        private readonly IBarcode _barcode;

        public BarcodeController(IBarcode barcode)
        {
            _barcode = barcode;
        }
        /// <summary>
        /// 按批获取Panel码
        /// </summary>
        /// <param name="GetPanelsCodeByLotDto"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetPanelsCodeByLot(GetPanelsCodeByLotDto getPanelsCodeByLot)
        {
            return _barcode.GetPanelsCodeByLot(getPanelsCodeByLot);
        }

       /// <summary>
       /// 通过Pnl号，获取Set Pcs
       /// </summary>
       /// <param name="getSetCodesByPnlDto"></param>
       /// <returns></returns>
        [HttpPost]
        public IResultModel GetSetAndPcsCodesByPnl(GetSetCodesByPnlDto getSetCodesByPnlDto)
        {
            return _barcode.GetSetAndPcsCodesByPnl(getSetCodesByPnlDto);
        }

        /// <summary>
        /// 根据客户和打码类型获取规则
        /// </summary>
        /// <param name="inplanDto"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel GetCodeRule(InplanDto inplanDto)
        {
            return _barcode.QueryPage<CodeRule, string>(x => x.CodeType == inplanDto.CodeType && (x.Custom == inplanDto.Custom || x.Custom == ""), 1000, 1, x => x.PrefixRule, false);
            //return _barcode.GetCodeRule(inplanDto);
        }

        /// <summary>
        /// 查询set/pcs点位信息
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        //[HttpPost]
        //public IResultModel GetCodeInfoOfSet(LotDto lotDto)
        //{
        //    return _barcode.GetCodeInfoOfSet(lotDto);
        //}

        /// <summary>
        /// 上传转码打码记录
        /// </summary>
        /// <param name="codePNLLog"></param>
        /// <returns></returns>
        [HttpPost]
        public IResultModel RecordCodePNLLog(List<CodePNLLog> codePNLLogs)
        {
            return _barcode.RecordCodePNLLog(codePNLLogs);
        }
       
    }
}
