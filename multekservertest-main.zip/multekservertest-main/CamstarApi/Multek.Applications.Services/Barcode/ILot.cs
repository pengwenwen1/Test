﻿using Multek.Applications.Data.Entities;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Barcode
{
    public interface ILot
    {
        /// <summary>
        /// 获取Lot的基础信息用于下码
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        public Container GetLotInfo(string lotName);
    }
}
