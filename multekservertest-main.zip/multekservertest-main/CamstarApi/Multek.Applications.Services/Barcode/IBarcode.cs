﻿using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Barcode
{
    public interface IBarcode: IBaseService
    {
        /// <summary>
        /// 按批获取Panel码
        /// </summary>
        /// <param name="getPanelsCodeByLot"></param>
        /// <returns></returns>
        public IResultModel GetPanelsCodeByLot(GetPanelsCodeByLotDto getPanelsCodeByLot);

        /// <summary>
        /// 按Panel获取Set/PCS
        /// </summary>
        /// <param name="getPanelsCodeByLot"></param>
        /// <returns></returns>
        public IResultModel GetSetAndPcsCodesByPnl(GetSetCodesByPnlDto getSetCodesByPnlDto);

        /// <summary>
        /// 根据客户和打码类型获取规则
        /// </summary>
        /// <param name="inplanDto"></param>
        /// <returns></returns>
        //public IResultModel GetCodeRule(InplanDto inplanDto);

        /// <summary>
        /// 查询PNL
        /// </summary>
        /// <param name="getPanelsCodeByLot"></param>
        /// <returns></returns>
        public GetPanelsCodeByLotRsp GetPnlCode(GetPanelsCodeByLotDto getPanelsCodeByLot,List<CodeTree> codeTreeList, CodeInfoOfPanel codeInfoOfPanel);

        /// <summary>
        /// 查询set和pcs
        /// </summary>
        /// <param name="getSetCodesByPnlDto"></param>
        /// <returns></returns>
        public GetSetAndPcsCodesByPnlRsp GetSetOrPcsCode(GetSetCodesByPnlDto getSetCodesByPnlDto, List<CodeTree> codeTreeList);

        /// <summary>
        /// 查询set/pcs点位信息
        /// </summary>
        /// <param name="lotDto"></param>
        /// <returns></returns>
        //public IResultModel GetCodeInfoOfSet(LotDto lotDto);

        /// <summary>
        /// 上传转码打码记录
        /// </summary>
        /// <param name="codePNLLog"></param>
        /// <returns></returns>
        public IResultModel RecordCodePNLLog(List<CodePNLLog> codePNLLogs);

    }
}
