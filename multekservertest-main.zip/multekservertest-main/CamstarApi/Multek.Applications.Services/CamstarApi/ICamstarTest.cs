﻿using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Barcode
{
    public interface ICamstarTest : IBaseService
    {
        /// <summary>
        /// 新增工厂
        /// </summary>
        /// <param name="factoryName">新增工厂信息</param>
        /// <returns></returns>
        public IResultModel AddFactory(string factoryName);

        /// <summary>
        /// 删除工厂
        /// </summary>
        /// <param name="factoryName">工厂信息</param>
        /// <returns></returns>
        public IResultModel DeleteFactory(string factoryName);
        /// <summary>
        /// 查看工厂
        /// </summary>
        /// <param name="factoryName">工厂信息</param>
        /// <returns></returns>
        public IResultModel LoadFactory(string factoryName);
    }
}
