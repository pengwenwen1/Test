﻿using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;
using Multek.Applications.Model.SplitAndCombine;
using Multek.Applications.Model.WIPMain;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.CamstarApi
{
    public interface IWIPMain : IBaseService
    {

        #region Move in
        /// <summary>
        /// 批量Lot Move in
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel MoveIn(MoveInReq param);
        #endregion

        #region Move Out
        /// <summary>
        /// 出站前获取下下道工步信息
        /// </summary>
        /// <param name="lotName"></param>
        /// <returns></returns>
        public IResultModel GetMoveOutNextStep(GetLotMsgReq param);

        /// <summary>
        /// 批量Lot Move Out
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel MoveOut(MoveOutReq param);
        #endregion

        public IResultModel GetLotMsg(GetLotMsgReq param);


        public IResultModel GetLotMsgNew(GetLotMsgReq param);

        /// <summary>
        /// 获取批次WIP信息
        /// </summary>
        /// <param name="LotName"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public string GetWIPMainAttributeNew(string LotName, string field);


        #region Track in
        /// <summary>
        /// 批量Lot Track in
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel TrackIn(TrackInReq param);
        #endregion

        #region Track Out
        /// <summary>
        /// 批量Lot Track Out
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel TrackOut(TrackOutReq param);
        #endregion

        //public string GetWIPMainAttribute(string LotName, string field);

        /// <summary>
        /// 获取需要补录过站信息的工步列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetStepMsg(GetStepInfo param);

        /// <summary>
        /// 根据结束工序获取HoldingTime信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetHoldingTimeMsg(HoldingTimeReq param);

        /// <summary>
        /// 获取Lot集合未关闭的定时器
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotsTimerMsg(HoldingTimeReq param);

        /// <summary>
        /// 批量Lot冻结
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotsHold(HoldLots param);

        /// <summary>
        /// 获取Lot当前工序及DataCode格式信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        IResultModel GetDataCodeFormat(GetLotMsgReq param);

        /// <summary>
        /// 获取OA预冻结信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOAFutureHoldMsg(OAFutureHoldMsgReq param);

        /// <summary>
        /// 获取批次预冻结信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotsFutureHoldMsg(LotsFutureHoldReq param);

        /// <summary>
        /// 重工：获取Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInfo(CreateNewInsertionReq param);

        /// <summary>
        /// 重工：获取重工原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetInsertionReason();

        /// <summary>
        /// 重工：执行CreateNewInsertion事务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CreateNewInsertion(CreateNewInsertionReq param);

        /// <summary>
        /// 根据Lot获取当前工序设备列表信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetEquipmentListByLot(GetLotMsgReq param);


        /// <summary>
        /// 根据员工获取工序信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetSpecByEmployee(EmployeeSpecReq param);

        /// <summary>
        /// 根据连续线设备获取连续线工序
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetSpecByContinuousEquipment(LotMessage param);

        /// <summary>
        /// 获取当前工步的后续工步
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetFollowStep(LotMessage param);

        /// <summary>
        /// 获取Lot当前工序设备的物料信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotMeMaterialLotMsg(MaterialLotMsgReq param);

        /// <summary>
        /// 获取LotWIP在线信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotWIPTrackMsg(GetLotMsgReq param);

        /// <summary>
        /// 连续线Lot过站记录补齐
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel ContinuousLotCompletion(ContinuousLotCompletionReq param);



    }
}
