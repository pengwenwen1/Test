﻿using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.WIPData;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.CamstarApi
{
    public interface IWIPData : IBaseService
    {
        /// <summary>
        /// 【OA=>MES】设置OA预Hold
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CuOAFutureHold(CuOAFutureHoldRep param);

        /// <summary>
        /// 执行ECN
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel ECNTxn(CuECNChangeReq param);

        /// <summary>
        /// dataCode录入
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel EntryDataCode(EntryDataCodeReq param);
        /// <summary>
        /// 获取跳站原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetMStdReason();
        /// <summary>
        /// getStep
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetToStep(cuGetSetpTypeRsp param);

        /// <summary>
        /// 执行跳站
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel MoveStd(MoevStdReq param);
        /// <summary>
        /// 查询ECNNumber
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetEcnInfo(GetECNInfoReq param);

        /// <summary>
        /// 新增OA预Hold的释放功能
        /// </summary>
        /// <param name="userLoginInfo"></param>
        /// <param name="cuOAFutureHold"></param>
        public IResultModel CuOAFutureHoldRelease(CuOAFutureHoldReleaseReq param);
        /// <summary>
        /// OAECN相关接口
        /// </summary>
        /// <param name="ecnChangeParameter"></param>
        /// <returns></returns>
        public IResultModel SExecutecuEcnFutureHoldMaint(CuEcnChangeParameter ecnChangeParameter);
        /// <summary>
        /// OAECN相关接口
        /// </summary>
        /// <param name="ecnChangeParameter"></param>
        /// <returns></returns>
        public IResultModel SExecuteLotFutureHoldSetup(CuEcnChangeParameter ecnChangeParameter);
        /// <summary>
        /// ERC重分类
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel ERCGradePN(ERCReq param);
        /// <summary>
        /// 获取ERC信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetERCInfo(GetERCInfoReq param);
        /// <summary>
        /// 获取ERCSPec
        /// </summary>
        /// <returns></returns>
        public IResultModel GetErcSpec();
        /// <summary>
        /// ERC获取Model信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetModelInfo(GetModelInfo param);
        /// <summary>
        /// 内外层查询lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LayerGetContainerInfo(CuLayerGetContinerInfoReq param);
        public IResultModel LayerGetEmployeeInfo(GetEmployeeInfo param);
        public IResultModel RequestNextLayerWO(cuLayerReq param);

        //public IResultModel CheckDataCode(string fromt, string Value);
    }
}
