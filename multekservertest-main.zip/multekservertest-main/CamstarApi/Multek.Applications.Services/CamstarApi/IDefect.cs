﻿using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.TRC;
using Multek.Applications.Model.WIPMain;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.CamstarApi
{
    public interface IDefect : IBaseService
    {

        /// <summary>
        /// Camstar发起报废流程请求
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        public IResultModel CuOA_RejectProcess(CuOARejectProcess cuOARejectProcesses);

        /// <summary>
        /// 获取报废信息
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        public IResultModel RefreshDefectInfo(CuOARejectInfo cuOARejectInfo);

        /// <summary>
        /// Camstar提交报废
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        public IResultModel SubmitDefect(CuOARejectInfo cuOARejectInfo);

        /// <summary>
        /// OA返回报废审核结果，执行报废
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        public IResultModel SExcuteRejectToMES(CuOARejectProcessResult cuOARejectProcessResult);

        /// <summary>
        /// 批次关闭
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        public IResultModel LotClose(LotStatusUpdateRsp param);

        /// <summary>
        /// 批次打开
        /// </summary>
        /// <param name="cuOARejectProcesses"></param>
        /// <returns></returns>
        public IResultModel LotOpen(LotStatusUpdateRsp param);

        /// <summary>
        /// Lot信息查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotStatusInfo(GetLotMsgReq param);

        /// <summary>
        /// Lot终止
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotTerminate(LotStatus param);

        /// <summary>
        /// Lot激活
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotUnTerminate(LotStatus param);

        /// <summary>
        /// Lot激活流程信息查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotUnTerminateWorkflow(GetLotMsgReq param);

        /// <summary>
        /// Lot继续
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel cuUnTerminate(LotStatus param);

        /// <summary>
        /// 批次首末检启动
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotFirstInspectStart(LotInspect param);

        /// <summary>
        /// 批次首检
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LotFirstInspect(LotFirstInspect param);

        /// <summary>
        /// 批次末检
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel cuLotLastInspect(LotFirstInspect param);

        /// <summary>
        /// 批次终止原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetTerminateReason();

        /// <summary>
        /// 批次激活原因
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetUnTerminateReason();

        /// <summary>
        /// 外协物料消耗（手工）
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel cuOutsouringConsumedMaterial(cuOutsouringLot param);

        /// <summary>
        /// 查询外协扣料批次信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOutsourcingLot(cuOutsouringLotInfo param);

        /// <summary>
        /// 查询批次首末检任务信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInspectMsg(GetLotInspect param);

        /// <summary>
        /// 查询批次首末检检验历史记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInspectRecord(GetLotInspect param);

        /// <summary>
        /// 查询批次首末检数据采集信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotWipDataName(GetLotInspect param);
    }
}
