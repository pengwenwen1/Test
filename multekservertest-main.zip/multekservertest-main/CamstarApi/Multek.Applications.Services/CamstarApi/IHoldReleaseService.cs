﻿using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.HoldRelease;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.CamstarApi
{
    public interface IHoldReleaseService :IBaseService
    {
        public IResultModel HoldLot(HoldLotInfoRsp param);
        public IResultModel GetHoldReason();
        public IResultModel LotRelease(LotReleaseReq param);
        public IResultModel GetReleaseReason();
        public IResultModel GetHoldReasonPC();
    }
}
