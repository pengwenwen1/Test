﻿using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.SplitAndCombine;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.CamstarApi
{
    public interface ISplitCombine : IBaseService
    {
        public IResultModel Combine(CombineLotReq param);
        public IResultModel GetSplitNewLot(GetLotMsgReq param);
        public IResultModel Split(SplitLotMsgReq param);
        public IResultModel GetSplitReason();
        public IResultModel GetCarrier();
    }
}
