﻿using Microsoft.AspNetCore.Http;
using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Applications.Model.Entities.Dto;
using Multek.Applications.Model.Entities.LotTxn;
using Multek.Applications.Model.Entities.Multek;
using Multek.Applications.Model.Entities.TRC;
using Multek.Library_Core.ResultModel;
using Multek.Library_Core.ServicesInface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Barcode
{
    public interface ILotInfoQuery : IBaseService
    {
        /// <summary>
        /// 按批获取Panel码
        /// </summary>
        /// <param name="getPanelsCodeByLot"></param>
        /// <returns></returns>
        public TrackALLInfo GetLotInfo(string lotName);
        public TrackALLInfo GetLotInfo(GetLotMsgReq PNLInfo);

        public List<TrackALLInfo> GetLotInfo(List<TrackALLInfo> PNLInfo);
        /// <summary>
        /// 返修：获取返修方法
        /// </summary>
        /// <returns></returns>
        public IResultModel GetRepairMethod();

        /// <summary>
        /// 返修：获取返修Lot信息
        /// </summary>
        /// <returns></returns>
        public IResultModel GetReworkLotInfo(SingleLotReq param);

        /// <summary>
        /// 返修：调用LotRework服务
        /// </summary>
        /// <returns></returns>
        public IResultModel CULotRepair(ReworkInfoReq param);

        /// <summary>
        /// 外协发送：获取供应商名字和描述
        /// </summary>
        /// <returns></returns>
        public IResultModel GetVendor(string param);

        /// <summary>
        /// 外协发送：获取外协Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSLotInfo(OSLotReq param);

        /// <summary>
        /// 外协发送：获取外协工序
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSSpecInfo(OSSpecReq param);

        /// <summary>
        ///  外协发送： 根据外协单号获取外协批次信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetLotInfoByOSOrder(string param);

        /// <summary>
        ///  外协发送： 调用cuOutsourcingLotTxn服务
        /// </summary>
        /// <returns></returns>
        public IResultModel CUOutsourcingLotTxn(OSLotSendReq param);

        /// <summary>
        ///  外协取消： 查询外协单号
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSROrder(SingleLotReq param);
        
        /// <summary>
        ///  外协取消： 查询Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSRLotByOrder(SingleLotReq param);

        /// <summary>
        ///  外协取消： 放行Lot
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CUOutSourcingLotRepealTxn(OSRLotRepealReq param);

        /// <summary>
        ///  外协接收： 查询Lot信息  
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetOSRELotInfo(OSRELotReq param);

        /// <summary>
        ///  外协接收：提交服务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CUOSRELotTxn(OSRESubmitReq param);

        /// <summary>
        /// 抽检-手动： 查询Lot信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetLotSamplingTask(STCreateLotReq param);

        /// <summary>
        /// 抽检-手动： 查询抽检种类
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetSamplingCategory(STCreateLotReq param);

        /// <summary>
        /// 抽检-手动： 查询检验矩阵
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetCheckMatrix(STCreateLotReq param);

        /// <summary>
        /// 抽检-手动：提交手动创建的抽检任务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_PostCreateSamplingTask(PostSamplingTask_Req param);

        /// <summary>
        /// 抽检-查询： 查询抽检任务
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_GetSamplingCheckTasks(SamplingCheckTasks_Req param);

        public IResultModel APP_FileUpload(HttpContext param);

        /// <summary>
        /// 抽检-查询：抽检任务提交
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel APP_PostSamplingCheckTask(PostSamplingCheckTask_Req param);

        /// <summary>
        /// 检验：查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadTaskList(LoadTaskListReq param);

        /// <summary>
        /// 检验：送样
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel SendSampling(SendSamplingReq param);

        /// <summary>
        /// 检验：扫描lot获取明细
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadLotDetail(SingleLotReq param);

        /// <summary>
        ///  检验：获取检验项
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel GetCheckItem(string param);

        /// <summary>
        /// 检验：保存结果
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel SaveSamplingTask(SamplingTaskReq param);

        /// <summary>
        /// 获取HOLD原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetHoldReason(string param);

        /// <summary>
        /// 获取检验失败原因
        /// </summary>
        /// <returns></returns>
        public IResultModel GetFailReason(string param);

        /// <summary>
        /// 获取产品
        /// </summary>
        /// <returns></returns>
        public IResultModel GetPN(string param);

        /// <summary>
        /// 获取工序
        /// </summary>
        /// <returns></returns>
        public IResultModel GetSpec(string param);

        /// <summary>
        /// 获取设备
        /// </summary>
        /// <returns></returns>
        public IResultModel GetEqp(string param);

        /// <summary>
        /// 获取检验种类
        /// </summary>
        /// <returns></returns>
        public IResultModel GetSamplingCategory(string param);

        /// <summary>
        /// 获取OEM
        /// </summary>
        /// <returns></returns>
        public IResultModel GetOEM(string param);

        /// <summary>
        /// 获取CEM
        /// </summary>
        /// <returns></returns>
        public IResultModel GetCEM(string param);

        /// <summary>
        /// 获取版样
        /// </summary>
        /// <returns></returns>
        public IResultModel GetProductionType(string param);

        /// <summary>
        ///  检验失败处理：查询
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadTaskListForFail(LoadTaskListForFailReq param);

        /// <summary>
        ///  检验失败处理：提交处理结果
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel SaveSamplingTaskForFail(SamplingTaskForFailReq param);

        /// <summary>
        /// 检验失败处理：扫描Lot校验状态
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel CheckFailLot(string param);

        /// <summary>
        /// 检验失败处理：查看检验明细
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IResultModel LoadTaskList(string param);
    }
}
