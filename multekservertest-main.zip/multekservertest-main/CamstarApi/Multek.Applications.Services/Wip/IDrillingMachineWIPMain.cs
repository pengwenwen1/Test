﻿using Multek.Applications.Model.DrillingMachine;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Wip
{
    public interface IDrillingMachineWIPMain
    {
        /// <summary>
        /// MES过数信息记录
        /// </summary>
        /// <param name="wipCountDto"></param>
        /// <returns></returns>
        public IResultModel MESTransferRecord(WipCountDto wipCountDto);
    }
}
