﻿using Multek.Applications.Model.DrillingMachine;
using Multek.Applications.Model.Entities.Camstar.Dto;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Wip
{
    public interface IWorkFlowMain
    {
        /// <summary>
        /// 工序是否存在
        /// </summary>
        /// <param name="lot"></param>
        /// <param name="spec"></param>
        /// <returns></returns>
        public IResultModel SpecIsExist(LotAndSpecDto lotAndSpecDto);
    }
}
