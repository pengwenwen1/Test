﻿using Multek.Applications.Data.Entities;
using Multek.Applications.Data.Entities.Dto;
using Multek.Library_Core.ResultModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multek.Applications.Services.Auth
{
    public interface IAuth
    {

        /// <summary>
        /// 员工资质验证
        /// </summary>
        /// <param name="verifyOperatorDto"></param>
        /// <returns></returns>
        public IResultModel VerifyOperator1(VerifyOperatorDto verifyOperatorDto);

        /// <summary>
        /// 员工资质验证(根据员工号和密码验证)
        /// </summary>
        /// <param name="verifyDto"></param>
        /// <returns></returns>
        public IResultModel VerifyOperator2(VerifyDto verifyDto);

    }
}
